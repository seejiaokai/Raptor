$ErrorActionPreference='Stop'
$taskRepo='C:\Users\User\projects\Raptor'
$taskProof=Join-Path $taskRepo '.superpowers\discard-review-fixes'
$taskZip=Join-Path $taskRepo 'raptor-port\docs\handpass\2026-10-03-discard-review-fixes-evidence.zip'
$taskFiles=[System.Collections.Generic.List[string]]::new()
Get-ChildItem -LiteralPath $taskProof -Recurse -File | ForEach-Object { $taskFiles.Add($_.FullName) }
$taskFinal=Get-Content -Raw -LiteralPath (Join-Path $taskProof 'after.json') | ConvertFrom-Json
foreach($taskRow in $taskFinal){$taskFiles.Add((Join-Path $taskRepo $taskRow.path))}
Get-ChildItem -LiteralPath (Join-Path $taskRepo 'raptor-port\dist') -Recurse -File | ForEach-Object { $taskFiles.Add($_.FullName) }
Add-Type -AssemblyName System.IO.Compression
$taskOutput=[IO.File]::Open($taskZip,[IO.FileMode]::Create)
$taskArchive=[IO.Compression.ZipArchive]::new($taskOutput,[IO.Compression.ZipArchiveMode]::Create)
try {
 foreach($taskFile in ($taskFiles | Sort-Object -Unique)){
  $taskRel=$taskFile.Substring($taskRepo.Length+1).Replace('\','/')
  $taskEntry=$taskArchive.CreateEntry($taskRel,[IO.Compression.CompressionLevel]::Optimal)
  $taskStream=$taskEntry.Open();$taskInput=[IO.File]::OpenRead($taskFile)
  try {$taskInput.CopyTo($taskStream)} finally {$taskInput.Dispose();$taskStream.Dispose()}
 }
} finally {$taskArchive.Dispose();$taskOutput.Dispose()}
[pscustomobject]@{bytes=(Get-Item -LiteralPath $taskZip).Length;sha256=(Get-FileHash -LiteralPath $taskZip).Hash} | ConvertTo-Json -Compress
