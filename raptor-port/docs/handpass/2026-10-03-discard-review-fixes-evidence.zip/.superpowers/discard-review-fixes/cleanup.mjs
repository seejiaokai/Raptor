import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs'
import {dirname} from 'node:path'
import {createHash} from 'node:crypto'
import {spawnSync} from 'node:child_process'
const root='C:/Users/User/projects/Raptor',proof=root+'/.superpowers/discard-review-fixes'
const source='raptor-port/src/state/sched-commit.ts'
const scripts=['am/w1-s33-reorder.mjs','am/w1-s02-discard.mjs','am/hr-01-fixes.mjs','dp-walk.mjs','cr-a1-pub.mjs','dbrA-W1-c.mjs'].map(p=>'raptor-port/scripts/handpass/'+p)
const comment='// Retired with the Discard marks button (D488); kept as historical walk evidence.'
const hash=b=>createHash('sha256').update(b).digest('hex')
const phase=process.argv[2]
if(phase==='before'){
  const records=[]
  for(const p of [source,...scripts]){
    const b=readFileSync(root+'/'+p),out=proof+'/before/'+p
    if(existsSync(out))throw Error('Refusing to overwrite original '+p)
    mkdirSync(dirname(out),{recursive:true});writeFileSync(out,b)
    records.push({path:p,sha256:hash(b),contract:p===source?'unused logAction occurrence count '+(b.toString().match(/\blogAction\b/g)||[]).length:'retirement head missing: '+!b.toString().startsWith(comment)})
  }
  writeFileSync(proof+'/before.json',JSON.stringify(records,null,2));console.log(JSON.stringify(records,null,2))
}else if(phase==='comments'){
  for(const p of scripts){const b=readFileSync(root+'/'+p);if(b.toString().startsWith(comment))throw Error('Already marked '+p);writeFileSync(root+'/'+p,Buffer.concat([Buffer.from(comment+(b.includes(Buffer.from('\r\n'))?'\r\n':'\n')),b]))}
}else if(phase==='after'){
  const records=[]
  for(const p of [source,...scripts]){
    const b=readFileSync(root+'/'+p),old=readFileSync(proof+'/before/'+p)
    const expected=p===source?Buffer.from(old.toString().replace(/^import \{ logAction \} from '\.\.\/engine\/editlog'\r?\n/m,'')):Buffer.concat([Buffer.from(comment+(old.includes(Buffer.from('\r\n'))?'\r\n':'\n')),old])
    if(!b.equals(expected))throw Error('Unexpected byte change '+p)
    if(p!==source){const c=spawnSync('node',['--check',root+'/'+p],{encoding:'utf8'});if(c.status!==0)throw Error(c.stderr)}
    records.push({path:p,sha256:hash(b),result:p===source?'only unused import removed':'one head comment; original body byte-identical; node --check PASS'})
  }
  writeFileSync(proof+'/after.json',JSON.stringify(records,null,2));console.log(JSON.stringify(records,null,2))
}else throw Error('Expected before/comments/after')
