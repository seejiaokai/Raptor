$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:\Users\User\projects\Raptor\raptor-port'
$taskGateRoot='C:\Users\User\projects\Raptor\.superpowers\discard-review-fixes'
$env:E2E_PORT='4243'
$env:PORT_URL='http://localhost:4243/'
node scripts/gatelock.mjs take 'codex/discard-marks-remove — seven-line review cleanup gates'
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$taskGateResults=[System.Collections.Generic.List[object]]::new()
try {
 foreach($taskGate in @(
  @{name='unit';exe='npm.cmd';args=@('test')},
  @{name='build';exe='npm.cmd';args=@('run','build')},
  @{name='tfin';exe='node';args=@('reference/tfin.js')},
  @{name='e2e';exe='npm.cmd';args=@('run','test:e2e')},
  @{name='tracker';exe='npm.cmd';args=@('run','smoke:tracker')},
  @{name='rulecheck';exe='npm.cmd';args=@('run','rulecheck')},
  @{name='docsize';exe='npm.cmd';args=@('run','docsize')}
 )) {
  $taskExecutable=$taskGate.exe; $taskArguments=$taskGate.args
  & $taskExecutable @taskArguments *> (Join-Path $taskGateRoot ('gate-'+$taskGate.name+'.log'))
  $taskGateCode=$LASTEXITCODE
  $taskGateResults.Add([pscustomobject]@{gate=$taskGate.name;exitCode=$taskGateCode})
  Write-Output ($taskGate.name+' exit '+$taskGateCode)
 }
 $taskGateResults | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskGateRoot 'gates.json') -Encoding utf8
} finally { node scripts/gatelock.mjs release }
if(@($taskGateResults | Where-Object { $_.exitCode -ne 0 }).Count -gt 0){exit 1}
