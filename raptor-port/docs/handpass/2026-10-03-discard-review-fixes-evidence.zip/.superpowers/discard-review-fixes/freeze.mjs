import {readFileSync,writeFileSync,readdirSync,statSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {spawnSync} from 'node:child_process'
const root='C:/Users/User/projects/Raptor',proof=root+'/.superpowers/discard-review-fixes'
const hash=b=>createHash('sha256').update(b).digest('hex')
const files=JSON.parse(readFileSync(proof+'/after.json','utf8')).sort((a,b)=>a.path.localeCompare(b.path)).map(({path})=>({path,sha256:hash(readFileSync(root+'/'+path))}))
const sourceHash=hash(files.map(f=>f.path+' '+f.sha256).join('\n'))
if(sourceHash!=='771cfc7f80361ff2858889382a50670a29c76b02c7ce65c9f5d2ee6032da70c9')throw Error('Independent source snapshot drift')
const walk=p=>readdirSync(p).flatMap(n=>{const q=p+'/'+n;return statSync(q).isDirectory()?walk(q):[q]})
const bundle=walk(root+'/raptor-port/dist').map(p=>({path:p.slice(root.length+1),sha256:hash(readFileSync(p))}))
const diff=spawnSync('git',['diff','--binary','HEAD','--','raptor-port/src','raptor-port/scripts/handpass'],{cwd:root,encoding:'utf8'})
if(diff.status!==0)throw Error(diff.stderr)
writeFileSync(proof+'/source.patch',diff.stdout)
writeFileSync(proof+'/fingerprints.json',JSON.stringify({base:'3e0970259cd5b6564c53dddc448d210c2dc1ae3d',branch:'codex/discard-marks-remove',sourceHash,sourceAlgorithm:'path-sorted LF-joined path lowercase-file-sha256, no trailing newline',files,bundleHash:hash(JSON.stringify(bundle)),bundle},null,2))
console.log(JSON.stringify({sourceHash,bundleHash:hash(JSON.stringify(bundle)),bundle:bundle.length}))
