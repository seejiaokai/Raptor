/* [ARCH-STACK] Step 2 — the DERIVED record registry (design §3.1).

   The registry is DERIVED FROM CODE, not hand-listed (Codex R4-004 / Fable
   R4-4): every sSet/persist()/store.set key builder is classified as one of
   - RECORD          — a durable logical record; every write yields a Change
   - BOOT_MIGRATION  — seed origin, exempt (migration flags, seedstamp)
   - VIEW_PREFERENCE — exempt but listed (Tracker kLast/kLastStudent, LW current)

   Completeness is proven by RECONSTRUCTING the persisted state from the
   envelope stream and comparing it to the legacy serializer — NOT "≥1 Change",
   which misses an omitted field (e.g. SCHED.changes). This table is the map
   from logical collection to the physical blob that owns it (LOGICAL_TO_BLOB),
   used by the Step-5 fold subscriber (defined, activated later — design §4).
   BUILT 30 Sep 26 ([DB-READINESS] group A, phase 0): the fold subscriber is the stream consumer in
   state/rowmap.ts — it maps each change to the stored ROW it lives in through per-collection mappers,
   not through this blob table; the table's stale entries (leavewar/balances, leavewar/config, lw.bid)
   were corrected as group A's phases 1–3 moved each collection to rows (plan §2.9) — the Leave War's
   in phase 3, whose rows its own store writes through its own door (leavewar/state/rows.ts).
*/
import type { LogicalCollection } from './types'

/* logical collection -> the physical storage blob that owns it. Several logical
   records can share one blob; the fold subscriber (Step 5) groups changes by
   blob, re-serializes each once. */
export const LOGICAL_TO_BLOB: Record<LogicalCollection, string> = {
  // scheduler — every record is one row of the weeks collection: a day row, the week row, an issuance or a
  // retraction row ([DB-READINESS] group A, phase 1 — state/weekrows.ts, state/rowmap.ts)
  'days': 'weeks',
  'sched.book': 'weeks',
  'sched.mutes': 'weeks',
  'sched.week': 'weeks',
  'sched.issuance': 'weeks',
  'sched.retraction': 'weeks',
  // inputs / plan / people
  'inputs': 'inputs',
  'plan': 'plan',
  'people': 'people',
  // settings — one blob per key
  'settings': 'settings',
  'insights.role': 'settings',
  // off-week session memory — stored per week under the weeks blob ([CMDL-FINISH] §6)
  'weekstash': 'weeks',
  // leave war — one row per record in the war's own collection ([DB-READINESS] group A, phase 3 —
  // leavewar/state/rows.ts): a war `war:<id>`, each record at an address `rec:<war>:<id>`, a ledger entry
  // `ledger:<id>`, an opening `opening:<pid>:<counter>`, a man's window and label together `profile:<pid>`; the
  // policy, the war on screen and each ⚙ setting its own key
  'lw.cell': 'leavewar',
  'lw.war': 'leavewar',
  'lw.ledger': 'leavewar',
  'lw.opening': 'leavewar',
  'lw.oilpolicy': 'leavewar',
  'lw.postouts': 'leavewar',
  'lw.label': 'leavewar',
  'lw.current': 'leavewar',
  'lw.config': 'leavewar',
  // tracker (the v3: keys)
  'trk.marks': 'tracker/marks',
  'trk.dates': 'tracker/dates',
  'trk.roster': 'tracker/roster',
  'trk.layout': 'tracker/layout',
  'trk.syls': 'tracker/syls',
  'trk.plan': 'tracker/plan',
  'trk.pace': 'tracker/pace',
  'trk.lulls': 'tracker/lulls',
  'trk.eventinfo': 'tracker/eventinfo',
  'trk.catalogue': 'tracker/catalogue',
  'trk.courses': 'tracker/courses',
}

export type RegistryClass = 'record' | 'boot-migration' | 'view-preference'

/* An entry in the derived registry. `key` is the code-level storage key builder
   or hydration key (as a stable string or a documented pattern); `collection`
   is its logical collection when it is a record. As each module is adopted
   (phases 2-5) it registers its writers here; the completeness test
   (reconstruct-and-compare) is what actually proves nothing was missed. */
export interface RegistryEntry {
  key: string
  cls: RegistryClass
  collection?: LogicalCollection
  module: string
  note?: string
}

const ENTRIES: RegistryEntry[] = []

export function registerRecord(e: RegistryEntry): void {
  /* a record entry MUST name its logical collection */
  if (e.cls === 'record' && !e.collection) {
    throw new Error(`registry: record ${e.key} must name a collection`)
  }
  const dup = ENTRIES.find(x => x.key === e.key)
  if (dup) {
    /* re-registering the same key with the same classification is idempotent
       (module hot-reload / repeated boot in tests); a CONFLICTING re-register
       is a bug worth surfacing. */
    if (dup.cls !== e.cls || dup.collection !== e.collection) {
      throw new Error(`registry: conflicting re-register of ${e.key}`)
    }
    return
  }
  ENTRIES.push(e)
}

export function registryEntries(): readonly RegistryEntry[] {
  return ENTRIES
}
export function recordEntries(): RegistryEntry[] {
  return ENTRIES.filter(e => e.cls === 'record')
}
/* test-only: clear the registry between suites */
export function _resetRegistry(): void {
  ENTRIES.length = 0
}
