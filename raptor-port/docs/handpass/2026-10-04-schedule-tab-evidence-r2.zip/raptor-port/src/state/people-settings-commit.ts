/* [ARCH-STACK] Step 2 phase 3 — routing PEOPLE + VCONF + the full SETTINGS
   inventory through the command gate (design §5.2, §8 item 3). ADDITIVE: the
   in-place people/settings writers run UNCHANGED; this only ADDS the auth gate +
   the record-level change stream around them, at the ONE persist seam each
   module already funnels through — so the ~30 UI call sites are untouched and no
   durable write can bypass the layer (the design's "forbid the raw settingsAdapter
   back door", enforced structurally rather than site-by-site). The legacy persist
   seams (the settingsAdapter store.set; persistPeople) are LEFT RUNNING — no
   cutover (Steps 3/5).

   TWO EnlistableStores, each keyed onto its module's persisted representation:

   - SETTINGS is ONE store over the 11 durable keys. Every settings writer ends in
     `store.set(key, …)`; engine/hooks.ts now routes that through an injected
     write hook (installed below) which, outside a running command, opens a named
     `settings.<key>` command that enlists the settings store and does the raw
     write. The store's records()/capture() read the PERSISTED value (store.get) —
     which is exactly the record source — so a command's before-image is the old
     persisted value and its after-image the new one; rollback writes the snapshot
     back AND re-runs every xLoad() to rebuild the module CFGs (correct even for a
     throw between a mutation and its save, since the mutators don't save
     internally and xLoad re-derives the CFG from the unchanged store).

   - PEOPLE is ONE store over the roster. Every people writer ends in
     persistPeople(); the wrapped persistPeople below opens a `people.edit` command
     that enlists the people store and does the raw persist. The store's
     records()/capture() read a module-level BASELINE string (the last-persisted
     roster), NOT the live PEOPLE object — because PEOPLE is mutated in place
     BEFORE persistPeople is called, so reading live PEOPLE as the before-image
     would show no diff. persistPeople updates the baseline inside the command, so
     the before-image is the pre-edit roster and the after-image the post-edit one;
     rollback rebuilds PEOPLE (and its ID_BY_CS index) from the snapshot.

   Permissions are PERMISSIVE (anyone) at Step 2, exactly as the scheduler phases:
   the real gates (the admin-only Admin/Quals pages at the write path) are
   UNCHANGED and authoritative, so a tighter command permission here could only ADD
   a refusal and regress a legitimate write. Each type is still EXPLICITLY
   registered (the registry refuses an unregistered type). Real auth is Step 5. */
import type { EnlistableStore, RecordEntry, Scope, CommitResult, Command } from '../command'
import {
  commit, commitProjection, isCommitting, definePermission, anyone, registerRecord, registerGuardedStore,
  cmdDeferEffect,
} from '../command'
import { PEOPLE, indexCallsigns } from '../engine/people'
import { store, setSettingsWriteHook, setSettingsGroupHook, HOOKS } from '../engine/hooks'
import { rulesLoad, rulesResetMem } from '../engine/rules'
import { lookaheadLoad } from '../engine/lookahead'
import { qualColsLoad } from '../engine/qualcols'
import {
  storesLoad, cxReasonsLoad, dutyTplLoad, waveTplLoad, dayTplLoad,
  secDefaultLoad, waveDefaultLoad,
} from '../engine'
import { mintOrd, byOrd } from '../command/ord'
import { accountsLoad, ACCOUNT_TYPES } from './accounts'
import { changesLoad, CHANGES_TYPES } from './changes'
import { insightsLoad } from '../engine/insights-config'

/* ---- the SETTINGS EnlistableStore ---------------------------------------- */
/* the 11 durable settings keys (design §3.1). `wavetpl` + `wavehide` are two
   records written by one save (waveTplSave, two store.set calls) and rebuilt by
   one load (waveTplLoad). */
export const SETTINGS_KEYS = [
  'rules', 'stores', 'cxreasons', 'daytpl', 'dutytpl', 'wavetpl', 'wavehide',
  'qualcols', 'lookahead', 'secdefault', 'wavedefault',
  /* [ACCOUNTS] (D166, D204, 26 Sep 26): the guest switch — one `Setting` (data-model §3, §11). Written ONLY by
     state/accounts.ts, through its intent commands. */
  'guestview', 'insights',
] as const
/* THE SETTINGS RECORDS KEPT ONE ROW PER THING ([DB-READINESS] group A, phase 4 — plan §2.5's matrix, §2.9: the command
   layer's records follow the storage grain). Each row is its own record, `settings/<prefix><id>`, found by its prefix:
   - `account:<id>`, `accessreq:<id>`, `reqseen:<accountId>` — the Shell's `User`, `AccessRequest` and
     `AccessRequestSeen` (they were the whole-list `accounts` and `accessreqs`); written ONLY by state/accounts.ts,
     through its intent commands ([ACCOUNTS], D166, D204);
   - `seen:<pid>` — each person's own "seen" for the change history, `EditLogSeen` (it was the shared `changeseen`);
     written ONLY by state/changes.ts, through its one command `changes.seen` (own row only — D170).
   The change history's own lines (`elog:<lineId>`) are NOT records here: written raw by engine/editlog.ts inside the
   command that made them, never undone (the log is not in any Undo). */
export const SETTINGS_ROW_PREFIXES = ['account:', 'accessreq:', 'reqseen:', 'seen:'] as const
const isRowKey = (k: string) => SETTINGS_ROW_PREFIXES.some(p => k.startsWith(p))
/* every row stored now — ONE pass over the settings keys (the guard reads this on every command, so never one per kind) */
const settingsRowKeys = (): string[] => store.keys('').filter(isRowKey)
/* every settings record's key: the fixed ones, then each row stored now */
function settingsRecordKeys(): string[] {
  return [...SETTINGS_KEYS, ...settingsRowKeys()]
}
/* every xLoad(), run to rebuild the module CFGs from the (restored) store on a
   rollback — deduped (waveTplLoad rebuilds both wavetpl + wavehide). */
const SETTINGS_LOADERS: Array<() => void> = [
  rulesLoad, storesLoad, cxReasonsLoad, dayTplLoad, dutyTplLoad, waveTplLoad,
  qualColsLoad, lookaheadLoad, secDefaultLoad, waveDefaultLoad, accountsLoad, changesLoad, insightsLoad,
]
function settingsRecords(): Map<string, RecordEntry> {
  const m = new Map<string, RecordEntry>()
  for (const k of SETTINGS_KEYS) {
    m.set(`settings/${k}`, { collection: 'settings', id: k, value: store.get(k, null) })
  }
  /* a row is a record while it is stored; absent, it is no record (so adding one is a put, removing it a delete) */
  for (const k of settingsRowKeys()) m.set(`settings/${k}`, { collection: 'settings', id: k, value: store.get(k, null) })
  return m
}
function captureSettings(): string {
  const o: Record<string, unknown> = {}
  for (const k of settingsRecordKeys()) o[k] = store.get(k, null)
  return JSON.stringify(o)
}
/* [CMDL-FINISH] R3-001 — the side-effect-free RESET-then-overlay rehydrator,
   shared by restore() and write(). rulesLoad only OVERLAYS overrides, so a plain
   loader pass would leave a dropped override live when an OLDER/smaller rules
   record is restored (or `rules` is deleted). Reset VCONF/SHIFT_HARD to the
   squadron standard IN MEMORY first (rulesResetMem — no storage write), THEN run
   every loader (each of the other nine already reset-then-overlays from a module
   constant, so re-running them is a full re-derive). The store is ALREADY at the
   target values here, so the loaders read the restored records. */
function rehydrateSettings(): void {
  rulesResetMem()
  for (const load of SETTINGS_LOADERS) load()
}
/* rollback: restore each key's persisted value, then the reset-then-overlay
   re-derive. Writes go through the raw setter (the hook is inert while
   committing) so nothing nests. */
function restoreSettings(snap: string): void {
  const o = JSON.parse(snap)
  for (const k of SETTINGS_KEYS) store.set(k, k in o ? o[k] : null)
  /* the rows: every one the snapshot held, back as it was; every one written since, removed */
  for (const k of settingsRowKeys()) if (!(k in o)) store.set(k, null)
  for (const k of Object.keys(o)) if (isRowKey(k)) store.set(k, o[k])
  rehydrateSettings()
}
export const settingsStore: EnlistableStore = {
  key: 'settings',
  capture: captureSettings,
  restore: (snap) => restoreSettings(snap as string),
  records: settingsRecords,
  signature: captureSettings,
  /* [CMDL-FINISH] §3 — batch record write for the undo seam. store.set is the
     record source AND the persist (the hook writes raw while committing, so
     nothing nests); a `delete` clears the key to null (records() reads
     get(k,null), so absent === null). One reset-then-overlay re-derive after ALL
     entries, then a boundary-deferred re-validate + repaint (a restored `rules`
     record changed the thresholds the warnings ride on). */
  write(entries: RecordEntry[]): void {
    for (const e of entries) {
      if (e.op === 'delete') store.set(e.id, null)
      else store.set(e.id, e.value)
    }
    rehydrateSettings()
    // HOOKS.reflow = validate() + notify(), released at the transaction boundary
    // (a restored `rules` record changed the thresholds the warnings ride on).
    cmdDeferEffect(HOOKS.reflow)
  },
}

/* ---- the PEOPLE EnlistableStore ------------------------------------------ */
/* the last-persisted roster, the record source (see the header). Initialised at
   registration; advanced inside each people command; snapshot on rollback. */
let PEOPLE_BASELINE: string | null = null
function baseline(): string { return PEOPLE_BASELINE ?? JSON.stringify(PEOPLE) }
function peopleRecords(): Map<string, RecordEntry> {
  const m = new Map<string, RecordEntry>()
  const roster = JSON.parse(baseline())
  for (const id of Object.keys(roster)) {
    m.set(`people/${id}`, { collection: 'people', id, value: roster[id] })
  }
  return m
}
/* rebuild PEOPLE + its callsign index from a snapshot, exactly as persist.ts's
   hydrate does (a stored callsign must resolve after a restore). */
function restorePeople(snap: string): void {
  PEOPLE_BASELINE = snap
  const obj = JSON.parse(snap)
  for (const k of Object.keys(PEOPLE)) delete (PEOPLE as any)[k]
  Object.assign(PEOPLE, obj)
  indexCallsigns()
}
/* THE ROSTER'S ORDER, ON EACH PERSON ([DB-READINESS] group A, phase 2 — plan §2.3): once each person is one stored row,
   the roster's order (the key order 27 readers iterate) is each person's own `ord`. Minted at every roster command's
   finish for a person who needs one — a new person takes 1024 below/above/between his neighbours, nobody else is
   touched; the placeholder pucks (ALL, ALL AVAIL) are code and carry none. */
const isPlaceholderBody = (id: string) => id === 'all' || id === 'allavail' || !!((PEOPLE as any)[id] && (PEOPLE as any)[id].special)
export function mintPeopleOrd(): void {
  const ids = Object.keys(PEOPLE).filter(id => !isPlaceholderBody(id))
  const rows = ids.map(id => (PEOPLE as any)[id])
  const pidOf = new Map(rows.map((p: any, i: number) => [p, ids[i]]))
  mintOrd(rows, (p: any) => pidOf.get(p)!)
}
/* put the roster back in its order after a restore: every person by (ord, id), the placeholders last — so an Undo that
   brings a person back puts him back where he stood, not at the end */
function reorderPeople(): void {
  const cmp = byOrd((row: any) => row.__pid)
  const ids = Object.keys(PEOPLE).filter(id => !isPlaceholderBody(id))
    .sort((a, b) => cmp({ ord: (PEOPLE as any)[a]?.ord, __pid: a }, { ord: (PEOPLE as any)[b]?.ord, __pid: b }))
  const keep = [...ids, ...Object.keys(PEOPLE).filter(isPlaceholderBody)].map(id => [id, (PEOPLE as any)[id]] as [string, any])
  for (const k of Object.keys(PEOPLE)) delete (PEOPLE as any)[k]
  for (const [id, p] of keep) (PEOPLE as any)[id] = p
}
/* rebuild ID_BY_CS from the whole live PEOPLE (a delete must drop the old cs
   mapping, so a touched-ids-only pass would leave a stale entry — full rebuild is
   the same work restorePeople does). The ONE index body — the roster and the
   placeholders only ([POST-OUT-OUTCOMES], D286: an archived man's callsign is free). */
const rebuildIdByCs = indexCallsigns
export const peopleStore: EnlistableStore = {
  key: 'people',
  capture: () => baseline(),
  restore: (snap) => restorePeople(snap as string),
  records: peopleRecords,
  signature: () => baseline(),
  /* [CMDL-FINISH] §3 — batch record write for the undo seam. Apply every
     people/<id> into PEOPLE (delete removes it), put the roster back in its order,
     rebuild the callsign index once and advance the baseline in the apply. Each
     restored person's row is written from this command's own change (the stream
     consumer, state/rowmap.ts — [DB-READINESS] group A, phase 2). */
  write(entries: RecordEntry[]): void {
    for (const e of entries) {
      // [GLOBAL-UNDO] GU2-009 — clone-on-write: never alias the undo entry's recorded
      // image with the live roster record, or a later in-place edit would corrupt it.
      if (e.op === 'delete') delete (PEOPLE as any)[e.id]
      else (PEOPLE as any)[e.id] = e.value == null ? e.value : JSON.parse(JSON.stringify(e.value))
    }
    reorderPeople()
    rebuildIdByCs()
    PEOPLE_BASELINE = JSON.stringify(PEOPLE)
    cmdDeferEffect(HOOKS.reflow)       // re-validate + repaint (roster feeds the warnings)
  },
}

/* ---- command types + the commit helpers ---------------------------------- */
export const PEOPLE_TYPES = { edit: 'people.edit' } as const
const settingsType = (k: string) => `settings.${k}`

const peopleScope = (): Scope => ({ module: 'people' })
const settingsScope = (): Scope => ({ module: 'settings' })

function commitSettings(type: string, fn: () => void): CommitResult {
  const cmd: Command = { type, scope: settingsScope(), apply: (txn) => { txn.enlist(settingsStore); fn() } }
  return commit(cmd)
}
/* `fn` receives the transaction ([ONE-DOOR], D308): a new person's post-in date is written on the war INSIDE the same
   command (HOOKS.warPostIn enlists the war's store), so the person and his war record commit or roll back together */
function commitPeople(type: string, fn: (txn: any) => void, meta?: any): CommitResult {
  const cmd: Command = { type, scope: peopleScope(), meta, apply: (txn) => { txn.enlist(peopleStore); fn(txn) } }
  return commit(cmd)
}
/* [ACCOUNTS] — ONE intent command over the settings store (Astra R2-3, Fable R2-3): an
   account change that touches two keys (approve = a new account AND the request
   cleared) writes both inside this one command, so they commit or roll back together.
   `fn` writes through store.set, which writes raw while a command is running. `meta`
   carries what the gate reads (perms.ts cmdAuthorize: meta.owner for a pending
   person's own request). */
export function commitSettingsIntent(type: string, meta: any, fn: () => void): CommitResult {
  const cmd: Command = { type, scope: settingsScope(), meta, apply: (txn) => { txn.enlist(settingsStore); fn() } }
  return commit(cmd)
}
/* [ACCOUNTS-NEW-PERSON] (D214, D217) — a NAMED people intent (`person.add`: Person C, never
   `people.edit`'s Person U — Astra's plan read 3), and the ONE command that makes a person
   and his account together (`account.addNew`, `access.approveNew`): it enlists BOTH stores,
   so a refusal or a throw anywhere inside restores both — the person, the callsign index,
   the people baseline and every settings key (command/commit.ts phase 6). Both finish the
   people half with the same body every roster command uses (advancePeople). */
export function commitPeopleIntent(type: string, meta: any, fn: (txn: any) => void): CommitResult {
  return commitPeople(type, txn => { fn(txn); advancePeople() }, meta)
}
export function commitPeopleSettingsIntent(type: string, meta: any, fn: (txn: any) => void): CommitResult {
  const cmd: Command = {
    type, scope: peopleScope(), meta,
    apply: (txn) => { txn.enlist(peopleStore); txn.enlist(settingsStore); fn(txn); advancePeople() },
  }
  return commit(cmd)
}
function commitPeopleProjectionCmd(type: string, fn: () => void): CommitResult {
  const cmd: Command = { type, scope: peopleScope(), apply: (txn) => { txn.enlist(peopleStore); fn() } }
  return commitProjection(cmd)
}
/* every roster command's finish — and so the one place the callsign index follows an archive, a restore, a rename, an
   add, the posting pass or a delete ([POST-OUT-OUTCOMES], D286: who is ON the roster decides what a typed callsign
   means, so it is re-read after every change to the roster) */
/* …and it saves nothing itself: each changed person's row is written from the command's own change (the stream
   consumer — [DB-READINESS] group A, phase 2); a new person first takes his place in the roster's order (mintPeopleOrd) */
const advancePeople = () => { mintPeopleOrd(); indexCallsigns(); PEOPLE_BASELINE = JSON.stringify(PEOPLE) }
/* the same finish for a command that enlists the people store beside others (state/person-delete.ts — a delete writes
   people, accounts, the schedule and the stash in ONE command) */
export const finishPeopleWrite = () => advancePeople()

/* [CMDL-FINISH] C10 — a durable roster write, ALWAYS through a command (never the
   old raw branch). A raw persist while a command is in flight changes PEOPLE
   WITHOUT enlisting peopleStore, and now that peopleStore is a guarded store the
   whole-world guard rolls that commit back. Routed: nested in a reducer it
   child-joins the parent; at phase 8 it enqueues; at idle it runs immediately. */
export function persistPeople(): void {
  commitPeople(PEOPLE_TYPES.edit, advancePeople)
}
/* the RECONCILER (auto-archive) people write — a causally-chained PROJECTION, not
   a stray `user` envelope (C10): raised at phase 8 by a reconcile it enqueues with
   the triggering command's seq as its cause. */
export function persistPeopleProjection(): void {
  commitPeopleProjectionCmd(PEOPLE_TYPES.edit, advancePeople)
}
/* wrap a user roster action (its mutations + the persist) in ONE command so a
   cross-seam gesture is a SINGLE envelope — restoreArchivedPerson's setPostOut
   (LW, child-joins) + archived flip + persist (C10). */
export function commitPeopleEdit(fn: () => void, meta?: any): CommitResult {
  return commitPeople(PEOPLE_TYPES.edit, () => { fn(); advancePeople() }, meta)
}

/* ---- one-time registration (called from initStore, after the scheduler) --- */
let registered = false
export function registerPeopleSettingsCommandLayer(): void {
  if (registered) return
  registered = true
  PEOPLE_BASELINE = JSON.stringify(PEOPLE)   // the seed/hydrated roster is the first baseline
  definePermission(PEOPLE_TYPES.edit, anyone)
  for (const k of SETTINGS_KEYS) definePermission(settingsType(k), anyone)
  /* the account intents; `anyone` only DECLARES them — their authority is perms.ts
     COMMAND_OPS through the resolver store.ts wireStore installs */
  for (const t of ACCOUNT_TYPES) definePermission(t, anyone)
  for (const t of CHANGES_TYPES) definePermission(t, anyone)
  registerGuardedStore(peopleStore)
  registerGuardedStore(settingsStore)
  // route every durable settings write (store.set) through a named command.
  // Inside a running command (a rollback, or a save nested in another command)
  // or for an unknown key, write raw so nothing nests or is refused-and-lost.
  setSettingsWriteHook((k, v, raw) => {
    if (k.startsWith('missionrole:')) throw new Error('Mission-role rows require the typed annotation command')
    if (isCommitting() || !(SETTINGS_KEYS as readonly string[]).includes(k)) { raw(k, v); return }
    commitSettings(settingsType(k), () => raw(k, v))
  })
  // a save that writes several keys (store.group) is ONE command, named for its first key; inside a running command the
  // body just runs (every store.set in it then writes raw)
  setSettingsGroupHook((name, fn) => {
    if (isCommitting()) { fn(); return }
    commitSettings(settingsType(name), fn)
  })
  // the derived registry entries (§3.1)
  registerRecord({ key: 'people:<personId>', cls: 'record', collection: 'people', module: 'people' })
  for (const k of SETTINGS_KEYS) {
    registerRecord({ key: `settings:${k}`, cls: 'record', collection: 'settings', module: 'settings' })
  }
  /* the rows kept one per thing ([DB-READINESS] group A, phase 4) — one registry entry per kind */
  for (const p of SETTINGS_ROW_PREFIXES) {
    registerRecord({ key: `settings:${p}<id>`, cls: 'record', collection: 'settings', module: 'settings' })
  }
}

/* re-sync the people baseline to the CURRENT PEOPLE. MUST run after any path that
   replaces the roster out-of-band — above all persist.ts hydrate() at boot, which
   rewrites PEOPLE in place with the STORED roster AFTER this module's registration
   captured the seed at import time (Fable-5). Without this the first post-boot
   people command's before-image is the seed, so it emits a bogus diff for every
   edited person, and a rollback would rebuild PEOPLE from the seed and the next
   persistAll would write that seed to storage — losing every roster edit.
   initStore() calls this after hydrate; a unit test that restores the roster calls
   it too. persistPeople keeps the baseline live thereafter. Every person takes his
   place in the roster's order first ([DB-READINESS] group A, phase 2), so the
   baseline is the roster as the app holds it. */
export function resyncPeopleBaseline(): void { mintPeopleOrd(); PEOPLE_BASELINE = JSON.stringify(PEOPLE) }
