/* [GLOBAL-UNDO] §13 phase 2 — the LIVE cutover wiring (design §8/§9, plan Rev 3
   step 7 / "2.3 remaining").

   This is the ONE place the global undo timeline is turned on in production: it
   installs the stream subscriber, registers the three real stores against the
   collections they own, declares the cut-over module set, and supplies the app
   hooks the engine calls during a restore (view-snap, bubble, locks, publish-day
   resolve, the per-entry publish adjustment). Until this runs, `cutover` is empty
   and globalUndo/globalRedo are no-ops — the engine records but drives nothing.

   Called once from main.tsx after both history baselines are taken (histInit /
   lwHistInit) and before the probe bridge. Kept OUT of main.tsx itself so the
   whole cutover — every hook and every registration — reads in one file, and so
   the button retarget (§9) imports the same helpers.

   Ordinary TS/React-layer style (new file). */
import { logReversed } from './changelines'
import { roleStore, invalidateRoleTargets } from './mission-roles'
import { decodeRoleId } from '../engine/mission-role'
import { peopleStore, settingsStore } from './people-settings-commit'
import { rosterRestoreProblem } from './roster-restore'
import { seedAccounts } from './accounts'
import { deletedRestoreProblem } from './person-delete'
import {
  installUndo, registerUndoStore, setCutoverModules, setUndoHooks, setDescribeNames,
} from '../undo'
import type { RecordCtx, UndoEntry } from '../undo/types'
import type { Change } from '../command'
import { weekOf, dayKeyOf } from '../undo/derive'
import { schedStore, schedPostRestore } from './sched-commit'
import { weekstashStore, loadWeek } from './store'
import { HIST } from './history'
import { armDrop, prunePreviews, SBDAY, CURPAGE, setPage, setBoardDay, focusQualsRow, requestAdminUsers, setSecDefOffer, setInpView } from './view'
import { canEditSched } from './auth'
import { bringDayIntoView } from '../ui/highlights'
import { boardTab } from '../ui/board'
import { toast } from '../ui/toast'
import { CURWEEK } from '../engine/waves'
import { PEOPLE } from '../engine/people'
import { parseVerId, dayIso } from '../engine/verid'
import { lwStore, LW_COLLS, selectWar, focusDay, bumpLwHistEpoch, restoreBlocker } from '../leavewar/state/store'
import { restoreAbsencesOf } from '../leavewar/sync'
import { warVisible } from '../leavewar/absences'
import { DATES, inputCoversDate } from '../engine/inputs'

/* the 8 collections schedStore owns (the scheduler week + inputs + plan). NOT
   `weekstash` — that is the separate weekstashStore's one collection, registered
   below, so an off-week undo routes through its CURWEEK-guarded write() seam. */
const SCHED_COLLS = ['days', 'sched.book', 'sched.mutes', 'sched.week', 'sched.issuance', 'sched.retraction', 'inputs', 'plan']

/* ---- context helpers ------------------------------------------------------ */

/* is the week context W carried ONLY by weekstash records in this closure? An
   off-week edit's only record is the stash blob (`weekstash/<wk>`); a loaded-week
   edit also carries days / sched.* records for the same week. loadContext must NOT
   loadWeek a weekstash-only context (C7): loading it makes the week CURWEEK, and
   the weekstash write() seam then refuses (its blob would be lost by persistAll). */
function weekIsStashOnly(entry: UndoEntry, wk: string): boolean {
  let sawWeek = false
  for (const ch of entry.forward) {
    if (weekOf(ch.collection, ch.id) !== wk) continue
    sawWeek = true
    if (ch.collection !== 'weekstash') return false   // a real loaded-week record
  }
  return sawWeek
}

/* the day index a scheduler closure touched, for the view-snap: a day's content first, then an issued version of it, then
   the one day whose sign-offs, plans or mutes changed — every schedule record names its day since [DB-READINESS] group
   A, phase 1 (walk S14a: Saturday's sign-off redone with the board on Friday must land on Saturday). */
function schedDayOf(entry: UndoEntry): number | null {
  for (const ch of entry.forward) if (ch.collection === 'insights.role') {
    const id=decodeRoleId(ch.id)
    if (id) for (let di=0;di<7;di++) if (dayIso(id.weekKey,di)===id.dayISO) return di
  }
  const dayOfCh = (ch: Change) => { const dk = dayKeyOf(ch.collection, ch.id); return dk && dk.includes('#') ? Number(dk.split('#')[1]) : null }
  for (const ch of entry.forward) if (ch.collection === 'days') return dayOfCh(ch)
  for (const ch of entry.forward) if (ch.collection === 'sched.issuance' || ch.collection === 'sched.retraction') { const d = dayOfCh(ch); if (d != null) return d }
  const days = new Set<number>()
  for (const ch of entry.forward) if (ch.collection === 'sched.book' || ch.collection === 'sched.mutes') { const d = dayOfCh(ch); if (d != null) days.add(d) }
  return days.size === 1 ? [...days][0] : null
}

/* the date an LW closure touched (lw.cell id = `<warId>:<pid>:<date>`,
   the date is the LAST segment — a warId may itself contain ':'). */
function lwDateOf(entry: UndoEntry): string | null {
  for (const ch of entry.forward) {
    if (ch.collection === 'lw.cell') {
      const p = ch.id.split(':')
      if (p.length >= 3) return p[p.length - 1]
    }
    /* a ledger entry (an OIL award) carries its own day — the undo lands there (Fable's round-2 read, N3) */
    if (ch.collection === 'lw.ledger') {
      const d = ((ch.after ?? ch.before) as any)?.date
      if (typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d)) return d
    }
  }
  return null
}

/* ---- the hooks (UndoHooks) ------------------------------------------------- */
/* the board's day, when a week load for an undo closed it (loadWeek shuts the board) — reopened on the changed day by
   snapView (walker A1-F2, 28 Sep 26: the board's Undo that crossed to another week closed the board, landing on the
   week on the wrong day, its Redo gone with it) */
let BOARD_WAS: number | null = null
function loadContext(ctx: RecordCtx, entry: UndoEntry): void {
  if (ctx.kind === 'week') {
    if (weekIsStashOnly(entry, ctx.weekId)) return   // off-week apply via the stash — do NOT load (C7)
    if (ctx.weekId !== CURWEEK) { if (SBDAY != null) BOARD_WAS = SBDAY; loadWeek(ctx.weekId) }
  } else if (ctx.kind === 'war') {
    selectWar(ctx.warId)
  }
  // 'course' — the Tracker has its own undo; 'page' — nothing to load (the page itself is chosen in snapView).
}

/* WHICH PAGE THE CHANGE LIVES ON — the change-recording re-test B7 (§11.6; walker A2-F4). The register's AM39b: an undo
   "takes you to where the change was". The page is the ACT's, read from the step's own area (its scope), never from a
   consequence folded into it (Astra's final read, F2: a weekend publish carries the Leave War's OIL credit and landed on
   the war, leaving the board on the wrong day): a schedule step to Edit Schedule, for someone who has it; a war's to the
   Leave War; an input to Inputs, the planning calendar to Inputs on its calendar (Fable's final read, F2), the inputs'
   look-ahead to Inputs; a roster record to Quals, on his row; the accounts, the requests and the guest switch to Admin →
   Users; a rule to Logic; the LoX columns to Quals; the templates and the default arrangement to Admin. The stores and the
   cancel reasons are edited on the board and the week, so they stay. `also` = the pages an undo may stay on because the
   change shows there too — only an input's: the loaded week it lands on (walk S16) and, for an absence, the Leave War
   (step4-leavewar's ATT C cut). null = stay where you are. */
type Landing = { primary: string | null; also: string[]; then?: () => void }
const inputRows = (c: { before?: unknown; after?: unknown }) => [c.before, c.after].filter(v => v && typeof v === 'object') as any[]
/* the loaded week's day an input covers — its day on Edit Schedule */
function inputDayOf(entry: UndoEntry): number | null {
  for (const c of entry.forward) {
    if (c.collection !== 'inputs') continue
    for (const r of inputRows(c)) for (let di = 0; di < 7; di++) if (DATES[di] && inputCoversDate(r, DATES[di])) return di
  }
  return null
}
function landingOf(entry: UndoEntry): Landing | null {
  const fwd = entry.forward, m = entry.scope.module
  const also: string[] = []
  let primary: string | null = null
  let then: (() => void) | undefined
  if (m === 'lw') primary = 'leavewar'
  else if (m === 'sched' || m === 'insights') primary = canEditSched() ? 'editsched' : null
  else if (m === 'inputs' || m === 'plan') {
    primary = 'inputs'
    /* the calendar's own records (a day title, its puck rows — saved through the Inputs page's door, so filed under
       inputs) and no input row: the change is on the calendar */
    if (fwd.some(c => c.collection === 'plan') && !fwd.some(c => c.collection === 'inputs')) then = () => setInpView('cal')
  } else if (m === 'people') {
    primary = 'quals'
    const person = fwd.find(c => c.collection === 'people')
    if (person) then = () => focusQualsRow(person.id)
  } else if (m === 'settings') {
    const ids = fwd.filter(c => c.collection === 'settings').map(c => c.id)
    if (ids.some(k => k.startsWith('account:') || k.startsWith('accessreq:') || k === 'guestview')) { primary = 'admin'; then = () => requestAdminUsers(false) }
    else if (ids.includes('rules') || ids.includes('insights')) primary = 'logic'
    else if (ids.includes('qualcols')) primary = 'quals'
    else if (ids.includes('lookahead')) primary = 'inputs'
    else if (ids.some(k => k === 'dutytpl' || k === 'wavetpl' || k === 'wavehide' || k === 'daytpl' || k === 'secdefault' || k === 'wavedefault')) primary = 'admin'
  }
  if (m === 'inputs') {
    if (canEditSched() && inputDayOf(entry) != null) also.push('editsched')
    if (fwd.some(c => c.collection === 'inputs' && inputRows(c).some(r => warVisible(r.type)))) also.push('leavewar')
  }
  return primary || also.length ? { primary, also, then } : null
}

function snapView(entry: UndoEntry, _dir: 'undo' | 'redo'): void {
  const boardWas = BOARD_WAS; BOARD_WAS = null
  const land = landingOf(entry)
  /* not when the change already shows on the page you are on (an input filed on Inputs, undone there) */
  if (land && land.primary && CURPAGE !== land.primary && !land.also.includes(CURPAGE)) setPage(land.primary)
  if (land && land.then) land.then()
  if (land && land.primary === 'leavewar') {
    const date = lwDateOf(entry)
    if (date) focusDay(date)
    return
  }
  const di = schedDayOf(entry) ?? inputDayOf(entry)
  if (di == null || CURPAGE !== 'editsched') return
  /* the board: bring the changed day onto it — and reopen it there when a week load closed it (A1-F2) */
  if (SBDAY != null) { if (SBDAY !== di) boardTab(di); return }
  if (boardWas != null) { setBoardDay(di); return }
  /* the week (walker A1-F3): the changed day brought on screen — stepped to on a phone, to the front on a desktop — once
     the undo has repainted it */
  setTimeout(() => bringDayIntoView(di), 0)
}

/* §3.4 / Fable N9 — hold the scheduler HIST.lock for the restore's duration, so
   the deferred histPush the restore's write() raises no-ops (a legacy step would
   feed the barrier-blind E3 hazard). The LW half is redundant — lwStore.write
   already runs its persist under locked(). Returns the un-lock. */
function reinstallLocks(): () => void {
  const prev = HIST.lock
  HIST.lock = true
  return () => { HIST.lock = prev }
}

/* §6.3 — resolve an AL/publish boundary's issued verId to its day when the
   closure carries no days/sched.issuance key. A publish always lands on the loaded
   week, so match the id's ISO date against CURWEEK's seven days (best-effort). */
function resolvePublishDay(id: string): { weekId: string; di: number } | null {
  const iso = parseVerId(id).iso
  for (let di = 0; di < 7; di++) if (dayIso(CURWEEK, di) === iso) return { weekId: CURWEEK, di }
  return null
}

/* §6.2/C5 + the restore epilogue (Fable N5). schedPostRestore clears the day's
   sign-offs on undo of a publish (GU5-005); the epilogue reproduces what the
   legacy histApply does after a restore but the write() seam does not:
   - armDrop(): a swapped-out model may leave the armed slot pointing at a row that
     no longer exists — put it down before anything repaints.
   - prunePreviews(): a day previewing a version the undo just un-published would
     otherwise render the live day while claiming to show history.
   - bumpLwHistEpoch(): signal the LW matrix to drop any in-flight drag/select.
   Runs INSIDE the restore reducer, so it precedes the deferred reflow — the same
   order histApply uses (armDrop/prunePreviews before reflow). */
function postRestore(entry: UndoEntry, dir: 'undo' | 'redo', pulledBack: Array<{ weekId: string; di: number }>): void {
  invalidateRoleTargets()
  if (entry.forward.every(ch=>ch.collection==='insights.role')) return
  schedPostRestore(entry, dir, pulledBack)
  /* the "use this section order as the default?" offer asks about the drag just made — once any step is undone or
     redone it asks about an order no longer on screen (walker A1 O5: "Set as default" would have promoted the order
     just undone, and on a phone the bubble sat over its buttons) */
  setSecDefOffer(null)
  armDrop()
  prunePreviews()
  bumpLwHistEpoch()
}

/* ---- the cutover ---------------------------------------------------------- */
/* Idempotent by construction: installUndo guards its own stream subscription,
   registerUndoStore is a Map set, and setCutoverModules/setUndoHooks replace.
   So a second call (e.g. a test after _resetTimeline) re-establishes the same
   wiring harmlessly rather than being skipped by a stale one-shot flag. */
/* B1 — each seen mark's field, carried onto an older step's image of the same record (timeline.ts carrySeen; Fable's
   final read F4, Astra's F1). His welcome note: `back` gone from his roster record. "OK, seen": the notices it removed
   (by their seq — a notice spans the days of one filing) gone from the day's list. Anything else: the image untouched.
   (The admins' bell had a branch here while each request carried its `seenBy`; since [DB-READINESS] group A, phase 4.4
   each admin's seen is a row of his own — AccessRequestSeen — which no step's image of a request holds.) */
function seenOverlay(type: string, seen: Change, image: unknown): unknown {
  if (!image || typeof image !== 'object') return image
  const b: any = seen.before, a: any = seen.after
  if (type === 'person.backSeen') {
    if (!(b && b.back) || (a && a.back) || !(image as any).back) return image
    const c = { ...(image as any) }; delete c.back; return c
  }
  if (type === 'lw.ack') {
    if (!Array.isArray(image) || !Array.isArray(b)) return image
    const kept = new Set((Array.isArray(a) ? a : []).map((r: any) => r && r.id))
    const gone = new Set(b.filter((r: any) => r && r.kind === 'notice' && !kept.has(r.id)).map((r: any) => r.seq))
    if (!gone.size) return image
    const next = image.filter((r: any) => !(r && r.kind === 'notice' && gone.has(r.seq)))
    return next.length === image.length ? image : next
  }
  return image
}

/** tests only — the landing, driven with a made-up entry */
export const _snapView = (e: UndoEntry, d: 'undo' | 'redo'): void => snapView(e, d)

export function installGlobalUndo(): void {
  installUndo()
  /* the words name a man by his callsign (describe.ts — the Leave War's records carry his id) */
  setDescribeNames((pid) => ((PEOPLE as any)[pid] ? String((PEOPLE as any)[pid].cs) : null), (k) => (k === 'accounts' ? seedAccounts() : null))
  registerUndoStore(schedStore, SCHED_COLLS)
  registerUndoStore(lwStore, LW_COLLS as unknown as string[])
  registerUndoStore(weekstashStore, ['weekstash'])
  /* B2 of the change-recording re-test (28 Sep 26, [UNDO-ROSTER-SETTINGS]): the roster and the settings join — the
     16 Sep 26 rule "roster and settings edits ARE undoable" (register AM39d), narrowed by D350: adding, archiving,
     restoring, deleting a person and a posting still write the war's stints (lw.postouts), which stay deferred
     (undo/timeline.ts), so those five stay out and say why (B3). A delete is kept dead by person-delete.ts (B4). */
  registerUndoStore(peopleStore, ['people'])
  registerUndoStore(settingsStore, ['settings'])
  registerUndoStore(roleStore, ['insights.role'])
  setCutoverModules(['sched', 'lw', 'inputs', 'plan', 'people', 'settings', 'insights'])
  setUndoHooks({
    loadContext,
    snapView,
    showBubble: (text: string) => toast(text, ''),
    /* the change history's line for an undo or a redo, on every day it touched ([DRAFT-PENDING], Astra DP-04) */
    reversed: (entry, dir) => logReversed(entry as any, dir),
    reinstallLocks,
    resolvePublishDay,
    postRestore,
    /* the war's own rules on what a restore may put back — a bid over a medical filed since (W3-F8) */
    /* …and B5 (the change-recording re-test): what a roster or settings restore must re-check — one callsign on the
       roster, the accounts' guards, a man still named somewhere (state/roster-restore.ts) */
    restoreRefusal: (changes, dir) => restoreBlocker(changes as any, dir, restoreAbsencesOf(changes as any)) || rosterRestoreProblem(changes as any, dir),
    /* [POST-OUT-OUTCOMES]: a step that would put a deleted man back is passed over, never taken (person-delete.ts) */
    deadRefusal: (changes) => deletedRestoreProblem(changes as any),
    /* D148 — the refusal says who: the callsign he goes by (a rename moves nothing, so it is read live) */
    seenOverlay,
    nameOf: (a) => (a.personId != null && (PEOPLE as any)[a.personId] ? String((PEOPLE as any)[a.personId].cs) : null),
    // currentActor OMITTED — the timeline defaults to deriveActor().
  })
}
