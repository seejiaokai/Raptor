/* [ARCH-STACK] Step 2 phase 2b — the scheduler PUBLISH path routed through the
   command gate (design §3.4, §5.1, §8 item 2). ADDITIVE: the engine
   setDayApproved / publishALDay run UNCHANGED inside commit();
   this proves the publish path now
     - emits the issued records (sched.orig on first publish, sched.als on an AL),
     - declares the publish boundary {kind:'publish', ids, crossable} (§3.4),
     - records the monotonic on-the-record signal that flips `crossable` for Step 3,
     - and that the envelope stream RECONSTRUCTS the persisted week byte-for-byte
       vs the legacy serializer (completeness, §7 / Codex R4-004).
   A refused/no-op publish mints nothing → no boundary, no envelope. */
import { beforeEach, afterEach, describe, expect, it } from 'vitest'
import { DAYS } from '../engine/data'
import { INPUTS } from '../engine/inputs'
import { SCHED, signOf, dayApproved, dayHasChanges } from '../engine/publish'
import { txtSet } from '../engine/slots'
import { CURWEEK } from '../engine/waves'
import { initStore, writeText } from './store'
import {
  commitSetDayApproved, commitPublishALDay,
  currentIssuedIds, discloseCurrentIssued, schedStore,
} from './sched-commit'
import { issuedDisclosed, _resetDisclosure } from './disclosure'
import { histSnap } from './history'
import { joinParts } from './weekrows'
import { sortByOrd } from '../command/ord'
import { setSession } from './auth'
import * as view from './view'
import { onCommit } from '../command'
import type { CommitEnvelope } from '../command'


const DSNAP = JSON.stringify(DAYS)
const ISNAP = JSON.stringify(INPUTS)

/* sign all four roles on a day so it is publishable */
const sign = (di: number) => {
  const g = signOf(di)
  g.cur = 'ignite'; g.sked = 'bane'; g.plan = 'stiff'; g.appr = 'pump'
}

let caught: CommitEnvelope[] = []
let unsub: () => void

beforeEach(() => {
  DAYS.length = 0; JSON.parse(DSNAP).forEach((d: any) => DAYS.push(d))
  INPUTS.length = 0; JSON.parse(ISNAP).forEach((i: any) => INPUTS.push(i))
  SCHED.pending = {}; SCHED.changes = {}; SCHED.added = {}; SCHED.als = []
  SCHED.al = 0; SCHED.dayOK = {}; SCHED.sign = {}; SCHED.orig = {}; SCHED.cur = {}
  SCHED.signBind = {}; SCHED.drafts = {}; SCHED.curDraft = {}
  setSession({ user: 'ad', role: 'admin' })
  view.selDrop(); view.armDrop()
  initStore()
  /* [ARCH-STACK] follow-up #1 (R2-01): the old warming of per-day sign objects
     (DAYS.forEach(signOf)) is GONE. It modelled rendering the sign strip lazily
     inserting SCHED.sign[di] — but the readers are non-mutating now (signAt), so
     the live app no longer materializes signs by rendering, and warming here would
     leave the command layer's baseline stale (SCHED.sign populated out-of-band
     after initStore's histInit set the baseline). With no warming, SCHED.sign is
     empty exactly as it is in the booted app before any sign action, so a refused
     publish truly records nothing (decision #5). */
  _resetDisclosure()
  caught = []
  unsub = onCommit(e => caught.push(e))
})
afterEach(() => { unsub() })

const cols = (e: CommitEnvelope) => e.changes.map(c => c.collection)

describe('first publish (setDayApproved) emits the Original + a publish boundary', () => {
  it('commitSetDayApproved -> ONE envelope, a sched.issuance change, boundary crossable', () => {
    sign(0)
    commitSetDayApproved(0, true)
    expect(dayApproved(0)).toBe(true)
    expect(caught.length).toBe(1)
    const e = caught[0]
    expect(e.type).toBe('sched.approve')
    expect(e.scope).toEqual({ module: 'sched', weekId: CURWEEK })
    // the Original is emitted as its own append-only record — issuance 0 of its version ([DB-READINESS] group A, phase 1)
    expect(e.changes.some(c => c.collection === 'sched.issuance' && c.id === `${CURWEEK}:${(SCHED.orig as any)[0].id}~0`)).toBe(true)
    // the mutable book moved too (dayOK / cur / pending cleared)
    expect(cols(e)).toContain('sched.book')
    // the publish boundary carries the new issued id, crossable (nothing disclosed)
    expect(e.boundary).toBeTruthy()
    expect(e.boundary!.kind).toBe('publish')
    expect(e.boundary!.crossable).toBe(true)
    expect(e.boundary!.ids.length).toBe(1)
    expect(e.boundary!.ids[0]).toBe((SCHED.orig as any)[0].id)
  })

  it('a refused first-publish (unsigned) mints nothing and emits nothing', () => {
    // not signed -> setDayApproved toasts and returns without stamping
    commitSetDayApproved(0, true)
    expect(dayApproved(0)).toBe(false)
    expect(caught.length).toBe(0)
  })
})

describe('an amendment (publishALDay) appends a sched.issuance record + boundary', () => {
  it('commitPublishALDay -> a sched.issuance change and the new AL id in the boundary', () => {
    sign(0)
    commitSetDayApproved(0, true)
    caught = []
    txtSet('dn:0.0', 'AMENDED NOTE')     // a real change vs the issued Original
    expect(dayHasChanges(0)).toBe(true)
    sign(0)
    commitPublishALDay(0)
    expect(caught.length).toBe(1)
    const e = caught[0]
    expect(e.type).toBe('sched.publishAL')
    expect(e.changes.some(c => c.collection === 'sched.issuance')).toBe(true)
    expect(e.boundary).toBeTruthy()
    expect(e.boundary!.ids.length).toBe(1)
    const newAl = (SCHED.als as any[])[(SCHED.als as any[]).length - 1]
    expect(e.boundary!.ids[0]).toBe(newAl.id)
  })

  it('publishALDay with no changes mints nothing and emits nothing', () => {
    sign(0)
    commitSetDayApproved(0, true)
    caught = []
    /* [ARCH-STACK] follow-up #1: NO out-of-band re-sign here. A no-changes AL is
       refused regardless of signing, and under the lagging-baseline model a raw
       (uncommitted) re-sign would be an uncaptured change the next command
       absorbs — in the real app signing is its own command (P3). So the no-op
       publish runs against a clean baseline and truly emits nothing. */
    commitPublishALDay(0)                // nothing changed since the Original
    expect(caught.length).toBe(0)
  })
})

describe('D488 — first publication clears draft marks through the publish command', () => {
  it('keeps the draft mark until publishing, with no separate clearing command', () => {
    writeText('dn:0.0', 'DRAFT NOTE')
    expect(SCHED.pending['dn:0.0']).toBeTruthy()
    caught = []
    sign(0); commitSetDayApproved(0, true)
    expect(SCHED.pending['dn:0.0']).toBeUndefined()
    expect(caught.map(e => e.type)).toEqual(['sched.approve'])
    expect(caught[0].boundary!.kind).toBe('publish')
  })
})

/* OWNER RULING 17 Sep 26 — the boundary is the SHARED DATABASE registering the
   publish, and nothing else. A PDF/print export, a CSV export and the session
   ending are NOT boundary events (they were, under Codex R4-003, until this
   ruling); the export is a scheduler-only snapshot of the current published
   schedule. So the reporting function has ONE future caller, the Step-5 database
   adapter, and is unwired today. These tests pin the SEAM's contract plus the
   Step-2 fact that nothing is ever on the record yet. */
describe('the on-the-record signal flips crossable for Step 3 (§3.4, owner 17 Sep 26)', () => {
  it('with no shared database, a fresh publish is never on the record — crossable', () => {
    sign(0)
    commitSetDayApproved(0, true)
    const issuedId = caught[0].boundary!.ids[0]
    expect(issuedDisclosed(issuedId)).toBe(false)
    expect(caught[0].boundary!.crossable).toBe(true)
    expect(currentIssuedIds()).toContain(issuedId)
  })

  it('once the backend acknowledges the write, the id is on the record, monotonically', () => {
    sign(0)
    commitSetDayApproved(0, true)
    const issuedId = caught[0].boundary!.ids[0]
    /* stands in for the Step-5 database adapter's acknowledgement — the ONLY
       caller this seam is ever meant to have. */
    discloseCurrentIssued()
    expect(issuedDisclosed(issuedId)).toBe(true)     // Step 3 must not silently reverse it
    discloseCurrentIssued()                          // monotonic: never taken back off the record
    expect(issuedDisclosed(issuedId)).toBe(true)
  })
})

describe('completeness — the stream reconstructs the persisted week (§7 / R4-004)', () => {
  /* invert schedRecords(): fold the change stream onto a pre-command snapshot of
     the logical records and re-assemble the legacy histSnap shape from them — the
     week through its rows' own join ([DB-READINESS] group A, phase 1: state/weekrows.ts). */
  function recordsToHist(m: Map<string, { collection: string; id: string; value: any }>): any {
    const wk = CURWEEK
    const days = [0, 1, 2, 3, 4, 5, 6].map(di => ({
      d: m.get(`days/${wk}#${di}`)!.value, book: m.get(`sched.book/${wk}#${di}`)!.value, wo: m.get(`sched.mutes/${wk}#${di}`)!.value,
    }))
    const is: Array<[string, any]> = [], rx: Array<[string, any]> = []
    const inputs: any[] = [], pp: any[] = [], dm: Record<string, string> = {}
    for (const [k, e] of m) {
      if (k.startsWith('sched.issuance/')) is.push([e.id.slice(e.id.indexOf(':') + 1), e.value])
      else if (k.startsWith('sched.retraction/')) rx.push([e.id.slice(e.id.indexOf(':') + 1), e.value])
      else if (k.startsWith('inputs/')) inputs.push(e.value)
      else if (k.startsWith('plan/pp:')) pp.push(e.value)
      else if (k.startsWith('plan/dm:')) dm[e.id.slice(3)] = e.value
    }
    /* [DB-READINESS] group A, phase 2 — each request and planning note carries its place (ord) */
    sortByOrd(inputs, (r: any) => r.iid); sortByOrd(pp, (p: any) => p.id)
    const w = joinParts({ week: m.get(`sched.week/${wk}`)!.value, days, is, rx }, wk)
    return {
      d: w.d, i: inputs,
      c: w.c, p: w.p, ad: w.ad, a: w.a,
      ok: w.ok, sg: w.sg, sb: w.sb, o: w.o, cv: w.cv, dr: w.dr, cd: w.cd,
      v: w.v, am: w.am, rt: w.rt, cr: w.cr, wo: w.wo, pp, dm,
    }
  }

  it('a publish + amendment sequence reconstructs byte-identically to histSnap()', () => {
    // snapshot the logical records BEFORE any command (deep copy)
    const base = new Map<string, { collection: string; id: string; value: any }>()
    for (const [k, e] of schedStore.records()) {
      base.set(k, { collection: e.collection, id: e.id, value: JSON.parse(JSON.stringify(e.value)) })
    }
    // a realistic sequence: publish day 0, amend it (through a command so the
    // edit is on the stream too), publish the AL
    sign(0); commitSetDayApproved(0, true)
    writeText('dn:0.0', 'AMENDED NOTE'); sign(0); commitPublishALDay(0)
    // fold every emitted change onto the snapshot
    for (const env of caught) for (const c of env.changes) {
      const key = `${c.collection}/${c.id}`
      if (c.op === 'delete') base.delete(key)
      else base.set(key, { collection: c.collection as string, id: c.id, value: c.after })
    }
    // the reconstruction must equal the legacy serializer's live output — less `al` (no reader, not stored)
    const live = JSON.parse(histSnap()); delete live.al
    expect(JSON.parse(JSON.stringify(recordsToHist(base)))).toEqual(live)
  })
})
