import { DAYS } from '../engine/data'
import { INPUTS } from '../engine/inputs'
import { SCHED } from '../engine/publish'
import { HOOKS } from '../engine/hooks'
import { logAction } from '../engine/editlog'
import { ensureRowIds } from '../engine/rowids'
import { armDrop, prunePreviews, WARNOFF } from './view'
import { PLANPUCKS, DAYRMK } from './plan'

const toast=(...a:any[])=>HOOKS.toast(...a)
const reflow=()=>HOOKS.reflow()
const syncHistBtns=()=>HOOKS.syncHistBtns()
/* =====================================================================
   UNDO / REDO — snapshot stack over DAYS + the amendment bookkeeping
   ===================================================================== */
/* the SIXTEEN SCHED fields (corrected 30 Sep 26 — it said fourteen; `rt` and `cr` joined with [GLOBAL-UNDO]), pulled
   out so histSnap (the whole-history undo snapshot, below) and the per-week
   stash (state/store.ts's weekStashSnap, engine/weekstash.ts — it PERSISTS since
   8 Sep 26, so "session stash" here was wrong too) build the identical object
   rather than two hand-copied field lists drifting apart the day another field
   is added. Same key ORDER as histSnap always wrote them in, so splicing this
   in with `...schedFields()` leaves histSnap's JSON.stringify output
   byte-identical to before this existed. */
export function schedFields(){return {c:SCHED.changes,p:SCHED.pending,ad:SCHED.added,a:SCHED.als,al:SCHED.al,ok:SCHED.dayOK,sg:SCHED.sign,sb:SCHED.signBind,o:SCHED.orig,cv:SCHED.cur,dr:SCHED.drafts,cd:SCHED.curDraft,v:SCHED.ridV,am:SCHED.amV,rt:SCHED.retired,cr:SCHED.correcting}}
export const HIST:any={stack:[],ix:-1,lock:false,cap:60};
/* [ARCH-STACK] follow-up #1 (R2-07): the scheduler command layer's lagging
   baseline (state/sched-commit.ts SCHED_BASELINE) must be re-synced to the live
   world after ANY out-of-band replacement of DAYS/SCHED/INPUTS/WARNOFF that does
   not go through a command. histInit (boot + loadWeek) and histRestore (undo,
   redo, the input-quarantine rollback, a command rollback) are the choke points
   for all of those, so a callback registered here fires from BOTH — covering
   every restore path BY CONSTRUCTION rather than by a hand-kept enumeration.
   history.ts cannot import sched-commit.ts (cycle: sched-commit imports history),
   so the layer registers the callback at module-eval (registerSchedCommandLayer).
   Null before that = no-op. The callback always sets the baseline to histSnap()
   AFTER the restore, never to the raw snapshot string — histRestore re-installs
   fields with ||{}/||[] defaults, so histSnap() can differ from the raw string by
   a byte and only the post-restore live snapshot is the true baseline. */
let SCHED_RESYNC:(()=>void)|null=null;
export function setSchedResync(cb:(()=>void)|null){SCHED_RESYNC=cb;}
/* `ok` carries SCHED.dayOK — the per-day publish state. It replaced the old
   week-wide ap/dr pair, so publishing or reopening a single day is an ordinary
   undo step. */
/* `dr`/`cd` carry SCHED.drafts and SCHED.curDraft (engine/drafts.ts) — the
   per-day alternate blobs and which one the live day is. In the snapshot for
   the same reason the AL records are: a duplicate or a draft switch is one
   ordinary undo step, and undoing past it must bring the blobs back too. */
/* `wo` carries the muted-check set (view.WARNOFF). Hiding or un-hiding a board
   warning pushes its own history step (interactions.ts), so undo/redo walk back
   over a mute the same as any other edit (owner, Aug 26 — "when I click undo I
   should revert my hidden warning changes"). A Set is not JSON-serialisable, so
   it rides as an array and histApply rebuilds it. It is the one session-view set
   in the snapshot — the rest (folds, previews, late marks) are not undoable and
   stay out on purpose. */
/* `pp`/`dm` carry the Inputs-calendar planning layer (state/plan.ts) —
   PLANPUCKS and DAYRMK. CORRECTED 17 Sep 26: NOT session-only — persistAll
   writes them as the plan/all record. Worth an undo step as well: a scheduler dragging pucks around a month wants the
   same Ctrl+Z safety net as every other edit, and riding the ordinary
   snapshot is free — it is already whole-state JSON. */
export function histSnap(){return JSON.stringify({d:DAYS,i:INPUTS,...schedFields(),wo:[...WARNOFF],pp:PLANPUCKS,dm:DAYRMK});}
/* the stable-ids walk (engine/rowids.ts) runs before EVERY snapshot so undo
   never hands back an id-less row */
/* RE-SYNC BEFORE syncHistBtns (F-01): syncHistBtns() -> HOOKS.syncHistBtns ->
   notify(), which runs every listener synchronously — the Leave War sync opens a
   real writeInputsBatch command. If that command runs while the baseline is still
   the PREVIOUS world (loadWeek has already swapped DAYS/SCHED), it would diff the
   old week against the new and emit a spurious whole-week envelope. Advance the
   baseline first so the notify's listeners see baseline === live. */
export function histInit(){ensureRowIds(DAYS);HIST.stack=[histSnap()];HIST.ix=0;SCHED_RESYNC&&SCHED_RESYNC();syncHistBtns();}
export function histPush(){
  if(HIST.lock)return;
  ensureRowIds(DAYS);
  const s=histSnap();
  if(HIST.stack[HIST.ix]===s)return;
  HIST.stack.splice(HIST.ix+1);
  HIST.stack.push(s);
  if(HIST.stack.length>HIST.cap)HIST.stack.shift();
  HIST.ix=HIST.stack.length-1;
  syncHistBtns();
}
/* RESTORE THE WHOLE MODEL from a histSnap() string, IN PLACE — the pure
   deserialize half of histApply, with none of its stack/UX epilogue. histApply
   uses it for undo/redo; the input funnel's quarantine backstop
   (state/store.ts writeInputs/writeInputsBatch) uses it to ROLL BACK a batch
   that turned out to touch a protected week — the same battle-tested restore the
   undo path runs, rather than a second hand-written one that could drift. Every
   binding is restored in place (DAYS/INPUTS/PLANPUCKS/DAYRMK arrays and object
   identities every reader holds), and NOTHING here notifies, persists or pushes
   history — the caller owns what happens next. */
export function histRestore(snapStr:any){
  const s=JSON.parse(snapStr);
  DAYS.length=0; s.d.forEach((x:any)=>DAYS.push(x));
  INPUTS.length=0; (s.i||[]).forEach((x:any)=>INPUTS.push(x));
  SCHED.changes=s.c||{}; SCHED.pending=s.p||{}; SCHED.added=s.ad||{}; SCHED.als=s.a||[];
  SCHED.al=s.al||0; SCHED.dayOK=s.ok||{};
  SCHED.sign=s.sg||{};
  SCHED.signBind=s.sb||{};   // AM-06 content bindings ride the snapshot so undo re-verifies (F-09)
  SCHED.orig=s.o||{};
  SCHED.cur=s.cv||{};   // stale entries are inert — dayCurVer self-heals
  SCHED.drafts=s.dr||{}; SCHED.curDraft=s.cd||{};
  SCHED.ridV=s.v;   // absent (undefined) on a foundation-era snapshot → migrateLegacyIds runs
  SCHED.amV=s.am;   // absent (undefined) on a PRE-Phase-2 snapshot → amFormatOf flags it unsupported
  SCHED.retired=s.rt||{}; SCHED.correcting=s.cr||{};   // [GLOBAL-UNDO] §6.1 — the issuance log + correction flags ride the snapshot
  WARNOFF.clear(); (s.wo||[]).forEach((k:any)=>WARNOFF.add(k));   // muted checks are an undo step
  /* PLANPUCKS/DAYRMK restored IN PLACE, the same live-binding idiom DAYS and
     INPUTS use above — every reader (the calendar UI) holds these two array
     /object identities, so a reassignment here would strand them pointing at
     the old, now-orphaned one. `|| []` / `|| {}` cover an OLDER snapshot, from
     before this feature landed, that carries no pp/dm at all — it restores to
     empty rather than throwing on a missing field. */
  PLANPUCKS.length=0; (s.pp||[]).forEach((x:any)=>PLANPUCKS.push(x));
  for(const k of Object.keys(DAYRMK))delete DAYRMK[k];
  Object.assign(DAYRMK,s.dm||{});
  /* the command layer's baseline follows every restore (see setSchedResync). It
     reads histSnap() itself, so it runs AFTER the whole model is back in place. */
  SCHED_RESYNC&&SCHED_RESYNC();
  return s;
}
export function histApply(i:any){
  if(i<0||i>=HIST.stack.length)return;
  HIST.ix=i; HIST.lock=true;
  histRestore(HIST.stack[i]);
  /* the model has just been swapped wholesale — an armed slot may now point at a
     wave, row or aircraft that no longer exists. The arm strip stayed on screen
     and the next tap threw "Cannot read properties of undefined" out of flyRef
     and planted nobody. Put the slot down before anything re-renders. */
  armDrop();
  /* same class of stale pointer: a day previewing an AL that the undo just
     un-published would render the live day while claiming to show history */
  prunePreviews();
  reflow();
  HIST.lock=false;
  HOOKS.histApplied();
  syncHistBtns();
}
/* Undo and redo are logged, and they do NOT erase what they undo.
   histSnap() deliberately does not carry the edit log, so an undo restores
   the schedule and leaves the record of how it got that way standing — a log
   you can rewrite by pressing undo is not a log. Without these two lines the
   list would show an edit whose value has since silently reverted, with
   nothing to say why; with them it reads the way it happened. */
export function undo(){ if(HIST.ix<=0)return toast('Nothing to undo'); histApply(HIST.ix-1); logAction(null,'Undo'); toast('Undo'); }
export function redo(){ if(HIST.ix>=HIST.stack.length-1)return toast('Nothing to redo'); histApply(HIST.ix+1); logAction(null,'Redo'); toast('Redo'); }
