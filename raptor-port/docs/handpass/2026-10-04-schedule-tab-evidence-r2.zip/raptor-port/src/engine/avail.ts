import { DAYS } from './data'
import { rosterShown } from './faceattrs'
import { INPUTS, inputsOn, inputCoversDate, isAway, awayAllDay, canSpare, canWork, offWord, inpWin, sansAvailOn, sansWindow, isPersonal, inpLabel } from './inputs'
import { PEOPLE, isSpecial, whoId, aarNeed, aarOK, scShiftKind, scQualOK } from './people'
import { parseHM, win, overlap, hm24 } from './time'
import { SHIFT_HARD, VCONF } from './rules'
import { isStandalone, scSpare, saExempt, saExemptKind } from './waves'
import { WARN, restClear, dayEvents, crossDayIfPlaced } from './validate'
import { waveWindows, inpShow, shiftEvHard, seatIntime, scSeatHit, avSeatHit } from './events'
import { whoArr, rowRef, rowPlaces, XKEY, sentinelSeatOK, SENTINEL_JET_BAR } from './slots'
import { keyDay, seatRow } from './keys'
/* busy windows [s,e] for one person on a day (fly/duty/sim/ground) */
export function personBusy(d:any,id:any){
  const out:any[]=[];
  if(isSpecial(id))return out;                                  // sentinel never occupies anyone's time
  /* one push, so midnight-crossing and open-ended rows are handled the same way
     everywhere: an overnight duty used to come out inverted and read as FREE */
  const add=(st:any,en:any,dflt?:any)=>{const w2=win(st,en,dflt); if(w2)out.push(w2);};
  const has=(r:any,who?:any)=>who===id||((r&&r.more)||[]).includes(id);
  (d.waves||[]).forEach((w:any)=>{const shift=isStandalone(w); w.formations.forEach((f:any)=>{ if(f.cx)return; f.aircraft.forEach((a:any)=>{
    if(a.cx)return;
    if(a.p===id||a.w===id){const to=parseHM(f.to); let ld=parseHM(f.ld);
      /* the step and dekit pads are VCONF's, not literals: both are editable on
         the Logic tab (0–240), and slotRules/events.ts/validate.ts all read them
         from there. Hardcoding 60/30 here matched only at the defaults, so
         raising either rule left this strip offering a man the validator already
         considered occupied.
         A standalone line is a SHIFT, not a sortie (owner, 8 Sep 26 — "don't
         pad"): 07:00–13:00 occupies exactly that, no step in front and no dekit
         behind — the reading slotRules and events.ts already give it. This strip
         was the one place still padding it, greying an SC man ~90 min wider
         than the engine reserves him. */
      if(to!=null&&ld!=null){if(ld<to)ld+=1440; out.push(shift?[to,ld]:[to-VCONF.step,ld+VCONF.dekit]);}}});});});
  /* both sim devices count, and a row's pax list counts as much as its p/w seats —
     an AMT box session with 8 aircrew makes all 8 of them busy for that window. */
  /* sim `who` is FREE TEXT since 1C (an "EXT SQN" label), never a person — crew
     are p/w/pax only, so it is not resolved to an id here (ARCH-STACK 1C). */
  const sm=d.sims||{}; ['amt','oft'].forEach((k:any)=>(sm[k]||[]).forEach((o:any)=>{ if(o.cx)return;
    if(o.p===id||o.w===id||(o.pax||[]).includes(id)||has(o))
      add(parseHM(o.str),parseHM(o.end),VCONF.simLen); }));
  (d.dutywaves||[]).forEach((dw:any)=>dw.rows.forEach((r:any)=>{ if(r.cx)return; if(has(r,r.id))add(parseHM(r.str),parseHM(r.end)); }));
  /* an ⓘ info-only row never occupies anyone's time — same reasoning as its
     skip in events.ts: shown, never checked (owner, 1 Sep 26) */
  (d.ground||[]).forEach((g:any)=>{ if(g.cx)return; if(g.info)return; if(has(g,whoId(g.who)))add(parseHM(g.str),parseHM(g.end)); });
  (d.allhands||[]).forEach((x:any)=>{ if(x.cx)return; if(x.info)return;
    if(whoArr(x).some((nm:any)=>whoId(nm)===id)||has(x))add(parseHM(x.str),parseHM(x.end)); });
  return out;
}
/* engaged = tasked anywhere that day; off = leave/DNIF that day */
export function dayStandby(d:any){const s=new Set();
  (d.waves||[]).forEach((w:any)=>(w.formations||[]).forEach((f:any)=>{if(f.cx)return;
    (f.aircraft||[]).forEach((a:any)=>{if(a.cx||!scSpare(w,f,a))return;
      [a.p,a.w].forEach((id:any)=>{if(id&&PEOPLE[id]&&!PEOPLE[id].special)s.add(id);});});}));
  return s;}
export function dayEngaged(d:any){const s=new Set(),add=(id:any)=>{if(id&&PEOPLE[id]&&!PEOPLE[id].special)s.add(id);};
  /* an SC SPARE is deliberately NOT counted as tasked: he is standing by and may
     be planned for anything else, so he must read as free in the palette. */
  (d.waves||[]).forEach((w:any)=>w.formations.forEach((f:any)=>{if(f.cx)return;f.aircraft.forEach((a:any)=>{
    if(a.cx||scSpare(w,f,a))return;add(a.p);add(a.w);});}));
  const sm=d.sims||{}; ['amt','oft'].forEach((k:any)=>(sm[k]||[]).forEach((o:any)=>{if(o.cx)return;add(o.p);add(o.w);(o.pax||[]).forEach(add);}));   // sim who is free text (1C), not a person
  /* the extras dropped under a row are tasked exactly as much as the person in
     its primary seat — they used to be counted as free all day */
  const more=(r:any)=>((r&&r.more)||[]).forEach(add);
  (d.dutywaves||[]).forEach((dw:any)=>dw.rows.forEach((r:any)=>{if(!r.cx){add(r.id);more(r);}}));
  /* crew on ONLY an ⓘ info-only row stay un-greyed in the palette — being
     listed for information is not being tasked (owner, 1 Sep 26) */
  (d.ground||[]).forEach((g:any)=>{if(!g.cx&&!g.info){add(whoId(g.who));more(g);}});
  (d.allhands||[]).forEach((x:any)=>{if(x.cx)return;if(x.info)return;(Array.isArray(x.who)?x.who:(x.who?[x.who]:[])).forEach((w:any)=>add(whoId(w)));more(x);});
  ['amt','oft'].forEach((k:any)=>((d.sims||{})[k]||[]).forEach((o:any)=>{if(!o.cx)more(o);}));
  return s;}
/* AWAY, split by whether the absence closes the DAY or only some HOURS
   (10 Aug 26, for the AM/PM half-days). Built in ONE pass because the palette
   asks about sixty people and sixty scans of the same list is the shape this
   is replacing, not the shape to grow into. */
export function dayAway(d:any){const all=new Set(), tw:any={};
  inputsOn(d.dt).forEach((inp:any)=>{ if(!isAway(inp)||!PEOPLE[inp.person])return;
    if(awayAllDay(inp)){all.add(inp.person);return;}
    const w2=win(inp.s,inp.e); if(w2)(tw[inp.person]=tw[inp.person]||[]).push(w2); });
  return {all,tw};}
/* OFF means off for the WHOLE day, and deliberately kept narrow: it also feeds
   the day-info "off" tally and the palette's struck-through rank, and a man on
   AM leave is genuinely not off for the day. Timed absences are handled by
   availByWave below, per wave. */
export function dayOff(d:any){return dayAway(d).all;}
/* available crew bucketed by wave; anyWave = free across every wave (untasked) */
export function availByWave(d:any){
  const wins:any[]=waveWindows(d), aw=dayAway(d), off=aw.all, eng=dayEngaged(d);
  const byWave=wins.map(()=>[] as any[]), anyWave:any[]=[];
  const bySort=(a:any,b:any)=>PEOPLE[a].cs.localeCompare(PEOPLE[b].cs);
  /* personnel (ground crew) are not aircrew — they never count toward a
     wave's available-crew strip, even though they can be dropped into a rear
     seat by hand. Keeping them out stops the flying counts reading high.
     The roster is the one the face being drawn shows ([LEAVE-LATE-PUBLISHED], Astra's second read #3): an issued day
     counts the aircrew it went out with — a man posted out (or added) since moves the working copy, not the published
     day's "free all day" (engine/faceattrs.ts rosterShown); everywhere else it is today's, the same filter as before. */
  rosterShown().forEach((id:any)=>{
    if(off.has(id))return;
    /* AN ABSENCE OCCUPIES TIME EXACTLY AS A TASK DOES, so it is folded into
       the same busy list rather than checked on a second path — one overlap
       rule, not two that can drift.
       The untasked fast path is where a timed absence would otherwise be lost
       outright: a man with nothing else on is still not available during his
       leave, so he only reads free-all-day when there is genuinely nothing to
       check him against. But a day with NO waves (Friday, the weekend) has no
       bands to bucket into, and there anyWave is the only bucket there is —
       without that second guard he would vanish from the strip altogether,
       which is the same bug in a different corner. */
    const away=aw.tw[id]||[];
    if(!eng.has(id)&&(!away.length||!wins.length)){anyWave.push(id);return;}
    const busy=personBusy(d,id).concat(away);
    wins.forEach((w:any,i:any)=>{ if(!w.priorEmpty&&!busy.some(([bs,be]:any)=>bs<w.e&&be>w.s))byWave[i].push(id); });
  });
  byWave.forEach((a:any)=>a.sort(bySort)); anyWave.sort(bySort);
  return {wins,byWave,anyWave};
}
/* every place a person is written into the week, counted */
export function personCount(id:any){
  if(!id)return 0;
  let n=0; const hit=(v:any)=>{if(v===id)n++;};
  const more=(r:any)=>((r&&r.more)||[]).forEach(hit);
  DAYS.forEach((d:any)=>{
    (d.waves||[]).forEach((w:any)=>(w.formations||[]).forEach((f:any)=>(f.aircraft||[]).forEach((a:any)=>{hit(a.p);hit(a.w);})));
    ['amt','oft'].forEach((k:any)=>((d.sims||{})[k]||[]).forEach((o:any)=>{
      hit(o.p);hit(o.w);(o.pax||[]).forEach((x:any)=>hit(whoId(x)||x));more(o);}));   // sim who free text (1C)
    (d.dutywaves||[]).forEach((dw:any)=>(dw.rows||[]).forEach((r:any)=>{hit(r.id);more(r);}));
    (d.ground||[]).forEach((g:any)=>{hit(whoId(g.who));more(g);});
    (d.allhands||[]).forEach((x:any)=>{(Array.isArray(x.who)?x.who:(x.who?[x.who]:[])).forEach((v:any)=>hit(whoId(v)));more(x);});
  });
  return n;
}
/* every day index on which this person is named in a warning */
export function personWarnDays(id:any){
  const out:any[]=[];
  WARN.byDay.forEach((g:any)=>{ if(g&&g.warns&&g.warns.some((w:any)=>(w.who||[]).includes(id)))out.push(g.di); });
  return out;
}
export function personWarns(di:any,id:any){
  const g=WARN.byDay[di];
  if(!g||!g.warns)return [];
  return g.warns.map((w:any,ix:any)=>({w,ix})).filter((x:any)=>(x.w.who||[]).includes(id));
}
/* ---------------------------------------------------------------------------
   WHO MAY BE PLANNED INTO THIS SLOT
   The picker used to list the whole squadron and leave it to the validation
   engine to complain afterwards. It now offers only crew who are actually
   eligible for the slot in front of you: the seat rules, SC currency for an SC
   shift, and nobody on leave or downchit that day. Nothing becomes impossible —
   the ineligible are folded away behind a "show anyway" line with the reason
   against each name — but the default list is the one you can plan from.
   --------------------------------------------------------------------------- */
export function slotRules(key:any){
  /* an append target and an overflow body both sit on the row they hang off,
     so they carry its hours — strip both before looking the row up */
  const k=String(key).replace(/\.\+$/,'').replace(XKEY,'');
  const out:any={seat:null,sim:false,simKind:null,sc:null,scStart:null,scEnd:null,scSpare:false,aar:null,di:-1,slotStart:null,slotEnd:null,sansStart:null,avJet:false,avDuty:false,avKind:null,scDesk:false,infoRow:false,saExempt:false};
  out.di=keyDay(k);
  /* THE SLOT'S OWN HOURS (10 Aug 26, for the AM/PM half-days). Only an SC
     shift carried a window before, which is the whole reason a personal input
     could only ever be judged against the WHOLE DAY outside SC: there was
     nothing to judge it against. Every kind is read off the same row
     collectEvents() reads, and padded the same way, so what the picker bars
     and what the warning list flags cannot drift apart.
     null means UNKNOWN, never FREE — a BB shift is written ['SHIFT','',''] and
     a ground row may carry no times at all, and reading either as "clashes
     with nothing" would silently drop a real absence. slotBar falls back to
     the old whole-day answer instead. Fail closed, both sides. */
  if(/^[dsga]:/.test(k)){
    const kk=k[0], parts=k.slice(2).split('.'), r=rowRef(kk,parts);
    /* AVALON's desk (owner, 11 Aug 26): the wave's `sa` marker survives on its
       duty block (waveDutyBlock), so a `d:` key can tell whether its row is an
       AVALON desk without walking back through DAYS.waves at all. */
    if(kk==='d'){const dwx=((DAYS[+parts[0]]||{}).dutywaves||[])[+parts[1]];
      /* AVALON's desk, or BB's — its twin (7 Sep 26). saExempt too (audit,
         8 Sep 26): the desk row never becomes an event (events.ts sacrew), so
         the cross-day question at the foot of slotBar must stand down for it
         exactly as it does for the jet seat below — else the picker bars a
         run the validator never flags. */
      if(dwx&&saExemptKind(dwx.sa)){out.avDuty=true; out.saExempt=true;}
      /* an SC desk (7 Sep 26): checked like any duty row, AND one of the SC
         seats for the spare's same-hours rule — slotBar asks scSeatHit off this */
      if(dwx&&dwx.sa==='sc')out.scDesk=true;}
    /* a sim with no end runs VCONF.simLen, matching events.ts (a setting
       since 21 Aug 26 — the literal 90 here would have drifted the moment
       the Logic tab moved it); everything else falls to VCONF.openEnd, as
       win() does by default */
    const w2=r&&win(parseHM(r.str),parseHM(r.end),kk==='s'?VCONF.simLen:undefined);
    if(w2){out.slotStart=w2[0]; out.slotEnd=w2[1];}
    /* an ⓘ info-only ground/programme row (owner, 1 Sep 26): the flag rides out
       so slotBar can stand down — see its early return */
    if((kk==='g'||kk==='a')&&r&&r.info)out.infoRow=true;
  }
  /* a SIM box has the same two seats as the jet and the engine checks its
     FRONT one (day.simcrew). The picker used to skip the seat rules for
     any key carrying a ':' prefix, so it happily planted a WSO into a sim front
     seat and the engine then raised a hard warning about it. `s:di.kind.ri.p|w`
     — but not `s:di.kind.ri.pax.N`, which is a body in the room, not a seat.
     `sim` is what lets slotBar leave the sim's REAR seat open: an OFT or AMT
     session needs no instructor in the back (owner, 14 Aug 26). */
  if(/^s:/.test(k)){
    out.sim=true;
    const a=k.slice(2).split('.');
    if(a.length===4&&(a[3]==='p'||a[3]==='w'))out.seat=a[3];
    /* which sim device — read straight off the key, the same way a[3] reads
       the seat, so slotBar can ask sansGate for the right SANS domain (`amt'
       or 'oft') without re-parsing the key a second time. a[0] is the DAY
       index (`s:di.kind.ri…`, see keys.ts's grammar in CLAUDE.md) — a[1] is
       the kind. Bug found writing sansavail.test.ts (14 Aug 26): this read
       a[0], which is always a numeric day index and never 'amt'/'oft', so
       simKind was silently null for every sim key and the whole SANS OFT/AMT
       gate — slotBar's grey-out AND the validator's advisory — never fired
       for a sim seat. Only the flying-seat domain ever worked. */
    out.simKind=a[1]==='amt'||a[1]==='oft'?a[1]:null;
  }
  if(k.indexOf(':')<0){                                  // a flying seat
    const a=k.split('.');
    out.seat=a[4];
    const wv=(((DAYS[+a[0]]||{}).waves||[])[+a[1]]);
    const f=wv&&(wv.formations||[])[+a[2]];
    const ac=f&&(f.aircraft||[])[+a[3]];
    if(f&&ac){
      let ld=parseHM(f.ld); const to=parseHM(f.to);
      if(ld!=null&&to!=null&&ld<to)ld+=1440;
      /* the same rule the validator applies (events.ts): night AAR is the
         WAVE's nightness, never the landing clock (owner, 21 Aug 26). This
         line once carried its own literal 19:00 — the drift seam the owner
         warned about ("rules engine affects many parts… are they in sync") —
         so whatever the rule is, it must stay identical in both places. */
      out.aar=aarNeed(ac.rmks,!!wv.night);
      /* a line the conflict engine leaves alone (waves.ts saExempt: AVALON/BB
         whole wave, the SC SPARE row) never enters day.fly/day.events, so it
         bears no crew rest and counts as no day on the programme — the
         cross-day question below must stand down for it (5 Sep 26) */
      out.saExempt=saExempt(wv,f,ac);
    }
    /* the sortie's window, PADDED to the step and the dekit — because that is
       what the validator judges an input against (the brief/debrief loop), and
       a picker that offered a man the engine would immediately flag would be
       worse than no picker. Consequence worth knowing: a morning absence does
       not free a sortie that starts WALKING before noon.
       A standalone line is a shift, not a sortie: 07:00–13:00 means exactly
       that, no step in front and no dekit behind, matching events.ts. */
    if(f){ const st=parseHM(f.to); let en=parseHM(f.ld);
      if(st!=null){ if(en==null)en=st; if(en<st)en+=1440;
        const sh=wv&&isStandalone(wv);
        if(sh&&wv.noconf){out.avJet=true;    // AVALON or BB, MAIN or SPARE — all jet seats (owner, 11 Aug 26; BB 7 Sep 26)
          /* every jet seat asks for SC currency by the shift's kind (7 Sep 26,
             SPARE included the same day) — the same scShiftKind the validator
             reads, so night is night here too; the desk never asks */
          out.avKind=scShiftKind(st,en);}
        out.slotStart=sh?st:st-VCONF.step; out.slotEnd=sh?en:en+VCONF.dekit;
        /* SANS judges a flying seat from the crew's IN-TIME (owner, 26 Aug
           26 — "SANS should consider IN TIME till land plus 30 minutes for
           availability"): a published in-time line, or a typed SC B, that
           shows the crew EARLIER than the step (or shift start) opens the
           SANS window there instead — min(), so a late clock can never
           SHRINK the occupied window, the same guard insOf/workSpan put on
           crew rest. No in-time published leaves this exactly slotStart —
           the fallback is the window the seat occupies anyway, stated on
           the Logic tab. Its OWN field on purpose: slotStart/slotEnd still
           judge absences and the busy-at-this-hour check, which the owner
           did not move. The validator computes the identical front edge as
           min(e.report,e.step) off the same seatIntime body (events.ts) —
           the pair cannot drift. */
        const it=seatIntime(wv,f,st);
        out.sansStart=it!=null?Math.min(it,out.slotStart):out.slotStart; } }
    if(wv&&f&&isStandalone(wv)&&wv.kind==='sc'){
      const st=parseHM(f.to); let en=parseHM(f.ld);
      if(st!=null&&en!=null){ if(en<st)en+=1440; out.sc=scShiftKind(st,en); out.scEnd=en; }
      /* a SPARE is standing by, not tasked: he may fly, sit a sim or stand a
         duty in the same hours, and the shift buys him no crew rest either */
      out.scSpare=scSpare(wv,f,ac);
      /* the shift's own start time is the report time — an SC line may only be
         crewed by someone 12h clear of the previous day */
      out.scStart=st;
    }
  }
  return out;
}
/* THE SANS AVAILABILITY GATE (owner, 14 Aug 26) — one function judges a SANS
   member against his filed record for a flying/OFT/AMT slot, and every
   consumer (slotBar's grey-out, the validator's advisory, the test suite)
   calls THIS, not the record directly, so the rule cannot drift between them.
     'na'          — not a SANS person; the caller has nothing to ask about
     'none'        — SANS but no record filed for this day at all
     'not-offered' — a record exists but this event's box is unticked
     'ok'          — offered all day, or the slot falls inside the offered window
     'window'      — offered, but only for a narrower window than the slot
   s/e are the SLOT's own minutes-from-midnight, exactly as slotRules already
   computes them. The record carries ONE window for every ticked event (owner
   rework, 14 Aug 26 — sansWindow reads it off the row's standard allday /
   half / s / e fields), so `off` is that same window whichever event asked. */
const SANS_KEY:any={fly:'f',oft:'o',amt:'a'};
export const SANS_LABEL:any={fly:'Fly',oft:'OFT',amt:'AMT'};
export function sansGate(id:any,dt:any,domain:any,s:any,e:any):any{
  const p=PEOPLE[id]; if(!p||!p.san)return {status:'na'};
  const rec=sansAvailOn(id,dt); if(!rec)return {status:'none'};
  if(!(rec.sans&&rec.sans[SANS_KEY[domain]]))return {status:'not-offered'};
  /* an ALL-DAY offer covers every slot on the day, INCLUDING one whose window
     crosses midnight — a night sortie landing after 00:00 (slotEnd>1439), an
     SC night shift (…07:00), a small-hours take-off (slotStart<0). The day-
     bounded [0,1439] window would fail containment against those and wrongly
     read "available 00:00–23:59 only"; short-circuit to ok, matching the four
     midnight-tail blocks slotBar already carries for absences. A half/custom
     offer that genuinely does not reach past midnight still reads 'window'. */
  if(rec.allday)return {status:'ok'};
  const w=sansWindow(rec);
  if(w[0]<=s&&w[1]>=e)return {status:'ok'};
  return {status:'window',off:{s:w[0],e:w[1]}};
}
/* '' when they may be planned here, otherwise the reason they may not */
/* `fromKey` (5 Sep 26): the seat the man is being MOVED from, when this is a
   seat-to-seat drag — the cross-day question below then reads him as off
   that seat (a run counts the day off if it was his only event; a leg being
   moved cannot break its own crew rest), so the hover reason describes the
   schedule AFTER the move, not before. Omitted by every other caller. */
/* ONE MAN, ONCE PER ROW — REFUSED (owner, D271, 27 Sep 26 — "Q1 refused", to the five-flags mock-up's Question 1:
   "A man put on a row he's already on: warn, or refuse? … Recommended: refuse."). A crowd, a desk's or a ground row's
   extras and a sim's seats each hold PEOPLE'S places; the same man on two of them says nothing a scheduler wants and
   hides a mistake. So a drop (from the crew list or from another row) and the armed palette tap that would put him on
   a row where he already stands WRITE NOTHING: the row keeps its one copy, nothing reads pending, and the message says
   why — `<callsign> — ` + this sentence ("Ranger — already on FLIGHT SAFETY STAND-DOWN 08:30–09:00 · not added twice").
   It NARROWS "everything plants, warning after" (owner, 13 Aug 26) for this one case, the second hard refusal after
   D33's placeholder in a cockpit, and like D33's it is asked BEFORE anything is written, at every door — drag.ts
   applyDrop (a seat, a swap, a "+ add" cell) and state/view.ts placeArmed (an armed place, an armed "+ add") — so a
   swap's second write never runs behind a refused first one. It is also the reason the busy check below gives (slotBar),
   so the drag caption and the crew list's struck line say it before the drop does.
   The question: does he stand on this row at ANOTHER place than the one asked about (`key` — none for a "+ add", which
   is a new place), and not the place he is being moved FROM (`fromKey`)? So (his readings, stated to him): a man on
   two DIFFERENT rows is still only warned (the busy check); a swap of two men inside one crowd moves nobody onto a
   second place and still works (D274 item 3); a man from the crew list dropped onto ANOTHER man's place in a crowd he
   is already in — which would replace that man and leave him there twice — is refused the same way. A placeholder
   (ALL, ALL AVAIL) is not a man and is left out (it is silent on every row it may stand on, D33) — his "Leave", D278. A
   flying line's two seats are not one of these rows (`rowPlaces` lists none for a flying key): one man in FCP and RCP of
   one jet stays the red "two events at once" warning, his "Leave it no change", D276. A crowd's or a sim
   box's own bare key (`a:0.2`, `s:2.oft.0`) names the ROW, not a place, and no door asks with one; older callers and
   tests reading it as "this row" are left to the busy check, as before. */
export function rowTwice(id:any,key:any,fromKey?:any):string{
  if(!id||!PEOPLE[id]||isSpecial(id))return '';
  const ks=String(key), row=selfKey(key), here=/\.\+$/.test(ks)?null:ks, from=fromKey!=null?String(fromKey):null;
  if(row===ks&&/^[as]:/.test(ks))return '';
  if(!rowPlaces(row).some((x:any)=>x.id===id&&x.key!==here&&x.key!==from))return '';
  const di=keyDay(ks), ev=di>=0?dayEvents(di,id).find((e:any)=>selfKey(e.slot||e.key)===row):null;
  return (ev&&ev.s!=null&&ev.e!=null?`already on ${ev.label} ${hm24(ev.s)}–${hm24(ev.e)}`:'already on this row')+' · not added twice';
}
export function slotBar(id:any,key:any,rules?:any,fromKey?:any){
  const p=PEOPLE[id]; if(!p)return '';
  /* THE ONE HARD REFUSAL (D33). A placeholder is silent on every seat it is
     allowed on — it is not a person and no rule measures it — but on a jet it
     is refused, and the refusal has to SAY SO here, because this is the body the
     drag ghost, the drop message and the palette's struck-out row all read. One
     string, one source: ui cannot spell it differently. */
  if(p.special)return sentinelSeatOK(key,id)?'':SENTINEL_JET_BAR;
  const r=rules||slotRules(key);
  /* ONE MAN, ONCE PER ROW — refused, so said before the drop as well as by it (rowTwice, above; D271). Ahead of the ⓘ
     info-only exit: an FYI row lists anyone, absences and clashes included, but not the same man twice. */
  {const t=rowTwice(id,key,fromKey); if(t)return t;}
  /* an ⓘ info-only row raises nothing after planting (it never enters the event
     stream), so the picker must raise nothing before it — the standing rule that
     the picker and the warning list may not drift. Anyone may be listed on an
     FYI item, absences and clashes included. */
  if(r.infoRow)return '';
  /* Personnel (ground crew) may ride a REAR seat (an incentive ride) and do
     ground work, but never a front seat — flying or sim. Their seat is 'GND',
     so the FCP/RCP checks below never catch them; this is the whole front-seat
     bar for them. Everything else (rear seat, duty, ground, sim-rear) falls
     through to the normal input/busy checks. */
  if(p.pers&&r.seat==='p')return 'ground crew — rear seat only, cannot fly front seat';
  if(r.seat==='p'&&p.seat==='RCP')return 'WSO — cannot fly front seat';
  /* belt and braces, mirrored from the validator (validate.ts Q): CAT IW is a
     WSO-only category, so an IW record whose seat says FCP is inconsistent data
     — the Quals dropdowns never offer it, but a hand-edit could. The picker must
     red the same drag-drop the warning list does, or the two drift (7 Sep 26). */
  if(r.seat==='p'&&p.q==='IW'&&p.seat==='FCP')return 'CAT IW — a WSO category, cannot fly FCP';
  /* NO rear-seat instructor bar (owner, 7 Sep 26 — "don't flag out that they
     are in an illegal seat"): any pilot may ride any back seat, jet or sim, so
     the picker raises nothing on that count, matching the validator which no
     longer emits the QUAL either. The seat's OTHER bars below — SC currency,
     one-man-two-places, rest, busy — are their own rules and still apply. */
  if(r.sc&&!scQualOK(id,r.sc))return `not ${r.sc==='day'?'SC DAY':'SC NIGHT'} current`;
  /* every AVALON / BB jet seat wants SC currency for its hours (owner, 7 Sep
     26 — MAIN, then "AVALON SPARE also requires SC NIGHT") — the validator's
     SC_QUAL on that seat, refused here first so the two never disagree */
  if(r.avJet&&r.avKind&&!scQualOK(id,r.avKind))return `not ${r.avKind==='day'?'SC DAY':'SC NIGHT'} current`;
  /* TWO SC SEATS IN THE SAME HOURS bar the plant (owner, 31 Aug 26) — the
     same scSeatHit body the validator reads, so what bars here and what
     reds after a drag-drop can never disagree. Spares are absent from EVD,
     which is why the inside-this-shift scan below cannot answer this; runs
     for MAIN and SPARE slots alike. Abutting shifts pass (overlap is
     half-open) — a man on SC AM is still offered normally for SC PM. */
  /* every walk below excludes the seat being planned into AND, on a drag, the
     seat the man is leaving (fromKey) — the hover describes the week AFTER the
     move, as crossDayIfPlaced already does (reviewer, 7 Sep 26) */
  /* …the seat he LEAVES only when he leaves its row: a man standing on that row twice (a second copy is warned, not
     refused — "everything plants, warning after") still stands on it when one copy moves (Astra's read, 26 Sep 26) */
  const fromRow=fromKey!=null?selfKey(fromKey):null;
  const leaves=fromRow!=null&&!rowPlaces(fromRow).some((x:any)=>x.id===id&&x.key!==String(fromKey));
  const selfKeys=[selfKey(key),leaves?fromRow:null];
  if(r.sc&&r.scStart!=null&&r.scEnd!=null&&r.di>=0){
    const hit=scSeatHit(r.di,id,r.scStart,r.scEnd,selfKeys);
    if(hit)return `already on ${hit.what} ${hm24(hit.s)}–${hm24(hit.e)}`;
  }
  /* …AND THE SC DESK asks the same question of the SC seats (7 Sep 26): a
     man standing SC SPARE is no event, so only this walk can refuse him the
     desk; a MAIN is an event and the busy scan below would say so anyway. */
  if(r.scDesk&&r.slotStart!=null&&r.slotEnd!=null&&r.di>=0){
    const hit=scSeatHit(r.di,id,r.slotStart,r.slotEnd,selfKeys);
    if(hit)return `already on ${hit.what} ${hm24(hit.s)}–${hm24(hit.e)}`;
  }
  /* ONE MAN IN TWO AVALON PLACES (owner, 7 Sep 26) — a seat or the desk asks
     avSeatHit, the body the validator's DOUBLE_BOOK reads after a drop.
     Nothing on AVALON is an event (noconf), so the busy scan below is blind
     to it — and spare-like seats skip that scan anyway. */
  if((r.avJet||r.avDuty)&&r.slotStart!=null&&r.slotEnd!=null&&r.di>=0){
    const hit=avSeatHit(r.di,id,r.slotStart,r.slotEnd,selfKeys,!!r.avDuty);   // a desk asks about seats only
    if(hit)return `already on ${hit.what} ${hm24(hit.s)}–${hm24(hit.e)}`;
  }
  /* SC is treated as flying for crew rest: 12h clear of yesterday or he cannot
     be planned onto the shift at all. Read off the map validate() builds. */
  if(r.scStart!=null&&r.di>=0&&!r.scSpare){
    const cl=restClear(r.di,id);
    if(cl!=null&&cl>r.scStart)return `crew rest — not clear until ${hm24(cl)}`;
  }
  /* AN SC SLOT IS JUDGED AGAINST ITS OWN SHIFT WINDOW, NOT THE WHOLE DAY.
     Being tasked somewhere else on the day says nothing about whether a man can
     stand this shift — SC AM 07–13 and SC PM 13–19 are two clean halves and a
     body on one is perfectly plannable on the other. What bars him is a
     commitment INSIDE the window, and only the hard kinds: a flight, a sim, a
     duty post, another shift — plus, since 26 Aug 26, a GROUND ROW that is a
     red-list commitment (shiftEvHard, one body with the validator's clash
     grading). Any other ground event or programme item inside the window does
     not bar him — plan it and the engine says so in amber. A raw red-list
     INPUT deliberately stays warn-not-bar here, matching the flying-seat
     modality (inputs.ts:178-181): the validator reds him after planting. */
  if(r.sc&&r.scStart!=null&&r.scEnd!=null&&r.di>=0&&!r.scSpare){
    /* not the seat being planted into, and — on a drag — not the one he is dragged FROM (selfKeys, as the walks above
       read it; W3's walk, 26 Sep 26: a MAIN man dragged to another MAIN seat of the same shift was captioned "inside
       this shift" about the shift he was leaving, while the drop said nothing) */
    const live=(e:any)=>shiftEvHard(e)&&e.s!=null&&e.e!=null&&selfKeys.indexOf(selfKey(e.slot||e.key))<0;
    /* both windows are already minutes-from-midnight of day r.di, so plain
       overlap is the whole answer here */
    let hit=dayEvents(r.di,id).find((e:any)=>live(e)&&overlap(r.scStart,r.scEnd,e.s,e.e));
    /* a shift written 19:00–07:00 runs past midnight: its tail belongs to the
       NEXT day, so look there too, with the window rolled back a day */
    if(!hit&&r.scEnd>1440)
      hit=dayEvents(r.di+1,id).find((e:any)=>live(e)&&overlap(r.scStart-1440,r.scEnd-1440,e.s,e.e));
    if(hit)return `on ${hit.label} ${hm24(hit.s)}–${hm24(hit.e)} — inside this shift`;
  }
  if(r.aar&&r.seat==='p'&&!aarOK(id,r.aar))return `not ${r.aar} current`;
  if(r.di>=0&&DAYS[r.di]){
    /* WHY A PERSONAL INPUT CLOSES THIS SLOT — three filters, and the ORDER of
       the last one matters.
       · A STANDALONE SPARE is standby, not a task, so a type that may spare
         does not close it (canSpare: local yes, overseas no, medical never).
         AN AVALON SEAT — jet or desk, MAIN or SPARE (owner, 11 Aug 26) — bars
         exactly what the validator's one check flags: canSpare, with canWork
         already carving ATT B out of a desk below. Folded into the same
         `spareLike` flag as the SC spare so the picker and the warning list
         cannot drift apart — local leave no longer folds a man away from an
         AVALON seat, because the engine raises nothing for it either.
       · ATT B is grounded, not absent, so it closes a FLYING seat only — a
         duty post, a sim seat or a ground row is proper work for him. A flying
         key is the one with no prefix.
       · A HALF-DAY closes its own half. day.input has carried s/e since the
         validator learned to overlap them; this was the last place still
         reading every absence as the whole day, so a man on AM leave was
         struck out of an evening sortie nothing had a complaint about.
         An all-day absence — or one whose record is too thin to place — must
         short-circuit BEFORE any overlap test, and a slot with no window of
         its own keeps the old whole-day answer. Unknown is not "never
         clashes", on either side. */
    /* one place the absence's window is read, through inpWin, so an absence
       typed across midnight rolls here exactly as it does in events.ts — the
       picker and the warning list are required not to drift apart, and this is
       the shape neither of them could see before. `shift` is 0 for today, and
       ±1440 for the two tails. */
    const inpHits=(x:any,shift:number)=>{const w2=inpWin(x);
      return !!w2&&overlap(r.slotStart,r.slotEnd,w2[0]+shift,w2[1]+shift);};
    const spareLike=!!(r.sc&&r.scSpare)||!!r.avJet||!!r.avDuty;
    const flying=String(key).indexOf(':')<0;
    const kn=r.slotStart!=null&&r.slotEnd!=null;
    const off=inputsOn(DAYS[r.di].dt).filter((x:any)=>isAway(x)&&x.person===id)
      .filter((x:any)=>!(spareLike&&canSpare(x.type)))
      .filter((x:any)=>!(canWork(x.type)&&!flying))
      .filter((x:any)=>!kn||awayAllDay(x)||inpHits(x,0));
    if(off.length)return offWord(off[0]);
    /* THE MIDNIGHT TAIL, picker side (owner, 11 Aug 26 — same modality as
       events.ts's day.input, so the picker and the warning list cannot
       disagree). A slot whose window runs past 1440 has a tail that belongs
       to TOMORROW; the same filter chain runs again over tomorrow's inputs,
       shifted +1440 so they land in this slot's minute-space, with an
       all-day (or thin) record covering the whole shifted day so it always
       overlaps a past-midnight window. */
    const nd=kn&&r.slotEnd>1440&&r.di>=0?DAYS[r.di+1]:null;
    const off2=!nd?[]:inputsOn(nd.dt).filter((x:any)=>isAway(x)&&x.person===id)
      .filter((x:any)=>!(spareLike&&canSpare(x.type)))
      .filter((x:any)=>!(canWork(x.type)&&!flying))
      .filter((x:any)=>awayAllDay(x)||inpHits(x,1440));
    if(off2.length)return offWord(off2[0])+' (tomorrow)';
    /* ...and the same tail BACKWARDS, for the same reason and by the same
       chain (see events.ts's matching block). A slot whose window opens before
       minute 0 — a small-hours take-off, whose step and brief run back into the
       previous evening — has a tail belonging to YESTERDAY, shifted −1440 into
       this slot's minute-space. Without this the picker offered a man who was
       at a meeting the night before, and the warning list stayed silent too, so
       the two agreed only by both being wrong. */
    const pdv=kn&&r.slotStart<0&&r.di>0?DAYS[r.di-1]:null;
    const off3=!pdv?[]:inputsOn(pdv.dt).filter((x:any)=>isAway(x)&&x.person===id)
      .filter((x:any)=>!(spareLike&&canSpare(x.type)))
      .filter((x:any)=>!(canWork(x.type)&&!flying))
      .filter((x:any)=>awayAllDay(x)||inpHits(x,-1440));
    if(off3.length)return offWord(off3[0])+' (yesterday)';
    /* A different backward reach, and it is NOT the block above. An absence
       typed ACROSS midnight yesterday (22:00–02:00) rolls past 1440, so its
       second half lands on TODAY's early minutes — which an ordinary 01:00 duty
       post runs into without its own window ever going negative. Checked
       WITHOUT the awayAllDay shortcut the block above relies on: that shortcut
       is sound only when the slot itself reaches back into yesterday, whereas
       an ordinary all-day absence yesterday says nothing whatever about today.
       So only records whose rolled window genuinely passes midnight qualify. */
    const pdo=kn&&r.di>0?DAYS[r.di-1]:null;
    const off4=!pdo?[]:inputsOn(pdo.dt).filter((x:any)=>isAway(x)&&x.person===id)
      .filter((x:any)=>!(spareLike&&canSpare(x.type)))
      .filter((x:any)=>!(canWork(x.type)&&!flying))
      .filter((x:any)=>{const w2=inpWin(x); return !!w2&&w2[1]>1440&&inpHits(x,-1440);});
    if(off4.length)return offWord(off4[0])+' (overnight)';
  }
  /* THE SANS AVAILABILITY GATE, PICKER SIDE (owner, 14 Aug 26). Absences
     outrank this — a SANS man on leave reads as on-leave, not as "no record
     filed" — so it sits AFTER the four absence blocks above and BEFORE the
     ordinary busy-at-this-hour check below: an offer that doesn't cover this
     slot is a closer reason than "already on something else today".
     `domain` is which offer this SLOT needs judging against: a sim key
     carries its own kind (simKind, from slotRules' `s:` branch); an
     unprefixed key is a flying seat; every other kind — duty, ground,
     programme — is null, and null never gates (owner's rule: "any ground
     event can also be planned"). Only a SANS person (p.san) is judged at
     all — sansGate itself would return 'na' for anyone else, but checking
     here first skips the lookup for the other fifty-odd names.
     The three printed reasons are the same three the validator's SANS_AVAIL
     advisory and the palette's badge agree on — one function, sansGate,
     decides all of it, and this is its only call site inside slotBar. */
  /* spare-like seats are carved out, the same as the four absence blocks above
     (spareLike there) and the busy-at-this-hour block below (spareLike0): an SC
     SPARE aircraft and a whole AVALON/BB wave never reach day.fly/day.events
     (events.ts saExempt / the standalone skip), so the VALIDATOR raises no
     SANS_AVAIL against them — greying them on the picker would be the picker
     saying what the warning list will not, the drift-seam this gate must avoid. */
  const domain=r.sim?r.simKind:(String(key).indexOf(':')<0?'fly':null);
  if(domain&&p.san&&r.di>=0&&DAYS[r.di]&&r.slotStart!=null&&r.slotEnd!=null&&!spareLike0(r)){
    /* a flying seat is judged from its IN-TIME front edge (sansStart, set in
       slotRules' flying branch); a sim key sets no sansStart and falls back
       to the box's own start — a sim window is read AS FILED, unchanged */
    const g=sansGate(id,DAYS[r.di].dt,domain,r.sansStart!=null?r.sansStart:r.slotStart,r.slotEnd);
    if(g.status==='none')return 'SANS — no availability filed for today';
    if(g.status==='not-offered')return `SANS — not offering ${SANS_LABEL[domain]}`;
    if(g.status==='window')return `SANS — available ${hm24(g.off.s)}–${hm24(g.off.e)} only`;
  }
  /* IS HE ALREADY BUSY AT THIS HOUR?
     The SC block above asks exactly this, for a shift. Every other slot asked
     nothing at all: the picker knew "tasked somewhere today" — a faint dimming,
     captioned "you can still plan him" — and never "tasked AT THIS TIME". So it
     offered a man who was airborne for an overlapping sim seat with no reason
     against him, and planting him raised a hard clash the same instant (owner,
     11 Aug 26, who found the same hole from the other end: two sorties on one
     man at one time went unflagged). events.ts has carried `slot`/`key` on every
     event for precisely this question — "is he busy at this hour, not counting
     the very seat I am about to plant him into".
     Kept in step with the validator on all three counts: every kind of event
     counts, because every non-shift overlap it finds is a hard DOUBLE_BOOK; a
     STANDBY spare is exempt, because he is deliberately free for anything else;
     and the seat being planned into is excluded, so an ordinary swap is silent.
     Advisory in force, like every other bar here — the name still shows with the
     reason against it, and a drop still goes through with a warning.
     …and, on a drag, the seat he is being dragged FROM is excluded too
     ([CROWD-SWAP-SAYS-BUSY], 26 Sep 26): the SC and AVALON walks above already
     read `selfKeys` so the hover describes the week AFTER the move (5 and 7 Sep
     26), and this scan was the one that still told a man he was "already on" the
     row he was leaving — a hover the drop then contradicted. */
  if(r.slotStart!=null&&r.slotEnd!=null&&r.di>=0&&!r.sc&&!spareLike0(r)){
    const hit=dayEvents(r.di,id).find((e:any)=>e.s!=null&&e.e!=null
      &&selfKeys.indexOf(selfKey(e.slot||e.key))<0&&overlap(r.slotStart,r.slotEnd,e.s,e.e));
    if(hit)return `already on ${hit.label} ${hm24(hit.s)}–${hm24(hit.e)}`;
    /* AND THE SAME QUESTION FOR AN UNACCEPTED PERSONAL COMMITMENT (owner, Aug 26).
       An activity input (a meeting, an appointment) that is NOT on the Ground
       Programme lives only in day.input: the VALIDATOR reads it and raises
       INPUT_FLY the instant a man is planted onto it, but it never became a
       day.event, so the EVD scan above could not see it and the picker stayed
       silent while the warning list would complain — the one drift the picker
       and the warning list must never have. This closes it with the SAME soft
       "already on X" a scheduled event gives, NOT a strike-out: an activity
       type is deliberately never struck from the palette (inputs.ts), only
       advised against, so the man still shows and the drop still goes through.
       isAway types are handled by the four absence blocks above; a commitment
       already promoted to a ground row is carried by the EVD scan just above.
       The gate that keeps only the live-voice ones here is `inpShow` — the
       SAME per-day gate the validator uses to build day.input (events.ts), not
       a second copy: inputFlags() alone was DAY-BLIND, so a timed accepted
       input that covers several days but lands a ground row on only ONE of them
       stayed hidden from the picker on the OTHER covered days while the
       validator still raised INPUT_FLY there — the exact drift this scan exists
       to close, reopened by a day (audit, Aug 26). inpShow defers an input only
       on its row's own day (or hides SANS offers); off that day, or when the
       row is gone entirely (an orphaned accept), it reports VISIBLE and the
       picker warns in step with the validator. Mirrors the absence blocks' four
       midnight shifts so the two cannot disagree across a day boundary either
       (the validator's day.input carries the nx/pv tails). */
    const flying=String(key).indexOf(':')<0;
    const cand=(dt:any,pred:(x:any)=>boolean)=>inputsOn(dt).find((x:any)=>
      !isAway(x)&&isPersonal(x.type)&&inpShow(x,dt)&&x.person===id
      &&!(canWork(x.type)&&!flying)&&pred(x));
    const iHit=(x:any,shift:number)=>{const w2=inpWin(x);
      return !!w2&&overlap(r.slotStart,r.slotEnd,w2[0]+shift,w2[1]+shift);};
    const onWord=(x:any,suf:string)=>{const w2=inpWin(x);
      const tm=(!awayAllDay(x)&&w2)?` ${hm24(w2[0])}–${hm24(w2[1])}`:'';
      return `already on ${inpLabel(x)}${tm}${suf}`;};
    const t0=cand(DAYS[r.di].dt,(x:any)=>awayAllDay(x)||iHit(x,0));
    if(t0)return onWord(t0,'');
    const nd=r.slotEnd>1440?DAYS[r.di+1]:null;
    const t1=!nd?null:cand(nd.dt,(x:any)=>awayAllDay(x)||iHit(x,1440));
    if(t1)return onWord(t1,' (tomorrow)');
    const pdv=r.slotStart<0&&r.di>0?DAYS[r.di-1]:null;
    const t2=!pdv?null:cand(pdv.dt,(x:any)=>awayAllDay(x)||iHit(x,-1440));
    if(t2)return onWord(t2,' (yesterday)');
    const pdo=r.di>0?DAYS[r.di-1]:null;
    const t3=!pdo?null:cand(pdo.dt,(x:any)=>{const w2=inpWin(x);return !!w2&&w2[1]>1440&&iHit(x,-1440);});
    if(t3)return onWord(t3,' (overnight)');
  }
  /* THE TWO HARD CROSS-DAY RULES, LAST (5 Sep 26 — step 3 of the flagging
     plan): would landing here be his seventh day in a row, or break crew
     rest against yesterday's end or tomorrow's report? Read off the
     validator's own tables (validate.ts crossDayIfPlaced), never a second
     copy. Last because every reason above is a closer fact about THIS slot;
     this one is about the days around it. Warn-not-bar like the rest. */
  if(!r.saExempt){const xd=crossDayIfPlaced(id,key,fromKey); if(xd)return xd;}
  return '';
}
/* An armed key names a SEAT; an event names the ROW it came off. Bring the two
   to the same shape so "the slot I am planting into" can be excluded — without
   this a swap warns about the seat the man is being moved out of. A flying event
   already stores the full seat key, so it is compared as it stands. */
/* The one body is engine/keys.ts seatRow, shared with the validator's "the seat he is leaving" ([CROWD-SWAP-SAYS-BUSY],
   26 Sep 26 — its programme trim used to take the ROW's own number off an event's key, so a man moved inside his own
   crowd was "already on" it). */
const selfKey=seatRow;
const spareLike0=(r:any)=>!!(r.sc&&r.scSpare)||!!r.avJet||!!r.avDuty;
