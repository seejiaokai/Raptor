import { DAYS } from './data'
import { SCHED } from './publish'
import { elogRemap } from './editlog'
import { HOOKS } from './hooks'
/* ---- day bookkeeping ------------------------------------------------------
   Every amendment key starts with its day index, whatever the prefix:
     0.1.0.0.p   ar:0.1.0   at:0.1.0   st:0.1.0.0   it:0.1
     d:0.0.1     s:0.amt.1.pax.3        g:0.2        a:0.4.0
   so one parse serves them all and an AL can always say which days it touched. */
export function keyDay(key:any){const s=String(key),c=s.indexOf(':');
  const n=parseInt((c<0?s:s.slice(c+1)).split('.')[0],10);
  return Number.isFinite(n)?n:-1;}
/* ---- WHICH ROW IS THIS — one shape for a seat key and an event's key ([CROWD-SWAP-SAYS-BUSY], 26 Sep 26) ----------
   A seat key names a PERSON'S place (a crowd seat `a:0.2.1`, an extra `g:0.3.x0`, a sim seat `s:0.amt.1.p`, a pax
   `s:0.amt.1.pax.2`, an append box `a:0.2.+`); an event names the ROW it came off (`a:0.2`, `g:0.3`, `s:0.amt.1`). Every
   "is this the place he is being planted into / dragged from" question compares the two, so both go through here. A
   flying seat is compared as it stands (a flying event stores the full seat key). The programme trim takes ONLY the
   person index: it used to take the last number off anything `a:`-shaped, so the row `a:0.2` came out as `a:0` — a man
   moved inside the crowd he was on was "already on" his own row, and arming a crowd's "+ add" excluded every programme
   row of the day. Readers: avail.ts selfKey (the crew picker's busy checks), validate.ts crossDayIfPlaced / restIfPlaced
   (the seat he is leaving). */
export function seatRow(k:any){
  let s=String(k==null?'':k).replace(/\.\+$/,'').replace(/\.x\d+$/,'');
  if(s.indexOf(':')<0)return s;                              // flying: di.gi.li.ai.seat
  s=s.replace(/\.pax\.\d+$/,'').replace(/\.(p|w)$/,'');      // a sim's two seats and its pax
  return s.replace(/^(a:\d+\.\d+)\.\d+$/,'$1');              // programme: a place in the crowd → its row
}
export function uniqDays(keys:any):any[]{return [...new Set((keys||[]).map(keyDay))].filter((i:any)=>i>=0&&i<DAYS.length).sort((a:any,b:any)=>a-b);}
/* ---------------------------------------------------------------------------
   DELETING A ROW RENUMBERS EVERYTHING AFTER IT
   The amendment machinery addresses rows by index — dn:0.2, ap:0.3.prog,
   fr:0.1.0.3, and the bare flying key 0.1.0.3.p — so a plain splice silently
   slides every mark past the cut onto the wrong row: an AL1 tint lands on a note
   nobody amended, and the issued AL record permanently mis-attributes which item
   it changed. shiftKeys() rewrites the key space to match the splice — marks ON
   the deleted row are dropped, marks after it move down one — across pending,
   changes and every issued AL. `head` is the literal text a key must start with,
   `pos` is which dot-separated component after `head` carries the index.
   --------------------------------------------------------------------------- */
export function shiftKeys(head:any,pos:any,ix:any){
  if(!head||!isFinite(ix))return;
  const move=(k:any)=>{
    if(String(k).indexOf(head)!==0)return k;            // a different key space
    const a=k.slice(head.length).split('.');
    const n=+a[pos];
    if(!isFinite(n)||n<ix)return k;                     // before the cut
    if(n===ix)return null;                              // the row itself is gone
    a[pos]=String(n-1);
    return head+a.join('.');
  };
  const remap=(o:any)=>{const out:any={}; Object.keys(o||{}).forEach((k:any)=>{const m=move(k); if(m)out[m]=o[k];}); return out;};
  SCHED.pending=remap(SCHED.pending);
  SCHED.changes=remap(SCHED.changes);
  SCHED.added=remap(SCHED.added);
  /* A Phase-2 AL record carries a frozen `diff` + snapshot, not live keys/adds/
     structAdds — those three fields were removed from the record contract. The old
     `a.keys=(a.keys||[]).map(...)` form ASSIGNED an empty array to an ABSENT field,
     re-adding all three onto every issued current-format record (on unrelated days
     too), so the serialized document diverged from the contract though snap/diff
     stayed intact (P2-REV2-08). Remap ONLY a field that is actually present — a
     legacy record's keys as before, a Phase-2 record genuinely untouched. The
     frozen `snap`/`diff` are never touched either way. */
  (SCHED.als||[]).forEach((a:any)=>{
    if(a.keys)a.keys=a.keys.map(move).filter(Boolean);
    if(a.adds)a.adds=a.adds.map(move).filter(Boolean);
    if(a.structAdds)a.structAdds=a.structAdds.map(move).filter(Boolean);
  });
  elogRemap(move);   // the edit log addresses rows by the same keys (editlog.ts)
  HOOKS.remapViewKeys(move);   // and so does key-addressed view state (hooks.ts)
}
/* ---------------------------------------------------------------------------
   REORDERING A LIST RENUMBERS IT TOO — and unlike a delete, nothing may be lost
   shiftKeys() above handles a splice: marks ON the cut row are dropped, marks
   after it move down one. A reorder is the other shape — every row survives and
   simply changes address, so the remap must be a BIJECTION. Drop a key here and
   an issued AL silently forgets an amendment; collide two and one amendment
   permanently re-labels itself as being about a different sortie. Neither shows
   on screen, which is why this is tested on its own before anything calls it.
   `oldOf[newIndex] = oldIndex` — the same shape groundOrder() already returns,
   so freezing a rendered order and moving one row are the same operation.
   An index outside the permutation is left ALONE rather than dropped: a stale
   key from a longer list is inert, a vanished one is a lost record.
   --------------------------------------------------------------------------- */
export function permuteKeys(head:any,pos:any,oldOf:any){
  if(!head||!Array.isArray(oldOf))return;
  const newOf:any={}; oldOf.forEach((o:any,n:any)=>{newOf[o]=n;});
  const move=(k:any)=>{
    if(String(k).indexOf(head)!==0)return k;            // a different key space
    const a=k.slice(head.length).split('.');
    const n=+a[pos];
    if(!isFinite(n)||!(n in newOf))return k;
    a[pos]=String(newOf[n]);
    return head+a.join('.');
  };
  const remap=(o:any)=>{const out:any={}; Object.keys(o||{}).forEach((k:any)=>{out[move(k)]=o[k];}); return out;};
  SCHED.pending=remap(SCHED.pending);
  SCHED.changes=remap(SCHED.changes);
  SCHED.added=remap(SCHED.added);
  /* remap ONLY a present field — never assign an empty array onto an absent one, or
     a Phase-2 record gains three fields its contract removed (P2-REV2-08). A legacy
     record's keys are remapped as before; a Phase-2 record is genuinely untouched. */
  (SCHED.als||[]).forEach((a:any)=>{
    if(a.keys)a.keys=a.keys.map(move);
    if(a.adds)a.adds=a.adds.map(move);
    if(a.structAdds)a.structAdds=a.structAdds.map(move);
  });
  elogRemap(move);   // the edit log addresses rows by the same keys (editlog.ts)
  HOOKS.remapViewKeys(move);   // and so does key-addressed view state (hooks.ts)
}
/* one row moving to another position, `to` being its index AFTER removal —
   plain splice-out / splice-in, the same arithmetic the model array does. */
export function moveKeys(head:any,pos:any,from:any,to:any,len:any){
  if(!isFinite(from)||!isFinite(to)||from===to)return;
  if(!isFinite(len)||from<0||to<0||from>=len||to>=len)return;
  const oldOf=[]; for(let i=0;i<len;i++)oldOf.push(i);
  oldOf.splice(to,0,oldOf.splice(from,1)[0]);
  permuteKeys(head,pos,oldOf);
}
/* every key space that carries an AIRCRAFT index on one formation */
export function shiftAircraft(di:any,gi:any,li:any,ai:any){
  [`fr:${di}.${gi}.${li}.`,`st:${di}.${gi}.${li}.`,`${di}.${gi}.${li}.`]
    .forEach((h:any)=>shiftKeys(h,0,ai));
}
/* every key space that carries a FORMATION index on one wave */
export function shiftFormation(di:any,gi:any,li:any){
  [`ff:${di}.${gi}.`,`fr:${di}.${gi}.`,`st:${di}.${gi}.`,`ar:${di}.${gi}.`,`at:${di}.${gi}.`,
   `${di}.${gi}.`].forEach((h:any)=>shiftKeys(h,0,li));
}
/* every key space that carries a WAVE index on one day */
export function shiftWave(di:any,gi:any){
  [`wl:${di}.`,`ff:${di}.`,`fr:${di}.`,`st:${di}.`,`ar:${di}.`,`at:${di}.`,`it:${di}.`,
   `tr:${di}.`,`${di}.`].forEach((h:any)=>shiftKeys(h,0,gi));
}
