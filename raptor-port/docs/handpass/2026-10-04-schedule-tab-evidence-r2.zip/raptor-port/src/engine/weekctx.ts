/* CROSS-WEEK SEED READS for validate.ts (owner ask: the warnings engine reads
   continuously across week boundaries — a 7-day run and a Sunday-into-Monday
   rest bust must both be caught, not just what fits inside the loaded week).
   Everything here is a PURE READ off weekBundle(v) + the global (date-keyed)
   INPUTS array — nothing here mutates SCHED, DAYS, or INPUTS.

   WINDOW SEMANTICS: bounded both ways — up to VCONF.maxRun days before the
   loaded week's Monday for the consecutive-days run (seedRunIn), 1 day back
   for crew rest (prevSundaySeed), and 1 day FORWARD (nextMondaySeed) for the
   forward crew-rest trace: the "Breaks Monday" box on a Sunday whose late
   finish busts next week's Monday (owner, 23 Aug 26 — planning it must flag
   "just like what u see for outlaw"). The midnight sliver (a Sunday shift
   running past 23:59 reading next Monday's inputs) lives in buildDay's own
   tails (events.ts), not here. Every flag still lands on the day it breaks —
   next Monday's own breach warning fires when next week is loaded and
   validated, seeded by THIS week's Sunday through prevSundaySeed; the
   forward trace is a pointer to it, not a second warning.

   WHAT A NON-LOADED WEEK ANSWERS WITH (since the per-week session stash,
   23 Aug 26): bundle() below reads the STASH first — what loadWeek last saw
   of a week the scheduler actually edited (weekstash.ts, persisted per
   browser) — and falls back to `weekBundle(v)`'s pure seed/authored shape
   for a week never touched. Either way a seed read matches exactly what a
   scheduler sees on navigating back to that week — nothing is invented and
   nothing is silently wrong. SCHED (publish/amendment state) rides the
   stash for the week's own restore but is deliberately not read here: the
   rules judge the programme, not its publication state. ("Personal INPUTS
   are GLOBAL" in CLAUDE.md stays the other half — INPUTS is read live here,
   not off the bundle.) */
import { weekBundle, shiftWeekKey } from './weeks-data'
import { buildDay } from './events'
import { INPUTS, inputsOn, frozenInputDiffs, inputCoversDate, isPersonal, inputDormant, baseYear, inpId } from './inputs'
import { PEOPLE, isSpecial } from './people'
import { stashDays, stashSched, stashGet } from './weekstash'
import { getWorld, filingActive, filingHas } from './world'
import { dayCurVerIn, daySnapIn } from './publish'
import { canonicalDiff } from './canonical'
import { viewOfWeek, deletedOverlayDue, landingDue } from './overlay'

/* weekBundle(v) is a pure function of v for the two authored weeks and a
   fresh-but-identical blank for everything else (weeks-data.ts) — so caching
   it by key is pure perf, never a drift seam: nothing INPUTS-dependent is
   cached here, only the bundle's own days/dates shape. Module-level and never
   cleared — the set of weeks ever asked for in one session is small.

   STASH-AWARE (the per-week session-stash fix): a week the scheduler has
   actually edited and then navigated away from is no longer well described
   by its pure seed — weekstash.ts holds what loadWeek last saw of it. Check
   stashHas FIRST, every call, before ever touching the cache: this is what
   keeps a week that GAINS a stash entry mid-session from going on serving a
   stale cached seed bundle forever after — there is nothing to invalidate,
   the stashed branch is simply checked ahead of the cache on every read.
   stashDays hands back a fresh copy every time (never itself cached), because
   unlike the seed it keeps changing while the scheduler is still editing it. */
const bundleCache:any={};
/* ONE DAY of a stashed week resolved to its OFFICIAL (signed) version
   (published-schedule flagging, §5.3). An unapproved day has no other version, so
   its working copy IS official. An approved day resolves through the SAME resolver
   OIL uses — dayCurVerIn/daySnapIn against the stash's own SCHED and week key — so a
   member's programme and their OIL credit can never disagree about "which version is
   official". An approved day whose issued snapshot cannot be resolved is PROTECTED
   (§14.1): its content is stripped so no cross-week flag is DERIVED from unavailable
   evidence — never a fall-back to the unpublished draft. */
function issuedDayIn(sc:any,di:number,v:any,working:any){
  if(!(sc.dayOK||{})[di])return working;
  const ver=dayCurVerIn(sc,di,v), snap=ver!=null?daySnapIn(sc,di,ver,v):null;
  /* the frozen CONTENT, but the NORMALIZED date from the stashed working day (Codex
     CRPF-004): a snapshot froze its dt under the year that was loaded when it was
     signed, so returning snap.d raw would re-introduce that label and, at a New Year
     boundary, address the wrong year in inputCoversDate/fileAcc. Never mutate the
     stored snapshot — spread a fresh object. */
  if(snap&&snap.d)return {...snap.d,dt:working.dt};
  return {...working,waves:[],dutywaves:[],sims:{amt:[],oft:[]},ground:[],allhands:[]};
}
function bundle(v:any){
  /* stashDays, not stashHas-then-trust: a persisted blob that fails to parse
     comes back null and the read falls through to the pure seed — a corrupt
     localStorage entry must degrade to "as if never edited", never crash a
     validate() that runs on every keystroke. */
  const st=stashDays(v);
  if(st){
    /* THE OFFICIAL WORLD (validate.ts's second pass) reads each stashed day at its
       SIGNED version, so an unpublished amendment to a neighbour week cannot leak
       into the loaded week's official flags. A never-stashed (pure-seed) week has no
       publication state and no divergence, so working IS official for it. */
    if(getWorld()==='official'){
      const sc=stashSched(v);
      if(sc)return {days:st.days.map((d:any,di:number)=>issuedDayIn(sc,di,v,d)),dates:st.dates};
    }
    return st;
  }
  /* keyed by v AND the loaded year (24 Aug 26): a blank week's labels leave
     the CURRENT baseYear() implicit (weeks-data.ts weekLabels), so the same
     v generated under one loaded year reads wrong under another — real at a
     New Year boundary, where the week of Dec 28 is read both as "next week"
     (loaded year 2026) and as "last week" (loaded year 2027). */
  const ck=v+'@'+baseYear();
  if(!(ck in bundleCache))bundleCache[ck]=weekBundle(v);
  /* a man deleted, and a request's row landed, worked out on read on a copy — the cache holds the pure seed ([DB-READINESS]
     group A, phase 6 (d) and (c) — engine/overlay.ts viewOfWeek; Fable's round-2 F2: a week nobody has saved lands its
     requests too, so the checks read it as they would with it open). A week never saved has no publication state. */
  if(!deletedOverlayDue(v)&&!landingDue(v))return bundleCache[ck];
  const b=bundleCache[ck], days=JSON.parse(JSON.stringify(b.days));
  viewOfWeek(String(v),days,{loaded:false,issued:()=>null});
  return {...b,days};
}

/* WHICH ids counted as "on the programme" for one bundle day — the seed-side
   mirror of the two things that put a body on RUNLEN's on-set for a LOADED
   day (validate.ts): (1) an actual event (fly/shift/duty/sim/ground/prog —
   buildDay's own `events`), filtered EXACTLY as RUNLEN's `on` set is
   (`PEOPLE[e.id]&&!isSpecial(e.id)`); (2) a personal ACTIVITY input that
   would have auto-landed onto that day's ground programme had this been the
   loaded week (`isPersonal(row.type)` on a date-matching row). Since
   [DB-READINESS] phase 6 (c) a non-loaded week's own landing IS worked out on
   read (bundle() above, engine/overlay.ts viewOfWeek) — but only on the
   request's START day, while this half counts every day the input covers, and
   the Set dedups the two — so it stays, unchanged. Two of
   autoAcceptInput's own guards are deliberately NOT mirrored: `row.acc`'s
   landed states ('g'/'u'), because those record the LOADED week's landing
   only (loadWeek clears them and re-lands from scratch — an input spanning
   the boundary that is accepted on the loaded side must still count as work
   on the seed side, and the Set dedups it against any authored ground row) —
   the dormant 'r' IS honoured below, being the one acc value that rides the
   input across week switches; and dayApproved,
   which is publish state that per the file header does not exist to be read
   for a non-loaded week. xweek:true on buildDay bypasses the accepted-row dedup in inpShow
   (events.ts) — irrelevant to workedSet, which never reads day.input, but
   passed for the one buildDay contract every caller here shares. */
function workedSet(day:any,ix:any,approved?:any){
  const built=buildDay(day,ix,null,null,true);
  const ids=new Set<any>();
  (built.events||[]).forEach((e:any)=>{ if(e.id&&PEOPLE[e.id]&&!isSpecial(e.id))ids.add(e.id); });
  /* the hypothetical auto-landing of a personal ACTIVITY input models an UNSIGNED
     seed date: loadWeek would land it as a ground row, but a non-loaded week never
     does. An APPROVED date never auto-lands a working input at all (autoAcceptInput's
     own approved-day guard), and its frozen/selected document already reflects exactly
     what landed — so its events ARE the work in BOTH worlds (Codex CRPF-007/R2-005),
     matching validateCore's own RUNLEN on-set (day.events only). Skip the re-add for
     an approved date (from the stash) or a signed official date; a cancelled/unlanded
     activity must never be counted off its input. */
  const signed=approved||(filingActive()&&filingHas(day.dt));
  if(!signed){
    inputsOn(day.dt).forEach((inp:any)=>{
      if(!isPersonal(inp.type))return;
      /* a REMOVED input (acc 'r' — dormant, owner 26 Aug 26) never auto-lands. */
      if(inputDormant(inp))return;
      const id=inp.person;
      if(id&&PEOPLE[id]&&!isSpecial(id))ids.add(id);
    });
  }
  return ids;
}

/* CONSECUTIVE-DAYS SEED — per-person count of days worked immediately
   BEFORE the loaded week's Monday, walking back day by day from the
   previous week's Sunday, up to `maxRun` days (RUNLEN only needs to know
   whether a run is already AT the limit walking in, so it never needs to
   walk further than the limit itself). k=1 is the nearest day (prev Sunday),
   k=7 its Monday, k=8..14 (only reached when maxRun>7) walk into the week
   before that. A person absent on a NEARER day (smaller k) must stop
   counting even if they show up on a FARTHER one — `done` enforces that —
   and since only ids present at k=1 can possibly have a run touching the
   boundary, only those are ever tracked at all. */
export function seedRunIn(curWeek:any,maxRun:any){
  const prevKey=shiftWeekKey(curWeek,-1);
  const prevBundle=bundle(prevKey);
  let prevPrevBundle:any=null;
  const counts:any={};
  const done=new Set<any>();
  const prevSc=stashSched(prevKey); let prevPrevSc:any=undefined;
  for(let k=1;k<=maxRun;k++){
    let day:any,ix:any,sc:any;
    if(k<=7){ ix=7-k; day=prevBundle.days[ix]; sc=prevSc; }
    else{
      if(!prevPrevBundle){prevPrevBundle=bundle(shiftWeekKey(curWeek,-2)); prevPrevSc=stashSched(shiftWeekKey(curWeek,-2));}
      ix=14-k; day=prevPrevBundle.days[ix]; sc=prevPrevSc;
    }
    if(!day)break;
    /* an APPROVED seed date counts events only, in both worlds (R2-005) */
    const worked=workedSet(day,ix,!!((sc&&sc.dayOK)||{})[ix]);
    if(k===1){
      worked.forEach((id:any)=>{ counts[id]=1; });
    }else{
      Object.keys(counts).forEach((id:any)=>{
        if(done.has(id))return;
        if(worked.has(id))counts[id]++; else done.add(id);
      });
    }
  }
  return counts;
}

/* CREW-REST SEED FOR THE LOADED WEEK'S MONDAY — the previous week's Sunday,
   built the same shape as a real `ev[idx-1]` entry (validate.ts's own
   per-day accumulator) so the crew-rest block can read it with no branch of
   its own: `{events,input,dow,di:null}`. `di:null` rather than a real index
   because this day belongs to a week that was never validated — nothing
   should ever markTrace or write REST against it, and `di:null` is already
   the guarded no-op case in both (see validate.ts markTrace / w.prevDi
   consumers). Tails (nx/pv) are irrelevant here and passed null: the
   crew-rest scan reads only `ev[idx-1].events`/`.input`, never another day's
   nx/pv tail entries. */
export function prevSundaySeed(curWeek:any){
  const prevBundle=bundle(shiftWeekKey(curWeek,-1));
  const day=prevBundle.days[6];
  const built=buildDay(day,6,null,null,true);
  return {events:built.events,input:built.input,dow:built.dow,di:null};
}

/* Authored date relative to the loaded Monday. Kept inside the existing
   bundle/world window; off-week indices never address the loaded WARN/REST. */
export function datedRestSeed(curWeek:any,index:number){
  const offset=Math.floor(index/7), targetDi=((index%7)+7)%7;
  const targetWeek=shiftWeekKey(curWeek,offset), b=bundle(targetWeek);
  const built=buildDay(b.days[targetDi],targetDi,null,null,true);
  return {...built,di:null,restIndex:index,targetDi,targetWeek};
}

/* NEXT WEEK'S MONDAY AS A PHANTOM "TODAY" for the forward crew-rest trace
   (validate.ts's crewRestDay phantom pass — owner, 23 Aug 26: planning a
   late Sunday must draw the same "Breaks Monday" box the within-week edge
   draws). prevSundaySeed's mirror image, one day the other way, but the
   phantom pass computes the CURRENT day's side of the rule too, so this
   seed also carries `fly` — the rest-bearing commitments the rule anchors
   on. Reads through the same bundle() as every other seed, so an edited
   next week (the session stash) is what Sunday is judged against — exactly
   what the real Monday will validate against when its week loads. di:null:
   this day belongs to a week this WARN cannot address by index. */
/* WHO IS ON THE PROGRAMME NEXT MONDAY — the seed-side on-set (workedSet, the
   one body RUNLEN's own on-set mirrors) for the forward run trace and the
   pre-drop run query (validate.ts, 5 Sep 26): a run that reaches Sunday at
   the limit and continues into next Monday breaks THERE, and this week's
   days are the ones a scheduler can still clear. Same bundle() as every
   seed, so an edited next week (the stash) is what Sunday is judged
   against. Bounded to Monday — one lookahead day, like the crew-rest trace. */
export function nextMondayWorked(curWeek:any){
  const nextKey=shiftWeekKey(curWeek,1), nextBundle=bundle(nextKey), sc=stashSched(nextKey);
  return workedSet(nextBundle.days[0],0,!!((sc&&sc.dayOK)||{})[0]);
}
/* THE WARNINGS HIDDEN ON ONE DAY OF A WEEK THAT IS NOT LOADED ([WARN-HIDE-KEPT], owner D469 / D471 — Astra's and Fable's
   plan reads): the keys in force there. A draft day: the hides its working copy carries (`wo`, kept with the day). A
   PUBLISHED day: the hides its current issued version went out with (`w.wo`) — a hide made since waits for that day's
   next amendment (D471), so it is not in force yet. A week never saved, or one that will not parse: none. Read by the two
   marks that cross the week's edge (validate.ts shownOf — Sunday's "Breaks Monday", the run's forward mark) and by the
   next-week preview's amber time box (ui/peek.ts). Never throws — read inside validate(). */
/* ONCE PER SAVED COPY (Fable's final read F1, 1 Oct 26): the face asks this on every repaint — once per published day
   drawn, per ALL AVAIL chip, per open list — and the answer costs a parse of the whole saved week. The saved copy is
   replaced whole when it changes (a save, the hydrate, an off-week Undo), so the same string object is the same copy:
   the answer is kept against it, and `===` on it is a reference check. Never keyed on the stash's generation count,
   which a direct restore does not bump. */
const HID_MEMO=new Map<string,{s:any,set:Set<string>}>();
export function dayHidesIn(v:any,di:number):Set<string>{
  const out=new Set<string>(), s=stashGet(v); if(!s)return out;
  const mk=`${v}|${di}`, hit=HID_MEMO.get(mk); if(hit&&hit.s===s)return hit.set;
  HID_MEMO.set(mk,{s,set:out});
  try{
    const sc=stashSched(v);
    if(sc&&(sc.dayOK||{})[di]){ const ver=dayCurVerIn(sc,di,v), snap:any=ver!=null?daySnapIn(sc,di,ver,v):null;
      (((snap&&snap.w&&snap.w.wo)||[]) as any[]).forEach((k:any)=>out.add(String(k))); }
    else ((JSON.parse(s).wo||[]) as any[]).forEach((k:any)=>{ if(String(k).split('|')[0]===String(di))out.add(String(k)); });
  }catch(_e){ /* unreadable: nothing is hidden */ }
  return out;}
export function nextMondayHides(curWeek:any){ return dayHidesIn(shiftWeekKey(curWeek,1),0); }
export function nextMondaySeed(curWeek:any){
  const nextBundle=bundle(shiftWeekKey(curWeek,1));
  const built=buildDay(nextBundle.days[0],0,null,null,true);
  return {fly:built.fly,events:built.events,input:built.input,dow:built.dow,di:null};
}
/* THE ALIAS GATE'S CROSS-WEEK HALF (published-schedule flagging, §14.1/§14.2).
   validate() aliases OFFICIAL=WORKING (skips the second pass) only when NOTHING in
   the dependency window diverges. The loaded week's own approved-day deltas are
   checked by validate() directly; this answers the NEIGHBOUR half — a prior Sunday
   or next Monday that is PUBLISHED but carries an unpublished amendment in its
   stash. Without it, a delta-free loaded week would alias and a neighbour's
   amendment would silently drive the loaded week's official flags. Reads the
   STASHED days (§14.2 — dayDeltaIn reads the LIVE DAYS and cannot diff a non-loaded
   week) and diffs each approved day's signed snapshot against its stashed working
   copy. An UNRESOLVABLE approved snapshot forces the official pass (so that week is
   protected there), never an alias. Bounded to the same window the seeds read:
   prev week (crew rest + run), next Monday, and the week-before when maxRun>7. */
/* the LIVE filing (acc) for one date, keyed by input id — dayFilingFingerprint
   parameterized on a date instead of a loaded DAYS index (Codex CRPF-002/§14.2). */
function liveFilingAt(dt:any){
  const f:any={};
  (INPUTS||[]).forEach((inp:any)=>{ if(inputCoversDate(inp,dt))f[inpId(inp)]=inp.acc||''; });
  return f;
}
/* a filing divergence between a frozen fingerprint and the live filing for its date.
   MEMBERSHIP-aware (Codex CRPF-003 half): an input present now but absent when signed
   (or vice versa) is a divergence regardless of its acc value; so is a changed acc.
   Exported so the LOADED-week gate uses the same comparator (Codex R2-001), not the
   coarse filingDelta (which treats absent == present-empty). */
export function filingDivergesAt(snapFil:any,dt:any){ return filingDiffers(snapFil,dt); }
function filingDiffers(snapFil:any,dt:any,xweek?:any){
  const now=liveFilingAt(dt), was=snapFil||{};
  const ids=new Set([...Object.keys(now),...Object.keys(was)]);
  for(const id of ids){
    const inNow=Object.prototype.hasOwnProperty.call(now,id), inWas=Object.prototype.hasOwnProperty.call(was,id);
    if(inNow!==inWas)return true;
    let a=now[id]||'', b=was[id]||'';
    /* CROSS-WEEK ONLY (Fable FR-002): 'g' — an activity landed on a ground row — is
       PER-WEEK landing state. Navigation clears the live acc of every input not on the
       loaded week (store.ts applyWeekModel reconcileLandedAcc), so a neighbour signed at
       'g' reads live '' while its frozen fingerprint still holds 'g'. Left exact, that
       forces the second validate() pass on EVERY keystroke for any published neighbour
       carrying an accepted input — with no amendment anywhere. Treat 'g' and '' as the
       same signed state for the alias decision (fileAcc still honours the frozen 'g'
       during the pass, so correctness is untouched). 'r' (removed) and 'u' (filed) are
       real filing decisions that survive navigation — kept exact. The LOADED-week gate
       (filingDivergesAt) passes no xweek: there the live acc is authoritative. */
    if(xweek){ if(a==='g')a=''; if(b==='g')b=''; }
    if(a!==b)return true;
  }
  return false;
}
export function windowDiverges(curWeek:any,maxRun:any){
  const keys=[shiftWeekKey(curWeek,-1),shiftWeekKey(curWeek,1)];
  if(maxRun>7)keys.push(shiftWeekKey(curWeek,-2));
  return keys.some((v:any)=>{
    const days=stashDays(v), sc=stashSched(v);
    if(!days||!sc)return false;                     // never edited → no unpublished amendment
    for(let di=0;di<7;di++){
      if(!(sc.dayOK||{})[di])continue;
      const ver=dayCurVerIn(sc,di,v), snap=ver!=null?daySnapIn(sc,di,ver,v):null;
      if(!snap||!snap.d)return true;                // unresolvable → compute official (protect), never alias
      if(canonicalDiff(snap.d,days.days[di],di).length>0)return true;
      /* FILING divergence too (Codex CRPF-002): a signed input removed to 'r' (or a
         new one added) changes no DAYS content, so a content-only gate would alias and
         drop the signed input's contribution from OFFICIAL. */
      const dt=days.days[di]&&days.days[di].dt;
      if(dt!=null&&filingDiffers(snap.fil,dt,true))return true;   // xweek: a navigation-cleared 'g' is not a divergence (Fable FR-002)
      /* …and its INPUTS' details ([LEAVE-LATE-PUBLISHED], D178): a leave edited or filed on a published neighbour moves no
         content and no filing, so without this the loaded week would alias and read the edit live into its seeds */
      if(dt!=null&&frozenInputDiffs(snap.inp,dt).length>0)return true;
    }
    return false;
  });
}
/* THE INPUTS each stashed neighbour approved day was issued with ([LEAVE-LATE-PUBLISHED], D177–D179), keyed by date —
   windowFiling's twin, so the official pass's seeds read a published neighbour's leave, medical and SANS offers as
   issued. A protected date (no readable snapshot) holds none; a version issued before the freeze holds no copy and is
   left to the live records, as its filing is to fileAcc. */
export function windowInputs(curWeek:any,maxRun:any){
  const out:any={};
  const keys=[shiftWeekKey(curWeek,-1),shiftWeekKey(curWeek,1)];
  if(maxRun>7)keys.push(shiftWeekKey(curWeek,-2));
  keys.forEach((v:any)=>{
    const days=stashDays(v), sc=stashSched(v);
    if(!days||!sc)return;
    for(let di=0;di<7;di++){
      if(!(sc.dayOK||{})[di])continue;
      const ver=dayCurVerIn(sc,di,v), snap=ver!=null?daySnapIn(sc,di,ver,v):null;
      const dt=days.days[di]&&days.days[di].dt;
      if(dt==null)continue;
      if(!(snap&&snap.d))out[dt]={};
      else if(snap.inp)out[dt]=snap.inp;
    }
  });
  return out;
}
/* THE SIGNED FILING of each stashed neighbour approved day, keyed by date
   (published-schedule flagging, §14.3 trap a). The loaded week's own filing is
   installed by validate.ts:withIssuedWeek off the live snapshots; this is its
   cross-week half, so the official run's 7-day count and neighbour seed reads read
   the SIGNED filing there too. Same window and resolver as windowDiverges. */
export function windowFiling(curWeek:any,maxRun:any){
  const out:any={};
  const keys=[shiftWeekKey(curWeek,-1),shiftWeekKey(curWeek,1)];
  if(maxRun>7)keys.push(shiftWeekKey(curWeek,-2));
  keys.forEach((v:any)=>{
    const days=stashDays(v), sc=stashSched(v);
    if(!days||!sc)return;
    for(let di=0;di<7;di++){
      if(!(sc.dayOK||{})[di])continue;
      const ver=dayCurVerIn(sc,di,v), snap=ver!=null?daySnapIn(sc,di,ver,v):null;
      const dt=days.days[di]&&days.days[di].dt;
      /* ALWAYS install a filing entry for an approved adjacent date (Codex R3-001):
         its signed fingerprint when resolvable, else {} to PROTECT it — issuedDayIn
         strips such a day's programme, but without an empty filing here fileAcc would
         fall back to live acc and let a live commitment input leak into the seed. */
      if(dt!=null)out[dt]=(snap&&snap.d)?(snap.fil||{}):{};
    }
  });
  return out;
}
