/* ---- THE LOADABLE WEEKS ----
   The week selector (the .wk chips) switches between loaded weeks now (owner,
   21 Aug 26). `weekBundle(v)` hands state/store.ts:loadWeek a FRESH DEEP COPY
   of the chosen week's model each call — the live DAYS/INPUTS get spliced in
   place, so the backing datasets here must never be handed out directly.
     · 13/07/2026 → the seed week (from the pristine week-1 snapshots)
     · 20/07/2026 → the authored second week (engine/week2.ts)
     · anything else → a blank, editable week — 7 bare Mon..Sun days a scheduler
       can start filling in (the owner's end-state: click ahead to a future week
       and build it; cross-week persistence is the later, server-side step).
   A leaf module: imports data/inputs/week2 only, so it introduces no cycle. */
import { WEEK1_DAYS_SNAP } from './data'
import { WEEK1_INPUTS_SNAP, WEEK1_DATES, baseYear } from './inputs'
import { WEEK2_DAYS, WEEK2_DATES, WEEK2_INPUTS } from './week2'

const DOW=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
/* days in month, leap-year aware — a pure walker so no Date/timezone enters */
function dim(m:number,y:number){return [31,(y%4===0&&(y%100!==0||y%400===0))?29:28,31,30,31,30,31,31,30,31,30,31][m-1];}
/* seven 'Mon DD' labels from a dd/mm/yyyy week-start value. A day whose year
   is not the LOADED week's own (baseYear()) is labelled WITH its year —
   'Jan 1 2027' on the week of Dec 28 2026 — which is the exact convention the
   input labels already follow (fmt in ui/inputedit.tsx) and dateOrd reads
   back. Bare January labels on the spanning week resolved to the PREVIOUS
   year, so a leave running into the new year never covered the January days
   of the very week it was filed on (owner bug family, 24 Aug 26). Labels are
   generated at load/validate time, after CURWEEK moves, so baseYear() is
   always the week being described for the loaded week — and the CURRENT
   loaded year for a cross-week (weekctx) read, which is what its dateOrd
   comparisons need. */
function weekLabels(v:any){
  const parts=String(v).split('/').map((x:any)=>parseInt(x,10));
  let d=parts[0]||1,m=parts[1]||1,y=parts[2]||2026; const out:any[]=[];
  for(let i=0;i<7;i++){out.push(`${MON[m-1]} ${d}`+(y!==baseYear()?` ${y}`:'')); d++; if(d>dim(m,y)){d=1;m++;if(m>12){m=1;y++;}}}
  return out;
}
/* the cross-week engine reads (events.ts, weekctx.ts) need this under a name
   that says what it hands back — a thin re-export, same function */
export {weekLabels as weekDateLabels};
/* seven ALWAYS year-qualified labels ('Jul 13 2026') from a dd/mm/yyyy week key,
   INDEPENDENT of baseYear() — unlike weekLabels, which drops the year for a day in
   the LOADED week's own year. For readers that compare a stashed week's dates
   against inputs while a DIFFERENT year is loaded: quarantine.ts protectedDates
   pushed weekBundle(k).dates, but an AUTHORED week's dates are the fixed, bare
   WEEK1_DATES/WEEK2_DATES ('Jul 13'), which dateOrd then re-resolved against the
   loaded year — so a protected 2026 week read while a 2027 week was loaded locked
   the 2027 weekday of the same label (Q2R-03 cross-year mislock). A trailing year
   makes dateOrd read the absolute date regardless of what is loaded. */
export function weekDatesAbs(v:any){
  const parts=String(v).split('/').map((x:any)=>parseInt(x,10));
  let d=parts[0]||1,m=parts[1]||1,y=parts[2]||2026; const out:any[]=[];
  for(let i=0;i<7;i++){out.push(`${MON[m-1]} ${d} ${y}`); d++; if(d>dim(m,y)){d=1;m++;if(m>12){m=1;y++;}}}
  return out;
}
/* a dd/mm/yyyy Monday key, shifted by 7·n days (n may be negative), still a
   dd/mm/yyyy Monday key. WHY a second implementation instead of importing
   ui/weeknav.ts:shiftWeek, which does the identical ±7n-day walk: that walker
   goes through `Date.UTC`, and the engine stays Date-free by house rule (see
   weekLabels/dim above) — an engine→ui import would also be a layering
   violation the wrong way round. This is a deliberate drift seam, pinned by
   a test asserting the two walkers agree across month/year/leap boundaries
   so they cannot silently diverge. */
export function shiftWeekKey(v:any,n:any){
  const parts=String(v).split('/').map((x:any)=>parseInt(x,10));
  let d=parts[0]||1,m=parts[1]||1,y=parts[2]||2026;
  const days=Math.abs((n||0)*7);
  const pad=(x:any)=>String(x).padStart(2,'0');
  if((n||0)>=0){ for(let i=0;i<days;i++){ d++; if(d>dim(m,y)){d=1;m++;if(m>12){m=1;y++;}} } }
  else { for(let i=0;i<days;i++){ d--; if(d<1){m--;if(m<1){m=12;y--;} d=dim(m,y);} } }
  return `${pad(d)}/${pad(m)}/${y}`;
}
/* THE MONDAY OF THE WEEK A DATE FALLS IN, as a dd/mm/yyyy week key, from a
   dateOrd ordinal (yyyymmdd). Needed by the OIL credit to find the week a
   request's ONE row is anchored in when that week is not loaded
   ([OIL-XWEEK-ELSEWHERE], 22 Sep 26).
   Date-free, like everything else here: Sakamoto's day-of-week, then walk back
   to Monday through the same dim() the walkers above use. ui/weeknav.ts's
   mondayOf does the identical job through Date.UTC — a deliberate drift seam,
   the same one shiftWeekKey/shiftWeek already carry, and pinned by the same
   kind of agreement test across month, year and leap boundaries. */
const SAKAMOTO=[0,3,2,5,0,3,5,1,4,6,2,4];
export function weekKeyOfOrd(ord:any){
  const o=+ord; if(!isFinite(o)||o<=0)return '';
  let y=Math.floor(o/10000), m=Math.floor((o%10000)/100), d=o%100;
  if(m<1||m>12||d<1)return '';
  const yy=m<3?y-1:y;
  const dow=(yy+Math.floor(yy/4)-Math.floor(yy/100)+Math.floor(yy/400)+SAKAMOTO[m-1]+d)%7; // 0=Sun
  const back=(dow+6)%7;
  for(let i=0;i<back;i++){ d--; if(d<1){ m--; if(m<1){m=12;y--;} d=dim(m,y); } }
  const pad=(x:any)=>String(x).padStart(2,'0');
  return `${pad(d)}/${pad(m)}/${y}`;
}
/* the date label a cross-week seed read lands on at CURWEEK's edge: dir -1 is
   the PREVIOUS week's Sunday (crew rest / days-run look back that far), dir
   +1 is the NEXT week's Monday (the Sunday midnight-tail looks that far
   forward — the only lookahead anywhere in this engine, see events.ts). */
export function edgeDate(curWeek:any,dir:any){
  return dir<0 ? weekLabels(shiftWeekKey(curWeek,-1))[6] : weekLabels(shiftWeekKey(curWeek,1))[0];
}
/* a blank week: every day section present-but-empty (exactly the seed weekend's
   shape) so dayCount/dayKeys never hit a hole, and the edit flow can add waves
   and lines to it like any other week */
export function emptyWeek(v:any){
  const labels=weekLabels(v);
  const days=labels.map((dt:any,i:number)=>({dow:DOW[i],dt,wc:'0 X 0 X 0',notes:[],allhands:[],waves:[],sims:{amt:[],oft:[]},dutywaves:[],ground:[]}));
  return {days,dates:labels.slice(),inputs:[],seedSans:false};
}
/* THE TWO AUTHORED DEMO WEEKS ARE THE DEMO'S ([DB-READINESS] group A, phase 5 — Fable F3 build note): on a shared store
   (the boot policy's `seedDemo` false, set at every boot by state/seeds.ts) an unsaved 13 or 20 Jul 2026 is a blank week
   like any other, and no authored week's inputs are merged in — so a scheduler opening one never sees, or saves, demo
   content. On by default: every test, the dev server and his preview see them as always. */
let AUTHORED=true;
export function setAuthoredWeeks(on:any){ AUTHORED=!!on; }
export function weekBundle(v:any){
  if(!AUTHORED) return emptyWeek(v);
  if(v==='13/07/2026') return {days:JSON.parse(WEEK1_DAYS_SNAP), dates:WEEK1_DATES.slice(), inputs:JSON.parse(WEEK1_INPUTS_SNAP), seedSans:true};
  if(v==='20/07/2026') return {days:JSON.parse(JSON.stringify(WEEK2_DAYS)), dates:WEEK2_DATES.slice(), inputs:JSON.parse(JSON.stringify(WEEK2_INPUTS)), seedSans:false};
  return emptyWeek(v);
}
/* PERSONAL INPUTS ARE GLOBAL, NOT WEEK-SCOPED (owner, 22 Aug 26 — "show all
   inputs regardless of which week I am selected on"). The module-load INPUTS is
   week 1's; this hands boot every OTHER authored week's inputs to merge in once,
   so the Inputs page carries them all while date-matching still scopes each
   week's SCHEDULE to its own. A fresh deep copy — the backing dataset is never
   handed out live. Blank/other weeks contribute nothing. */
export function otherWeekInputs(){ return AUTHORED ? JSON.parse(JSON.stringify(WEEK2_INPUTS)) : []; }
