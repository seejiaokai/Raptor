// src/engine/rowids.ts
import { newId } from './newid'
/* STABLE ROW IDS (10 Sep 26, the stable-ids round). A schedule row — a wave,
   a Go, a seat pair, a duty block or desk, a sim row, a programme or ground
   row — is addressed by its POSITION (the slot-key grammar, keys.ts), and
   deleting a row renumbers the ones after it. The shared database wants a
   key that survives that, the way `iid` gives an input one. So every row
   carries `rid`: opaque, minted at creation, never printed (html.ts builds
   every key from the loop index — parity stays byte-identical), never used
   for addressing this round. Random rather than a counter so two browsers
   never mint the same id.
   ONE walk mints them, and it runs before every baseline and snapshot
   (store.ts initStore/loadWeek, history.ts histInit/histPush), so nothing
   is rendered or saved before a row has its id — inputs.ts's lesson that an
   id minted later than the snapshot it should be in is worse than none. A
   DUPLICATE is re-minted: a day template or a duplicated wave copies a row by
   JSON, and that copy is a new row; the first one seen keeps its id. A parked
   DRAFT is the deliberate EXCEPTION (drafts.ts, 11 Sep 26): it is an alternate
   VERSION of the same day, not an independent copy, so it KEEPS the source ids
   — and it never coexists with the live day in DAYS, so the dedupe below never
   sees the two together. */
/* the opaque-id minter now lives in newid.ts (shared with inputs' iid and note
   lines, 13 Sep 26); mintRowId keeps its name and its 'r' prefix. */
export function mintRowId(){return newId('r');}
/* every row object of one day, parents before children, in section order */
export function rowsOf(d:any):any[]{
  const out:any[]=[];
  (d.allhands||[]).forEach((r:any)=>out.push(r));
  (d.waves||[]).forEach((w:any)=>{out.push(w);(w.formations||[]).forEach((f:any)=>{out.push(f);(f.aircraft||[]).forEach((a:any)=>out.push(a));});});
  const s=d.sims||{};(s.amt||[]).forEach((r:any)=>out.push(r));(s.oft||[]).forEach((r:any)=>out.push(r));
  (d.dutywaves||[]).forEach((b:any)=>{out.push(b);(b.rows||[]).forEach((r:any)=>out.push(r));});
  (d.ground||[]).forEach((r:any)=>out.push(r));
  return out;
}
/* mint a missing rid, re-mint a duplicate; returns how many were minted.
   Day-NOTE lines ride the same walk since 13 Sep 26 (ARCH-STACK 1A): they are
   `{rid,t}` objects now, so they take a stable `rid` the same way — minted here,
   never in the seed literal, and re-minted on a duplicate so a day-template
   applied to two days (which deep-copies the note objects) cannot leave the two
   sharing one note id. Notes are NOT in rowsOf (they stay positionally addressed,
   dn:di.i), so they get their own pass — but in the SAME `rid` field and `seen`
   space as rows, which is what lets every rid-stripping path handle a note for
   free. A legacy bare-string note from a pre-1A blob is skipped, not crashed on
   (the storage reset coerces it). */
export function ensureRowIds(days:any[]):number{
  const seen=new Set<string>();let n=0;
  for(const d of days||[]){
    for(const r of rowsOf(d||{})){
      if(!r||typeof r!=='object')continue;
      if(typeof r.rid!=='string'||!r.rid||seen.has(r.rid)){r.rid=mintRowId();n++;}
      seen.add(r.rid);
    }
    for(const note of (d&&Array.isArray(d.notes)?d.notes:[])){
      if(!note||typeof note!=='object')continue;
      if(typeof note.rid!=='string'||!note.rid||seen.has(note.rid)){note.rid=mintRowId();n++;}
      seen.add(note.rid);
    }
  }
  return n;
}
/* a COPY is a new row: the day-template capture/apply strips the ids so the
   copy mints its own, rather than leaving the first-seen dedupe to decide which
   of two identical rows was "first". (A parked DRAFT does NOT strip — keep-ids,
   drafts.ts; a duplicated wave leans on ensureRowIds' dedupe as it coexists in
   the live model.) */
export function stripRowIds(d:any){
  for(const r of rowsOf(d||{}))if(r&&typeof r==='object')delete r.rid;
  /* note lines are a COPY boundary too (13 Sep 26): strip their rid so a captured
     day template / duplicated day re-mints a fresh one via ensureRowIds */
  for(const note of (d&&Array.isArray(d.notes)?d.notes:[]))if(note&&typeof note==='object')delete note.rid;
}
/* every row with its ADDRESS (section.index… path) — the pairing key for a
   snapshot written before ids existed: the row at the same address in the
   live day is the same row */
export function pathsOf(d:any):Array<[string,any]>{
  const out:Array<[string,any]>=[];
  (d.allhands||[]).forEach((r:any,i:number)=>out.push(['allhands.'+i,r]));
  (d.waves||[]).forEach((w:any,gi:number)=>{out.push(['waves.'+gi,w]);(w.formations||[]).forEach((f:any,li:number)=>{out.push(['waves.'+gi+'.formations.'+li,f]);(f.aircraft||[]).forEach((a:any,ai:number)=>out.push(['waves.'+gi+'.formations.'+li+'.aircraft.'+ai,a]));});});
  const s=d.sims||{};(s.amt||[]).forEach((r:any,i:number)=>out.push(['sims.amt.'+i,r]));(s.oft||[]).forEach((r:any,i:number)=>out.push(['sims.oft.'+i,r]));
  (d.dutywaves||[]).forEach((b:any,wi:number)=>{out.push(['dutywaves.'+wi,b]);(b.rows||[]).forEach((r:any,ri:number)=>out.push(['dutywaves.'+wi+'.rows.'+ri,r]));});
  (d.ground||[]).forEach((r:any,i:number)=>out.push(['ground.'+i,r]));
  return out;
}
/* =====================================================================
   ADDRESSING BY rid (addressing-by-rid, 10 Sep 26) — the amendment book
   resolves a row by its stable `rid`, not its array position, so a delete or
   reorder never renumbers another row's stored key across the shared database.
   ===================================================================== */
/* The DOM stays POSITIONAL: html.ts builds every data-slot / data-area / the
   alAttr colour from the loop index and stringifies no row, which is what keeps
   the byte-parity gate (tfin.js 728/0, html.test.ts) identical. So the two
   worlds meet at a translation boundary — a positional key in from the DOM
   becomes a rid-anchored key in the book (`ridKey`); a stored rid key becomes
   the row's CURRENT positional key to find a live cell (`posKey`).
   restore.ts:dayKeys is the executable grammar these two mirror, prefix for
   prefix; its tests pin every one.
   A key is `prefix:di.…` (or the bare flying seat `di.…`, no prefix); the day
   index is always the first component and stays literal (keyDay depends on it).
   ONLY the position components collapse to a rid — the sim `kind` (amt/oft),
   the field/seat selector, the .xN overflow, the crew index .k and pax.k all
   stay literal. A position component reads `\d+`; a rid never does, so the two
   forms are always told apart. */
/* `iu:<iid>` is here too (Fable review): it addresses an INPUT, carries NO day
   component (slots.ts:297), and must pass through untouched — without this
   posKey read its missing day as "the row is gone" and returned null. */
const NONROW = new Set(['dn', 'sn', 'pn', 'dtn', 'gn', 'del', 'mov', 'inp', 'iu']);
/* per prefix, the position slots (index into the dot-parts) and the array each
   one indexes — parents first, so slot i's row is found inside slot i-1's. The
   first level indexes off the DAY, later levels off the row resolved above. */
function keyLevels(prefix: string, parts: string[]): Array<{ slot: number; arr: (p: any) => any }> | null {
  const W = { slot: 1, arr: (d: any) => d.waves }, F = { slot: 2, arr: (w: any) => w.formations }, A = { slot: 3, arr: (f: any) => f.aircraft };
  switch (prefix) {
    case '': return [W, F, A];                                   // bare flying seat di.gi.li.ai.seat
    case 'wl': case 'it': case 'tr': case 'wx': return [W];       // wx: canonical wave flags (Phase 2)
    case 'ff': case 'ar': case 'at': case 'fx': case 'fa': case 'ft': return [W, F];  // fx/fa/ft: canonical formation content (Phase 2)
    case 'fr': case 'st': case 'aa': case 'au': return [W, F, A]; // aa/au: canonical per-aircraft area/atime (Phase 2)
    case 'dl': return [{ slot: 1, arr: (d: any) => d.dutywaves }];
    case 'dr': case 'd': return [{ slot: 1, arr: (d: any) => d.dutywaves }, { slot: 2, arr: (b: any) => b.rows }];  // (bxr retired — a duty row's cxr rides dr:...role now, P2-IMPL-08)
    case 'bx': return [{ slot: 1, arr: (d: any) => d.dutywaves }];  // bx: canonical duty-block flags (Phase 2)
    case 'sr': case 's': return [{ slot: 2, arr: (d: any) => ((d.sims || {})[parts[1]!] || []) }];  // parts[1]=kind, literal
    case 'ap': case 'a': return [{ slot: 1, arr: (d: any) => d.allhands }];
    case 'gr': case 'g': case 'gx': return [{ slot: 1, arr: (d: any) => d.ground }];  // gx: canonical ground src (Phase 2)
    default: return null;                                        // dn:/sn: etc. never reach here (NONROW)
  }
}
/* a positional key → its rid-anchored form. All-or-nothing: if EVERY row on the
   path carries a rid, each position slot becomes that row's rid; if any row is
   missing a rid (a legacy/pristine row) or a slot is already a rid, the key is
   returned UNCHANGED — the "fallback to position" the scope names, and also what
   makes this idempotent (a rid slot is non-numeric, so the walk bails). */
export function ridKey(key: any, days: any[]): string {
  const s = String(key), c = s.indexOf(':'), prefix = c < 0 ? '' : s.slice(0, c);
  if (NONROW.has(prefix)) return s;
  const parts = (c < 0 ? s : s.slice(c + 1)).split('.'), day = (days || [])[+parts[0]!];
  if (!day) return s;
  const lv = keyLevels(prefix, parts); if (!lv) return s;
  const out = parts.slice(); let container: any = day;
  for (const { slot, arr } of lv) {
    const a = arr(container), comp = parts[slot]!;
    if (!/^\d+$/.test(comp)) return s;                           // already a rid / not positional → leave it
    const row = Array.isArray(a) ? a[+comp] : null;
    if (!row || typeof row.rid !== 'string' || !row.rid) return s;   // no id here → positional fallback
    out[slot] = row.rid; container = row;
  }
  return (c < 0 ? '' : prefix + ':') + out.join('.');
}
/* a rid-anchored key → the row's CURRENT positional key, or null if the row is
   gone (a deleted rid). Tolerant of a mixed key: a numeric slot is kept as-is
   (a legacy/fallback address), a rid slot is resolved to the row's live index. */
export function posKey(key: any, days: any[]): string | null {
  const s = String(key), c = s.indexOf(':'), prefix = c < 0 ? '' : s.slice(0, c);
  if (NONROW.has(prefix)) return s;
  const parts = (c < 0 ? s : s.slice(c + 1)).split('.'), day = (days || [])[+parts[0]!];
  if (!day) return null;
  const lv = keyLevels(prefix, parts); if (!lv) return s;
  const out = parts.slice(); let container: any = day;
  for (const { slot, arr } of lv) {
    const a = arr(container); if (!Array.isArray(a)) return null;
    const comp = parts[slot];
    /* a short/malformed key leaves this slot undefined; without the guard the
       findIndex below would match the first row that has NO rid (r.rid ===
       undefined) and hand back a real-looking address for the wrong row */
    if (typeof comp !== 'string' || !comp) return null;
    const ix = /^\d+$/.test(comp) ? +comp : a.findIndex((r: any) => r && r.rid === comp);
    if (ix < 0 || !a[ix]) return null;                          // the addressed row is gone
    out[slot] = String(ix); container = a[ix];
  }
  return (c < 0 ? '' : prefix + ':') + out.join('.');
}
/* Is this key a ROW address — a keyLevels-known prefix, or the bare flying
   seat — rather than a note / synthetic (NONROW) or an unknown key? The
   write-in self-heal gates on this so a note or del:/mov: key never triggers a
   wasted mint walk (posKey returns the string, not null, for an unknown prefix,
   so an ungated check could not tell them apart). */
export function isRowKey(key:any):boolean{
  const s=String(key),c=s.indexOf(':'),prefix=c<0?'':s.slice(0,c);
  if(NONROW.has(prefix))return false;
  const parts=(c<0?s:s.slice(c+1)).split('.');
  return keyLevels(prefix,parts)!==null;
}
/* THE WRITE-IN TRANSLATE, self-healing (review finding 1). A mark is stored
   rid-anchored, but ridKey can only anchor a row that ALREADY carries a rid —
   and a freshly-created row is marked (noteChange / markEdit / trackStructuralAdd)
   BEFORE the next histPush mints its id. So when ridKey returns the key
   unchanged AND it is a row key, mint the whole week's ids (ensureRowIds —
   whole-week, never per-day, so a cross-day duplicate is re-minted before it
   can orphan the mark) and translate once more. This is the SAFETY mechanism:
   a missed per-site mint at any creation path cannot silently store a positional
   key, so the board's per-site mints are an optimisation, not the guarantee.
   A NONROW / unknown key returns unchanged with no walk; an already-rid key is
   idempotent (ridKey bails on the first non-numeric slot, so no walk). */
export function ridWriteKey(key:any,days:any[]):string{
  const s=String(key),m=ridKey(s,days);
  if(m!==s)return m;                       // anchored, or already rid
  if(!isRowKey(s))return m;                // note / synthetic / unknown — leave positional
  ensureRowIds(days);
  return ridKey(s,days);
}
/* MIGRATE A PERSISTED BOOK written with positional keys (the storage seam now
   persists SCHED per browser). Runs once per boot/week-load AFTER
   backfillSnapshotIds (every row has a rid) and BEFORE the baseline, so a
   re-keying is not read as a dirtying edit. Rewrites the live book — pending,
   changes, added, and every AL's keys/adds/structAdds/snap.c — from positional
   to rid form against the live DAYS; an unresolvable key is left positional
   (fallback). Idempotent: an already-rid key returns itself. Returns how many
   keys changed. NOTE: not wired into store.ts in this foundation step — a pure
   function, tested in isolation; the wiring is task 5. */
export function migrateBookKeys(sched: any, days: any[]): number {
  if (!sched) return 0;
  let n = 0;
  const one = (k: any, d: any[]) => { const m = ridKey(k, d); if (m !== k) n++; return m; };
  const remap = (o: any, d: any[]) => { const out: any = {}; for (const k of Object.keys(o || {})) out[one(k, d)] = o[k]; return out; };
  sched.pending = remap(sched.pending, days);
  sched.changes = remap(sched.changes, days);
  sched.added = remap(sched.added, days);
  (sched.als || []).forEach((al: any) => {
    /* keys/adds/structAdds address the LIVE model (they paint live cells), so
       they translate against the live day. */
    if (al.keys) al.keys = al.keys.map((k: any) => one(k, days));
    if (al.adds) al.adds = al.adds.map((k: any) => one(k, days));
    if (al.structAdds) al.structAdds = al.structAdds.map((k: any) => one(k, days));
    /* a snapshot's changes-slice addresses the SNAPSHOT's OWN rows (restore
       installs snap.c alongside snap.d), so it translates against snap.d — which
       backfillSnapshotIds has already given rids. Translating it against the
       live day would map a row that has since moved onto the wrong rid, the
       exact mis-attribution this change exists to prevent. A legacy snap with
       no day blob falls back to the live day. */
    if (al.snap) Object.keys(al.snap).forEach((di: any) => {
      const sd = al.snap[di]; if (!sd || !sd.c) return;
      let ref = days;
      if (sd.d) { ref = []; ref[+di] = sd.d; }
      sd.c = remap(sd.c, ref);
    });
  });
  /* Fable-B: SCHED.orig[di].c drives the reissue/Original preview and rides
     this same stash. Missing here, its marks are lost on migration. Re-key it
     against its OWN snapshot day (orig[di].d), exactly as al.snap.c above —
     backfillSnapshotIds has already given orig[di].d its rids. */
  Object.keys(sched.orig || {}).forEach((di: any) => {
    const o = sched.orig[di]; if (!o || !o.c) return;
    let ref = days;
    if (o.d) { ref = []; ref[+di] = o.d; }
    o.c = remap(o.c, ref);
  });
  return n;
}
/* THE FORMAT VERSION this build writes into every persisted book (schedFields'
   `v`, engine → state/history.ts). A book WITHOUT it was written before the
   addressing-by-rid change (the foundation build #384 and earlier), and its row
   identities are INCONSISTENT with the keep-ids model: #384's draftDup re-minted
   the parked copy, so a parked (or selected-then-live) draft carries rids foreign
   to the issued snapshots. Persisted books DO reach this build (state/persist.ts
   files week snapshots — drafts and amendments included, schedFields — to the
   localStorage whiteboard and hydrates them at boot), so this must be migrated. */
export const RID_BOOK_VERSION = 2;
/* LEGACY BOOK MIGRATION (Astra RID-REVIEW-01, RID-IR-02/03). One-time, gated on
   the persisted version so it runs ONLY on a foundation-era book and NEVER on a
   modern one — a modern draft may legitimately share zero rids with its live day
   (all rows replaced), so legacy-ness must be an explicit version, never inferred
   from id overlap. For a legacy book it STRIPS every row id across the whole book
   (the live days, the parked drafts, SCHED.orig and every AL snapshot), so the
   ensureRowIds + backfillSnapshotIds pass that follows rebuilds ONE consistent
   id-space by position — the same legacy-faithful position-pairing the backfill
   already uses, reused rather than reinvented. Runs BEFORE ensureRowIds. Sets the
   version so it is a no-op ever after. Returns true when it migrated. */
/* Is this key rid-SHAPED — does any POSITION slot hold a rid instead of a numeric
   index? This asks about the key's FORM, not whether the row still exists, which
   is the point (Astra RID-REV2-01): an issued AL retains keys for DELETED rows,
   rid-shaped but no longer resolvable, and a resolve-based check would miss them
   and call the whole book legacy. A position slot is `\d+` in positional form and
   a rid (non-numeric) in rid form; a field selector (.cs, .role, …) is never a
   position slot, so keyLevels tells the two apart. NONROW/unknown keys are never
   rid-shaped. */
function keyIsRidShaped(key: any): boolean {
  const s = String(key), c = s.indexOf(':'), prefix = c < 0 ? '' : s.slice(0, c);
  if (NONROW.has(prefix)) return false;
  const parts = (c < 0 ? s : s.slice(c + 1)).split('.');
  const lv = keyLevels(prefix, parts); if (!lv) return false;
  return lv.some(({ slot }) => { const comp = parts[slot]; return typeof comp === 'string' && comp !== '' && !/^\d+$/.test(comp); });
}
/* Does this book carry ANY rid-anchored key? Scans every stored-key space —
   pending/changes/added, each AL's keys/adds/structAdds and snap[di].c, and
   SCHED.orig[di].c — by SHAPE, so a key on a since-deleted row still counts.
   Day-independent (shape only), so it needs no `days`. */
function bookIsRidAnchored(sched: any): boolean {
  const objShaped = (o: any) => Object.keys(o || {}).some(keyIsRidShaped);
  const arrShaped = (a: any) => (a || []).some(keyIsRidShaped);
  const snapShaped = (snap: any) => Object.keys(snap || {}).some((di: any) => snap[di] && objShaped(snap[di].c));
  if (objShaped(sched.pending) || objShaped(sched.changes) || objShaped(sched.added)) return true;
  if (snapShaped(sched.orig)) return true;
  return (sched.als || []).some((al: any) =>
    arrShaped(al.keys) || arrShaped(al.adds) || arrShaped(al.structAdds) || snapShaped(al.snap));
}
export function migrateLegacyIds(sched: any, days: any[]): boolean {
  if (!sched) return false;
  /* Gate on the KEEP-IDS version (2), NOT the current RID_BOOK_VERSION: the
     strip repairs a v<2 (foundation-era) book only. A v2+ book already speaks
     keep-ids, so stripping it would re-mint every row and orphan every
     rid-anchored key — finding 1's corruption in reverse — and that must not
     happen when the format version is bumped to 3 later either. */
  if ((sched.ridV || 0) >= 2) return false;                     // already migrated — never touch
  /* Version-absence alone is NOT proof of a foundation book. An INTERMEDIATE
     build (a branch preview written after the rid-anchored key form landed but
     before the ridV stamp existed) has NO ridV yet its KEYS are already
     rid-anchored. Stripping it would orphan every one of those keys (migrateBookKeys
     then bails on an id-shaped slot and cannot repair them). So if any stored key
     is rid-SHAPED — by form, so a key on a since-deleted row still counts — it is
     new-format: stamp it and skip the strip. A book with only note/positional keys
     is not detected here, but stripping it is harmless — nothing references a rid. */
  if (bookIsRidAnchored(sched)) { sched.ridV = RID_BOOK_VERSION; return false; }
  (days || []).forEach((d: any) => stripRowIds(d));
  Object.keys(sched.drafts || {}).forEach((k: any) => (sched.drafts[k] || []).forEach((t: any) => { if (t && t.d) stripRowIds(t.d); }));
  Object.keys(sched.orig || {}).forEach((k: any) => { const o = sched.orig[k]; if (o && o.d) stripRowIds(o.d); });
  (sched.als || []).forEach((al: any) => Object.keys(al.snap || {}).forEach((k: any) => { const sd = al.snap[k]; if (sd && sd.d) stripRowIds(sd.d); }));
  sched.ridV = RID_BOOK_VERSION;
  return true;
}
/* THE BACKFILL (review finding 6): the amendment book — SCHED.orig, every
   AL's day snapshots, the drafts — is persisted with the week, so a book
   written before ids existed would mint a DIFFERENT id on every restore. Run
   once per boot/week-load, after ensureRowIds(DAYS) and before the baseline:
   a snapshot row still without an id takes the live row's id at the same
   address, or a minted one when the address is gone; written into the
   snapshot so it persists. Idempotent — rows that have an id are untouched. */
export function backfillSnapshotIds(sched:any,days:any[]):number{
  let n=0;const fill=(snapDay:any,di:number)=>{if(!snapDay)return;const live=new Map(pathsOf(days[di]||{}));
    for(const [p,r] of pathsOf(snapDay)){if(!r||typeof r!=='object'||(typeof r.rid==='string'&&r.rid))continue;const l=live.get(p);r.rid=(l&&typeof l.rid==='string'&&l.rid)?l.rid:mintRowId();n++;}};
  Object.keys(sched.orig||{}).forEach((k:any)=>fill(sched.orig[k]&&sched.orig[k].d,+k));
  (sched.als||[]).forEach((al:any)=>Object.keys(al.snap||{}).forEach((k:any)=>fill(al.snap[k]&&al.snap[k].d,+k)));
  Object.keys(sched.drafts||{}).forEach((k:any)=>(sched.drafts[k]||[]).forEach((t:any)=>fill(t&&t.d,+k)));
  return n;
}
