/* AUDIT A (12 Aug 26) — adversarial pass over the edit log's ENGINE half.

   The load-bearing discovery in this file: shiftKeys()/permuteKeys()
   (engine/keys.ts) rewrite SCHED.pending, SCHED.changes, SCHED.added and
   every issued AL when a delete or reorder renumbers the key space — and
   they never touch ELOG.rows. Every log row keeps the key it was born
   with, so after any renumbering the log's addresses point at the WRONG
   live rows: elogFor(new address) answers null for the row that was
   actually edited, and elogFor(old address) answers with history that now
   belongs to a different row on screen.

   The tests that carry a BUG marker assert the CURRENT (broken) behaviour
   on purpose, so this file runs green while the divergence stands and
   starts failing the moment someone fixes it — at which point the
   assertions should be flipped, not deleted. */
import { beforeEach, afterEach, describe, expect, it } from 'vitest'
import { DAYS } from './data'
import { SCHED } from './publish'
import { setSlotVal, slotVal } from './slots'
import { shiftKeys } from './keys'
import { moveDutyRow } from './reorder'
import { HOOKS } from './hooks'
import { ELOG, elogClear, elogFor, elogAllFor, elogGroups, elogRows, logEdit, logAction, elogVal } from './editlog'
import { ridKey } from './rowids'

/* addressing-by-rid: the book stores keys rid-anchored, and keys.ts's
   shiftKeys/permuteKeys are INERT on them — a delete/reorder no longer
   renumbers the stored string, the row's identity rides along instead. So the
   OUTCOME the audit pins is unchanged (history stays on its row), but a raw
   positional expectation must read the row's rid form. */
const rk = (k: string) => ridKey(k, DAYS)

let who: any
beforeEach(() => {
  SCHED.pending = {}; SCHED.changes = {}
  elogClear()
  who = HOOKS.whoami
  HOOKS.whoami = () => 'Auditor'
})
afterEach(() => { HOOKS.whoami = who })

describe('renumbering and the log (delete)', () => {
  it('a delete renumbers the log with SCHED — history stays on its row (fixed 12 Aug 26)', () => {
    const rows = DAYS[0].dutywaves[0].rows
    const B = rows.length
    /* three fresh rows so nothing demo-seeded is touched; the middle one
       gets the edit, the top one gets deleted */
    rows.push(
      { role: 'AUD-A', id: '', str: '', end: '' },
      { role: 'AUD-B', id: '', str: '', end: '' },
      { role: 'AUD-C', id: '', str: '', end: '' },
    )
    try {
      setSlotVal(`d:0.0.${B + 1}`, 'bane')          // logged: — → Bane at address B+1
      expect(elogVal(elogFor(`d:0.0.${B + 1}`)!, 'to')).toBe('Ranger')   // the log keeps his id; readers say his callsign

      /* exactly what board.ts's [data-drdel] branch does */
      rows.splice(B, 1)
      ;[`d:0.0.`, `dr:0.0.`].forEach(h => shiftKeys(h, 0, B))

      /* the model and the amendment bookkeeping agree: the edited man now
         sits at B, and pending followed him there */
      expect(rows[B].id).toBe('bane')
      expect(SCHED.pending[rk(`d:0.0.${B}`)]).toBe(1)              // the mark rode the row (rid-anchored)
      expect(SCHED.pending[rk(`d:0.0.${B + 1}`)]).toBeUndefined()  // the untouched neighbour carries nothing

      /* the log followed (elogRemap, called from shiftKeys): the row that
         holds the edit owns its history, the untouched neighbour has none */
      const moved = elogFor(`d:0.0.${B}`)
      expect(moved, 'the edited row owns its history').toBeTruthy()
      expect(elogVal(moved!, 'to')).toBe('Ranger')
      expect(elogFor(`d:0.0.${B + 1}`), 'the untouched neighbour wears nothing').toBeNull()
      expect(slotVal(`d:0.0.${B + 1}`)).toBe('')
    } finally {
      rows.splice(B, rows.length - B)               // net zero on the demo data
    }
  })
})

describe('renumbering and the log (reorder)', () => {
  it('a reorder permutes the log with SCHED — no divergence, no row lost (fixed 12 Aug 26)', () => {
    const rows = DAYS[0].dutywaves[0].rows
    const B = rows.length
    rows.push(
      { role: 'AUD-D', id: '', str: '', end: '' },
      { role: 'AUD-E', id: '', str: '', end: '' },
    )
    try {
      setSlotVal(`d:0.0.${B}`, 'bane')              // logged at address B
      moveDutyRow(0, 0, B, B + 1)                   // the edited row slides down one

      expect(rows[B + 1].id).toBe('bane')
      /* pending rode with him — the rid-anchored key resolves to his new index … */
      expect(SCHED.pending[rk(`d:0.0.${B + 1}`)]).toBe(1)
      /* … and so did the log (elogRemap rides the same permutation) */
      const moved = elogFor(`d:0.0.${B + 1}`)
      expect(moved, 'his history moved with him').toBeTruthy()
      expect(elogVal(moved!, 'to')).toBe('Ranger')
      expect(elogFor(`d:0.0.${B}`), 'nothing left at the old address').toBeNull()
      expect(slotVal(`d:0.0.${B}`)).toBe('')
    } finally {
      rows.splice(B, rows.length - B)
    }
  })
})

describe('the ring past its cap', () => {
  /* the cap is read, not written as a number: it rose from 400 to 2,000 when the log became the durable change
     history ([DRAFT-PENDING], 28 Sep 26) — the ring's behaviour at its edge is what these pin */
  it('drops the oldest and keeps every query coherent', () => {
    const cap = ELOG.cap
    for (let i = 0; i < cap + 10; i++) logEdit('ff:0.0.0.cs', 'v' + i, 'v' + (i + 1))
    expect(ELOG.rows.length).toBe(cap)
    /* the ten oldest fell off the front, in order */
    expect(ELOG.rows[0]!.from).toBe('v10')
    expect(ELOG.rows[cap - 1]!.to).toBe('v' + (cap + 10))

    /* the three queries agree with each other after the overflow */
    expect(elogRows().length).toBe(cap)
    expect(elogRows()[0]!.to, 'newest first').toBe('v' + (cap + 10))
    const all = elogAllFor('ff:0.0.0.cs')
    expect(all.length).toBe(cap)
    expect(all[0]!.from, 'oldest first').toBe('v10')
    const g = elogGroups()
    expect(g.length).toBe(1)
    expect(g[0]!.rows.length).toBe(cap)
    expect(elogFor('ff:0.0.0.cs')!.to).toBe('v' + (cap + 10))
  })

  it('a structural row crossing the boundary stays its own group of one', () => {
    const cap = ELOG.cap
    logAction(0, 'Line removed')
    logAction(0, 'Line removed')
    for (let i = 0; i < cap - 1; i++) logEdit('ff:0.0.0.cs', 'w' + i, 'w' + (i + 1))
    /* cap + 1 pushes — the FIRST structural row fell off, the second survives */
    expect(ELOG.rows.length).toBe(cap)
    const structs = ELOG.rows.filter(r => !r.key)
    expect(structs.length).toBe(1)
    const g = elogGroups(0)
    expect(g.filter(x => !x.key).length, 'still one group, not folded into anything').toBe(1)
  })
})
