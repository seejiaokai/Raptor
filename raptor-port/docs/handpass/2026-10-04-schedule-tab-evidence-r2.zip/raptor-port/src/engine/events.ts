import { parseReportingLines, resolveReporting, flightBrief, type ReportingLine } from './reporting'
import { DAYS } from './data'
import { INPUTS, inputsOn, inputOn, inputCoversDate, inputFlags, inputDormant, inpWin, isSansAvail, inpMeta, shiftHardInput, shiftHardLabel, inpById, isDownchit, isUpchit } from './inputs'
import { fileAcc, filingActive } from './world'
import { PEOPLE, isSpecial, whoId, aarNeed } from './people'
import { toMin, parseHM, win, overlap } from './time'
import { VCONF, SHIFT_HARD } from './rules'
import { isStandalone, saExempt, saExemptKind, CURWEEK } from './waves'
import { whoArr, acceptedDay } from './slots'
import { edgeDate } from './weeks-data'
import { standsOn } from './overlay'
/* THE ACCEPT DEFERRAL IS PER-DAY, NOT PER-INPUT (audit, 12 Aug 26).
   inputFlags defers a timed accepted input to the ground row the accept
   created — but that row lives on ONE day, while the input may cover
   several. Filtering by inputFlags alone silenced the input on EVERY
   covered day, so accepting a Tue–Thu meeting onto Wednesday switched off
   real INPUT_FLY/NO_BRIEF warnings on Tuesday and Thursday, where no row
   exists to carry the clash. The gate the carve-out promises — "a clash
   surfaces exactly once, as DOUBLE_BOOK on the ROW" — only holds on the
   row's own day, so that is the only day the deferral now applies to.
   A deferred input whose row cannot be found at all stays VISIBLE: with no
   row anywhere, hiding it here would silence the man's absence outright. */
export const inpShow=(inp:any,dt:any,xweek?:any)=>{
  /* SANS AVAILABILITY IS AN OFFER, NOT A COMMITMENT — it must never reach
     day.input (brief/debrief clashes, INPUT_FLY, the midnight-tail machinery
     all read that array). sansGate (avail.ts) is the only thing that judges
     it, against a slot, not against the day (owner, 14 Aug 26). All three
     construction sites funnel through here, so this one line keeps it out
     everywhere at once. */
  if(isSansAvail(inp.type))return false;
  /* A REMOVED INPUT IS DORMANT (owner, 26 Aug 26 — see inputDormant): parked
     back in Personal Inputs by unacceptInput, it speaks NOWHERE until
     re-accepted. Before the xweek bypass on purpose — dormancy holds for
     cross-week seed reads of the loaded week too.
     On the OFFICIAL run (published-schedule flagging, §14.3) read through fileAcc so
     an approved date sees the SIGNED filing — a working-copy 'r' cannot silence a
     signed warning, and a post-publish-added input reads 'r' (absent when signed).
     Off the official run the path is the exact prior inputDormant (no id mint).
     NO EXCEPTION FOR MEDICAL any more (owner, D179, 25 Sep 26 — "freeze everything for now"): a
     medical downchit filed, lifted or trimmed after a day is published moves the working copy
     only and shows as pending for the admin; the issued face keeps the fitness it went out
     with until the next AL. SETS ASIDE the crew-rest plan's §4 ("current safety facts are
     never versioned", Codex CRPF-001 — a design decision, never a ruling of his). Provisional:
     he is to be shown it on the build and asked again.
     On the official run compute the effective acc ONCE and run the WHOLE gate on it —
     dormancy AND the accepted-row deferral (Fable FR-001). Folding only the dormancy
     check through the frozen filing but leaving the deferral (inputFlags/acceptedDay)
     on the LIVE acc let a sign-time 'g' whose working row was later spliced (acc→'r')
     be SHOWN again beside its still-frozen snapshot row — double-speaking on the issued
     face. inp.iid is read directly, never minted (Fable FR-005): the official pass must
     not write INPUTS, and an input with no id cannot be in any frozen fingerprint. */
  if(filingActive()){
    const eff=inp.iid?fileAcc(dt,inp.iid,inp.acc):'r';
    if(eff==='r')return false;                    // dormant, or absent when this date was signed
    if(xweek)return true;
    if(!isUpchit(inp.type)&&!(eff==='g'&&!inp.allday))return true;   // not a timed accepted input → a live flag
    /* a timed accept speaks as its landed ground row: find that row on the SWAPPED DAYS
       by its source id (live-acc-agnostic — acceptedDay's own 'g' guard reads the working
       acc, now 'r'), and defer only on the row's OWN day (per-day carve-out, 12 Aug 26). */
    let di=-1; for(let i=0;i<DAYS.length;i++){ if(standsOn(DAYS[i],inp.iid,inp)){di=i;break;} }   // its STANDING row — never a dead kept one (overlay.ts)
    return di<0||(DAYS[di]||{}).dt!==dt;
  }
  if(inputDormant(inp))return false;
  /* CROSS-WEEK SEED READS BYPASS THE ACCEPTED-ROW DEDUP (weekctx.ts, via
     buildDay's xweek flag). acceptedDay(inp) below finds the row on the
     LOADED week's live DAYS — it has no idea a non-loaded day even exists,
     so for a pristine snapshot day (no landed ground row of its own to defer
     to) it would silently drop a spanning input's timed window from the
     seed. The tails (nx/pv, below) never set xweek and keep this dedup. */
  if(xweek)return true;
  if(inputFlags(inp))return true;                 // not a timed accepted input
  const di=acceptedDay(inp);
  return di<0||(DAYS[di]||{}).dt!==dt;            // defer only on the row's day
};
/* IS THIS EVENT A HARD CLASH AGAINST AN SC MAIN SHIFT? (owner, 26 Aug 26).
   The kind table (SHIFT_HARD) still grades ground/prog as academics — amber —
   but a GROUND ROW that IS a red-list commitment is the commitment, not
   academics. Two recoveries, src first: a row lifted from an input carries the
   source TYPE in row.src (inpKey = person|date|type|s|yr — the only place
   'Other' survives, its label being the remarks), corroborated by prog===label
   so a stale or cross-week key can never decide by the wrong row (fail-soft to
   the keywords); a hand-typed row is judged by its own words (shiftHardLabel).
   Programme (a:) rows stay amber always — they cannot be input-derived and the
   owner's keyword rule was stated about ground rows. Lives HERE beside the g:
   key grammar it parses; validator (clash loop) and crew picker (avail.ts
   live) both call it, so the two can never disagree — the same promise
   SHIFT_HARD itself makes. */
export function shiftHardGround(e:any){
  if(!e||e.kind!=='ground')return false;
  const m=/^g:(\d+)\.(\d+)$/.exec(String(e.key||''));
  const row=m&&DAYS[+m[1]]&&((DAYS[+m[1]].ground||[])[+m[2]]);
  if(row&&row.src&&String(row.prog||'')===String(e.label||'')){
    /* row.src is the source input's STABLE ID (13 Sep 26, ARCH-STACK 1A) — resolve
       the input and grade by its TYPE. Was String(row.src).split('|')[2] when src
       was the content key person|date|type|s|yr; an opaque id has no such field,
       so parsing it silently fell through to the label keywords (a 'ESCORT VISIT'
       Other stopped grading hard by its source type). */
    /* read as the document for this row's date holds it ([LEAVE-LATE-PUBLISHED], A7): on a published day's face the
       issued copy, so retyping the request after publishing cannot flip the issued clash red ↔ amber */
    const inp=inputOn(row.src,DAYS[+m![1]].dt);
    if(inp&&inpMeta(inp.type))return shiftHardInput(inp.type);
    /* [ARCH-STACK] step 4 §8.1 — the input is GONE (deleted after it landed):
       the row keeps the type it was landed from, so an orphaned 'Other' keeps
       its hard-clash grade instead of falling back to the label keywords. */
    if(!inp&&row.srcType&&inpMeta(row.srcType))return shiftHardInput(row.srcType);
  }
  return shiftHardLabel(e.label);
}
export function shiftEvHard(e:any){return !!SHIFT_HARD[e.kind]||shiftHardGround(e);}
/* DOES HE ALREADY HOLD ANOTHER SC SEAT IN THESE HOURS? (owner, 31 Aug 26 —
   "give a warning conflict if u are planned for MAIN and SPARE in the same
   time framing … the 1300 is not a conflict"; SPARE+SPARE ruled the same red
   the same day.) A spare seat never becomes an event, so EVD cannot answer
   this — the walk reads the day MODEL, which also lets the crew picker ask
   the identical question BEFORE a plant (slotBar) and the validator after
   it, off this one body, so the two can never drift. overlap() is half-open:
   SC AM 07:00–13:00 and PM 13:00–19:00 share only the 13:00 instant and stay
   two clean shifts — the owner's own example. selfKey excludes the seat
   being asked about (a re-arm, or the seat a warning is being raised FOR).
   SINCE 7 SEP 26 (owner — "for sc duties desk they are also not allowed to be
   planned as the same time as main or spare") the walk also reads every
   `sa:'sc'` DUTY BLOCK (the desk a template marked as SC's, dutytpl.ts): a
   man on an SC desk row (its seat or its extras) inside the hours is a hit
   with role 'DUTY'. MAIN-vs-desk needs nothing here (both are events, the
   clash loop reds them); this is what lets the SPARE — absent from EVD — be
   caught against the desk, and the desk's own picker refuse a spare. `what`
   is the spoken form for a message: "SC AM SPARE" / "SXO AM duty". The
   AVALON twin is avSeatHit below. */
export function scSeatHit(di:any,id:any,s:any,e:any,selfKey:any){
  return standaloneHits(di,id,s,e,selfKey,'sc')[0]||null;
}
/* EVERY SC place, not the first — the SC twin of avSeatHits (audit, 8 Sep
   26): a man on two SPARE rows and the SC desk at once is three pairs, and
   the first-hit walk let one spare "use up" the other and left spare↔desk
   unspoken. The picker keeps scSeatHit's single answer (one refusal reason). */
export function scSeatHits(di:any,id:any,s:any,e:any,selfKey:any){
  return standaloneHits(di,id,s,e,selfKey,'sc');
}
/* DOES HE ALREADY HOLD ANOTHER AVALON / BB PLACE IN THESE HOURS? (owner, 7 Sep
   26 — "they should also not be planned as a main and a spare the same timing
   … or be planned on a duty for Avalon and planned as Avalon main or spare";
   and "bb main and spare rules are exactly the same"). These waves are noconf
   whole — no seat on them and no `sa:'avalon'`/`'bb'` desk row ever becomes an
   event — so, as with the SC spare, only a model walk can answer this, and the
   same body serves the validator (after a drop) and the crew picker (before a
   plant). ONE family: an AVALON seat against a BB seat in the same hours is
   one man in two places too (a man is one body; the walk reads every noconf
   wave and both desks). The shift is overnight: the window is rolled (07:00 <
   19:00 → +1440) exactly as collectEvents rolls it, so 19:00–07:00 against
   19:00–07:00 overlaps and a desk retyped 07:00–19:00 beside it touches only
   at 19:00 and passes — half-open, the SC precedent. */
export function avSeatHit(di:any,id:any,s:any,e:any,selfKey:any,seatsOnly?:any){
  return standaloneHits(di,id,s,e,selfKey,null,seatsOnly)[0]||null;
}
/* EVERY place, not the first (sweep, 7 Sep 26): a man on MAIN, SPARE and the
   desk at once is three pairs, and the validator must word each — the
   first-hit walk let MAIN "use up" the desk's one hit and left SPARE↔desk
   unspoken. The picker keeps the single answer (one refusal reason). */
export function avSeatHits(di:any,id:any,s:any,e:any,selfKey:any,seatsOnly?:any){
  return standaloneHits(di,id,s,e,selfKey,null,seatsOnly);
}
/* the one walk behind both: the KIND's waves (every crew row, MAIN and SPARE)
   plus every duty block marked `sa:<kind>` (the seat and its extras); a null
   kind is the noconf family — AVALON and BB, waves and desks. `seatsOnly`
   skips the desks: a DESK asking (owner, 7 Sep 26 — "two avalon desk roles is
   ok") wants only the seats, while a seat asking wants seats and desks. */
function standaloneHits(di:any,id:any,s:any,e:any,selfKey:any,kind:any,seatsOnly?:any){
  const hits:any[]=[];
  const d=DAYS[di]; if(!d||!id||s==null||e==null)return hits;
  /* selfKey: the place being asked about — OR a list of them, so the crew
     picker can also exclude the seat a man is being DRAGGED FROM (slotBar's
     fromKey, 5 Sep 26): the hover reads the week after the move, and telling
     him he is "already on" the seat he is leaving would put the hover and the
     post-drop warning list at odds (reviewer, 7 Sep 26) */
  const self:any[]=(Array.isArray(selfKey)?selfKey:[selfKey]).filter(Boolean);
  const isSelf=(k:any)=>self.indexOf(k)>=0;
  const wantsW=(w:any)=>kind?w.kind===kind:!!w.noconf;
  const wantsD=(dw:any)=>!seatsOnly&&(kind?dw.sa===kind:saExemptKind(dw.sa));
  (d.waves||[]).forEach((w:any,gi:any)=>{ if(!isStandalone(w)||!wantsW(w))return;
    (w.formations||[]).forEach((f:any,li:any)=>{ if(f.cx)return;
      const st=parseHM(f.to); let en=parseHM(f.ld||f.to);
      if(st==null||en==null)return; if(en<st)en+=1440;
      if(!overlap(s,e,st,en))return;
      (f.aircraft||[]).forEach((a:any,ai:any)=>{ if(a.cx)return;
        [['p',a.p],['w',a.w]].forEach(([seat,pid]:any)=>{ if(pid!==id||!PEOPLE[pid]||isSpecial(pid))return;
          const k=`${di}.${gi}.${li}.${ai}.${seat}`;
          if(isSelf(k))return;
          /* the WAVE's full label (AVALON), not the callsign (AV) — see the
             sacrew note in buildDay; SC's cs and label are both "SC" */
          const role=(f.spare||a.spare)?'SPARE':'MAIN', label=`${w.label} ${f.msn}`;
          hits.push({label,role,what:`${label} ${role}`,s:st,e:en,key:k});});});});});
  (d.dutywaves||[]).forEach((dw:any,dwi:any)=>{ if(!dw||!wantsD(dw))return;
    (dw.rows||[]).forEach((r:any,ri:any)=>{ if(r.cx)return;
      const w2=win(parseHM(r.str),parseHM(r.end)); if(!w2)return;
      if(!overlap(s,e,w2[0],w2[1]))return;
      const k=`d:${di}.${dwi}.${ri}`; if(isSelf(k))return;
      if(![r.id].concat(r.more||[]).some((pid:any)=>pid===id&&PEOPLE[pid]&&!isSpecial(pid)))return;
      const label=`${r.role} duty`;
      hits.push({label,role:'DUTY',what:label,s:w2[0],e:w2[1],key:k});});});
  return hits;
}
/* D503: flight reporting resolves against each formation's take-off; SC's
   existing typed-B priority and bounded shift-date rule remain separate. */
export { intimeTime, intimeFold } from './reporting'
export function seatIntime(w:any,f:any,toM:any,parsed?:ReportingLine[]){
  const scIn=(w&&w.kind==='sc')?parseHM(f.br):null;
  if(scIn!=null)return toM-VCONF.reportLead<0&&scIn>toM?scIn-1440:scIn;
  return resolveReporting(w,f,toM,parsed).report;
}
/* "BRIEF 30 PRIOR", "brief 30", "30 mins prior" — an OFT remark that names its
   own brief lead overrides VCONF.epBrief for that line only (owner, 5 Aug 26);
   the seed EP-4s said 30 while the engine padded 15. \b keeps DEBRIEF out, the
   brief-first order settles "BRIEF 30 PRIOR" on the 30 it names, and the 0–240
   bound mirrors RULE_SPEC.epBrief so a typo like "BRIEF 3000" falls back to
   the default instead of minting a 50-hour window. */
export const briefLeadOf=(rmks:any)=>{ const s=String(rmks||'');
  const m=s.match(/\bbrief\s*[-:]?\s*(\d{1,3})\b/i)||s.match(/\b(\d{1,3})\s*(?:min(?:ute)?s?\s*)?prior\b/i);
  if(!m)return null; const n=+m[1]; return n>0&&n<=240?n:null; };
/* "2A: LATE SHOW", "SHOW AT BRIEF", "show @ brief" — an aircraft remark saying
   this crew is not required at the published in-time, only from the brief
   (owner, 6 Aug 26). Crew rest normally anchors on whichever comes first, the
   in-time or the brief; this moves that crew's anchor onto the brief alone.
   It does NOT excuse the rest rule — the 12h is still measured to the brief,
   so a brief that is itself too early still breaches. Parsed off the remark
   rather than a new field because the ride prefix ("2A:") is the squadron's
   own labelling and the phrase is what carries meaning — the same shape as
   briefLeadOf above and aarNeed in people.ts. */
export const lateShowOf=(rmks:any)=>/\b(?:late\s*show|show\s*(?:at|@)\s*brief|brief\s*show)\b/i.test(String(rmks||''));
/* THE PER-DAY BUILDER, extracted so a cross-week seed read (weekctx.ts) can
   run the exact same rule logic against an ADJACENT week's day — the day
   object comes from weekBundle(prevWeek) instead of the live DAYS array —
   without a second copy of any of it. nextDt/prevDt are date labels (not
   DAYS lookups) so the caller decides what's "next"/"previous", which is
   what lets collectEvents below hand the loaded week's Monday/Sunday the
   ADJACENT WEEK's edge dates instead of nothing. xweek marks a cross-week
   read for inpShow (see its own comment) — never set by collectEvents. */
export function buildDay(d:any,di:any,nextDt:any,prevDt:any,xweek?:any){
    const fly:any[]=[],forms:any[]=[],events:any[]=[],simcrew:any[]=[],sacrew:any[]=[];
    (d.waves||[]).forEach((w:any,gi:any)=>{
      const im=parseReportingLines(w);
      w.formations.forEach((f:any,li:any)=>{
        if(f.cx)return;                                        // cancelled line — nothing to check
        if(saExempt(w,f,null)){                                // AVALON / BB — outside the conflict engine
          /* AVALON'S ONE CHECK (owner, 11 Aug 26). The wave stays noconf — its crew are
             cross-checked against nothing — but the men on it must be on the island and
             fit, so their names and the shift window are collected here for the single
             look validate() gives them. MAIN and SPARE alike: both are jet seats.
             BB joined on 7 Sep 26 (owner — "bb main and spare rules are exactly the
             same … as Avalon"): every noconf standalone wave is collected. A BB shift
             with blank times has no window and is skipped — fail closed, inert. */
          if(w.noconf){
            const sTo=toMin(f.to); let sLd=toMin(f.ld||f.to); if(sLd<sTo)sLd+=1440;
            if(isFinite(sTo)&&isFinite(sLd))f.aircraft.forEach((a:any,ai:any)=>{ if(a.cx)return;
              /* the warning names the wave by its FULL label (AVALON), not the
                 formation callsign — that was shortened to "AV" on 25 Aug 26 for
                 the narrow board callsign box, and the LEAVE_FLY/DNIF prose reads
                 as prose ("but on AVALON — overseas"). Don't re-shorten to f.cs. */
              /* role + seat ride along since 7 Sep 26 for the three checks
                 validate() added on top of the availability look: SC currency
                 (every seat), the pilots-only front seat, and one man in two
                 AVALON/BB places. sacrew is port-only (the parity gate excises
                 it whole), so the extra fields cost nothing there. */
              const role=(f.spare||a.spare)?'SPARE':'MAIN';
              [['p',a.p],['w',a.w]].forEach(([seat,id]:any)=>{ if(id&&PEOPLE[id]&&!isSpecial(id))sacrew.push({id,s:sTo,e:sLd,label:`${w.label} ${f.msn}`,key:`${di}.${gi}.${li}.${ai}.${seat}`,work:false,role,seat,kind:w.kind}); });
            });
          }
          return;
        }
        const toM=toMin(f.to);
        let ldM=toMin(f.ld||f.to); if(ldM<toM)ldM+=1440;      // landed after midnight
        /* A STANDALONE line is a SHIFT, not a sortie: 0700–1300 means 0700–1300.
           It used to be padded like a jet — an hour of step in front, half an
           hour of dekit behind, a brief before that and a two-hour debrief tail —
           which made SC AM (07–13) and SC PM (13–19) overlap by 50 minutes and
           reported two clean abutting shifts as one fifteen-hour day. */
        const shiftLine=isStandalone(w);
        /* The brief time the scheduler INDICATED on the line (f.br) governs
           every brief-driven rule (owner, 6 Aug 26). VCONF.briefLead is only
           the default the board offers as a suggestion to accept — a blank B
           is still checked, against that same suggested time, so a line
           nobody has confirmed never goes silently unchecked. A standalone
           wave is a shift, not a sortie: it briefs nothing, and a value typed
           on one stays inert because every consumer gates on shift first. */
        /* Typed B retains the existing briefLead-bounded small-hours roll.
           D503 broadens only ordinary flight IN/RALLY: a reporting clock
           later than its own take-off belongs to the immediately prior day.
           Keep both interpretations shared with the pure chronology check. */
        const briefM=shiftLine?null:flightBrief(f,toM);
        const stepM=shiftLine?toM:toM-VCONF.step;               // sortie: step 1h pre-T/O
        const dekitM=shiftLine?ldM:ldM+VCONF.dekit;             // sortie: land + 30m dekit
        /* intime is the in-time the wave actually PUBLISHED (null when none is
           given); report falls back to the step time so the occupied window is
           still right. Crew rest needs the difference between the two.
           SC (owner, 24 Aug 26): a standalone briefs nothing, but the B box on
           an SC line is repurposed as that crew's IN-TIME — the report time,
           usually earlier than the shift start. Typed, it becomes the in-time
           that anchors crew rest and the advisories; blank (the normal case)
           leaves SC on its shift start exactly as before. AVALON/BB never reach
           here (saExempt returns above), so w.kind==='sc' is the whole guard.
           The body lives in seatIntime above (26 Aug 26) so slotRules' SANS
           window reads the identical clock — same SC-B precedence, same
           midnight roll. */
        const intime=seatIntime(w,f,toM,im);
        const report=(intime!=null)?intime:stepM;
        const fcps:any[]=[],acs:any[]=[],allCrew:any[]=[],spareCrew:any[]=[],spareAcs:any[]=[];
        f.aircraft.forEach((a:any,ai:any)=>{ if(a.cx)return;
          /* collected BEFORE the spare exemption: a spare crew is not checked
             against other commitments, but their SC currency still is */
          [a.p,a.w].forEach((id:any)=>{if(id&&PEOPLE[id]&&!isSpecial(id))allCrew.push(id);});
          if(saExempt(w,f,a)){                                  // SC SPARE — stood by, not cross-checked
            /* ...but still kept, because "not cross-checked against other tasks"
               is not the same as "may be anywhere on earth" */
            [a.p,a.w].forEach((id:any)=>{if(id&&PEOPLE[id]&&!isSpecial(id))spareCrew.push(id);});
            /* the RAW rows too, beside the deduped id set (31 Aug 26): the
               spare seat rule needs to know WHICH seat holds the man, and the
               two-SC-seats conflict needs the same man on two spare rows to
               stay two rows — the Set above collapses him to one id */
            spareAcs.push({p:a.p,w:a.w,key:`${di}.${gi}.${li}.${ai}`});
            return;}
          /* night for AAR purposes: the wave says so, or the sortie itself runs
             past 19:00 between take-off and landing */
          /* key = the aircraft's slot-key prefix, captured HERE because acs
             excludes CX'd and spare aircraft — ai is not recoverable by
             position later. Warnings anchor on it to pan to the line. */
          /* NIGHT AAR IS THE WAVE'S CALL, NOT THE CLOCK'S (owner, 21 Aug 26,
             the same afternoon the 19:00 clock line briefly became a setting:
             "make the rule for NAAR instead of a time — if the wave is night
             and AAR is mentioned, it's night AAR. Or NAAR is mentioned").
             A bare AAR is night only on a night wave; a landing time never
             decides it. An explicit NAAR/DAAR in the remarks still overrides
             either way, inside aarNeed. The reference's clock clause is
             excised by refwin.ts:reaar() so both engines agree everywhere. */
          acs.push({p:a.p,w:a.w,rmks:a.rmks,aar:aarNeed(a.rmks,!!w.night),key:`${di}.${gi}.${li}.${ai}`});
          [['FCP',a.p],['RCP',a.w]].forEach((pair:any)=>{ const seat=pair[0],id=pair[1]; if(!id||isSpecial(id))return;
            if(seat==='FCP')fcps.push(id);
            fly.push({id,seat,brief:briefM,to:toM,ld:ldM,step:stepM,dekit:dekitM,report,intime,
              lateShow:!shiftLine&&lateShowOf(a.rmks),   // this crew shows at the brief, not at the in-time
              shift:shiftLine,label:`${f.cs} ${f.msn}`,key:`${di}.${gi}.${li}.${ai}.${seat==='FCP'?'p':'w'}`});
            /* the slot key this event came off — so the crew picker can ask
               "is he busy at this hour" without counting the very slot it is
               about to plant him into (he occupies it in a swap or a re-test) */
            events.push({id,s:stepM,e:dekitM,to:toM,ld:ldM,report,brief:briefM,label:`${f.cs} ${f.msn}`,
              kind:shiftLine?'shift':'fly',slot:`${di}.${gi}.${li}.${ai}.${seat==='FCP'?'p':'w'}`});
          });
        });
        /* an SC formation carries its shift window so the SC DAY / SC NIGHT
           currency can be checked against it */
        forms.push({label:`${f.cs} ${f.msn}`,cs:f.cs,fcps,acs,
          sc:isStandalone(w)&&w.kind==='sc', shift:f.msn||f.shift||'', s:toM, e:ldM,
          allCrew:[...new Set(allCrew)], spareCrew:[...new Set(spareCrew)],spareAcs,key:`${di}.${gi}.${li}`});
      });
    });
    ['amt','oft'].forEach((k:any)=>((d.sims&&d.sims[k])||[]).forEach((s:any,ri:any)=>{ if(s.cx)return;
      const st=parseHM(s.str), en=parseHM(s.end)!=null?parseHM(s.end):(st!=null?st+VCONF.simLen:null);
      /* a sim box has the same two seats as the jet: front = pilot, back = WSO.
         only rows that actually name a p/w pair get seat-qualification checked. */
      if(s.p||s.w)simcrew.push({p:s.p,w:s.w,label:(k.toUpperCase()+' '+(s.label||'sim')),kind:k,ri});
      /* through win(), like every other row: a 2300–0100 box used to be stored
         as [1380,60] — an inverted interval that `overlap` can never match, so
         every check on that row was silently switched off. And the bodies
         dropped underneath the row (more[]) are as tasked as the two in seats. */
      const sw=win(st,en,VCONF.simLen); if(!sw)return;
      [s.p,s.w].concat(s.pax||[]).concat(s.more||[])   // sim who is free text (1C), not a person
        .forEach((id:any)=>{ if(id&&PEOPLE[id]&&!isSpecial(id))events.push({id,s:sw[0],e:sw[1],label:'Sim '+s.label,kind:'sim',key:'s:'+di+'.'+k+'.'+ri}); }); }));
    /* ---- sim brief / debrief windows -------------------------------------
       An EP profile on the OFT briefs 15 min before the box — unless its
       remarks name their own lead (briefLeadOf above), which wins for that
       line — and debriefs for 30 min after. The AMT is run as a block: it
       carries its OWN BRIEF row, and that row's time is the hard line — no
       extra lead is added on top — while its debrief is the DEBRIEF row + 30.
       Windows deliberately ABUT the box rather than overlap it, so the sim
       never clashes with itself.                                              */
    const simwin:any[]=[];
    const isB=(r:any)=>/^\s*BRIEF/i.test(r.label||''), isD=(r:any)=>/DEBRIEF/i.test(r.label||'');
    const rowIds=(r:any)=>[r.p,r.w].concat(r.pax||[]).concat(r.more||[]).filter((id:any)=>id&&PEOPLE[id]&&!isSpecial(id));   // sim who free text (1C)
    ((d.sims&&d.sims.oft)||[]).forEach((s:any,ri:any)=>{ if(s.cx)return; if(!/EP/i.test(s.label||''))return;
      const st=parseHM(s.str); if(st==null)return;
      const en=parseHM(s.end)!=null?parseHM(s.end):st+VCONF.simLen, ids=rowIds(s); if(!ids.length)return;
      const lead=briefLeadOf(s.rmks);
      simwin.push({ids,label:'OFT '+(s.label||'sim'),bs:st-(lead!=null?lead:VCONF.epBrief),be:st,ds:en,de:en+VCONF.simDebrief,key:`s:${di}.oft.${ri}`}); });
    (()=>{ const rows=((d.sims&&d.sims.amt)||[]).filter((r:any)=>!r.cx); if(!rows.length)return;
      const box=rows.filter((r:any)=>!isB(r)&&!isD(r));
      const ids=[...new Set(box.reduce((a:any,r:any)=>a.concat(rowIds(r)),[]))]; if(!ids.length)return;
      const br=rows.find(isB), dr=rows.find(isD);
      const bs=br?parseHM(br.str):null;
      const boxStart=box.reduce((m:any,r:any)=>{const t=parseHM(r.str);return t!=null&&(m==null||t<m)?t:m;},null);
      const boxEnd=box.reduce((m:any,r:any)=>{const t=parseHM(r.end)!=null?parseHM(r.end):parseHM(r.str);return t!=null&&(m==null||t>m)?t:m;},null);
      const ds=dr?parseHM(dr.str):boxEnd;
      /* DEBRIEF is a RANGE now (owner, 13 Aug 26): if the DEBRIEF row carries its
         own end, that is the debrief window's close — a real start-to-end span,
         read straight off the cell. Only when the end is BLANK does it fall back
         to the old ds+VCONF.amtDebrief length, so the seed week (every DEBRIEF
         end empty) is byte-for-byte unchanged and the reference parity holds.
         The AMT block still anchors its BRIEF window on the BRIEF row and its
         box on the box rows; indexOf against the MODEL array recovers the true
         ri because `rows` was filtered (cx dropped). */
      const de=dr&&parseHM(dr.end)!=null?parseHM(dr.end):(ds!=null?ds+VCONF.amtDebrief:null);
      simwin.push({ids,label:'AMT',
        bs:bs!=null?bs:null, be:bs!=null?(boxStart!=null?boxStart:bs):null,
        ds:ds!=null?ds:null, de,key:'s:'+di+'.amt.'+d.sims.amt.indexOf(br||box[0])}); })();
    /* every body on a row counts, not just the one in its primary seat: the
       extras dropped underneath (row.more) were invisible to the engine, so a
       man added to a duty could fly straight through it unflagged. */
    /* kind matters now: a shift clashing with a duty post is a Warning, with a
       ground event or a programme item only an Advisory. */
    const push=(id:any,st:any,en:any,label:any,kind:any,key?:any)=>{
      if(!id||!PEOPLE[id]||isSpecial(id))return;
      const w2=win(st,en); if(!w2)return;
      /* the same man in the row's seat AND in its more[] is one commitment, not
         two — he used to be flagged as clashing with himself */
      if(events.some((x:any)=>x.id===id&&x.s===w2[0]&&x.e===w2[1]&&x.label===label))return;
      events.push({id,s:w2[0],e:w2[1],label,kind:kind||'other',key});
    };
    const extras=(r:any)=>(r&&r.more)||[];
    (d.dutywaves||[]).forEach((dw:any,dwi:any)=>dw.rows.forEach((r:any,ri:any)=>{ if(r.cx)return;
      if(dw.noconf||r.noconf){
        /* AVALON's desk shares the wave's exemption, not its invisibility: the same
           one check applies, with ATT B carved out — he cannot fly but he can man a
           desk (owner, 11 Aug 26). work:true is that carve-out. BB's desk is the
           same (7 Sep 26). */
        if(saExemptKind(dw.sa)){
          const w2=win(parseHM(r.str),parseHM(r.end));
          if(w2)[r.id].concat(extras(r)).forEach((id:any)=>{ if(id&&PEOPLE[id]&&!isSpecial(id))sacrew.push({id,s:w2[0],e:w2[1],label:r.role+' duty',key:`d:${di}.${dwi}.${ri}`,work:true,role:'DUTY',seat:null,kind:dw.sa}); });
        }
        return;
      }
      const st=parseHM(r.str),en=parseHM(r.end);
      push(r.id,st,en,r.role+' duty','duty',`d:${di}.${dwi}.${ri}`);
      extras(r).forEach((x:any)=>push(x,st,en,r.role+' duty','duty',`d:${di}.${dwi}.${ri}`)); }));
    /* a row flagged ⓘ info-only (owner, 1 Sep 26) is shown but never checked:
       it must not enter the event stream — that one skip keeps it out of every
       validator rule, the palette's clash checks and the Insights hours, which
       all read day.events. Kept as a SEPARATE guard beside cx, not merged. */
    (d.ground||[]).forEach((g:any,ri:any)=>{ if(g.cx)return; if(g.info)return;
      const st=parseHM(g.str),en=parseHM(g.end);
      push(whoId(g.who),st,en,g.prog,'ground',`g:${di}.${ri}`);
      extras(g).forEach((x:any)=>push(x,st,en,g.prog,'ground',`g:${di}.${ri}`)); });
    /* the squadron-wide Programme was never read here at all — a man booked to
       a 0845–1630 engagement could be scheduled to fly at 1245 with nothing
       said about it */
    (d.allhands||[]).forEach((x:any,ri:any)=>{ if(x.cx)return; if(x.info)return;
      const st=parseHM(x.str),en=parseHM(x.end);
      whoArr(x).forEach((nm:any)=>push(whoId(nm),st,en,x.prog||'programme','prog',`a:${di}.${ri}`));
      extras(x).forEach((v:any)=>push(v,st,en,x.prog||'programme','prog',`a:${di}.${ri}`)); });
    /* through inpWin, so an absence typed across midnight rolls exactly as a
       duty row or a night sortie does — see inputs.ts. A record with no usable
       window still comes through with null s/e and stays uncheckable. */
    const mapInp=(inp:any)=>{const w2=inpWin(inp);
      return {id:inp.person,s:w2?w2[0]:null,e:w2?w2[1]:null,type:inp.type,remarks:inp.remarks};};
    const input:any[]=inputsOn(d.dt).filter((inp:any)=>inpShow(inp,d.dt,xweek)).map(mapInp);
    /* THE MIDNIGHT TAIL (owner, 11 Aug 26 — "the default warning engine also checks
       in the same modality for all applicable rules based on timing"). A window that
       runs past midnight — a night sortie's landing and debrief, an overnight duty
       or shift — lives past minute 1440 in this day's minute-space, and win() /
       the ld<to roll already put it there. So TOMORROW's inputs are appended here,
       shifted a day, and every consumer of day.input inherits the check without
       knowing it exists: today's events (all ending ≤1440) can never reach them,
       and a shifted all-day input still spans exactly 1439 minutes, so the
       timedInput filter in validate.ts treats both copies identically. A record
       with no usable window stays uncheckable, exactly as its unshifted copy is.
       `nx` marks the entries as port-only for the parity excision (parity.test.ts)
       and the positive pin in the overnight suite. */
    if(nextDt!=null)inputsOn(nextDt).filter((inp:any)=>inpShow(inp,nextDt)).forEach((inp:any)=>{
      const m=mapInp(inp); if(m.s==null||m.e==null)return;
      input.push({...m,s:m.s+1440,e:m.e+1440,nx:true});
    });
    /* AND THE SAME TAIL BACKWARDS. The forward half above covers a window that
       runs PAST midnight; the mirror case is a window that starts BEFORE minute
       0. A sortie taking off in the small hours does exactly that — the brief
       lead (140), the step (60) and the report lead (180) are all subtracted
       from the take-off, so a 00:30 T/O briefs at 22:10 the PREVIOUS EVENING and
       its occupied window opens at 23:30 the night before. Those minutes are
       negative in this day's minute-space, and nothing in day.input could ever
       reach them: yesterday's inputs live only on yesterday's day. So a genuine
       clash — a man at a 22:00 meeting the night before a 00:30 take-off — went
       unflagged in complete silence, while the identical case in the forward
       direction flagged correctly (measured both ways, 11 Aug 26).
       Shifted −1440 so yesterday's records land in this day's minute-space, by
       the same rules as the forward half: a record with no usable window stays
       uncheckable, and a shifted all-day input still spans exactly 1439 minutes
       so validate.ts's timedInput filter treats every copy identically. An
       ordinary daytime sortie can never match one of these — its window never
       goes negative — so this adds no warning to any day that did not earn one.
       `pv` marks them port-only for the parity excision, as `nx` does. */
    if(prevDt!=null)inputsOn(prevDt).filter((inp:any)=>inpShow(inp,prevDt)).forEach((inp:any)=>{
      const m=mapInp(inp); if(m.s==null||m.e==null)return;
      input.push({...m,s:m.s-1440,e:m.e-1440,pv:true});
    });
    return {di,dow:d.dow,dt:d.dt,fly,forms,input,events,simcrew,simwin,sacrew};
}
/* the loaded week's Monday pv-tail and Sunday nx-tail used to read nothing
   past DAYS' own ends (owner ask: continuous rule reading — see weekctx.ts).
   edgeDate hands them the adjacent week's Monday/Sunday date label instead,
   and the global (date-keyed) INPUTS array already carries every authored
   week's rows, so the tail's date read (inputsOn — the live records, or a published date's frozen copies) just
   starts finding matches at the week edges it could never reach before. */
export function collectEvents(){
  return DAYS.map((d:any,di:any)=>buildDay(d,di, DAYS[di+1]?DAYS[di+1].dt:edgeDate(CURWEEK,1), DAYS[di-1]?DAYS[di-1].dt:edgeDate(CURWEEK,-1)));
}
/* earliest IN-TIME of a wave (from the wave's in-time lines; fallback = earliest TO) */
export function waveInTime(w:any){
  let best:any=null;
  const parsed=parseReportingLines(w);
  (w.formations||[]).forEach((f:any)=>{
    if(f.cx)return;
    const to=parseHM(f.to); if(to==null)return;
    const t=resolveReporting(w,f,to,parsed).report;
    if(t!=null&&(best==null||t<best))best=t;
  });
  if(best==null)(w.formations||[]).forEach((f:any)=>{const to=parseHM(f.to); if(to!=null&&(best==null||to<best))best=to;});
  return best;
}
/* Contiguous wave BANDS keyed off each wave's earliest in-time.
   Band 1 = start-of-day → wave-2 in-time; band 2 = wave-2 in-time → wave-3 in-time;
   last band → end of day. (matches "morning up to next wave's in-time = this wave") */
export function waveWindows(d:any){
  const ws=(d.waves||[]).map((w:any)=>({label:w.label,night:!!w.night,in:waveInTime(w)})).filter((w:any)=>w.in!=null)
          .sort((a:any,b:any)=>a.in-b.in);
  return ws.map((w:any,i:any)=>{
    const start=i===0?0:w.in, end=i<ws.length-1?ws[i+1].in:1440;
    return {label:w.label,night:w.night,in:w.in,s:Math.max(0,start),e:Math.max(0,end),
      ...(end<0||w.in<0&&end<=0?{priorEmpty:true}:{})};
  });
}
