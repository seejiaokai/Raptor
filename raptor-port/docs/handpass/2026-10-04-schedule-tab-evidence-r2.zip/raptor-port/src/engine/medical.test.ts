/* The medical tracker's derivations and trim planners (owner, 27 Aug 26).
   Pure functions over INPUTS — these tests plant rows directly and restore
   the array after each, the suite's pristine-INPUTS idiom. Ordinals are the
   dateOrd form y*10000+m*100+d; every planted row carries an explicit yr
   anchor so nothing here leans on the loaded week. */
import { afterEach, describe, expect, it } from 'vitest'
import { INPUTS } from './inputs'
import { ordShift, ordLabel, medStartOrd, medEndOrd, medDownAsOf, pendingUpchits, upchitsWithin, upchitTrimPlan, upchitEffects, newMedTrimPlan, medClashes, medTailBeyond, subtractSpans, medEpisode } from './medical'

const ISNAP = JSON.stringify(INPUTS)
afterEach(() => { INPUTS.length = 0; JSON.parse(ISNAP).forEach((r: any) => INPUTS.push(r)) })

const med = (person: string, type: string, date: string, endDate?: string, yr = 2026) => {
  const r: any = { person, type, date, allday: true, remarks: '', mod: 'now', yr }
  if (endDate) r.endDate = endDate
  INPUTS.push(r); return r
}
const up = (person: string, date: string, yr = 2026) => med(person, 'Upchit', date, undefined, yr)

describe('the date helpers', () => {
  it('ordShift walks real calendar days, across month and year ends', () => {
    expect(ordShift(20260801, -1)).toBe(20260731)
    expect(ordShift(20260101, -1)).toBe(20251231)
    expect(ordShift(20260713, -30)).toBe(20260613)
    expect(ordShift(null, -1)).toBe(null)
  })
  it('ordLabel speaks the record convention, anchored to the ROW year', () => {
    expect(ordLabel(20260713, 2026)).toBe('Jul 13')
    expect(ordLabel(20270103, 2026)).toBe('Jan 3 2027')
    expect(ordLabel(20270103, 2027)).toBe('Jan 3')
  })
  it('span ordinals resolve through the row anchor; a bad label is null', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect([medStartOrd(r), medEndOrd(r)]).toEqual([20260710, 20260713])
    expect(medEndOrd(med('t1', 'OML', 'Jul 10'))).toBe(20260710)   // no endDate → its own day
    expect(medStartOrd(med('t1', 'HL', 'garbage'))).toBe(null)
  })
})

describe('medDownAsOf', () => {
  it('covers its whole span inclusive, and only its span', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect(medDownAsOf(20260709).some((e: any) => e.person === 't1')).toBe(false)
    expect(medDownAsOf(20260710).some((e: any) => e.person === 't1')).toBe(true)
    expect(medDownAsOf(20260713).some((e: any) => e.person === 't1')).toBe(true)
    expect(medDownAsOf(20260714).some((e: any) => e.person === 't1')).toBe(false)
  })
  it('an unparseable row is skipped, never guessed at', () => {
    med('t1', 'ATT C', 'nonsense')
    expect(medDownAsOf(20260713).some((e: any) => e.person === 't1')).toBe(false)
  })
})

describe('pendingUpchits — the expired-and-unanswered nag', () => {
  it('appears the day after the downchit ends, carrying that row', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect(pendingUpchits(20260713).some((e: any) => e.person === 't1')).toBe(false)
    const hit = pendingUpchits(20260714).find((e: any) => e.person === 't1')
    expect(hit && hit.row).toBe(r)
    expect(hit.endOrd).toBe(20260713)
  })
  it('does not age out — an old debt still nags months later', () => {
    med('t1', 'OML', 'Feb 2', 'Feb 4')
    expect(pendingUpchits(20260714).some((e: any) => e.person === 't1')).toBe(true)
  })
  it('a person down again as of the date is not pending', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    med('t1', 'ATT B', 'Jul 15', 'Jul 20')
    expect(pendingUpchits(20260716).some((e: any) => e.person === 't1')).toBe(false)
  })
  it('a NEWER medical entry replaces the nag even before it starts (owner rule)', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    med('t1', 'ATT B', 'Jul 20', 'Jul 25')      // future-dated as of the 14th
    expect(pendingUpchits(20260714).some((e: any) => e.person === 't1')).toBe(false)
  })
  it('an upchit dated on the (trimmed) end clears it; an older episode\'s does not', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 12')      // the trimmed shape: end == upchit date
    up('t1', 'Jul 12')
    expect(pendingUpchits(20260714).some((e: any) => e.person === 't1')).toBe(false)
    med('t2', 'ATT C', 'Jul 10', 'Jul 13')
    up('t2', 'Jun 5')                            // last episode's paperwork
    expect(pendingUpchits(20260714).some((e: any) => e.person === 't2')).toBe(true)
  })
  it('the LATEST-ended expired row is the one carried', () => {
    med('t1', 'OML', 'Jun 1', 'Jun 3')
    const late = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    const hit = pendingUpchits(20260720).find((e: any) => e.person === 't1')
    expect(hit.row).toBe(late)
  })
})

describe('upchitsWithin — the trailing 30-day window, newest first', () => {
  it('takes exactly the trailing window, half-open at the far edge', () => {
    up('t1', 'Jul 31')
    up('t2', 'Jul 2')
    up('t3', 'Jul 1')                            // exactly 30 days back — out
    up('t4', 'Aug 2')                            // after as-of — not yet
    const got = upchitsWithin(20260731).map((e: any) => e.person)
    expect(got).toEqual(['t1', 't2'])            // newest first
  })
})

describe('upchitTrimPlan — the upchit day itself is a FIT day (owner, 27 Aug 26)', () => {
  it('trims a spanning row to end the day BEFORE the upchit (the owner\'s example)', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect(upchitTrimPlan('t1', 20260712)).toEqual([{ row: r, action: 'trim', newEndOrd: 20260711 }])
  })
  it('a row ending ON the upchit date still covers it — trimmed back a day too', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 12')
    expect(upchitTrimPlan('t1', 20260712)).toEqual([{ row: r, action: 'trim', newEndOrd: 20260711 }])
  })
  it('leaves an already-ended row alone (pending clears without mutation)', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 12')
    expect(upchitTrimPlan('t1', 20260713)).toEqual([])   // the canonical day-after upchit
    expect(upchitTrimPlan('t1', 20260714)).toEqual([])
  })
  // A row that STARTS AFTER the upchit is not this episode — it is the
  // "newer entry" the owner said replaces the nag (a future surgery already
  // filed, with its own document). The first cut swept it into the delete
  // branch, so an upchit for an OLD episode silently destroyed the future
  // record (27 Aug 26 overnight pass).
  it('a row starting after the upchit is left alone — a future entry is not this episode', () => {
    med('t1', 'OML', 'Jul 10', 'Jul 13')
    expect(upchitTrimPlan('t1', 20260709)).toEqual([])
  })
  it('a single-day row on the upchit day is REMOVED (a status covering only fit days is void), a future one untouched', () => {
    const r = med('t1', 'HL', 'Jul 10')
    expect(upchitTrimPlan('t1', 20260710)).toEqual([{ row: r, action: 'delete' }])
    expect(upchitTrimPlan('t1', 20260709)).toEqual([])
  })
  it('covers every COVERING row of the person in one pass — nobody else\'s, and no future row', () => {
    const a = med('t1', 'ATT C', 'Jul 10', 'Jul 20')
    const b = med('t1', 'OML', 'Jul 14', 'Jul 18')      // starts after the upchit — untouched
    med('t2', 'ATT C', 'Jul 10', 'Jul 20')
    const plan = upchitTrimPlan('t1', 20260712)
    expect(plan).toHaveLength(1)
    expect(plan[0]).toMatchObject({ row: a, action: 'trim', newEndOrd: 20260711 })
    expect(b.endDate).toBe('Jul 18')                    // the future row untouched
  })
  it('the row being edited is excluded via except', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect(upchitTrimPlan('t1', 20260712, r)).toEqual([])
  })
})

describe('upchitEffects — the save-time summary: what the upchit does, and what it leaves standing', () => {
  it('splits covering rows into the plan and later-dated rows into leftovers', () => {
    const now = med('t1', 'ATT B', 'Jul 13', 'Jul 15')
    const later = med('t1', 'ATT C', 'Jul 16', 'Jul 20')   // the tail of a split, or a filed future entry
    med('t2', 'ATT C', 'Jul 16', 'Jul 20')                 // someone else's — neither list
    const fx = upchitEffects('t1', 20260714)
    expect(fx.plan).toEqual([{ row: now, action: 'trim', newEndOrd: 20260713 }])
    expect(fx.leftovers).toEqual([later])
  })
  it('an already-ended row is in NEITHER list — it is history, not a leftover', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 12')
    const fx = upchitEffects('t1', 20260714)
    expect(fx.plan).toEqual([])
    expect(fx.leftovers).toEqual([])
  })
  it('honours except and an unreadable date answers nothing', () => {
    const r = med('t1', 'ATT C', 'Jul 16', 'Jul 20')
    expect(upchitEffects('t1', 20260714, r).leftovers).toEqual([])
    expect(upchitEffects('t1', null)).toEqual({ plan: [], leftovers: [] })
  })
})

describe('newMedTrimPlan — a different-type overlap wins its days', () => {
  it('the owner\'s example: ATT B 12–15 over ATT C 10–13 trims the C to 10–11', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect(newMedTrimPlan('t1', 'ATT B', 20260712, 20260715))
      .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711 }])
  })
  it('same type never reaches the planner\'s knife', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect(newMedTrimPlan('t1', 'ATT C', 20260712, 20260715)).toEqual([])
    expect(newMedTrimPlan('t1', 'att c', 20260712, 20260715)).toEqual([])   // spelling-proof
  })
  it('full containment deletes; disjoint spans touch nothing', () => {
    const r = med('t1', 'OML', 'Jul 12', 'Jul 13')
    expect(newMedTrimPlan('t1', 'ATT B', 20260710, 20260715)).toEqual([{ row: r, action: 'delete' }])
    expect(newMedTrimPlan('t1', 'ATT B', 20260714, 20260715)).toEqual([])
  })
  // The new input wins exactly ITS OWN days — an old row running PAST the
  // new one's end keeps its tail as a second row the applier mints. The
  // first cut dropped the tail wholesale, so a two-day entry landing
  // mid-way through a long downchit marked the man fit for the rest of it
  // (27 Aug 26 overnight pass).
  it('an old row starting inside the new range loses its head, and its tail rides the plan', () => {
    const r = med('t1', 'ATT C', 'Jul 12', 'Jul 20')
    expect(newMedTrimPlan('t1', 'HL', 20260710, 20260715))
      .toEqual([{ row: r, action: 'delete', tail: { startOrd: 20260716, endOrd: 20260720 } }])
  })
  it('a mid-span drop splits the old row: head trimmed, tail minted', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 20')
    expect(newMedTrimPlan('t1', 'ATT B', 20260712, 20260714))
      .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711, tail: { startOrd: 20260715, endOrd: 20260720 } }])
  })
  it('a single-day new input still cuts what it lands on, keeping the day after as the tail', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    expect(newMedTrimPlan('t1', 'OML', 20260712, null))
      .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711, tail: { startOrd: 20260713, endOrd: 20260713 } }])
  })
  it('cross-year: a row anchored 2027 is untouched by a 2026 span on the same words', () => {
    med('t1', 'ATT C', 'Jul 10', 'Jul 13', 2027)
    expect(newMedTrimPlan('t1', 'ATT B', 20260712, 20260715)).toEqual([])
  })
})

// The leftover (owner, 28 Aug 26): a status overtaken in the MIDDLE leaves a
// tail past the new entry. medTailBeyond is the one body the clash sheet and
// the planner read, and keepTail is the filer's per-leftover answer.
describe('medTailBeyond — the leftover the clash sheet offers Keep/Remove', () => {
  it('is the piece past the new end, the day after to the row\'s end', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 15')
    expect(medTailBeyond(r, 20260713)).toEqual({ startOrd: 20260714, endOrd: 20260715 })
  })
  it('is null when the row ends on or before the new end — no leftover to decide', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 15')
    expect(medTailBeyond(r, 20260715)).toBe(null)
    expect(medTailBeyond(r, 20260718)).toBe(null)
    expect(medTailBeyond(r, null)).toBe(null)
  })
})

describe('newMedTrimPlan keepTail — the tail is minted only where the filer kept it', () => {
  // A middle drop: ATT B 12–13 over ATT C 10–15 → head 10–11, leftover 14–15.
  it('OMITTED keeps every tail — the safety default for direct callers', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 15')
    expect(newMedTrimPlan('t1', 'ATT B', 20260712, 20260713))
      .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711, tail: { startOrd: 20260714, endOrd: 20260715 } }])
  })
  it('an EMPTY keepTail removes the tail — the clash sheet\'s Remove default', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 15')
    expect(newMedTrimPlan('t1', 'ATT B', 20260712, 20260713, undefined, []))
      .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711 }])   // head only, no tail
  })
  it('a LISTED row keeps its tail; the row is still cut to its head either way', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 15')
    expect(newMedTrimPlan('t1', 'ATT B', 20260712, 20260713, undefined, [r]))
      .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711, tail: { startOrd: 20260714, endOrd: 20260715 } }])
  })
  // When the new entry was split into segments around a kept status, each
  // segment calls the planner with its OWN end, but the leftover is the part
  // past the WHOLE entry — measured per-segment it minted a tail into a later
  // segment that then dropped it (28 Aug 26 review). entryEnd fixes it.
  it('the leftover is measured past the whole ENTRY end, not the segment end', () => {
    const r = med('t1', 'ATT C', 'Jul 10', 'Jul 25')
    // segment [10,12] of an entry whose real end is Jul 20: tail is 21–25, not 13–25
    expect(newMedTrimPlan('t1', 'ATT B', 20260710, 20260712, undefined, [r], 20260720))
      .toEqual([{ row: r, action: 'delete', tail: { startOrd: 20260721, endOrd: 20260725 } }])
    // omitted entryEnd still falls back to the segment end — direct callers unmoved
    expect(newMedTrimPlan('t1', 'ATT B', 20260710, 20260712, undefined, [r])[0].tail)
      .toEqual({ startOrd: 20260713, endOrd: 20260725 })
  })
  it('is identical across all four down-types as the middle status', () => {
    for (const mid of ['ATT B', 'ATT C', 'HL', 'OML']) {
      INPUTS.length = 0; JSON.parse(ISNAP).forEach((x: any) => INPUTS.push(x))
      // the existing row is a DIFFERENT down-type so it always clashes
      const base = mid === 'ATT C' ? 'HL' : 'ATT C'
      const r = med('t1', base, 'Jul 10', 'Jul 15')
      expect(newMedTrimPlan('t1', mid, 20260712, 20260713, undefined, []))
        .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711 }])              // removed: head only
      expect(newMedTrimPlan('t1', mid, 20260712, 20260713, undefined, [r]))
        .toEqual([{ row: r, action: 'trim', newEndOrd: 20260711, tail: { startOrd: 20260714, endOrd: 20260715 } }])  // kept
    }
  })
})

describe('medClashes — the clash sheet\'s list, one body with the trim planner', () => {
  it('lists each different-type overlap with the SHARED window, clamped both ends', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 15')
    expect(medClashes('t1', 'ATT B', 20260713, 20260718))
      .toEqual([{ row: c, loOrd: 20260713, hiOrd: 20260715 }])
    expect(medClashes('t1', 'ATT B', 20260708, 20260712))
      .toEqual([{ row: c, loOrd: 20260710, hiOrd: 20260712 }])
  })
  it('skips same-type rows, other people, disjoint spans and except', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 15')
    med('t1', 'ATT B', 'Jul 1', 'Jul 3')          // disjoint
    med('t2', 'OML', 'Jul 10', 'Jul 15')          // someone else
    expect(medClashes('t1', 'ATT C', 20260713, 20260718)).toEqual([])   // same type — refused elsewhere
    expect(medClashes('t1', 'ATT B', 20260713, 20260718, c)).toEqual([])
    expect(medClashes('t1', 'ATT B', 20260713, 20260718)).toHaveLength(1)
  })
})

describe('subtractSpans — the days a new entry keeps after the filer\'s choices', () => {
  it('a kept status in the middle splits the new span into two pieces', () => {
    expect(subtractSpans(20260710, 20260720, [{ s: 20260713, e: 20260714 }]))
      .toEqual([{ startOrd: 20260710, endOrd: 20260712 }, { startOrd: 20260715, endOrd: 20260720 }])
  })
  it('a kept status covering everything leaves nothing', () => {
    expect(subtractSpans(20260713, 20260715, [{ s: 20260710, e: 20260715 }])).toEqual([])
  })
  it('edge overlaps clamp; no choices keeps the whole span; month edges step through real dates', () => {
    expect(subtractSpans(20260710, 20260715, [{ s: 20260708, e: 20260711 }]))
      .toEqual([{ startOrd: 20260712, endOrd: 20260715 }])
    expect(subtractSpans(20260710, 20260715, [])).toEqual([{ startOrd: 20260710, endOrd: 20260715 }])
    expect(subtractSpans(20260728, 20260805, [{ s: 20260801, e: 20260802 }]))
      .toEqual([{ startOrd: 20260728, endOrd: 20260731 }, { startOrd: 20260803, endOrd: 20260805 }])
  })
  it('two kept statuses carve three ways round them, overlapping choices merge', () => {
    expect(subtractSpans(20260701, 20260715, [{ s: 20260704, e: 20260705 }, { s: 20260709, e: 20260710 }]))
      .toEqual([
        { startOrd: 20260701, endOrd: 20260703 },
        { startOrd: 20260706, endOrd: 20260708 },
        { startOrd: 20260711, endOrd: 20260715 }])
    expect(subtractSpans(20260701, 20260710, [{ s: 20260703, e: 20260706 }, { s: 20260705, e: 20260708 }]))
      .toEqual([{ startOrd: 20260701, endOrd: 20260702 }, { startOrd: 20260709, endOrd: 20260710 }])
  })
})

// medEpisode (owner, 1 Sep 26): the person's overlapping-or-touching medical
// rows as one evolving episode, so the Medical page shows every document
// together. A pure partition over existing rows — oldest-first, own person
// only, the closing upchit folded in, fail-closed on a bad date.
describe('medEpisode — one evolving episode\'s rows, for showing its documents together', () => {
  it('groups an overlapping change of status, oldest first, from either end', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    const b = med('t1', 'ATT B', 'Jul 12', 'Jul 16')      // overlaps the C
    expect(medEpisode(c)).toEqual([c, b])
    expect(medEpisode(b)).toEqual([c, b])                 // symmetric
  })
  it('groups statuses that merely TOUCH — the common shape after the clash sheet trims', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    const b = med('t1', 'ATT B', 'Jul 14', 'Jul 18')      // starts the day after C ends
    expect(medEpisode(c)).toEqual([c, b])
  })
  it('does NOT bridge a real gap — a separate later episode stays separate', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    med('t1', 'ATT B', 'Jul 20', 'Jul 25')                // a week clear — its own episode
    expect(medEpisode(c)).toEqual([c])
  })
  it('folds in the closing upchit (owner: see the whole episode\'s paperwork)', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    const u = up('t1', 'Jul 14')                          // the day-after closer
    expect(medEpisode(c)).toEqual([c, u])
    expect(medEpisode(u)).toEqual([c, u])                 // from the upchit too, no duplicate
  })
  it('is one person\'s own rows only', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 13')
    med('t2', 'ATT B', 'Jul 12', 'Jul 16')               // someone else, same days
    expect(medEpisode(c)).toEqual([c])
  })
  it('a lone entry is its own episode; a bad-date row answers with just itself', () => {
    const c = med('t1', 'OML', 'Jul 10', 'Jul 12')
    expect(medEpisode(c)).toEqual([c])
    const bad = med('t3', 'HL', 'garbage')
    expect(medEpisode(bad)).toEqual([bad])
    expect(medEpisode(null)).toEqual([])
  })
  it('chains a three-status episode into one, oldest first', () => {
    const c = med('t1', 'ATT C', 'Jul 10', 'Jul 12')
    const b = med('t1', 'ATT B', 'Jul 13', 'Jul 16')
    const h = med('t1', 'HL', 'Jul 15', 'Jul 20')         // overlaps the B, which touches the C
    expect(medEpisode(c)).toEqual([c, b, h])
  })
})
