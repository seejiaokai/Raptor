import { DAYS } from './data'
import { PEOPLE, whoId, isSpecial, callsignTakenBy, indexCallsigns } from './people'
import { SCHED, markEdit, markDeletion, deletionWasIssued, markStructuralAdd, dayApproved, dropRowMarks, protectedWeek, dayCurVer, daySnapOf } from './publish'
import { parseHM, hhmm, hmOK } from './time'
import { INPUTS, DATES, inpId, inputCoversDate, isUnavail, isPersonal, inpLabel, dateIx } from './inputs'
import { shiftKeys, seatRow } from './keys'
import { inputProtected } from './quarantine'
import { VCONF } from './rules'
import { HOOKS } from './hooks'
import { logEdit } from './editlog'
import { ridWriteKey } from './rowids'
import { rowElsewhere } from './weekstash'
import { requestRowFields, srcvOf, standsOn, standingRow } from './overlay'
export function whoArr(r:any){return Array.isArray(r.who)?r.who.slice():(r.who?[r.who]:[]);}
/* Blanks are HELD, not filtered out: a cleared slot has to keep its index or
   every person after it shifts up one and the amendment marks — and the keys
   stored on a published AL — come to point at the wrong body. Only trailing
   blanks are dropped, so the list cannot grow without bound. */
export function whoSet(r:any,arr:any){
  arr=arr.slice();
  while(arr.length&&!arr[arr.length-1])arr.pop();
  r.who=arr.length>1?arr:(arr[0]||'');
}
/* every level optional: a key can outlive the row it addresses (an armed slot,
   a drag in flight, a stale amendment key) and asking for it must return nothing
   rather than throwing out of the middle of a click handler */
export function flyRef(key:any){const[di,gi,li,ai]=String(key).split('.');
  const d=DAYS[+di]; if(!d)return undefined;
  const w=(d.waves||[])[+gi]; if(!w)return undefined;
  const f=(w.formations||[])[+li]; if(!f)return undefined;
  return (f.aircraft||[])[+ai];}
/* ---------------------------------------------------------------------------
   OVERFLOW CREW — "drop below a puck to add"
   Duties, ground, sims and the personal-input rows were one person each: the
   drop replaced whoever was there. Every one of them can now hold as many as
   you drop in. The extras live on the row itself as `more[]` and are addressed
   with an `.xN` suffix on the key the row already had, so amendment marks,
   undo, drag-and-drop and the text funnels all keep working unchanged.
   A flying line is the one exception — an F-15 has two seats, so it stays
   FCP + RCP and a third body is refused.
   --------------------------------------------------------------------------- */
export function rowRef(k:any,a:any){
  const d=DAYS[+a[0]]; if(!d)return null;
  try{
    if(k==='d')return d.dutywaves[+a[1]].rows[+a[2]];
    if(k==='g')return d.ground[+a[1]];
    if(k==='s')return d.sims[a[1]][+a[2]];
    if(k==='a')return d.allhands[+a[1]];
  }catch(_){}
  return null;
}
export const XKEY=/\.x(\d+)$/;
/* how many crew a row is holding right now, primary seats included */
export function rowCrew(k:any,a:any){
  const r=rowRef(k,a); if(!r)return [];
  const out:any[]=[];
  if(k==='d')out.push(PEOPLE[r.id]?r.id:'');
  else if(k==='g')out.push(whoId(r.who)||'');
  else if(k==='s'){
    if(Array.isArray(r.pax))r.pax.forEach((v:any)=>out.push(PEOPLE[v]?v:''));
    else {out.push(PEOPLE[r.p]?r.p:''); out.push(PEOPLE[r.w]?r.w:'');}
  }
  (r.more||[]).forEach((v:any)=>out.push(PEOPLE[v]?v:''));
  return out;
}
/* EVERY PLACE ON A ROW, with who stands there — the places a seat key can name (a crowd's `a:di.ri.N`, a desk or a
   ground row's primary seat and its `.xN` extras, a sim's `.p`/`.w`/`.pax.N`/`.xN`). `rowKey` is the ROW (keys.ts
   seatRow). Read by avail.ts slotBar's one-man-one-place-on-a-row check ([CROWD-SWAP-SAYS-BUSY], 26 Sep 26). A flying
   seat is its own row and has no list here. */
export function rowPlaces(rowKey:any):any[]{
  const s=String(rowKey),c=s.indexOf(':'); if(c<0)return [];
  const k=s.slice(0,c),a=s.slice(c+1).split('.'),r=rowRef(k,a); if(!r)return [];
  const out:any[]=[], add=(key:any,v:any)=>{const id=whoId(v); if(id&&PEOPLE[id])out.push({key,id});};
  if(k==='a')whoArr(r).forEach((v:any,i:any)=>add(`${s}.${i}`,v));
  else if(k==='g')add(s,r.who);
  else if(k==='d')add(s,r.id);
  else if(k==='s'){add(`${s}.p`,r.p);add(`${s}.w`,r.w);(r.pax||[]).forEach((v:any,i:any)=>add(`${s}.pax.${i}`,v));}
  (r.more||[]).forEach((v:any,i:any)=>add(`${s}.x${i}`,v));
  return out;
}
export function slotVal(key:any){
  key=String(key);const c=key.indexOf(':');
  { const m=key.match(XKEY);
    if(m&&c>=0){const k=key.slice(0,c),a=key.slice(c+1).replace(XKEY,'').split('.');
      const r=rowRef(k,a); const v=r&&(r.more||[])[+m[1]];
      return PEOPLE[v]?v:'';} }
  /* the flying branch guards like every other (audit, 8 Sep 26): flyRef is
     built to answer nothing for a key that outlived its row, and reading a
     seat off that nothing threw out of the middle of a click handler */
  if(c<0){const r=flyRef(key); return r?(r[key.split('.')[4]]||''):'';}
  const k=key.slice(0,c),a=key.slice(c+1).split('.'),d=DAYS[+a[0]];
  try{
    if(k==='d'){const r=d.dutywaves[+a[1]].rows[+a[2]];return r&&PEOPLE[r.id]?r.id:'';}
    if(k==='s'){const r=d.sims[a[1]][+a[2]]; if(!r)return '';
      if(a[3]==='pax'){const v=(r.pax||[])[+a[4]];return PEOPLE[v]?v:'';}
      return PEOPLE[r[a[3]]]?r[a[3]]:'';}
    if(k==='g'){const r=d.ground[+a[1]];return r?(whoId(r.who)||''):'';}
    if(k==='a'){const r=d.allhands[+a[1]];return r?(whoId(whoArr(r)[+a[2]])||''):'';}
  }catch(_){}
  return '';
}
/* every slot mutation funnels through setSlotVal, so this is the one place that
   needs to remember WHICH item changed for the amendment-level marks.
   `was`/`now` are the edit log's, and optional: a caller that does not know
   both values logs nothing rather than logging a half-truth (editlog.ts). */
/* store the mark rid-anchored (ridWriteKey self-heals a just-created row's
   missing id); logEdit translates independently on its own read side, so it
   takes the original positional key. */
export function noteChange(key:any,was?:any,now?:any){ if(key){const rk=ridWriteKey(String(key),DAYS); SCHED.pending[rk]=1; delete SCHED.changes[rk]; logEdit(key,was,now);} }

/* =====================================================================
   THE ONE REFUSAL IN THIS APP — a placeholder puck may not crew a jet (D33,
   22 Sep 26; [OIL-SEATS-CAN-EARN] §5 step 2).

   WHY IT IS A REFUSAL AND NOT A WARNING, said out loud because it breaks a
   standing rule. Every other door here PLANTS FIRST AND WARNS AFTER (owner,
   13 Aug 26). The newest ruling wins, and this change carves the FIRST hard
   refusal out of that rule — narrowly: a placeholder id on a flying key, and
   nothing else. The reason it earns the exception is that a placeholder in a
   cockpit draws the jet as CREWED with nobody on it: `isSpecial` removes both
   pucks from every validation and availability path, so no warning the app can
   raise would ever appear. A rule that plants and then says nothing is not
   plant-then-warn; it is plant-and-hide.

   THE GRAMMAR DECIDES, NOT THE LOOKUP. A flying seat is the one key with no
   prefix (`di.gi.li.ai.seat`); everything else carries `d:`/`s:`/`g:`/`a:`/`iu:`.
   Judging by grammar rather than by resolving the row means a STALE flying key
   is still refused — resolving it would return nothing and the puck would pass
   the check on a technicality.

   NO OTHER SEAT IS TOUCHED. Ground rows, their extras, duty desks and their
   extras, sim seats, passengers, the Common Programme and — explicitly — an
   ACCEPTED REQUEST ROW (D46) all take the puck exactly as before. The owner
   chose the answer with no carve-outs, so over-refusing here is the specific
   mistake to avoid. */
export const SENTINEL_JET_BAR='cannot crew a jet; name the people flying it';

/** May this id be written into this seat? The PREFLIGHT — asked before anything
 *  is written, because a swap is TWO writes and a refusal thrown from inside the
 *  writer lets the second one run (Codex OSE-04): the person is duplicated, the
 *  placeholder is lost, and the caller reports success. Every door asks this
 *  first, about BOTH ends of a swap; the writers below keep their own copy as a
 *  belt so no future caller can bypass it. */
export function sentinelSeatOK(key:any,id:any):boolean{
  if(!id||!isSpecial(id))return true;                  // a named man is refused nowhere
  const k=String(key).replace(/\.\+$/,'');
  return k.indexOf(':')>=0;                            // no prefix = a flying seat
}
/* THE RETURN VALUE SAYS ONE THING ONLY: `false` means the write was REFUSED
   (D33) and nothing at all was written — no value, no pending mark, no edit-log
   line. `true` means the write proceeded exactly as it always has, which
   includes the two cases that write nothing for their own old reasons (a stale
   flying key, and re-planting the man already in the seat). It is deliberately
   NOT a "did the day change" answer: every caller that existed before this
   change ignores the result, and widening its meaning would quietly change what
   those callers do. */
export function setSlotVal(key:any,id:any):boolean{
  key=String(key);const c=key.indexOf(':');
  /* THE BELT, BEFORE noteChange. The doors preflight with sentinelSeatOK, so
     this should never fire from the app; it is here so no future caller can
     write a placeholder into a cockpit by a route nobody remembered to guard.
     It must sit above the mark: a pending mark with no change behind it reaches
     the next amendment as an unexplained item (Fable M4). */
  if(!sentinelSeatOK(key,id))return false;
  if(c<0&&!flyRef(key))return true;              // a stale flying key: nothing to write, nothing to mark
  /* dropping someone onto the seat they already occupy is not a change — it
     used to raise a pending mark, an undo step and a line in the next AL */
  const was=slotVal(key);
  if(was===(id||''))return true;
  noteChange(key,was,id||'');
  { const m=key.match(XKEY);
    if(m&&c>=0){const k=key.slice(0,c),a=key.slice(c+1).replace(XKEY,'').split('.');
      const r=rowRef(k,a); if(!r)return true;
      /* NEVER PAST THE END ([OIL-READ-LEFTOVERS] 2, Fable F4 — phase 7): a full sim row opens a spare PAIR (D50), and a
         drop on the second seat of it wrote beyond the list, leaving a hole saved as `null` in a list of text. The
         seat skipped is a BLANK, as every other empty seat is. */
      r.more=r.more||[]; while(r.more.length<+m[1])r.more.push(''); r.more[+m[1]]=id||'';
      while(r.more.length&&!r.more[r.more.length-1])r.more.pop();   // keep the tail tidy
      return true;} }
  if(c<0){flyRef(key)[key.split('.')[4]]=id||'';return true;}   // non-null: guarded above
  const k=key.slice(0,c),a=key.slice(c+1).split('.'),d=DAYS[+a[0]];
  try{
    if(k==='d'){d.dutywaves[+a[1]].rows[+a[2]].id=id||'';return true;}
    if(k==='s'){const r=d.sims[a[1]][+a[2]];
      /* pax indices are held in place rather than spliced out: lSeat() renders an
         empty id as nothing, so a blanked pax leaves no gap on screen but every
         other pax keeps the slot key it already had (no re-render key drift). */
      if(a[3]==='pax'){r.pax=r.pax||[];while(r.pax.length<+a[4])r.pax.push('');r.pax[+a[4]]=id||'';return true;}   // no hole — see the extras branch above
      r[a[3]]=id||'';return true;}
    /* store the stable person ID, not PEOPLE[id].cs (ARCH-STACK 1C, 14 Sep 26).
       The renderers resolve who→id→cs (whoId), so the printed byte is unchanged,
       and a rename now moves nothing — see renameCallsign. */
    if(k==='g'){d.ground[+a[1]].who=id||'';return true;}
    if(k==='a'){const r=d.allhands[+a[1]],arr=whoArr(r),i=+a[2];
      /* hold the index rather than splicing, exactly as the pax branch does.
         Splicing shifted every later person up one, so an amendment mark — and
         the key stored on a published AL — silently came to point at the wrong
         person. Trailing blanks are trimmed so the list does not grow forever. */
      if(id){if(i>=arr.length)arr.push(id);else arr[i]=id;}
      else if(i<arr.length)arr[i]='';
      while(arr.length&&!arr[arr.length-1])arr.pop();
      whoSet(r,arr);return true;}
  }catch(_){}
  return true;
}
/* dropped on a people CELL rather than on a specific puck */
/* Same contract as setSlotVal above: `false` means REFUSED and nothing written. */
/* WHERE A FILL LANDED ([CROWD-SWAP-SAYS-BUSY], W3's walk, 26 Sep 26). A drop on a row's "+ add" and an armed append
   name the ROW, and fillSlot picks the place — the next index of a crowd, the first empty seat, the next extra. The
   question asked AFTER the write ("is he on this row twice now?", avail.ts slotBar) has to be asked of that place, not
   of the row, or every ordinary add would read as a second copy. drag.ts and view.ts placeArmed read it back. */
let FILLED:any=null;
export function lastFilled():any{return FILLED;}
const putAt=(k:any,id:any):boolean=>{FILLED=k;return setSlotVal(k,id);};
export function fillSlot(key:any,id:any):boolean{
  key=String(key); FILLED=null;
  /* the belt, ahead of every branch — so the append doors cannot reach a
     cockpit by a route the preflight was not asked about */
  if(!sentinelSeatOK(key,id))return false;
  /* …and ONE MAN, ONCE PER ROW (owner, D271, 27 Sep 26). An append puts him on the row at a NEW place, so any place he
     already holds there refuses it and nothing is written. The doors ask first, with their own words (avail.ts
     rowTwice, called by drag.ts applyDrop and state/view.ts placeArmed — a move clears the place he leaves BEFORE this
     runs, so his own move to the end of his crowd is not refused here); this belt is for a caller nobody remembered to
     guard, as sentinelSeatOK's is. Never in setSlotVal: a swap inside one crowd is two writes, and between them the
     first man briefly stands on the row twice. */
  if(id&&PEOPLE[id]&&!isSpecial(id)&&rowPlaces(seatRow(key)).some((x:any)=>x.id===id))return false;
  if(/\.\*$/.test(key)){const b=key.slice(0,-1);            // sims: front seat, else rear
    return putAt(slotVal(b+'p')?b+'w':b+'p',id);}
  /* sims pax: append to the end of the list. This MUST be tested before the generic
     '.+' programme branch below, because 's:0.amt.1.pax.+' also ends in '.+' and
     would otherwise be written into d.allhands. */
  if(/\.pax\.\+$/.test(key)){const a=key.slice(key.indexOf(':')+1).split('.');
    const r=(DAYS[+a[0]].sims||{})[a[1]]&&DAYS[+a[0]].sims[a[1]][+a[2]]; if(!r)return true;
    r.pax=r.pax||[];
    /* reuse the first blanked index if there is one, so removing then re-adding a
       body doesn't grow the array forever */
    let i=r.pax.findIndex((v:any)=>!v||!PEOPLE[v]); if(i<0)i=r.pax.length;
    return putAt(`s:${a[0]}.${a[1]}.${a[2]}.pax.${i}`,id);}
  if(/^a:.*\.\+$/.test(key)){const a=key.slice(key.indexOf(':')+1).split('.');   // programme: append
    const r=DAYS[+a[0]].allhands[+a[1]]; if(!r)return true;
    return putAt(`a:${a[0]}.${a[1]}.${whoArr(r).length}`,id);}
  /* every other list row: fill the first empty primary seat, else add one more.
     No limit — a duty, a ground item or a sim can carry as many bodies as the
     scheduler drops onto it. */
  if(/\.\+$/.test(key)){
    const base=key.slice(0,-2), c2=base.indexOf(':');
    const k=base.slice(0,c2), a=base.slice(c2+1).split('.');
    const r=rowRef(k,a); if(!r)return true;
    /* only a genuinely EMPTY primary seat is filled. A row carrying free text
       ("ALL PILOTS", "149") is not empty — the puck goes below it instead, or
       the text would be silently destroyed. */
    if(k==='d'&&!String(r.id||'').trim())return putAt(base,id);
    if(k==='g'&&!String(r.who||'').trim())return putAt(base,id);
    if(k==='s'&&!Array.isArray(r.pax)){
      if(!PEOPLE[r.p])return putAt(base+'.p',id);
      if(!PEOPLE[r.w])return putAt(base+'.w',id);}
    if(k==='s'&&Array.isArray(r.pax)){
      let i=r.pax.findIndex((v:any)=>!v||!PEOPLE[v]);
      if(i>=0)return putAt(base+'.pax.'+i,id);}
    r.more=r.more||[];
    let i=r.more.findIndex((v:any)=>!v||!PEOPLE[v]);
    if(i<0)i=r.more.length;
    return putAt(base+'.x'+i,id);
  }
  return putAt(key,id);
}
/* ---------------- generic TEXT addressing (inline editing) ------------
   Every string in the day model is reachable through one key, exactly the way
   every crew position is reachable through a slot key. The day index always
   comes FIRST after the prefix so keyDay() still resolves the amendment day
   and per-item AL colouring works on text as well as on pucks.
     dn:di.i             day (overall) note line
     sn:di               sims scheduler-notes block
     pn:di               programme scheduler-notes block
     dtn:di              duties scheduler-notes block
     gn:di               ground scheduler-notes block
     ap:di.ri.fld        programme row   (prog|sub|str|end)
     wl:di.gi            wave label
     ff:di.gi.li.fld     formation       (cs|msn|to|ld|br)
                         br is the BRIEF time the scheduler indicated. Blank
                         means "not indicated" — the engine then briefs off
                         VCONF.briefLead, which is the same value the board
                         offers as a suggestion to accept.
     fr:di.gi.li.ai      aircraft remarks
     dl:di.wi            duty-wave label
     dr:di.wi.ri.fld     duty row        (role|str|end)
     sr:di.kind.ri.fld   sim row         (label|str|end)
     gr:di.ri.fld        ground row      (prog|str|end)
   -------------------------------------------------------------------- */
export const TIME_TXT=/\.(to|ld|br|str|end)$/;
export function txtRef(path:any){
  const s=String(path),c=s.indexOf(':'); if(c<0)return null;
  const k=s.slice(0,c),a=s.slice(c+1).split('.'),d=DAYS[+a[0]]; if(!d)return null;
  try{
    /* a day-note line is `{id,t}` now (engine/note.ts) — edit targets its TEXT,
       leaving the id intact; addressing stays positional (dn:di.i). A missing or
       legacy non-object note yields null → txtGet '' / txtSet no-op. */
    if(k==='dn'){const nt=(d.notes||[])[+a[1]];return nt&&typeof nt==='object'?{o:nt,k:'t'}:null;}
    if(k==='sn')return{o:d,k:'simnotes'};
    if(k==='pn')return{o:d,k:'prognotes'};
    if(k==='dtn')return{o:d,k:'dutynotes'};
    if(k==='gn')return{o:d,k:'grndnotes'};
    if(k==='ap')return{o:d.allhands[+a[1]],k:a[2]};
    if(k==='wl')return{o:d.waves[+a[1]],k:'label'};
    if(k==='ff')return{o:d.waves[+a[1]].formations[+a[2]],k:a[3]};
    if(k==='fr')return{o:d.waves[+a[1]].formations[+a[2]].aircraft[+a[3]],k:'rmks'};
    if(k==='dl')return{o:d.dutywaves[+a[1]],k:'label'};
    if(k==='dr')return{o:d.dutywaves[+a[1]].rows[+a[2]],k:a[3]};
    if(k==='sr')return{o:d.sims[a[1]][+a[2]],k:a[3]};
    if(k==='gr')return{o:d.ground[+a[1]],k:a[2]};
  }catch(_){}
  return null;
}
export function txtGet(path:any){const r=txtRef(path);return (r&&r.o&&r.o[r.k]!=null)?String(r.o[r.k]):'';}
/* returns true when the model actually moved, so callers can skip a re-render */
export function txtSet(path:any,v:any){
  const r=txtRef(path); if(!r||!r.o)return false;
  v=String(v==null?'':v).replace(/\s+/g,' ').trim();
  if(v==='—')v='';                                       // the empty-field placeholder
  /* A TIME CELL TAKES A TIME, OR NOTHING (audit, 12 Aug 26). Until this, an
     unreadable value was silently normalised to '' — so typing `morning` into
     a take-off did not just fail, it CLEARED the take-off, and the line then
     dropped out of the conflict engine altogether: on the seed Monday four
     real warnings, including a hard clash, disappeared with it. And an
     out-of-range value went in as arithmetic (`9999` → `100:39`), printing a
     take-off no clock shows and a crew-rest line reading "-5h-5".
     Refused rather than warned for the same reason as the brief guard below:
     these are not planning decisions anyone could mean, they are typos, and
     both callers already answer a false return by reverting their own cell.
     Clearing a time to EMPTY stays legal — that is how a scheduler unsets it.
     hmOK, not parseHM, is the question: parseHM is the shared loose reader
     and stays loose (time.ts). */
  if(TIME_TXT.test(String(path))){
    if(v&&!hmOK(v)){HOOKS.toast(`${v} is not a time — try 0900 or 09:00`,'warn');return false;}
    const m=parseHM(v);v=(m==null)?'':hhmm(m);
  }
  const was=String(r.o[r.k]==null?'':r.o[r.k]);
  if(was===v)return false;
  /* A BRIEF LATER THAN ITS OWN TAKE-OFF IS REFUSED (owner, 12 Aug 26 — "u can
     put guard rails to deny such inputs", after the audit found what one does).
     The brief window runs brief..T/O, so a B typed after T/O inverts it and the
     line's "no time for the flight brief" check goes silently dark — the one
     failure mode a soft-bar app must not have, because every other bar here
     still SAYS something. Refused rather than warned because, unlike every
     other bar in this app, it is not a planning decision a scheduler might
     mean: it is a typo. Both callers already revert the cell on a false return
     (board.ts's boardChange, textedit.ts's routeFocusOut), so the bad value
     never sits on screen looking saved.
     NOT refused where events.ts's preflight roll makes it legitimate: a
     small-hours T/O whose brief lead already crosses midnight briefs the
     PREVIOUS evening, so 2210 against a 0030 launch is a real time. Same
     condition, spelled the same way — toM < VCONF.briefLead.
     A standalone wave is a shift, not a sortie: it briefs nothing and every
     consumer gates on that first, so its inert B is left alone. */
  if(r.k==='br'&&v&&String(path).indexOf('ff:')===0){
    const a=String(path).slice(3).split('.');
    const w=((DAYS[+a[0]]||{}).waves||[])[+a[1]];
    const toM=parseHM(r.o.to),br=parseHM(v);
    if(w&&!w.standalone&&toM!=null&&br!=null&&toM>=VCONF.briefLead&&br>toM){
      HOOKS.toast(`The brief cannot be after the ${r.o.to} take-off`,'warn');
      return false;
    }
  }
  r.o[r.k]=v; noteChange(path,was,v);
  /* THE OTHER WAY ROUND: the T/O moves EARLIER and strands a brief behind it.
     The guard above closes the ordinary way in, but a scheduler who retimes a
     sortie must not be refused — the take-off is the primary fact and the
     stale brief is the thing that is now wrong. So the new T/O goes in and the
     impossible brief is CLEARED, visibly, with the reason said: the line falls
     back to the suggested lead (exactly what a blank B has always meant) and
     the B box is empty on screen, so a scheduler can see there is a brief to
     retype. Clearing it silently, or leaving it and computing something else
     underneath, would both break the standing promise that a bad time stays a
     VISIBLE bad time rather than being quietly reinterpreted. Through
     noteChange so the clear is marked pending and logged like any other edit. */
  if(r.k==='to'&&String(path).indexOf('ff:')===0&&r.o.br){
    const a=String(path).slice(3).split('.');
    const w=((DAYS[+a[0]]||{}).waves||[])[+a[1]];
    const toM=parseHM(v),br=parseHM(r.o.br);
    if(w&&!w.standalone&&toM!=null&&br!=null&&toM>=VCONF.briefLead&&br>toM){
      const bwas=String(r.o.br);
      r.o.br=''; noteChange(`ff:${a[0]}.${a[1]}.${a[2]}.br`,bwas,'');
      HOOKS.toast(`The ${bwas} brief was after the new take-off, so it has been cleared`,'warn');
    }
  }
  return true;
}
/* does the row an armed key addresses still exist? */
export function armTargetExists(key:any){
  const k=String(key).replace(/\.\+$/,'');
  try{
    if(k.indexOf(':')<0){const a=k.split('.');
      const f=(((DAYS[+a[0]]||{}).waves||[])[+a[1]]||{}).formations;
      const fm=f&&f[+a[2]];
      return !!(fm&&(fm.aircraft||[])[+a[3]]);}
    /* an Unavailable-row arm (see inputedit.tsx's reassignInput) addresses an
       INPUT by iid, not a schedule row — rowRef knows nothing of that grammar,
       so it is answered here directly: the arm is live exactly as long as the
       input record it names still exists. */
    if(k.indexOf('iu:')===0)return INPUTS.some((i:any)=>i.iid===k.slice(3));
    return rowRef(k.slice(0,k.indexOf(':')),k.slice(k.indexOf(':')+1).split('.'))!=null;
  }catch(_){ return false; }}
/* ---- board line / wave / panel controls --------------------------------
   One delegated click covers every ✕ / + / CX / ■ button on the board. Every
   branch ends in afterSchedMutate(), which re-validates, re-renders both the
   board and the week, and pushes an undo snapshot. */
export const acRef=(k:any)=>{const[di,gi,li,ai]=String(k).split('.').map(Number);
  const w=DAYS[di]&&DAYS[di].waves[gi], f=w&&w.formations[li];
  return f?{d:DAYS[di],w,f,a:f.aircraft[ai],ai,li,gi,di}:null;};
/* a formation is cancelled exactly when every one of its aircraft is */
export const rollCx=(f:any)=>{f.cx=f.aircraft.length>0&&f.aircraft.every((a:any)=>a.cx);};
/* ---- accepting a personal input ---------------------------------------
   A personal input is what aircrew SUBMITTED; it is not part of the issued
   programme until a scheduler accepts it. Accepting to 'g' promotes it into
   the day's ground programme as an ordinary row — from that moment it
   validates, drags, publishes and prints on the view-only page like anything
   else the scheduler wrote. Accepting to 'u' just files it under Unavailable
   and creates no row.

   The push goes through noteChange() on the row's own key, exactly as the
   board's "+ Item" control does. A write that skipped the funnel would be
   invisible to the amendment machinery: not marked pending, absent from the
   next AL and never re-validated.

   The link back to the source input is `src` on the ground row, so unaccept
   can find and remove the row it created even after other rows shift around
   it. Storing an index instead would rot the moment a row above it is deleted. */
/* The trailing segment is the row's anchor year `yr` (24 Aug 26): without it
   two inputs a year apart — same person, type, start AND bare date words —
   shared one key, so the global data-inpedit resolver could open last year's
   record from this year's card. The RAW field, never baseYear(): a fallback
   that moved with the loaded week would change the key on every week switch
   and orphan the ground rows that store it as `src`. */
export function inpKey(inp:any){return `${inp.person}|${inp.date}|${inp.type}|${inp.s==null?'':inp.s}|${inp.yr==null?'':inp.yr}`;}
/* A FILING IS COUNTED FROM THE FILING, NEVER MARKED ON THE DAYS ([DB-READINESS] group A, phase 6 (b); data-model.md §3
   ScheduleWeek — the `inp:` marks are "not stored at all — worked out on read"). Filing under Unavailable, its undo and
   the adoption of a standing row used to write an `inp:<di>.<id>` mark into the book of EVERY loaded day the request
   covered (markInputDays / publish.ts markInputFiling, both gone): one act writing days its maker may not hold (D450).
   The marks were already cosmetic — a published day's count, its pending list and its sign-offs come from the filing
   axis (publish.ts filingDelta against the issued version's `fil`), and "Discard marks" never undid a filing. So the
   act changes the request's own `acc` and nothing else; the bare markEdit() below is the history / render epilogue. */
export function acceptInput(di:any,inp:any,dest:any){
  const d=DAYS[di]; if(!d||!inp)return false;
  /* READ-ONLY QUARANTINE (P2-IMPL-03 + P2-QREV-02). Landing an input pushes/edits
     a ground row on DAYS[di] — the loaded week — AND changes the input's GLOBAL
     acc. Two tests, because filing is a GLOBAL input write, not only a loaded-week
     one: protectedWeek() covers the loaded week's own book; inputProtected(inp)
     covers a MULTI-DAY input that also spans a STASHED protected week (round-1
     checked only the loaded week, so filing such an input mutated the frozen
     week's global acc — the writer that bypassed the input funnel). Every accept
     path (the board control, the auto-land on create, the boot/week-load pass)
     funnels through here, so this one guard closes them all. */
  if(protectedWeek()||inputProtected(inp))return false;
  /* 'r' (removed — see unacceptInput) is NOT "already actioned": it is the
     dormant parked state whose whole exit is this call, so the Accept button
     must come back through here. Landed ('g') and filed ('u') still refuse. */
  if(inp.acc&&inp.acc!=='r')return false;        // already actioned — unaccept first
  /* leave / downchit / detachment are never accepted — they are already issued
     to everyone via the Unavailable block, and promoting one to a ground row
     would make the validator flag the row against its own source input (the
     two carry identical times, so overlap() is trivially true). The board
     never offers the control for these; this guard keeps any future call
     site honest. */
  if(isUnavail(inp.type))return false;
  if(dest==='u'){ inp.acc='u'; markEdit(); return true; }
  /* THE FILING ADDRESS IS THE INPUT'S STABLE ID (13 Sep 26, ARCH-STACK 1A;
     was the content key inpKey). Content keys are not unique — two inputs
     agreeing on person·date·type·start-minute (twins) minted the same `src`, so
     acceptedDay/unacceptInput/reconcile resolved the FIRST match and unaccepting
     one silently removed the other's row. The old mitigation REFUSED the second
     accept; the id fix lets both twins file independently. The guard below now
     means "this EXACT input already has a landing" — a correct idempotency check
     (re-accepting the same input never duplicates), not a twin refusal. */
  const key=inpId(inp);
  const onDay=DAYS.findIndex((dd:any)=>!!standsOn(dd,key,inp));   // its STANDING row — never a dead kept one (overlay.ts)
  if(onDay>=0){
    /* A "TAKEN OFF" REQUEST WHOSE OWN ROW STANDS AGAIN ([REQ-ORPHAN-ROW] 3, 28 Sep 26 — Fable's D176 read F3). A plan
       parked WITH the row, the request ✕'d since (dormant 'r'), then the plan switched in: the row is back beside a request
       reading "taken off", and Accept did nothing. Accept now ADOPTS that row — the request is on the programme again,
       no second row. (A general re-file on the switch itself was refused: switching back would then wake a deliberate
       removal as a fresh, flagging request — Fable's plan read F1.) Any other filing: the row is already there. */
    if(inp.acc==='r'){ inp.acc='g'; markEdit(); return true; }
    return false;
  }
  /* …AND NOT A SECOND ROW ON ANOTHER WEEK ([REQ-ORPHAN-ROW], 28 Sep 26; D175 across weeks — Fable's G3). A request covering
     Sun 19 – Mon 20 Jul landed on Sunday keeps its row in week 1; with week 2 loaded this guard used to see no row and let
     Monday take a second one. It asks the saved weeks too (weekstash.ts rowElsewhere — read-only; the filing stays
     week-local), and refuses when it cannot read one (never a second row on an unknown). */
  if(rowElsewhere(key,inp))return false;
  d.ground=d.ground||[];
  /* PUTTING AN ISSUED LANDING BACK IS A ROUND TRIP, NOT A NEW ROW ([HUMAN-RETEST] the amendment
     system, walk W4-F2, 24 Sep 26; register AM20). On a published day whose CURRENT issued
     version already carries this input's landed row, re-landing it restores THAT row's identity
     (its rid) at the place it held — otherwise the comparison with the issued document read
     "an issued row removed + a new row added": a two-item amendment on a day identical to what
     was issued, and publishable on the old sign-offs (content-equal, so they still matched).
     The values are minted from the input exactly as any landing's are, so a real difference
     (the scheduler had retimed the issued row) still shows as the change it is. */
  let ri=d.ground.length, rid:any=null;
  if(dayApproved(di)){
    const ver=dayCurVer(di), snap:any=ver!=null?daySnapOf(di,ver):null;
    const ig:any[]=(snap&&snap.d&&snap.d.ground)||[];
    /* (an issued row carrying `kept` — dead when it went out — is reused too: the published face shows that very row, and a
       landing on read restores it under the same id (overlay.ts landedRid), so Accept does not read "removed + added" for
       a row that looks unchanged — the FULL check, Astra's final read #3, its Accept half declined) */
    const ix=ig.findIndex((r:any)=>r&&r.src===key&&r.rid);
    if(ix>=0&&!(d.ground||[]).some((r:any)=>r&&r.rid===ig[ix].rid)){   /* never mint a second row with one id */
      rid=ig[ix].rid;
      /* back BESIDE ITS ISSUED NEIGHBOURS — before the first surviving row that followed it in the issued
         version — not at its issued index: once an earlier issued row is gone, or under a hand-set order, that
         index is somewhere else, and the day read "1 reorder" for a row that went back where it was (the
         amendment re-test's final read, Fable #5, 24 Sep 26) */
      const after=ig.slice(ix+1).map((r:any)=>r&&r.rid).filter(Boolean);
      const nx=(d.ground||[]).findIndex((r:any)=>r&&after.includes(r.rid));
      ri=nx>=0?nx:d.ground.length; }
  }
  /* who is the stable person ID (ARCH-STACK 1C, 14 Sep 26; was PEOPLE[id].cs).
     inp.person is already an id, and the renderers resolve who→id→cs (whoId), so
     the landed row prints the callsign unchanged while a rename moves nothing.
     Title is the TYPE and the submitter's remarks land in the row's rmks cell
     (owner, Aug 26): 'APPOINTMENT · dental review', not one mashed title. */
  /* the six fields the request writes on its row are ONE body (overlay.ts requestRowFields — a landing on read and a re-made
     row mint them the same way), and `srcv` records what the row was made from ([DB-READINESS] phase 6 (c)): a later edit
     of the request re-makes it, a scheduler's own edit of the row does not */
  const row:any={...requestRowFields(inp), src:key, srcv:srcvOf(inp)};
  if(rid)row.rid=rid;
  d.ground.splice(ri,0,row);
  inp.acc='g';
  if(rid){
    /* the restored row is the ISSUED one, not a draft addition: mark the edit (so the funnel's
       history + reconcile run) without registering a structural add, which would make a later
       removal of it read as "never issued" */
    markEdit(`gr:${di}.${ri}.prog`);
    return true;
  }
  /* markStructuralAdd, not trackStructuralAdd+noteChange (owner audit, 15 Aug
     26 — every OTHER new ground row gets a ~6s blue box, an accepted input's
     did not). The key is the row's first FIELD (gr:di.ri.prog), matching
     board.ts's own "+ Item" call exactly: that is what the row's <input>
     wears as data-bfld for paintFreshAdds to find, where the bare g:di.ri
     row address matches no element at all. deletionWasIssued's ground check
     already ORs both forms, so nothing that read the old key breaks. */
  markStructuralAdd(`gr:${di}.${ri}.prog`);
  return true;
}
/* LAND ONE ACTIVITY REQUEST ON ITS START DAY, AS A SCHEDULER'S ACCEPT WOULD — no longer an app path ([DB-READINESS] group A,
   phase 6 (c), 1 Oct 26). The app lands a request by working it out on read (engine/overlay.ts viewOfWeek, after every
   command and at every load — state/holderbase.ts): nobody's change, with the request's own row id. This helper, kept for
   the tests that set a day up by hand, lands through acceptInput instead (a scheduler's placement, its own row id); on a
   published day only with `onApproved` (the old live-filing rule, 16 Sep 26). Never call it from a door. */
export function autoAcceptInput(row:any,onApproved?:boolean):boolean{
  if(!row||row.acc||!isPersonal(row.type))return false;
  /* dateIx, not DATES.indexOf (24 Aug 26): the index must come from the DATE
     the row means, or a 2026 input landed on the identically-worded day of a
     loaded 2027 week. */
  const di=dateIx(row.date,row.yr);
  if(di<0)return false;
  if(dayApproved(di)&&!onApproved)return false;   // seed/restore: leave a published day alone
  return acceptInput(di,row,'g');
}
/* THE BOOT / WEEK-LOAD PASS (autoAcceptSeedInputs), THE ACC RE-READ (reconcileLandedAcc) AND THE RESTORE'S RE-LANDING
   (relandInputs) are gone ([DB-READINESS] group A, phase 6 (c), 1 Oct 26): every load and every command now works the week's
   request rows out from the holder base (state/holderbase.ts rederive → engine/overlay.ts viewOfWeek) — the landing, the
   `acc` the loaded week derives, and a request "taken off" staying off, all in one body; a second copy here could only
   drift from it. */
/* Which day carries the row this input was accepted onto, or -1. The row does
   NOT record its day, and the caller cannot infer it: a multi-day input
   renders an Accept button on every day it spans, so it may have been accepted
   onto any of them — the start date is a guess that silently misses. */
export function acceptedDay(inp:any){
  if(!inp||inp.acc!=='g')return -1;
  const key=inpId(inp);
  for(let i=0;i<DAYS.length;i++){
    if(standsOn(DAYS[i],key,inp))return i;   // its STANDING row (overlay.ts — never a dead kept one)
  }
  return -1;
}
/* RECONCILE A DAY'S GROUND FILING AFTER A WHOLE-DAY REPLACEMENT (P2-REV2-05).
   A recovery (loadVersionToWorkingCopy), a draft switch (draftSelect) or a
   template apply (applyDayTpl) replaces DAYS[di] wholesale — and the replacement
   content may not carry the ground row an input was filed 'g' onto. But those
   paths touch DAYS, not INPUTS, so the input keeps acc='g' with NO row behind it:
   a DANGLING filing. Left alone, a later AL freezes that 'g' into its snapshot
   fingerprint (a filing with no row), and the next navigation's acc-clear then
   re-derives '' (no row to reconstruct) — so a phantom input-amendment appears
   from navigation alone. Reconcile it HERE, right after the replacement and
   BEFORE any snapshot freezes it, exactly as the navigation reconciler
   (state/store.ts reconcileLandedAcc) would: an input covering this day whose 'g'
   landing no longer exists on ANY loaded day is unfiled. 'u' (a global filing
   decision with no ground row) and 'r' (dormant) are filing DECISIONS, not
   landings, and are untouched — as is a 'g' whose row still exists (the ordinary
   recovery that keeps the row), and a multi-day 'g' still landed on another day. */
export function reconcileDayFiling(di:any){
  const dt=(DAYS[+di]||{}).dt; if(dt==null)return;
  INPUTS.forEach((inp:any)=>{
    if(!inputCoversDate(inp,dt)||inputProtected(inp))return;
    /* 'u' (a global filing DECISION with no ground row) and 'r' (dormant) are not
       per-week ground landings — untouched. */
    if(inp.acc==='u'||inp.acc==='r')return;
    /* is there a ground row for this input on ANY loaded day? Scanned by content
       key directly (NOT acceptedDay, which early-returns unless acc is already
       'g' and so cannot re-derive) — the same scan reconcileLandedAcc uses. */
    const key=inpId(inp);
    const landed=DAYS.some((d:any)=>!!standsOn(d,key,inp));
    /* BOTH directions (P2-REV2-05 + its round-2 regression P2-QREV/Fable-2): a 'g'
       whose row a replacement DROPPED is unfiled; a falsy-acc personal input whose
       row a replacement RESTORED (a draft round-trip) is re-filed 'g' — the old
       delete-only form left it stranded, phantom-amending on the next navigation. */
    if(landed){ if(inp.acc!=='g'&&isPersonal(inp.type))inp.acc='g'; }
    else if(inp.acc==='g')delete inp.acc;
  });
}
export function unacceptInput(di:any,inp:any){
  if(protectedWeek()||inputProtected(inp))return false;   // read-only quarantine — global filing write, so guard the input's every date (P2-IMPL-03 + P2-QREV-02)
  if(!inp||!inp.acc||inp.acc==='r')return false; // 'r' is already removed — nothing to undo
  const was=inp.acc;
  if(inp.acc==='g'){
    /* search by content key across the week rather than trusting di — see
       acceptedDay. Guessing the day left the real row orphaned on another day
       AND let the next accept push a duplicate. */
    const key=inpId(inp);
    for(let d2=0;d2<DAYS.length;d2++){
      const g=(DAYS[d2]||{}).ground; if(!g||!g.length)continue;
      const i=g.findIndex((r:any)=>r&&r.src===key&&standingRow(r,inp,(DAYS[d2]||{}).dt));   // its row, never a dead kept one
      if(i<0)continue;
      const issued=deletionWasIssued(d2,'ground',i,key);
      const rid=g[i]&&g[i].rid;                      // captured before the splice
      g.splice(i,1);
      /* the shift* calls stay — inert on the rid-anchored keys, still live for
         the positional-fallback/legacy space — and dropRowMarks sweeps the
         removed row's marks from the LIVE book (its old shiftKeys drop-half). */
      [`g:${d2}.`,`gr:${d2}.`].forEach((h:any)=>shiftKeys(h,0,i));
      dropRowMarks([rid]);
      markDeletion(d2,'ground',issued);
      break;
    }
  }
  /* 'r', not delete (owner, 26 Aug 26 — tested the preview, removed Comet's
     accepted Training back to Personal Inputs and it still flagged "Training
     but tasked — SC AM": "when it is removed it goes into the personal input
     section. if it goes there, stop it from flagging anything, until its
     added back"). Deleting acc made a removed input indistinguishable from a
     fresh one, and fresh inputs count (10 Aug). 'r' is the explicit DORMANT
     state: inputDormant() blanks it out of the engine (inputFlags + inpShow),
     autoAcceptInput's truthy-acc guard keeps it from re-landing at week load,
     and accCtl reads it as "offer Accept again". An input that was never
     landed at all (acc undefined — e.g. filed onto a published day) still
     counts; only a deliberate removal parks. */
  inp.acc='r';
  /* The amendment was marked on an inert deletion/input-action key above.
     Keep the bare call as the history/render epilogue; it must never re-mark
     the removed row address, which now belongs to whatever shifted into it. */
  markEdit();
  return true;
}
/* RENAMING A CALLSIGN — a label change that MOVES NOTHING (ARCH-STACK 1C,
   14 Sep 26; was a DAYS-wide row rewrite).

   Since 1C every person-reference field stores the stable PEOPLE id — flying
   seats, duty rows, sim p/w/pax and more[] always did; ground and programme
   (allhands) `who` now do too (setSlotVal/acceptInput store the id, and whoId
   resolves id→cs at read/render). So a rename only changes the DISPLAY label:
   set p.cs and remap ID_BY_CS, and every row keeps pointing at the same person
   by id. The old DAYS-walk that rewrote ground/allhands/sim `who` STRINGS is
   gone — it only existed because those rows stored the callsign, and it walked
   the LIVE week alone, missing every snapshot/draft/other week, which let a
   reused callsign later cross two people. That crossing is the bug 1C closes;
   the walk is what it replaces. (This mirrors the Tracker's renCourse/renSyl.)

   It marks nothing pending: no row moved, only how the person's name is spelt.
   The uniqueness guard stays: a name that already resolves to someone else — by
   callsign OR by bare id (nameToId is id-tolerant) — is refused, because
   ID_BY_CS can point only one way; the one add (state/roster-add.ts
   newPersonProblem — Admin → Users since [ACCOUNTS-NEW-PERSON], D217) enforces the
   same guard so a new callsign can never collide with an existing id either. */
/* [POST-OUT-OUTCOMES] (D286, D295): "taken" is the one rule, callsignTakenBy — a man on the roster, a placeholder or a
   bare id holding it; a callsign only an ARCHIVED man holds is free, so an archived man may be renamed on the Archived
   list and a roster man may take an archived man's old callsign. The index is rebuilt by its one body. */
export function renameCallsign(id:any,next:any){
  const p=PEOPLE[id]; if(!p)return false;
  const cs=String(next==null?'':next).trim();
  if(!cs||cs===p.cs)return false;
  if(callsignTakenBy(cs,id))return false;
  p.cs=cs;
  indexCallsigns();
  return true;
}
