/* THE ONE ⚙ SETTINGS SHEET (owner, 3 Sep 26 — "this row will just have a settings
   icon and an OIL tracker … inside the settings icon"). Every admin CONFIG control
   folds in here: the counters and event rows up top, then the roster GROUPS below.
   What is NOT here is REARRANGING — moving people and reordering the category blocks
   is a hands-on-the-grid job (owner: "I thought the rearrange could be done on the
   grid main page itself"), so it lives on the grid in rearrange mode, not in this
   window.

   The groups editor is folded in from the old GroupSheet, squeezed into tight rows
   ("make use of the space and squeeze the data"). This sheet ADDS/REMOVES groups,
   REORDERS them (owner, 3 Sep 26 — "allow me to drag and drop to rearrange the
   groups": the ⠿ grip, the same machine and the same write as the grid's heading
   grip, so the two never disagree), PICKS a qualification group's colour ("allow me
   to pick the colour i want" — a palette strip that opens under the row the moment
   the group is added, and again from its swatch), shows who is in each, and sets the
   OVERRIDE who-wins order. Who-wins follows the page order by default (owner: "the
   priority order should also change by default in accordance with the category
   order"); the "Who wins" list is tucked behind a disclosure, opened only when
   someone wants a different order. */

import { Fragment, useEffect, useState } from 'react'
import {
  assignGroup,
  groupLabel,
  matchesGroup,
  OTHER_LABEL,
  SANS_GROUP_ID,
  type GroupDef,
} from '../engine'
import {
  addEventRow,
  addGroup,
  clearGroupPriority,
  DEFAULT_EVENT_ROWS,
  eventRowUsed,
  getState,
  groupsInOrder,
  groupPriorityIds,
  isGroupPriorityCustom,
  MAX_EVENT_ROWS,
  offerableGroupList,
  removeEventRow,
  resetGroups,
  resetRosterOrder,
  rosterFollowsDefault,
  setGroupColor,
  setGroupDefs,
  setShowSans,
} from '../state/store'
import { Sheet } from './Sheet'
import { PALETTE, groupColorOf, isColourable } from './groupColor'
import './bidpicker.css'

export function SettingsSheet({
  onClose,
  onAddCounter,
  armCounterReset,
  onResetCounters,
  disarmCounterReset,
  onGroupDragStart,
  onPriorityDragStart,
  draggingId,
  dragOver,
  dragAfter,
}: {
  onClose: () => void
  /** Open the counter builder (Matrix owns the form + its `counterEdit` state). */
  onAddCounter: () => void
  /** Reset counters ARMS first (Matrix owns the arm state so it disarms when this
   *  sheet closes); this sheet only shows the armed/unarmed label and forwards taps. */
  armCounterReset: boolean
  onResetCounters: () => void
  /** Take Reset counters' question back — Reset order arming does it, so two "Really reset?" never stand side by side
   *  (W2's walk, 26 Sep 26); Matrix owns that arm. */
  disarmCounterReset?: () => void
  /** Drag in the groups list (display order — the same write as the grid's heading
   *  grip) and in the who-wins (priority) list — both wired by Matrix to the one
   *  drag machine. */
  onGroupDragStart?: (e: React.PointerEvent, id: string) => void
  onPriorityDragStart?: (e: React.PointerEvent, id: string) => void
  draggingId?: string | null
  dragOver?: string | null
  /** The pointer is in the hovered row's LOWER half — the drop lands after it,
   *  so the bar is drawn on its bottom edge (the roster rows' `.after`). */
  dragAfter?: boolean
}) {
  const { people, qualCatalog, eventRows, showSans, groupColors } = getState()
  // the roster, as drawn, is out of the default order — Reset order has something to do (judged by what the grid
  // SHOWS, so a drag away and back reads as the default: rosterFollowsDefault)
  const handOrder = !rosterFollowsDefault()
  // Reset order ARMS first (the Reset counters idiom); local, so closing the sheet takes the question back
  const [armOrder, setArmOrder] = useState(false)
  const chosen = groupsInOrder()
  const offered = offerableGroupList()
  const priority = groupPriorityIds()
  const chosenIds = new Set(chosen.map(d => d.id))
  // Which group draws each person — ONE walk per render, shared by every row's
  // count and by the who-is-in list (`groupIdOf` per person per row re-derived
  // the group order each call: groups × people × 3 reads, for nothing).
  const homeOf = new Map(people.map(p => [p.id, assignGroup(p, chosen, priority)]))
  const overClass = (id: string) =>
    dragOver === id && draggingId !== id ? (dragAfter ? ' dragover after' : ' dragover') : ''
  const custom = isGroupPriorityCustom()
  const lastEventRowUsed = eventRowUsed(eventRows - 1)
  // Which group's people are lit (tap a name to show, tap again to clear).
  const [lit, setLit] = useState<string | null>(null)
  // The who-wins override is tucked away — rarely touched (owner, 3 Sep 26).
  const [whoOpen, setWhoOpen] = useState(false)
  // Which qualification group's colour palette is open under its row. Opened by
  // the add (pick straight after adding) and by the row's swatch. It closes the
  // moment a colour is picked (see the dot below), and closes on a click outside
  // it — the app's standing rule for a click-open popup (owner, 4 Sep 26 — "if i
  // close outside the box … it should close the colour pallete. or after i
  // selected a colour it will auto close … build pop up windows to have auto
  // close feature if i click outside of it").
  const [colorFor, setColorFor] = useState<string | null>(null)
  useEffect(() => {
    if (!colorFor) return
    const onDown = (e: PointerEvent) => {
      const t = e.target as HTMLElement | null
      // A press on the palette itself, or on any group's colour swatch, is not
      // "outside": the swatch owns its own open/close toggle, so leaving it to
      // that button avoids a close-then-reopen fight on the same tap.
      if (t && (t.closest('.set-palette') || t.closest('.set-swbtn'))) return
      setColorFor(null)
    }
    /* Escape peels the palette first, not the whole sheet: the Sheet's own
       Escape listens on `document` (capture), and a `window` capture listener
       runs ahead of it, so stopping the event here leaves the sheet up. */
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return
      // Kept-mounted guard (as Sheet.tsx): act only while Leave War is showing.
      const pg = document.getElementById('page-leavewar')
      if (pg && !pg.classList.contains('on')) return
      e.stopPropagation()
      setColorFor(null)
    }
    document.addEventListener('pointerdown', onDown, true)
    window.addEventListener('keydown', onKey, true)
    return () => {
      document.removeEventListener('pointerdown', onDown, true)
      window.removeEventListener('keydown', onKey, true)
    }
  }, [colorFor])

  const label = (d: GroupDef) => groupLabel(d, qualCatalog)
  const shownIn = (d: GroupDef) => people.filter(p => homeOf.get(p.id) === d.id)
  const membersOf = (d: GroupDef) => people.filter(p => matchesGroup(p, d))

  // Remove a group. The SANS row is not a stored group — its ✕ just turns the
  // Show SANS switch back off (owner, 3 Sep 26); everything else drops normally.
  const drop = (d: GroupDef) => {
    if (d.kind === 'sans') { setShowSans(false); return }
    setGroupDefs(chosen.filter(x => x.id !== d.id && x.id !== SANS_GROUP_ID))
  }

  const litDef = lit ? chosen.find(d => d.id === lit) ?? null : null
  const swClass = (id: string) => `set-sw g-${id.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`

  return (
    <Sheet testid="settings-sheet" label="Roster, counters and groups" onClose={onClose}>
      <div className="bidsheet-hd">
        <span className="who">SETTINGS</span>
        <span className="dt">counters, rows &amp; groups</span>
        <button className="x" data-testid="settings-close" onClick={onClose} aria-label="Close">✕</button>
      </div>

      {/* ---- counters & rows ------------------------------------------------- */}
      <div className="gs-sec">Counters &amp; rows</div>
      <div className="set-tray">
        <div className="set-ctrls">
          <button
            className="rtbtn"
            data-testid="counter-add"
            title="Add a manning counter — pick who it counts and when it turns amber or red"
            onClick={onAddCounter}
          >＋ Counter</button>
          <button
            className="rtbtn"
            data-testid="event-add"
            disabled={eventRows >= MAX_EVENT_ROWS}
            title={eventRows >= MAX_EVENT_ROWS ? `At most ${MAX_EVENT_ROWS} event rows` : 'Add another event row'}
            onClick={() => addEventRow()}
          >＋ Event row</button>
          {eventRows > DEFAULT_EVENT_ROWS && (
            <button
              className="rtbtn"
              data-testid="event-remove"
              disabled={lastEventRowUsed}
              title={lastEventRowUsed ? 'Clear the last event row before removing it' : 'Remove the last event row'}
              onClick={() => removeEventRow()}
            >－ Event row</button>
          )}
          <button
            className={`rtbtn${showSans ? ' on' : ''}`}
            data-testid="sans-toggle"
            aria-pressed={showSans}
            title={showSans ? 'Take SANS aircrew off the leave war roster' : 'Put SANS aircrew on the leave war roster'}
            onClick={() => setShowSans(!showSans)}
          >{showSans ? '✓ SANS shown' : 'Show SANS'}</button>
          <button
            className={`rtbtn set-danger${armCounterReset ? ' arm' : ''}`}
            data-testid="counter-reset-all"
            title="Put the built-in counters back — counters you built are discarded"
            // arming (or firing) Reset counters takes Reset order's question back — one question at a time
            onClick={() => { setArmOrder(false); onResetCounters() }}
          >{armCounterReset ? 'Really reset?' : '↺ Reset counters'}</button>
        </div>
        <div className="set-hint">Reset counters asks once before it clears your custom counters.</div>
      </div>
      <div className="gs-note">
        Showing SANS puts them on the roster as <b>their own group at the very bottom</b>,
        and on the days they are available they <b>count toward the manning numbers</b> like
        everyone else.
      </div>

      {/* ---- the roster's row order (owner, D160, 24 Sep 26 — "9 yes": a "Reset order" line HERE; the grid's old
          Auto-sort button and strip stay gone). People are still rearranged by hand on the grid (⇅); this only
          takes a hand arrangement back to the default. It asks once, like Reset counters above — fifty rows
          arranged by hand are real work — and is greyed, with a line saying so, while the roster already follows
          the default. The store clears the saved order (resetRosterOrder), so a man who joins later lands in his
          ranked place too; the one Undo brings the arrangement back. */}
      <div className="gs-sec">
        Roster order
        <span className="gs-hint">people are rearranged on the grid with ⇅</span>
      </div>
      <div className="set-tray">
        <div className="set-ctrls">
          <button
            className={`rtbtn set-danger set-order${armOrder ? ' arm' : ''}`}
            data-testid="roster-reset-order"
            disabled={!handOrder}
            title={handOrder ? 'Put every row back in the default order' : 'The roster is already in the default order'}
            onClick={() => {
              if (!armOrder) { setArmOrder(true); disarmCounterReset?.(); return }
              setArmOrder(false)
              resetRosterOrder()
            }}
          >{armOrder ? 'Really reset?' : '↺ Reset order'}</button>
        </div>
        <div className="set-hint" data-testid="roster-order-hint">
          {handOrder
            ? 'Arranged by hand. Reset order puts every row back in the default order — each group as listed below, pilots above WSOs, then by CAT and callsign. It asks once; Undo brings your arrangement back.'
            : 'In the default order — each group as listed below, pilots above WSOs, then by CAT and callsign.'}
        </div>
      </div>

      {/* ---- the groups shown, top to bottom ---------------------------------- */}
      <div className="gs-sec">
        Groups — shown, top to bottom
        <span className="gs-hint">drag ⠿ to reorder · tap a name for who is in it · tap a colour square to change it</span>
      </div>
      <div className="set-grows" data-testid="group-chosen">
        {chosen.map(d => {
          const isSans = d.kind === 'sans'
          const shown = shownIn(d).length
          const colour = groupColorOf(d.id, groupColors)
          const pickable = isColourable(d.id)
          return (
            <Fragment key={d.id}>
              <div
                className={`set-grow${isSans ? ' sans' : ''}${draggingId === d.id ? ' dragging' : ''}${overClass(d.id)}`}
                data-testid={`grow-${d.id}`}
                data-grow={isSans ? undefined : d.id}
              >
                {/* The SANS row is auto-placed at the foot and never moves; every
                    other row has the grip. Its pointerdown starts the drag; the
                    machine hit-tests `[data-grow]` under the pointer, which while
                    this sheet is up are these rows. */}
                {isSans
                  ? <span className="set-grip off" aria-hidden="true" />
                  : (
                    <span
                      className="set-grip"
                      data-testid={`gsdrag-${d.id}`}
                      title={`Drag to move ${label(d)}`}
                      style={{ touchAction: 'none' }}
                      onPointerDown={e => onGroupDragStart?.(e, d.id)}
                    >⠿</span>
                  )}
                {pickable
                  ? (
                    <button
                      className={`set-sw set-swbtn${colorFor === d.id ? ' on' : ''}`}
                      data-testid={`gcolor-${d.id}`}
                      style={{ background: colour }}
                      aria-label={`Pick a colour for ${label(d)}`}
                      title={`Pick a colour for ${label(d)}`}
                      aria-expanded={colorFor === d.id}
                      onClick={() => setColorFor(v => (v === d.id ? null : d.id))}
                    />
                  )
                  : <span className={swClass(d.id)} />}
                <button
                  className={`set-gname${lit === d.id ? ' on' : ''}`}
                  data-testid={`gpick-${d.id}`}
                  aria-pressed={lit === d.id}
                  onClick={() => setLit(v => (v === d.id ? null : d.id))}
                >{label(d)}</button>
                {isSans
                  ? <span className="set-badge">shown · counted</span>
                  : <span className="set-gkd">{d.kind === 'qual' ? 'qual' : 'cat'}</span>}
                <span className="set-gct">{shown}</span>
                <button
                  className="set-gdel"
                  data-testid={`gdrop-${d.id}`}
                  aria-label={isSans ? 'Hide SANS again' : `Remove the ${label(d)} group`}
                  title={isSans ? 'Hide SANS again' : `Remove the ${label(d)} group`}
                  onClick={() => { if (colorFor === d.id) setColorFor(null); drop(d) }}
                >✕</button>
              </div>
              {/* The colour palette for THIS group (owner, 3 Sep 26 — "allow me to
                  pick the colour i want"): twelve dots, the current one ringed. A
                  tap stores the pick; the heading swatch and the quals popover pill
                  both take it at once. */}
              {pickable && colorFor === d.id && (
                <div className="set-palette" data-testid={`gpalette-${d.id}`} role="radiogroup" aria-label={`Colour for ${label(d)}`}>
                  <span className="set-plab">Colour for {label(d)}</span>
                  <div className="set-dots">
                    {PALETTE.map(c => (
                      <button
                        key={c}
                        // case-blind: a stored pick is read leniently, any case
                        className={`set-dot${colour?.toUpperCase() === c ? ' on' : ''}`}
                        data-testid={`gdot-${d.id}-${c.slice(1).toLowerCase()}`}
                        role="radio"
                        aria-checked={colour?.toUpperCase() === c}
                        aria-label={c}
                        style={{ background: c }}
                        onClick={() => { setGroupColor(d.id, c); setColorFor(null) }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </Fragment>
          )
        })}
      </div>
      <div className="gs-note">
        Anyone no group above claims is shown under <b>{OTHER_LABEL}</b>, always last.
      </div>

      {/* who is in the tapped group */}
      {litDef && (() => {
        const here = shownIn(litDef)
        const above = membersOf(litDef).filter(p => homeOf.get(p.id) !== litDef.id)
        return (
          <div className="gs-who" data-testid="group-members">
            <div className="gs-sec">Shown in {label(litDef)}</div>
            <div className="gs-chips">
              {here.map(p => (
                <span key={p.id} className="gs-chip" data-testid={`gmem-${p.id}`}>{p.callsign}</span>
              ))}
              {here.length === 0 && <span className="gs-empty">nobody — every one of them is claimed higher up</span>}
            </div>
            {above.length > 0 && (
              <>
                <div className="gs-sec">Also fit it, but shown higher up</div>
                <div className="gs-chips">
                  {above.map(p => (
                    <span key={p.id} className="gs-chip muted" data-testid={`gelse-${p.id}`}>{p.callsign}</span>
                  ))}
                </div>
                <div className="gs-note">
                  Move {label(litDef)} higher on the grid (or under <b>Who wins</b>) to draw them here instead.
                </div>
              </>
            )}
          </div>
        )
      })()}

      {/* ---- add a group ---------------------------------------------------- */}
      <div className="gs-sec">
        Add a group
        <span className="gs-hint">the qualification options — grows as the squadron adds Quals</span>
      </div>
      <div className="gs-chips" data-testid="group-offer">
        {offered.filter(d => !chosenIds.has(d.id)).map(d => (
          <button
            key={d.id}
            className="tchip"
            data-testid={`gadd-${d.id}`}
            // Adding a qualification group opens its palette straight away, so the
            // colour is picked as part of adding it (owner, 3 Sep 26).
            onClick={() => { addGroup(d); setColorFor(isColourable(d.id) ? d.id : null) }}
          >
            + {label(d)}
          </button>
        ))}
        {offered.every(d => chosenIds.has(d.id)) && <span className="gs-empty">every group is already shown</span>}
      </div>

      {/* ---- who wins (the override, tucked away) ---------------------------- */}
      <button
        className="set-disc"
        data-testid="who-wins-toggle"
        aria-expanded={whoOpen}
        onClick={() => setWhoOpen(o => !o)}
      >
        <span className="cv">{whoOpen ? '▾' : '▸'}</span>
        <span className="dl">Who wins when someone fits two</span>
        <span className="dh">{custom ? 'custom order set' : 'follows the page — rarely needed'}</span>
      </button>
      {whoOpen && (
        <>
          <div className="gs-note">
            {custom
              ? 'A custom order is set, so it no longer follows the page. Drag to change it.'
              : 'Right now this follows the page order (higher on the grid wins). Drag a group here to set your own order instead.'}
          </div>
          <div className="clist" data-testid="group-priority">
            {priority.filter(id => id !== SANS_GROUP_ID).map((id, i) => {
              const d = chosen.find(x => x.id === id)
              if (!d) return null
              return (
                <div
                  key={id}
                  className={`crow-wrap gs-row${draggingId === id ? ' dragging' : ''}${overClass(id)}`}
                  data-gprio={id}
                  data-testid={`gprio-${id}`}
                >
                  <span
                    className="drag"
                    data-testid={`gpdrag-${id}`}
                    title={`Drag to change where ${label(d)} ranks`}
                    style={{ touchAction: 'none' }}
                    onPointerDown={e => onPriorityDragStart?.(e, id)}
                  >⠿</span>
                  <span className="crow bdrow">
                    <span className="crow-top"><span className="cn">{i + 1}. {label(d)}</span></span>
                  </span>
                </div>
              )
            })}
          </div>
          {custom && (
            <div className="cfoot">
              <button className="creset" data-testid="who-wins-reset" onClick={() => clearGroupPriority()}>
                Match the page order
              </button>
            </div>
          )}
        </>
      )}

      <div className="cfoot">
        <button className="creset" data-testid="group-reset" onClick={() => resetGroups()}>
          Back to the standard groups
        </button>
      </div>
    </Sheet>
  )
}
