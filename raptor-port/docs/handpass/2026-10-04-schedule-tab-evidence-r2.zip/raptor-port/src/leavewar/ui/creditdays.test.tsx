// HOW MANY DAYS A GRANTED OIL CREDIT IS WORTH (owner, 20 Sep 26 — "on the
// leave war i can also grant more than 1 day of OIL credit just like how the
// oil tracker does it").
//
// THIS FILE REPLACED `credithours.test.tsx`, WRITTEN THE DAY BEFORE, and the
// reason is the model changing under it rather than those tests being wrong.
// The hours existed so a two-hour call-out beside afternoon leave would not
// flag the day. Then the owner ruled that OIL may be granted "for any reason,
// doesnt have to be like working on weekends" and told us to drop the hours —
// which together mean a granted credit is an AWARD, not a record of
// attendance. An award cannot contradict a day off, so there is nothing for
// hours to prevent. The hours live on only where they are real: the AUTOMATIC
// credit, which reads them off the published schedule.
//
// Since [OIL-AWARD-IS-A-GRANT] (29 Sep 26) the award is a ledger entry — the one kind of hand-given OIL — and its
// worth is its AMOUNT; FO / HO is only how the grid labels it.

import { fireEvent, render, screen } from '@testing-library/react'
import { beforeEach, describe, expect, it } from 'vitest'
import { balanceOf } from '../engine'
import { awardsOnDay, editAward, getState, HALF_STEP_MSG, ingestDutyCredit, initStore, rawState, setCell, setDayAward, setRole } from '../state/store'
import { memoryBackend } from '../state/storage'
import { Matrix } from './Matrix'

const P = 'slammed'
const TUE = '2026-01-13'

beforeEach(() => {
  initStore(memoryBackend())
  setRole('admin')
})

/** the day's award, as the grid draws it: its label and its worth (the amount) */
const creditOn = (person: string, date: string) => {
  const e = awardsOnDay(person, date)[0]
  return e ? { id: e.id, code: e.amount === 0.5 ? 'HO' : 'FO', days: e.amount } : undefined
}

const oilOf = (person: string) => {
  const { openings, ledger, wars } = getState()
  return balanceOf(openings, ledger, wars, person, 'oil')
}

describe('a grant worth more than one day', () => {
  it('a quantity moves the balance by that much, not by the code’s own worth', () => {
    const before = oilOf(P)
    expect(setDayAward(P, TUE, 3, { note: 'Exercise' })).toBeNull()
    expect(creditOn(P, TUE)!.days).toBe(3)
    expect(oilOf(P)).toBe(before + 3)
  })

  it('half a day is worth half a day, and reads HO', () => {
    const before = oilOf(P)
    expect(setDayAward(P, TUE, 0.5, { note: 'Recall' })).toBeNull()
    expect(creditOn(P, TUE)).toMatchObject({ code: 'HO', days: 0.5 })
    expect(oilOf(P)).toBe(before + 0.5)
  })

  it('goes in halves at EVERY door, in the same words (owner, 21 Sep 26)', () => {
    expect(setDayAward(P, TUE, 1.5)).toBeNull()
    expect(oilOf(P)).toBeGreaterThan(0)
    expect(setDayAward(P, TUE, 1.3)).toBe(HALF_STEP_MSG)
    expect(setDayAward(P, TUE, 1)).toBeNull()
    expect(editAward(creditOn(P, TUE)!.id, { days: 0.3 })).toBe(HALF_STEP_MSG)
    expect(setDayAward(P, TUE, 0)).toContain('how many days')
    expect(setDayAward(P, TUE, -2)).toContain('how many days')
    expect(setDayAward(P, TUE, 9999)).toContain('more than')
  })

  it('is COUNTED ONCE — one record, one number', () => {
    // The rule counters.ts enforces: never two records of one fact. The award IS one ledger entry (the one kind of
    // hand-given OIL — [OIL-AWARD-IS-A-GRANT]); the war holds no record of it beside that.
    const before = oilOf(P)
    expect(setDayAward(P, TUE, 2)).toBeNull()
    expect(oilOf(P)).toBe(before + 2)
    expect(getState().ledger.filter(e => e.personId === P && e.date === TUE)).toHaveLength(1)
    expect((rawState().wars[0]!.recs[P]?.[TUE] ?? []).filter(r => r.kind === 'credit')).toHaveLength(0)
  })

  it('its days change afterwards, in one step', () => {
    expect(setDayAward(P, TUE, 2)).toBeNull()
    expect(editAward(creditOn(P, TUE)!.id, { days: 4 })).toBeNull()
    expect(creditOn(P, TUE)!.days).toBe(4)
  })

  it('leaves a credit the published schedule owns alone', () => {
    ingestDutyCredit(P, TUE, 'FO', 'Duty', [[480, 1080]])
    const auto = (rawState().wars[0]!.recs[P]![TUE] ?? []).find(r => r.kind === 'credit')!
    expect(editAward(auto.id, { days: 3 })).toContain('no OIL award')
  })
})

describe('a granted credit still behaves like every other credit', () => {
  it('lands beside leave and does NOT flag it, whatever quantity it carries', () => {
    /* The question this test used to park — whether a grant should stop
       flagging — was PUT TO THE OWNER and answered on 20 Sep 26: a granted
       credit is an AWARD. It says a man is owed days, not that he was at work,
       so it cannot contradict his leave and the day must not go amber. Both
       records still land; the quantity never mattered either way. */
    expect(setCell(P, TUE, 'LL')).toBe(true)
    expect(setDayAward(P, TUE, 2, { note: 'Exercise' })).toBeNull()
    const v = getState().views[P]?.[TUE]
    expect(v?.all.filter(c => c.kind === 'request')).toHaveLength(1)
    expect(v?.all.filter(c => c.kind === 'credit')).toHaveLength(1)
    expect(v?.amber).toBe(false)
  })
})

describe('the quantity in the OIL tracker', () => {
  it('shows on the row and is changed in the one editor every award opens — its date shown, never changed (D260)', () => {
    expect(setDayAward(P, TUE, 3, { note: 'Exercise', givenBy: 'OC Ops' })).toBeNull()
    const id = creditOn(P, TUE)!.id
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('oil-tracker'))
    expect(screen.getByTestId(`oil-entry-${id}`).textContent).toContain('+3')
    fireEvent.click(screen.getByTestId(`oil-entry-${id}`))
    expect((screen.getByTestId('oil-edit-amt') as HTMLInputElement).value).toBe('3')
    expect(screen.getByTestId('oil-edit-date').tagName).not.toBe('BUTTON')     // read only
    fireEvent.change(screen.getByTestId('oil-edit-amt'), { target: { value: '2.5' } })
    fireEvent.click(screen.getByTestId('oil-edit-save'))
    expect(creditOn(P, TUE)!.days).toBe(2.5)
  })

  it('says so rather than guessing when the quantity cannot be read', () => {
    expect(setDayAward(P, TUE, 1, { note: 'Exercise' })).toBeNull()
    const id = creditOn(P, TUE)!.id
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('oil-tracker'))
    fireEvent.click(screen.getByTestId(`oil-entry-${id}`))
    fireEvent.change(screen.getByTestId('oil-edit-amt'), { target: { value: 'lots' } })
    fireEvent.click(screen.getByTestId('oil-edit-save'))
    expect(screen.getByTestId('oil-edit-err').textContent).toBeTruthy()
    expect(creditOn(P, TUE)!.days).toBe(1)
  })
})

describe('tapping an OIL day shows what is on it', () => {
  // Owner, 20 Sep 26: "when I click on FO or HO on the leave war, i should be
  // able to see the reason and given by who if applicable and quantity."
  const openDay = () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${TUE}`))
  }

  it('the button names it instead of offering to add one', () => {
    expect(setDayAward(P, TUE, 3, { note: 'Exercise', givenBy: 'OC Ops' })).toBeNull()
    openDay()
    expect(screen.getByTestId('bid-oil').textContent).toBe('FO · 3 days')
  })

  it('opens already filled in, and says it in words above the boxes', () => {
    expect(setDayAward(P, TUE, 0.5, { note: 'Exercise', givenBy: 'OC Ops' })).toBeNull()
    openDay()
    fireEvent.click(screen.getByTestId('bid-oil'))
    expect(screen.getByTestId('oil-current').textContent).toContain('half a day of OIL')
    expect(screen.getByTestId('oil-current').textContent).toContain('Exercise')
    expect(screen.getByTestId('oil-current').textContent).toContain('OC Ops')
    expect((screen.getByTestId('oil-why') as HTMLInputElement).value).toBe('Exercise')
    expect((screen.getByTestId('oil-given-by') as HTMLInputElement).value).toBe('OC Ops')
  })

  it('changing it writes over the same record rather than adding a second', () => {
    expect(setDayAward(P, TUE, 3, { note: 'Exercise' })).toBeNull()
    openDay()
    fireEvent.click(screen.getByTestId('bid-oil'))
    fireEvent.change(screen.getByTestId('oil-days'), { target: { value: '1' } })
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(awardsOnDay(P, TUE)).toHaveLength(1)
    expect(creditOn(P, TUE)!.days).toBe(1)
  })

  it('Remove takes it off the day', () => {
    expect(setDayAward(P, TUE, 1, { note: 'Exercise' })).toBeNull()
    openDay()
    fireEvent.click(screen.getByTestId('bid-oil'))
    fireEvent.click(screen.getByTestId('oil-clear'))
    expect(creditOn(P, TUE)).toBeUndefined()
  })

  it('a credit the SCHEDULE earned is still never EDITED — it is the schedule’s', () => {
    /* An admin reaches the picker on such a day now (N16: he may record an
       AWARD beside it), so what this pins is the thing that has not changed:
       the earned credit itself is read-back only. Nothing offers to change
       its worth, its reason or its giver, and nothing offers to remove it —
       the OIL pass owns it and would overwrite anything typed on top. */
    ingestDutyCredit(P, TUE, 'FO', 'Duty', [[480, 1080]])
    openDay()
    // it is read back, in full
    expect(screen.getByTestId('oil-detail-days')).toBeTruthy()
    expect(screen.getByTestId('raptor-note')).toBeTruthy()
    // …and offered no editor of its own
    expect(screen.queryByTestId('oil-current')).toBeNull()
    expect(screen.queryByTestId('oil-clear')).toBeNull()
  })
})

describe('the marks on the box', () => {
  it('an arrow points at the half, and a star means the app put it there', () => {
    expect(setCell(P, TUE, '*LL')).toBe(true)
    render(<Matrix />)
    expect(screen.getByTestId(`cell-${P}-${TUE}`).textContent).toContain('<LL')
  })
})

/* ONE QUANTITY, ONE MEANING (owner, 21 Sep 26). */
describe('how many days the sheet asks for', () => {
  const openOil = (date: string) => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${date}`))
    fireEvent.click(screen.getByTestId('bid-oil'))
  }
  const days = (v: string) => fireEvent.change(screen.getByTestId('oil-days'), { target: { value: v } })

  it('shows 1 rather than an empty box — the ordinary grant, said out loud', () => {
    openOil(TUE)
    expect((screen.getByTestId('oil-days') as HTMLInputElement).value).toBe('1')
  })

  it('there is ONE button, and it says what the day will READ as', () => {
    /* It had an FO/HO pair AND a days box — two controls for one fact, so "HO"
       beside a "1" read as nonsense. For an award the code is only the label on
       the grid square now; the quantity is the fact, and the code follows it. */
    openOil(TUE)
    expect(screen.queryByTestId('oil-fo')).toBeNull()
    expect(screen.queryByTestId('oil-ho')).toBeNull()
    expect(screen.getByTestId('oil-give').textContent).toContain('FO')
    days('0.5')
    expect(screen.getByTestId('oil-give').textContent).toContain('HO')
    days('2')
    expect(screen.getByTestId('oil-give').textContent).toContain('FO')
  })

  it('the default 1 gives a day, and reads FO', () => {
    openOil(TUE)
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(creditOn(P, TUE)).toMatchObject({ code: 'FO', days: 1 })
    expect(getState().views[P]?.[TUE]?.code).toBe('FO')
  })

  it('under a day reads HO and is worth what was typed', () => {
    openOil(TUE)
    days('0.5')
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(creditOn(P, TUE)).toMatchObject({ code: 'HO', days: 0.5 })
    expect(getState().views[P]?.[TUE]?.code).toBe('HO')
  })

  it('more than a day reads FO and is worth what was typed', () => {
    openOil(TUE)
    days('3')
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(creditOn(P, TUE)).toMatchObject({ code: 'FO', days: 3 })
  })

  it('REFUSES a quantity that is not a half — the guard rail (owner, 21 Sep 26)', () => {
    /* "put a guard rail to make sure that only 0.5 multiples can be input just
       like the oil tracker". A half day is the smallest thing the grid ever
       CHARGES, so an odd quantity can never be drawn down cleanly — a
       remainder under a half strands in the balance. Refused, not silently
       corrected: a number quietly changed after it was typed is the very
       thing this branch spent two days removing.
       Restores his 6 Sep rule and extends it to the door that had escaped
       it; withdraws his own earlier ask the same day that an odd number be
       accepted, which he reversed once he saw the cost. */
    openOil(TUE)
    days('0.3')
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(screen.getByTestId('oil-err').textContent).toContain('halves')
    expect(creditOn(P, TUE)).toBeUndefined()
  })

  it('and says it the SAME way the OIL tracker does', () => {
    /* Two sentences for one rule drift apart the moment one is edited — the
       seam the house rules name. The war used to word this its own way. */
    openOil(TUE)
    days('1.3')
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(screen.getByTestId('oil-err').textContent).toBe(HALF_STEP_MSG)
  })

  it('still refuses what is not a quantity at all', () => {
    openOil(TUE)
    days('lots')
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(screen.getByTestId('oil-err').textContent).toContain('how many days')
    expect(creditOn(P, TUE)).toBeUndefined()
  })
})
