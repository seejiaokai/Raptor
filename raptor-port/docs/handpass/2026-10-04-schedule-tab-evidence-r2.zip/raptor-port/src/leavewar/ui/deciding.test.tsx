import { act, fireEvent, render, screen } from '@testing-library/react'
import { beforeEach, describe, expect, it } from 'vitest'
import { advanceStage, getState, initStore, reopenStage, setRole } from '../state/store'
import { memoryBackend } from '../state/storage'
import { StageBar } from './Chrome'
import { Matrix } from './Matrix'

/* ONE CHIP, ONE MOVE (owner, D262, 27 Sep 26): the window's Move no longer reads a date box — it picks the chip up
   into the grid's move mode, and a click on a day lands it. A person's click comes a beat after the Move (the move
   ignores clicks for its first moments — a double-click on Move must land nothing). */
async function moveTo(testid: string) {
  fireEvent.click(screen.getByTestId('decide-shift'))
  await act(async () => { await new Promise(r => setTimeout(r, 420)) })
  fireEvent.click(screen.getByTestId(testid))
}

beforeEach(() => {
  initStore(memoryBackend())
  /* deciding is an admin activity, and advancing the cycle to 'closed' is
     admin-only since 27 Aug 26 (owner) — so the file runs as an admin; the
     two member-view cases set 'member' themselves after advancing */
  setRole('admin')
})

// Seed: ASICS has a pending half day of LL on 2026-01-23.
const PENDING = 'cell-asics-2026-01-23'

describe('deciding a bid', () => {
  it('offers the SAME four answers while bidding is still open', () => {
    /* MOVED 21 Sep 26. The decision used to appear only once bidding closed,
       so the same input answered to different controls depending on which day
       of the cycle you clicked it. Owner: "enable it in all Stage on leave
       war". An admin can now Ack, Approve, Refuse or Move from the first day
       of bidding — the stage decides what the SQUADRON may do, never what the
       admin running it may do. */
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('decide-ack')).toBeTruthy()
    expect(screen.getByTestId('decide-approve')).toBeTruthy()
    expect(screen.getByTestId('decide-refuse')).toBeTruthy()
    expect(screen.getByTestId('decide-shift')).toBeTruthy()
  })

  it('keeps the leave buttons once bidding has closed — ONE window, every stage', () => {
    /* MOVED 21 Sep 26, the other half of the same ruling. Deciding used to
       REPLACE the window with a smaller one, so an admin who wanted to change
       what was asked for had to reopen the war. He keeps both: the decision at
       the top, what was asked for below it. */
    advanceStage()
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('decide-approve')).toBeTruthy()
    expect(screen.getByTestId('bid-LL')).toBeTruthy()
    expect(screen.getByTestId('bid-clear')).toBeTruthy()
  })

  it('approves a pending bid once closed', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    fireEvent.click(screen.getByTestId('decide-approve'))
    expect(getState().states.asics['2026-01-23']?.state).toBe('approved')
  })

  // Acknowledging is deliberately NOT a decision: it records that management
  // has the bid in hand. The man stays out of the counts, because the counts
  // show the worst case and nothing has been granted or denied yet.
  it('acknowledges a pending bid without moving the counts', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    const before = screen.getByTestId('count-opsp-2026-01-23').textContent
    fireEvent.click(screen.getByTestId(PENDING))
    // the button reads "Ack" (owner, 21 Sep 26, renaming his own 27 Aug
    // "Pending") though the stored state token is still 'acknowledged' — the
    // label changed, not the model
    expect(screen.getByTestId('decide-ack').textContent).toBe('Ack')
    fireEvent.click(screen.getByTestId('decide-ack'))
    expect(getState().states.asics['2026-01-23']?.state).toBe('acknowledged')
    expect(screen.getByTestId('count-opsp-2026-01-23').textContent).toBe(before)
  })

  // An acknowledged bid is still awaiting an answer, so all three controls
  // have to remain on it — otherwise acknowledging would be a dead end.
  it('still offers every control on a bid already acknowledged', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    fireEvent.click(screen.getByTestId('decide-ack'))
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('decide-ack').getAttribute('aria-pressed')).toBe('true')
    fireEvent.click(screen.getByTestId('decide-approve'))
    expect(getState().states.asics['2026-01-23']?.state).toBe('approved')
  })

  it('refuses a pending bid, and the man returns to the counts', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    const before = screen.getByTestId('count-opsp-2026-01-23').textContent
    fireEvent.click(screen.getByTestId(PENDING))
    fireEvent.click(screen.getByTestId('decide-refuse'))
    expect(getState().states.asics['2026-01-23']?.state).toBe('refused')
    expect(screen.getByTestId('count-opsp-2026-01-23').textContent).not.toBe(before)
  })

  it('closes the sheet once a decision is made', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    fireEvent.click(screen.getByTestId('decide-approve'))
    expect(screen.queryByTestId('bid-picker')).toBeNull()
  })

  // A decision can be changed while the period is still closed — the point
  // of showing the counts move is that management can try one and look.
  it('lets a decision be changed while the period is still closed', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    fireEvent.click(screen.getByTestId('decide-refuse'))
    fireEvent.click(screen.getByTestId(PENDING))
    fireEvent.click(screen.getByTestId('decide-approve'))
    expect(getState().states.asics['2026-01-23']?.state).toBe('approved')
  })

  it('offers nothing on a cell nobody bid for', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    // PIPPER is on a course: not a bid, so there is nothing to decide.
    fireEvent.click(screen.getByTestId('cell-pipper-2026-01-12'))
    expect(screen.queryByTestId('decide-approve')).toBeNull()
    // And an empty cell has nothing to decide either.
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.queryByTestId('decide-approve')).toBeNull()
  })

  // Published still decides (owner, 27 Aug 26 — "if leave war is published,
  // the admin can still have these functions"): publication freezes the
  // picture for the squadron, but the admin still runs the war, so a late
  // change tapped in after publication is approved/refused exactly as at
  // closed. A bid gets the decision; an empty cell still gets the picker.
  it('keeps the admin decision once the period is published', () => {
    advanceStage()
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('decide-approve')).toBeTruthy()
    expect(screen.getByTestId('decide-refuse')).toBeTruthy()
    // …and the leave buttons stay with them at published too (owner,
    // 21 Sep 26): an input NOT yet approved is still the admin's to change.
    expect(screen.getByTestId('bid-LL')).toBeTruthy()
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.getByTestId('bid-LL')).toBeTruthy()
  })

  // The precedence that had to be got right: an admin at `closed` satisfies
  // both canEdit and canDecide. Deciding wins where there is a bid to decide,
  // and the picker still opens where there is not — so a closed sheet can
  // still have leave added to it without a second control.
  it('gives an admin the decision on a bid and the picker on an empty cell', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('decide-approve')).toBeTruthy()
    expect(screen.getByTestId('bid-LL')).toBeTruthy()      // one window, both halves
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.getByTestId('bid-LL')).toBeTruthy()
    // An EMPTY day still offers no decision: there is nothing there to answer.
    expect(screen.queryByTestId('decide-approve')).toBeNull()
  })
})

/* ONE WINDOW FOR AN INPUT, IN EVERY STAGE (owner, 21 Sep 26). Four answers —
   Ack, Approve, Refuse, Move — plus what was asked for, on the same window
   whether the war is open for bidding, closed, or published. The exception he
   named himself: an input that is approved AND published is finished
   paperwork, so it offers remarks and nothing else; to change it an admin
   reopens the war. */
describe('the one input window', () => {
  const PENDING = 'cell-asics-2026-01-23'

  it('moves an input from ONE click — no drag-select needed', async () => {
    /* His words: "even a single click on an input, i should be able to click
       on a move button to move the input just like how i drag and select and
       click on move". */
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    await moveTo('cell-asics-2026-01-26')
    expect(getState().grid.asics['2026-01-23']).toBeFalsy()
    expect(getState().grid.asics['2026-01-26']).toBeTruthy()
  })

  it('says WHY when a move cannot land, rather than doing nothing', async () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    // 24 Feb already holds ASICS's acknowledged OIL bid — the day is taken
    await moveTo('cell-asics-2026-02-24')
    expect(screen.getByTestId('move-banner').textContent).toContain('already booked')
  })

  it('an APPROVED input on a PUBLISHED war offers remarks and nothing else', () => {
    /* The owner's own exception: "if the input is approved and published, once
       u click on it, the member and admin can input the remarks there. In
       order to edit it again, admin has to go back to open for bidding or
       bidding closed". */
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    fireEvent.click(screen.getByTestId('decide-approve'))
    act(() => { advanceStage(); advanceStage() })
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('remarks-sheet')).toBeTruthy()
    expect(screen.queryByTestId('decide-approve')).toBeNull()
    expect(screen.queryByTestId('bid-LL')).toBeNull()
  })

  it('an input NOT yet approved on a published war is still the admin’s to change', () => {
    advanceStage()
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('decide-ack')).toBeTruthy()
    expect(screen.getByTestId('decide-shift')).toBeTruthy()
    expect(screen.getByTestId('bid-LL')).toBeTruthy()
    expect(screen.getByTestId('bid-clear')).toBeTruthy()
  })

  it('offers NO decision in DRAFT — a war nobody has been shown has nothing to answer', () => {
    /* Astra, 21 Sep 26: the first cut gated the buttons on "an admin and a
       biddable cell", so at DRAFT they appeared and the store refused the
       write — a control that does nothing, which is the one outcome the house
       rule forbids. */
    setRole('admin')
    reopenStage()                                   // open → draft
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.queryByTestId('decide-ack')).toBeNull()
    /* MOVE LEFT THE DECISION ROW (D331 — order A: Decide, then Selected: Move · Delete), and who may move is the store's
       one rule at every door (the mock-up's reading, uncorrected): the admin may move a bid in a draft war, as the
       drag-selection's Move always could — the two sheets no longer answer differently. The decisions stay absent. */
    expect(screen.getByTestId('decide-shift')).toBeTruthy()
  })

  it('a MEMBER gets no decisions on anybody’s input, their own included', () => {
    advanceStage()
    setRole('member')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.queryByTestId('decide-approve')).toBeNull()
    expect(screen.queryByTestId('decide-shift')).toBeNull()
  })
})

// The stage control lives in the chrome, not the matrix, so this block
// renders StageBar — rendering Matrix would find no button and the test
// would fail for the wrong reason.
describe('moving the period on', () => {
  it('walks the stage forward and stops at published', () => {
    render(<StageBar />)
    expect(getState().period.stage).toBe('open')
    fireEvent.click(screen.getByTestId('stage-advance'))
    expect(getState().period.stage).toBe('closed')
    fireEvent.click(screen.getByTestId('stage-advance'))
    expect(getState().period.stage).toBe('published')
    expect(screen.getByTestId('stage-advance').hasAttribute('disabled')).toBe(true)
  })

  it('names the stage it will move to, not the one it is in', () => {
    render(<StageBar />)
    expect(screen.getByTestId('stage-now').textContent).toBe('OPEN FOR BIDDING')
    expect(screen.getByTestId('stage-advance').textContent).toContain('BIDDING CLOSED')
    fireEvent.click(screen.getByTestId('stage-advance'))
    expect(screen.getByTestId('stage-now').textContent).toBe('BIDDING CLOSED')
    expect(screen.getByTestId('stage-advance').textContent).toContain('PUBLISHED')
  })
})

// The workflow the owner described: once bidding closes, the sheet is
// view-only for the squadron while the admin account keeps working.
describe('the edit lock', () => {
  /* the file default is admin (advancing the cycle is admin-only, 27 Aug 26);
     these MEMBER-lockout cases advance as the admin, then drop to member for
     the assertion — the war closes by an admin's hand, and the member is what
     the lock is being tested on */
  it('lets a member edit while the war is open', () => {
    act(() => setRole('member'))
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.getByTestId('bid-picker')).toBeTruthy()
  })

  it('locks a member out of everything once bidding closes', () => {
    advanceStage()                    // admin closes the war
    act(() => setRole('member'))
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.queryByTestId('bid-picker')).toBeNull()
    // Not merely unable to bid — unable to decide either. A member watching
    // this screen sees the outcome, never the buttons.
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.queryByTestId('bid-picker')).toBeNull()
    expect(screen.queryByTestId('decide-approve')).toBeNull()
  })

  it('keeps a member locked out at published', () => {
    advanceStage()
    advanceStage()
    act(() => setRole('member'))
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.queryByTestId('bid-picker')).toBeNull()
  })

  // The admin is the one who can still correct the sheet after closing it —
  // that is the whole reason the lock is role-shaped rather than a stage
  // flag that stops everybody.
  it('lets an admin still edit a cell after bidding has closed', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    fireEvent.click(screen.getByTestId('bid-LL'))
    expect(getState().grid.dusk['2026-02-11']).toBe('LL')
  })

  it('follows the role switch without a reload', () => {
    advanceStage()                    // admin closes the war
    act(() => setRole('member'))
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.queryByTestId('bid-picker')).toBeNull()
    act(() => setRole('admin'))
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.getByTestId('bid-picker')).toBeTruthy()
  })
})

describe('a cell Raptor owns', () => {
  // Seed: TATA's OIL on 9 Jan came in through Raptor's input tab.
  const RAPTOR = 'cell-tata-2026-01-09'

  it('opens a sheet that explains itself rather than offering a picker', () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(RAPTOR))
    expect(screen.getByTestId('raptor-sheet')).toBeTruthy()
    expect(screen.queryByTestId('bid-LL')).toBeNull()
    expect(screen.queryByTestId('bid-clear')).toBeNull()
  })

  it('offers no decision to an admin once bidding has closed', () => {
    advanceStage()
    setRole('admin')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(RAPTOR))
    expect(screen.getByTestId('raptor-sheet')).toBeTruthy()
    expect(screen.queryByTestId('decide-approve')).toBeNull()
    expect(screen.queryByTestId('decide-refuse')).toBeNull()
  })

  // A member who cannot edit anything still deserves to be told why that
  // cell is green and why nothing here will change it.
  it('explains itself to a locked-out member too', () => {
    advanceStage()
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(RAPTOR))
    expect(screen.getByTestId('raptor-sheet')).toBeTruthy()
  })

  it('paints green, and marks where it came from', () => {
    render(<Matrix />)
    const chip = screen.getByTestId(RAPTOR).querySelector('.c')!
    expect(chip.className).toContain('appr')
    expect(chip.className).toContain('raptor')
  })
})

describe('shifting a bid', () => {
  beforeEach(() => {
    advanceStage()
    setRole('admin')
  })

  it('moves the bid and leaves it pending on the new date', async () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    await moveTo('cell-asics-2026-01-30')
    expect(getState().grid.asics?.['2026-01-23']).toBeUndefined()
    expect(getState().grid.asics['2026-01-30']).toBe('*LL')
    expect(getState().states.asics['2026-01-30']).toEqual({
      state: 'pending', source: 'bid', shiftedFrom: '2026-01-23',
    })
  })

  it('marks the moved cell so the trail is visible on the grid', async () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    await moveTo('cell-asics-2026-01-30')
    expect(screen.getByTestId('cell-asics-2026-01-30').querySelector('.c')!.className).toContain('moved')
  })

  it('says why, rather than doing nothing, when the destination is taken', async () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    // ASICS already has LL on 2026-01-08.
    await moveTo('cell-asics-2026-01-08')
    expect(screen.getByTestId('move-banner').textContent).toContain('already booked')
    expect(getState().grid.asics['2026-01-23']).toBe('*LL')
  })

  /* REVERSED 27 Sep 26 by D262 ("the move button should be enabled ... The calendar can be removed"): Move used to be
     greyed until a date was typed, and the date box bounded the move to the war. It is never greyed now, and the war's
     bound is the grid itself — a move lands only on a day the grid draws, inside the war (moveCells' own rule). */
  it('can be moved at once — Move is never greyed out, and there is no date to type', () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    expect(screen.getByTestId('decide-shift').hasAttribute('disabled')).toBe(false)
    expect(screen.queryByTestId('shift-date')).toBeNull()
  })

  // The second half of the move. Management approves the date they moved it
  // to, and the trail has to survive that.
  it('keeps the trail when the moved bid is then approved', async () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    await moveTo('cell-asics-2026-01-30')
    fireEvent.click(screen.getByTestId('cell-asics-2026-01-30'))
    fireEvent.click(screen.getByTestId('decide-approve'))
    expect(getState().states.asics['2026-01-30']).toEqual({
      state: 'approved', source: 'bid', shiftedFrom: '2026-01-23',
    })
  })
})

// Owner, 27 Aug 26: the dotted "moved" edge is noise while bidding is open —
// people shuffle their own bids freely then — and becomes meaningful only once
// bidding has closed, where a shift is management moving someone's input.
describe('the moved mark waits for bidding to close', () => {
  const MOVED = 'cell-asics-2026-01-30'
  // Close the war, move ASICS's pending bid to 2026-01-30 (a shift), and it
  // carries the dotted "moved" edge — the trail management can see.
  const makeShift = async () => {
    advanceStage()                    // admin (file beforeEach) closes the war
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(PENDING))
    await moveTo('cell-asics-2026-01-30')
  }
  it('draws the moved edge once bidding has closed', async () => {
    await makeShift()
    expect(screen.getByTestId(MOVED).querySelector('.c')!.className).toContain('moved')
  })
  it('hides it again if the war is reopened for bidding', async () => {
    await makeShift()
    act(() => { reopenStage() })       // back to open — the bid (and its shift) survive
    expect(screen.getByTestId(MOVED).querySelector('.c')!.className).not.toContain('moved')
  })
})

// Owner, 10 Aug 26: "as an admin I can open bidding again after closing it".
describe('reopening the period from the strip', () => {
  it('offers a member neither control — not back, and (27 Aug 26) not forward', () => {
    advanceStage()                    // an admin closes the war…
    act(() => setRole('member'))      // …the member has no cycle controls at all
    render(<StageBar />)
    expect(getState().period.stage).toBe('closed')
    expect(screen.queryByTestId('stage-back')).toBeNull()
    expect(screen.queryByTestId('stage-advance')).toBeNull()
  })

  it('gives an admin a control back to bidding', () => {
    render(<StageBar />)
    fireEvent.click(screen.getByTestId('stage-advance'))
    act(() => setRole('admin'))
    fireEvent.click(screen.getByTestId('stage-back'))
    expect(getState().period.stage).toBe('open')
  })

  // It names where it goes, exactly as the forward control does — the pair
  // has to read as one cycle rather than as two unrelated buttons.
  it('names the stage it returns to', () => {
    act(() => setRole('admin'))
    render(<StageBar />)
    fireEvent.click(screen.getByTestId('stage-advance'))
    expect(screen.getByTestId('stage-back').textContent).toContain('OPEN FOR BIDDING')
    fireEvent.click(screen.getByTestId('stage-advance'))
    expect(screen.getByTestId('stage-back').textContent).toContain('BIDDING CLOSED')
  })

  it('offers nothing at draft, where there is nowhere back to', () => {
    act(() => setRole('admin'))
    render(<StageBar />)
    fireEvent.click(screen.getByTestId('stage-back'))
    expect(getState().period.stage).toBe('draft')
    expect(screen.queryByTestId('stage-back')).toBeNull()
  })

  // The point of the whole change: after reopening, the squadron can bid
  // again. Asserted through the matrix rather than the stage field, because
  // the stage is only interesting for what it lets people do.
  it('lets a member bid again once an admin has reopened', () => {
    act(() => setRole('admin'))
    render(<StageBar />)
    fireEvent.click(screen.getByTestId('stage-advance'))
    render(<Matrix />)
    act(() => setRole('member'))
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.queryByTestId('bid-picker')).toBeNull()

    act(() => setRole('admin'))
    fireEvent.click(screen.getByTestId('stage-back'))
    act(() => setRole('member'))
    fireEvent.click(screen.getByTestId('cell-dusk-2026-02-11'))
    expect(screen.getByTestId('bid-picker')).toBeTruthy()
  })
})
