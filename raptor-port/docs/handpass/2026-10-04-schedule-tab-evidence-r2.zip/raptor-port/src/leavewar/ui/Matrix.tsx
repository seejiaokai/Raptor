import { Fragment, memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type MutableRefObject, type PointerEvent as ReactPointerEvent, type RefCallback, type TouchEvent } from 'react'
import { shortDate } from './dates'
import {
  addDays,
  balanceOf,
  biddingClosed,
  canDecide,
  canEditCell,
  canEditRow,
  catClass,
  catText,
  codeOf,
  columnKindFor,
  displayCell,
  evaluatePeriod,
  groupOf,
  assignGroup,
  groupLabel,
  matchesGroup,
  OTHER_ID,
  OTHER_LABEL,
  SANS_GROUP_ID,
  inSquadron,
  beforeFirstStint,
  lastDayIn,
  postingSheetFor,
  isBiddable,
  isDuty,
  opsCatOf,
  orderedFigures,
  DEFAULT_FIGURE_ID,
  figureForLeave,
  figureLines,
  dayName,
  inBidWindow,
  isWeekend,
  monthsIn,
  oilLedgerOf,
  parseCell,
  raptorOwns,
  shiftedFrom,
  stateOf,
  defaultFocusDate,
  type Group,
  type Person,
  type Period,
  type DayInfo,
  type Grid,
  type States,
  type Role,
  type Figure,
  type FigureCtx,
} from '../engine'
import { awardsOnDay, balanceAfterFill, clearRecordById, figureCtxOf, oilOnDay, recordsAt, setBalance, setDayAward, groupsInOrder, groupPriorityIds, lwHistEpoch, moveGroupTo, moveGroupPriorityTo, displayRoster, getState, movableRecords, moveRecords, moveRecordsProblem, stayingIn, moveManningRowTo, moveEvent, moveEventProblem, moveRosterRow, orderedManningIds, resetManningRules, setPostIn, postingProblem, visibleFigures, hasAccount, postingBlocked, postingLocked, type MoveResult, type MoveRec, type EventMoveResult } from '../state/store'
import { AwardSheet, BidPicker, PostInSheet, PostOutSheet, RaptorSheet } from './BidPicker'
import { CounterSheet, FigureBreakdownSheet, PersonFiguresSheet } from './CounterSheet'
import { FigureCell, show } from './FigureCell'
import { FiguresDrawer, FigureTitle, figClass, type DrawerRow } from './FiguresDrawer'
import { OilTracker } from './OilTracker'
import { CountRows } from './CountRows'
import { CounterForm } from './CounterForm'
import { ManningSheet } from './ManningSheet'
import { EventRows } from './EventRows'
import { EventSheet } from './EventSheet'
import { monthInView } from './monthview'
import { popAt } from './popat'
import { clampWin, rollingTarget, stepAllowedInMotion, stepToward, visibleSpan, windowAround, WINDOW_FROM_MONTHS, type ColWin } from './colwindow'
import { touchesAM, touchesPM, winsOf, type DayView } from '../engine/dayview'
import type { Portion, PostOutcome } from '../engine'
import { outcomeOf } from '../engine'
import { isLwOnScreen, subLwScreen } from '../state/screen'
import type { RecordSpans } from '../state/merge'
import { creditGiver, type CreditRec } from '../engine/warrecs'
import { parseHM } from '../../engine/time'
import { msSinceInput } from '../../state/idle'
import { boxOf, frameLift, frameLand, landOn } from '../../ui/lift'
import { wireSelect, wireMove, wireFigureSelect, daysBetween, paintLanding, clearLanding, paintEventLanding, eventMoveDateAt, earliestDate, type Cell, type Selection, type SelectCtx, type FigureSelectCtx, type FigureSelection } from './select'
import { selectableFigure } from '../engine/counters'
import { SettingsSheet } from './SettingsSheet'
import { groupColorOf, inkFor } from './groupColor'
import { SelectSheet } from './SelectSheet'
import { BalanceBar } from './BalanceBar'
import { RemarksSheet } from './RemarksSheet'
import { leaveInputAt, postOut, postOutProblem, undoPostOut, undoPostOutProblem } from '../sync'
import { useVersion } from './useStore'
import { DayListSheet } from './DayList'
import type { Views } from '../engine/dayview'
import './matrix.css'

/** A posting through the store, or the sentence saying why it was refused (the absence-record re-test, AB5, 26 Sep
 *  26): every posting door — the bid sheet's PI / PO, the two posting sheets, the drag-selection's PO — shows it and
 *  stays open, where each used to close (or snap back) with nothing said. */
function postOutOr(id: string, from: string, archive?: boolean | PostOutcome): string | undefined {
  /* never Delete oneself (the posting door's own refusal — sync.ts postOutProblem) */
  const self = postOutProblem(id, typeof archive === 'string' ? archive : (archive === false ? 'none' : 'overseas'))
  if (self) return self
  /* through the bridge, so a Post out's own archive follows the new date and switch (Astra's final read, finding 2) */
  return postOut(id, from, archive) ? undefined : (postingProblem(id, 'out', from) || 'That posting date was not taken.')
}
function postInOr(id: string, from: string): string | undefined {
  return setPostIn(id, from) ? undefined : (postingProblem(id, 'in', from) || 'That posting date was not taken.')
}

/** A move refusal, in plain words for the move banner. */
function moveReason(r: Exclude<MoveResult, 'moved'>): string {
  switch (r.reason) {
    case 'occupied': return `That lands on ${r.at ? shortDate(r.at) : 'a day'} which is already booked — pick another day.`
    case 'raptor': return 'One of those is filed on the Inputs page and cannot be moved here.'
    case 'window': return 'That lands outside what you can edit — pick another day.'
    default: return 'Nothing to move.'
  }
}

/** WHAT A MOVE LEAVES BEHIND, in the banner's words (the mock-up's reading, uncorrected — D331: "in a block what can
 *  move goes; what can't stays, and the banner says what stays"). " · 1 OIL award stays", " · 2 OIL awards and 1 bid
 *  stay". Only what a person put there and might expect to travel (`stayingIn`); nothing when everything moves. */
function stayWords(stays: ReadonlyArray<{ what: 'award' | 'filed' | 'approved' | 'bid' | 'refused' }>): string {
  if (!stays.length) return ''
  const label: Record<string, [string, string]> = {
    award: ['OIL award', 'OIL awards'],
    approved: ['approved leave', 'approved leaves'],
    filed: ['leave filed on the Inputs page', 'leaves filed on the Inputs page'],
    bid: ['bid', 'bids'],
    refused: ['refused bid', 'refused bids'],
  }
  const parts = (['award', 'approved', 'filed', 'bid', 'refused'] as const)
    .map(k => { const n = stays.filter(x => x.what === k).length; return n ? `${n} ${label[k]![n === 1 ? 0 : 1]}` : '' })
    .filter(Boolean)
  return ` · ${parts.join(' and ')} ${stays.length === 1 ? 'stays' : 'stay'}`
}

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']

/** The month abbreviation for a date, but only on that month's first day —
 *  `null` every other day. The header renders it above the day number so a
 *  quarter running 01…31 twice says which "01" is which. */
function monthLabel(date: string): string | null {
  if (date.slice(8, 10) !== '01') return null
  return MONTHS[Number(date.slice(5, 7)) - 1]
}

/** Whether a person's row rides the roster for a visible month window
 *  ('yyyy-mm|yyyy-mm', or '' meaning no measurement → everyone).
 *
 *  A posted-out person rides every month up to and including the one holding
 *  their last day and drops off after it (owner, 19 Aug 26 — "once I hit the
 *  next month… the row disappears"); a late joiner mirrors it at the other
 *  end. Month granularity on purpose: scrolling inside a month never
 *  reshuffles the rows, only crossing a boundary does.
 *
 *  …AND the row stretches to reach anything the war shows for them outside
 *  those dates (owner, 20 Sep 26 — records may be dated before someone posts
 *  in and after they post out, "because those dates are official dates. But
 *  they can be for e.g still taking leave after or before they post in or
 *  out"). Without it a man posted out in January with clearing leave in
 *  September was charged for that leave and could not be seen — the money and
 *  the screen disagreed. `spans` is merge.ts's per-merge map, so this stays a
 *  lookup; it is a DISPLAY span only, and his own dates — which is what every
 *  manning count reads — are untouched. This narrows the 19 Aug rule above
 *  rather than reversing it: a row with nothing out there still disappears
 *  exactly as it did. */
function rowInWindow(p: Person, win: string, spans?: RecordSpans): boolean {
  if (!win) return true
  const [first, last] = win.split('|')
  const span = spans?.get(p.id)
  const endsAt = p.to === null ? null
    : span && span.last > p.to.slice(0, 7) ? span.last : p.to.slice(0, 7)
  const startsAt = p.from === null ? null
    : span && span.first < p.from.slice(0, 7) ? span.first : p.from.slice(0, 7)
  /* D320 ([ONE-DOOR], 27 Sep 26): an earlier stint shows his row too — a leave period that holds one of his stints
     shows him, one he was away for the whole of (and holding no record of his) does not */
  const inPast = !!p.past && p.past.some(s => s.to.slice(0, 7) >= first! && (s.from === null || s.from.slice(0, 7) <= last!))
  if (endsAt !== null && endsAt < first!) return inPast
  if (startsAt !== null && startsAt > last!) return inPast
  return true
}

/** Whether two frozen-header pins measured the same bar — its box and every
 *  column width, to a hundredth of a pixel. A re-pin that finds nothing moved
 *  keeps the old pin, so re-measuring after a change costs no re-render. */
function sameStuck(
  a: { top: number; left: number; width: number; cols: number[] },
  b: { top: number; left: number; width: number; cols: number[] },
): boolean {
  if (a.top !== b.top || a.left !== b.left || a.width !== b.width || a.cols.length !== b.cols.length) return false
  return a.cols.every((w, i) => Math.abs(w - b.cols[i]!) < 0.01)
}

/* The ground-crew free-text role-label editor (`PersLabel`) was REMOVED
   (owner, 28 Aug 26 — "i can edit personnel, dont need to show that, just leave
   it as the callsign/name"). In Rearrange, a ground-crew row used to turn its
   name column into a "Maint / Line" edit box; the owner does not want that
   editing, so the row now shows the same callsign + category chip as every
   other row, in both modes. The stored labels and the store's
   `personLabel`/`setPersLabel` seam are untouched (roster.test.ts still covers
   them) — only the on-grid editor is gone. */

/* The two kinds of row the one drag machine (startRowDrag) can reorder. */
type RowDragCfg = {
  /** querySelector for a draggable row (and for the ordered list at drop). */
  sel: string
  /** read a row element's id (null if it isn't one). */
  idOf: (el: Element) => string | null
  /** commit: move `from` to sit before `beforeId` (end when null). */
  move: (from: string, beforeId: string | null) => void
  /** the moved thing after the store has re-rendered — where the landing flash goes */
  landSel: (id: string) => string
}
const ROSTER_DRAG: RowDragCfg = {
  sel: '[data-testid^="row-"]',
  idOf: el => el.getAttribute('data-testid')?.slice(4) ?? null,
  move: moveRosterRow,
  landSel: id => `[data-testid="row-${id}"]`,
}
const MANNING_DRAG: RowDragCfg = {
  sel: '[data-mrow]',
  idOf: el => el.getAttribute('data-mrow'),
  move: moveManningRowTo,
  landSel: id => `[data-mrow="${id}"]`,
}
/* The group editor's two lists reorder with the SAME machine — display order
   and the separate who-wins priority (owner, 28 Aug 26). */
const GROUP_DRAG: RowDragCfg = {
  sel: '[data-grow]',
  idOf: el => el.getAttribute('data-grow'),
  move: moveGroupTo,
  landSel: id => `[data-grow="${id}"]`,
}
const GROUP_PRIO_DRAG: RowDragCfg = {
  sel: '[data-gprio]',
  idOf: el => el.getAttribute('data-gprio'),
  move: moveGroupPriorityTo,
  landSel: id => `[data-gprio="${id}"]`,
}

// ---- one roster row, memoised (3 Sep 26) ----------------------------------
//
// MEASURED before this existed (built bundle, CPU throttled 4x, ~18,000 cells):
// tapping a cell to open its sheet cost ~1.0s, of which ~0.6s was JS — the
// Matrix rebuilding every cell's JSX because a sheet is Matrix STATE. The
// first open paid the same rebuild ~3 times over as its mount-time
// measurements (strip height, bid box, row window) each stored a result.
// A memoised row repaints only when one of ITS inputs changes, so local UI
// state — a sheet, the quals popover, a drag hover on another row — costs the
// chrome, not the grid. Everything store-derived rides `version`: a bid, a
// decision, a war change, a roster re-projection bumps it and every row
// repaints exactly as before. So the contract is simple: a row is a pure
// function of its props, and every prop is either a primitive or an object
// whose identity changes only with the store version. Event-time callbacks
// go through ONE ref (`api`) so the row never receives a fresh function prop.
//
// The DOM this renders is byte-identical to the inline <tr> it replaced —
// every class, testid, title and handler position is unchanged, which is
// what keeps the geometry gate and the drag-select machinery (which finds
// cells by testid) honest.

type QualPill = { label: string; color: string }
const NO_QUALS: QualPill[] = []

type RowApi = {
  startRowDrag: (e: ReactPointerEvent, id: string, cfg: RowDragCfg) => void
  setWhoOpen: (id: string) => void
  setBalOpen: (v: { person: string; figureId: string }) => void
  setOpen: (v: { id: string; callsign: string; date: string }) => void
  chipEnter: (id: string, el: HTMLElement) => void
  chipLeave: () => void
  chipClick: (p: Person, el: HTMLElement) => void
}

/**
 * The half of a day that is FREE beside a record locked to the Inputs page
 * (CURRENT-STATE item D), or null when there is no such half.
 *
 * The read-only sheet speaks for the WHOLE day whenever the main record is
 * filed on the Inputs page — so a morning LL filed on the form made the
 * afternoon unbiddable too, with nothing on screen to say why. Most leave
 * arrives through the form, so this is the normal case, not a corner.
 *
 * Deliberately narrow, which is the constraint both reviewers put on it: it
 * finds a free half, it does NOT make the filed leave editable here. The filed
 * record keeps its lock, the store's own occupancy rule still has the last
 * word on any write, and a day held on BOTH halves (or on neither) returns
 * null and behaves exactly as before.
 *
 * A credit is not a blocker: since the owner's 20 Sep 26 ruling, recorded work
 * never bars a write — it flags the day. A refused bid never blocked anything.
 */
function freeHalfBeside(v: DayView | undefined): Portion | null {
  if (!v) return null
  const holding = v.all.filter(c => c.kind === 'absence' || (c.kind === 'request' && c.state !== 'refused'))
  if (!holding.length) return null
  /* by the REAL hours (the absence-record re-test, W5-F4, 26 Sep 26): a medical recorded 09:00–14:00 is drawn as a
     morning (the six-hour rule) but its hours run into the afternoon, and every clash is judged on real hours (§7) —
     so the afternoon was offered here and then refused by the door. winsOf is what the doors read. */
  const am = holding.some(c => winsOf(c).some(touchesAM))
  const pm = holding.some(c => winsOf(c).some(touchesPM))
  return am && !pm ? 'pm' : pm && !am ? 'am' : null
}

/** The day holds one of the viewer's OWN hand-given OIL awards (D261) — the record he may always read back, whatever
 *  the stage. ANY of the day's records counts, not only the one on top (Astra's plan read F02): a day holding his award
 *  beside anything else — the schedule's credit, a second award — opens the tap list, read only for him, which reads
 *  each award back; a day holding just the award opens its own sheet (`ownAwardAlone`). */
function ownAwardPresent(view: DayView | undefined, viewer: string | null, personId: string): boolean {
  return viewer !== null && personId === viewer && !!view && view.all.some(c => c.kind === 'credit' && !c.auto)
}
/** …and nothing else on the day — the award's own read-only sheet. */
function ownAwardAlone(view: DayView | undefined, viewer: string | null, personId: string): boolean {
  return ownAwardPresent(view, viewer, personId) && !!view?.main && view.main.kind === 'credit' && !view.main.auto && !view.mark
}

/** Whether a tap on this cell opens SOMETHING — the one body Matrix and the
 *  row share. Where a tap goes (bid / decide / read-only / remarks) is decided
 *  in the sheet from the same facts; this only says "there is a sheet". */
function cellOpenable(states: States, period: Period, role: Role, viewer: string | null, deciding: boolean, grid: Grid, personId: string, date: string, view?: DayView): boolean {
  return raptorOwns(states, personId, date) ||
    /* HIS OWN OIL AWARD, AT EVERY STAGE (owner, D261, 27 Sep 26 — "3 yes"): it opens read only (`ownAwardPresent`)
       where nothing else would — outside the bidding window, once bidding has closed, on a published war. Another man's
       award stays shut to a member. */
    ownAwardPresent(view, viewer, personId) ||
    // A member may open a cell to EDIT only on their own row (the person they
    // are viewing as); an admin, any row. Without the row half a member could
    // tap an empty cell on anyone's row and bid it (owner, 27 Aug 26). The
    // date/window half is `canEditCell`; both must pass.
    (canEditCell(period, role, date) && canEditRow(role, viewer, personId)) ||
    (deciding && isBiddable(grid[personId]?.[date])) ||
    // Published remarks editor (owner, 27 Aug 26): the viewer's own APPROVED
    // leave is tappable to edit its note (an admin's every cell is already
    // openable through the canEditCell branch above). Kept CHEAP — code and
    // state truthiness, never leaveInputAt, because this runs for every drawn
    // cell; the precise "is there a backing leave input" test is `canRemark`,
    // computed once when a cell is opened. Approved-only on purpose: a
    // member's refused or pending bid at published opens NOTHING (no editor,
    // no decision sheet), and the first cut still painted it tappable — a
    // dead-feeling tap exactly where the stakes are highest, a refusal.
    (period.stage === 'published' && personId === viewer
      && isBiddable(grid[personId]?.[date])
      && states[personId]?.[date]?.state === 'approved')
}

type PersonRowProps = {
  p: Person
  version: number
  period: Period
  /** The DRAWN days — the column window's slice of `period.days` (colwindow.ts)
   *  — as one array per month, each keeping its identity while the war's days
   *  do (Matrix `drawnMonthDays`), so `PersonMonth` can bail out per month. */
  monthDays: DayInfo[][]
  grid: Grid
  states: States
  views: Views
  role: Role
  viewer: string | null
  deciding: boolean
  movedShown: boolean
  shown: Figure
  figureCtx: FigureCtx
  /** The figure this row's counter box is SELECTED on, or null (Matrix
   *  `figSel`, 6 Sep 26 — a drag down one figure column). A primitive, so the
   *  memo only repaints the rows whose own value flips as the run grows. */
  figSel: string | null
  evKind: Map<string, string>
  lockedCols: Set<string>
  quals: QualPill[]
  me: boolean
  arranging: boolean
  dragging: boolean
  over: '' | 'dragover' | 'dragover after'
  api: MutableRefObject<RowApi>
  /** The column window's PLACEHOLDER cells (colwindow.ts, 5 Sep 26): one empty
   *  cell before / after the drawn days standing in for the undrawn months, so
   *  every row keeps the same column count as the header. Sized by Matrix,
   *  never here: `phL`/`phR` are its stable mount hooks that write the width
   *  straight onto the cell (see `applyPlaceholders`). */
  padL: boolean
  padR: boolean
  phL: RefCallback<HTMLTableCellElement>
  phR: RefCallback<HTMLTableCellElement>
}

type PersonMonthProps = {
  p: Person
  version: number
  period: Period
  /** ONE month's days (a `drawnMonthDays` slice — identity is the memo key). */
  days: DayInfo[]
  grid: Grid
  states: States
  /** the day views ([ARCH-STACK] step 4) — the corner mark and leave dated
   *  outside the person's time in the squadron read them */
  views: Views
  role: Role
  viewer: string | null
  deciding: boolean
  movedShown: boolean
  evKind: Map<string, string>
  lockedCols: Set<string>
  api: MutableRefObject<RowApi>
}

// A placeholder cell's width, all three properties so auto table layout can
// neither widen nor narrow it (Matrix `applyPlaceholders`).
const setPhWidth = (el: HTMLElement, w: string) => {
  const s = el.style
  s.width = w; s.minWidth = w; s.maxWidth = w
}

const PersonRow = memo(function PersonRow({ p, version, period, monthDays, grid, states, views, role, viewer, deciding, movedShown, shown, figureCtx, figSel, evKind, lockedCols, quals, me, arranging, dragging, over, api, padL, padR, phL, phR }: PersonRowProps) {
  const has = quals.length > 0
  // The selected figure's LINES for this person — the two-line box's own
  // number on top, the days taken from it stacked under (FigureCell, 6 Sep
  // 26). It has to move the instant a bid is placed, because a pending bid
  // has been asked for and cannot be asked for twice — and every store
  // change bumps `version`, so keying the memo on it keeps that true while a
  // window step (which re-renders the row for its new month but changes no
  // figure) no longer walks every war's ledger for all ~58 rows. A balance
  // can go negative (shown red, never refused — the squadron's balances
  // already run negative, §Counters); a total never does. Every figure
  // counts across EVERY war, not the one on screen — leave bid in Jan–Mar
  // still spends against Apr–Jun.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const lines = useMemo(() => figureLines(shown, figureCtx, p.id), [shown, figureCtx, p.id, version])
  return (
    /* `me` lights the VIEWER's own row (owner, 17 Aug 26). While arranging the
       row is a drop target the pointer drag reads by hit-test; the drag SOURCE
       is the handle alone, so a tap on the personnel label box types rather
       than starting a drag. */
    <tr
      data-testid={`row-${p.id}`}
      className={[
        me ? 'me' : '',
        arranging ? 'arrange' : '',
        dragging ? 'dragging' : '',
        over,
      ].filter(Boolean).join(' ') || undefined}
    >
      <td className="who">
        <div className="whorow">
          {arranging && (
            <span
              className="drag"
              data-testid={`drag-${p.id}`}
              title="Drag to move this row"
              style={{ touchAction: 'none' }}
              onPointerDown={e => api.current.startRowDrag(e, p.id, ROSTER_DRAG)}
            >⠿</span>
          )}
          {/* The callsign opens the person's all-figures sheet, for everyone
              (owner, 17 Aug 26). The CAT chip carries the person's colour,
              reused from Raptor's Quals palette, and an SXO sits under the SXO
              heading rather than wearing a second column. The chip: the
              person's CAT, coloured by CAT (an SXO keeps gold wherever they
              sit). When they hold a displayed qualification it becomes a live
              control — hover (desktop) or tap (phone) to list them; the click
              is swallowed so it never also opens the figures sheet the
              callsign owns. A second tap on the SAME chip closes it (the phone
              has no pointer to leave with); a tap on another chip moves it. */}
          <button
            className="whoedit"
            data-testid={`person-${p.id}`}
            title={`${p.callsign} — every figure`}
            onClick={() => api.current.setWhoOpen(p.id)}
          >
            <span className={`cs seat-${p.seat}`}>{p.callsign}</span>
            {/* D283 (the approved picture 4a): a SANS posting shown in his old place (Show SANS off) wears a SANS tag */}
            {p.to !== null && outcomeOf(p) === 'sans' && <span className="po-sans-tag" data-testid={`sans-tag-${p.id}`}>SANS</span>}
            <span
              className={`catchip ${catClass(p)}${has ? ' has-quals' : ''}`}
              data-testid={`cat-${p.id}`}
              aria-label={has ? `${p.callsign} qualifications: ${quals.map(q => q.label).join(', ')}` : undefined}
              onPointerEnter={has ? e => { if (e.pointerType === 'mouse') api.current.chipEnter(p.id, e.currentTarget) } : undefined}
              onPointerLeave={has ? e => { if (e.pointerType === 'mouse') api.current.chipLeave() } : undefined}
              onClick={has ? e => { e.stopPropagation(); api.current.chipClick(p, e.currentTarget) } : undefined}
            >{catText(p) || 'GND'}</span>
          </button>
          {/* The free-text role-label edit box is GONE (owner, 28 Aug 26 —
              "i can edit personnel, dont need to show that, just leave it as
              the callsign/name"). A ground-crew row now shows the same
              callsign + chip as every other row, in Rearrange too. */}
        </div>
      </td>
      {/* A tap opens the person's breakdown of the shown figure — the
          owner's "click the individual personnel counter" (17 Aug 26). The
          td is the target, like every grid cell here: a nested button would
          cost the 44px column its number.
          `dataFig`/`dataPerson` are what the figure DRAG addresses the box by
          (6 Sep 26) — the one vocabulary all three copies of a box share. */}
      <FigureCell
        figure={shown}
        lines={lines}
        personId={p.id}
        extraClass="bal act"
        testid={`bal-${p.id}`}
        dataFig={shown.id}
        dataPerson={p.id}
        selected={figSel === shown.id}
        title={`${p.callsign}: ${shown.label} ${show(lines.top)} ${shown.kind === 'bal' ? 'left' : 'taken'}. Tap for the breakdown`}
        onClick={() => api.current.setBalOpen({ person: p.id, figureId: shown.id })}
      />
      {padL && <td className="lwph lwph-l" ref={phL} />}
      {/* The day cells, one memoised block PER MONTH (6 Sep 26). A window step
          adds a month to every row; with the cells rendered inline, React
          re-reconciled all ~21,000 drawn cells and our per-cell logic re-ran
          for every one of them — profiled at ~⅔ of a month draw's JS on the
          slow laptop. Keyed by the month, not the position, so a month added
          on the LEFT still matches the blocks already drawn. */}
      {monthDays.map(md => (
        <PersonMonth
          key={md[0]!.date}
          p={p}
          version={version}
          period={period}
          days={md}
          grid={grid}
          states={states}
          views={views}
          role={role}
          viewer={viewer}
          deciding={deciding}
          movedShown={movedShown}
          evKind={evKind}
          lockedCols={lockedCols}
          api={api}
        />
      ))}
      {padR && <td className="lwph lwph-r" ref={phR} />}
    </tr>
  )
})

// One month of a person's day cells. `version` is a memo input only: every
// store change still repaints every cell through it, exactly as the row did.
const PersonMonth = memo(function PersonMonth({ p, period, days, grid, states, views, role, viewer, deciding, movedShown, evKind, lockedCols, api }: PersonMonthProps) {
  return (
    <>
      {days.map(d => {
        const code = grid[p.id]?.[d.date] ?? ''
        const here = inSquadron(p, d.date)
        // `here` is false on both sides of the roster window. Before `from`
        // the person has not arrived yet — that is not the same fact as
        // having been posted out, and must not read as one. Only the "after
        // `to`" direction is a genuine PO.
        /* D320 ([ONE-DOOR], 27 Sep 26): only a day before his FIRST stint is "not yet arrived"; a day in the gap
           between two stints he was here and left — it reads as away, PO with the hatch */
        const notYetArrived = !here && beforeFirstStint(p, d.date)
        /* [ARCH-STACK] step 4 — owner answer C (20 Sep 26): leave may be dated
           before someone posts in and after they post out (clearing leave). It
           SHOWS as the leave code — blank-looking before posting-in, with the
           small PO tag after posting-out — and never counts for manning (the
           hatch stays). */
        const view = views[p.id]?.[d.date]
        /* …and an OIL AWARD dated there too (Astra's final read, 3, 27 Sep 26): one may be given after a man posts out or
           before he posts in ("Place leave or OIL here instead…", N12), and the day drew a bare PO (or blank) that
           nobody could tap — his own award hidden from him, and from the admin's eye. It shows with the posting hatch,
           like the leave beside it, counts nobody (the hatch stays), and his own tap opens it read only (D261). */
        const outLeave = !here && !!code && !!view?.main && (codeOf(view.main.code)?.spends != null || view.main.kind === 'credit')
        const mark = view?.mark ?? ''
        const cls = [
          here ? '' : 'gone',
          outLeave ? 'outlv' : '',
          here && isDuty(code) ? 'duty' : '',
          // The band runs the whole column, not just the header — finding a
          // Tuesday in 90 columns should not need counting. `.gone`'s hatch
          // is declared after the weekend rule so a posted-out weekend still
          // reads as posted out.
          isWeekend(d.date) ? 'weekend' : '',
          // The event column colour (off = green, no-leave = orange),
          // declared after the weekend so a holiday Saturday reads as the
          // holiday, not the weekend.
          evKind.get(d.date) ?? '',
          // Outside the bidding window, for this role. Declared after the
          // event colour so a locked, tinted day still reads as locked — the
          // same cascade care the .blocked/.weekend pair needs, and for the
          // same reason.
          lockedCols.has(d.date) ? 'locked' : '',
        ].filter(Boolean).join(' ')
        // The stored notation, printed through the one display mapping — the
        // ATT markers read as the owner's bare B / C on the grid while
        // everything else prints as stored (displayCell is identity for it).
        /* `view.main.auto` is the fact the code string cannot carry: an OIL
           credit the APP worked out from the published schedule, rather than
           one a person granted. It prints as the trailing star (owner, 20 Sep
           26). */
        const text = here || outLeave ? displayCell(code, !!view?.main?.auto) : notYetArrived ? '' : 'PO'
        // Duty first for the reader — FO/HO are work, not a bid. (They carry
        // `bid: false`, so they could not reach a bid branch anyway; the
        // order is legibility, not a guard.) Then the bid state, but only
        // where the code is one a person bids for. Everything else is plain
        // information: medical, a course, overseas duty. A bare "PO" chip on
        // a posted-out cell carries no state class at all.
        //
        // A bid with NO decision recorded reads as pending, and PENDING IS
        // PLAIN — no colour class at all, so the chip renders as text on the
        // ordinary cell background. It was purple until 10 Aug 26, when the
        // owner pointed out what that cost: an input nobody had looked at and
        // one already in management's hands were the same colour, so the
        // sheet could not distinguish them. Purple now means acknowledged —
        // somebody has seen this — and the absence of colour means the
        // absence of news.
        const bid = stateOf(states, p.id, d.date)
        const chipState = (!here && !outLeave) || !code
          ? ''
          : isDuty(code) ? 'sc'
          : !isBiddable(code) ? 'info'
          : bid === 'approved' ? 'appr'
          : bid === 'refused' ? 'ref'
          : bid === 'acknowledged' ? 'tbc'
          : ''
        // The half-day fill is read off the stored string via `parseCell`,
        // never kept as its own bit of state and never guessed by matching an
        // asterisk here in the component. The asterisk in `text` stays the
        // one source of truth; this is only a derived echo of it, so the two
        // can never disagree.
        const portion = (here || outLeave) && code ? parseCell(code)?.portion : undefined
        const portionClass = portion === 'am' || portion === 'pm' ? ` ${portion}` : ''
        // Two marks on top of the state colour, never instead of it: the
        // squadron reads green as approved and magenta as pending, and that
        // stays true here. `raptor` says the approval happened elsewhere and
        // nothing on this screen will change it; `moved` says management
        // shifted this bid off another date.
        const marks = [
          (here || outLeave) && code && raptorOwns(states, p.id, d.date) ? 'raptor' : '',
          movedShown && (here || outLeave) && code && shiftedFrom(states, p.id, d.date) ? 'moved' : '',
        ].filter(Boolean).join(' ')
        /* BOTH ENDS of the squadron window are tappable (owner answer C, 20
           Sep 26 — leave outside the window may be "filed OR bid"; and the
           post-in ruling the same day). The old text here said a day before
           someone joins is "blank, not a post-out, and nothing there to undo",
           and `notYetArrived` barred it on both branches. That reading is
           DEAD: there is now a joining date to undo (before the post-in button
           no person had one, so no such day could exist), and answer C says
           leave may be bid there. So the split is now the same at both ends —
           an ADMIN's tap manages the POSTING (the post-out sheet after, the
           post-in sheet before), and the person's OWN tap places LEAVE. */
        const actionable =
          (here && cellOpenable(states, period, role, viewer, deciding, grid, p.id, d.date, view)) || (role === 'admin' && !here) ||
          // a marked day always opens its list; leave dated outside the
          // squadron window opens for an admin and for the person themself
          (!!mark && (here || outLeave)) || (outLeave && (role === 'admin' || viewer === p.id)) ||
          // …and the person may bid clearing leave after posting out, or leave
          // dated before they post in
          (!here && role !== 'admin' && viewer === p.id && canEditCell(period, role, d.date))
        // Their LAST day in the squadron wears a small PO tag (owner, 19 Aug
        // 26 — chosen over nothing after the edge case was put to him):
        // someone posting out on the 1st has a final month that otherwise
        // looks completely normal, and the next month their row is gone — so
        // without this, a reader jumping month to month never sees the PO at
        // all. The tag rides the corner of the cell so a leave code on the
        // same day still prints.
        /* D320: every stint's last day wears the corner, an earlier one's too */
        const lastIn = lastDayIn(p, d.date)
        const lastCurrent = lastIn && d.date === p.to
        return (
          <td
            key={d.date}
            data-testid={`cell-${p.id}-${d.date}`}
            className={`${cls}${actionable ? ' act' : ''}${lastIn ? ' pofin' : ''}${mark ? ' mkd' : ''}`}
            onClick={actionable
              ? () => api.current.setOpen({ id: p.id, callsign: p.callsign, date: d.date })
              : undefined}
          >
            {text && (
              <span
                className={`c${chipState ? ` ${chipState}` : ''}${portionClass}${marks ? ` ${marks}` : ''}`}
              >
                {text}
              </span>
            )}
            {mark && (here || outLeave || notYetArrived) && (
              <span
                className={`mk ${view!.amber ? 'warn' : 'more'}`}
                data-testid={`mark-${p.id}-${d.date}`}
                /* Item A: on the reader's OWN row an amber day is not "someone
                   else has a job to do" — it is news about their own leave,
                   which is still live. Two audiences, two sentences. */
                title={!view!.amber
                  ? 'More on this day — tap to see'
                  : viewer === p.id
                    ? 'Your bid is still live — tap to see what else is on this day'
                    : 'Something on this day needs an admin — tap to see'}
              >
                {mark}
              </span>
            )}
            {outLeave && !notYetArrived && (
              <span className="potag" data-testid={`potag-${p.id}-${d.date}`}>PO</span>
            )}
            {lastIn && (
              <span
                className="polast"
                data-testid={lastCurrent ? `polast-${p.id}` : `polast-${p.id}-${d.date}`}
                title={lastCurrent
                  ? `${p.callsign} posts out ${shortDate(addDays(p.to!, 1))} — this is their last day in the squadron`
                  : `${p.callsign} was posted out ${shortDate(addDays(d.date, 1))} — the last day of an earlier stint`}
              >
                PO
              </span>
            )}
          </td>
        )
      })}
    </>
  )
})

export function Matrix() {
  /* kept in a name (not just subscribed) so store-reading memos below can
     re-derive on every store change — `movers` reads live grid state, and a
     memo keyed only on the selection went stale when a sync pass changed a
     selected cell under an armed move */
  const version = useVersion()
  const { people, period, grid, states, views, spans: rowSpans, requirements, role, viewer, eventDefs, openings, ledger, wars, figureOrder, manningHidden, eventRows, focusDate, focusSeq, qualCatalog, groupColors } = getState()
  const dates = period.days.map(d => d.date)
  // Memoized on the store objects (the store replaces what it writes, so
  // identity IS change): rules-as-data made a day's evaluation walk every
  // rule's own filter, and paying that for all 365 days again on every
  // VIEW-state render (a sheet opening, Rearrange toggling) is waste the old
  // fixed-kind lookup merely tolerated.
  const verdicts = useMemo(
    () => evaluatePeriod(people, grid, states, requirements, dates, views),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [people, grid, states, views, requirements, period],
  )
  // The colour a whole day column takes from its events: light green for an
  // off day (a PH), orange for a no-leave day. Computed once per day and read
  // into both the header and the body cells, so a tag colours the whole
  // column, not just the event rows — finding a holiday in 90 columns should
  // not need reading the top two rows. `work` never colours the column (its
  // own word goes red instead), so it maps to no class here.
  // Memoised on the store version (3 Sep 26): the map is a row prop now, and
  // a fresh Map on every render would defeat the row memo (see PersonRow).
  // Keyed on `version`, not the period object, because store writes may
  // update in place — the version is the one signal that never lies.
  const evKind = useMemo(() => {
    const m = new Map<string, string>()
    for (const d of period.days) {
      const k = columnKindFor(eventDefs, d, period.bands)
      if (k === 'off') m.set(d.date, 'evoff')
      else if (k === 'free') m.set(d.date, 'evfree')
      else if (k === 'nolv') m.set(d.date, 'evnolv')
    }
    return m
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version])

  // Which cell is open, not which sheet is open: what the sheet OFFERS is
  // derived from the stage and the role, so a period that moves on — or a
  // role that changes — while a sheet is open cannot leave the wrong
  // controls on screen.
  /* `posting` — the posting sheet the tap opened, PINNED for as long as the sheet is up (the absence-record re-test,
     W3-F5, 26 Sep 26 — found by the war walker). The Post out sheet commits on change and stays up so the admin can
     see the grid move behind it; moving the date PAST the tapped day made that day an in-squadron day, and the grid
     re-chose the sheet from the day's new state, so a bid sheet appeared under his hands, one tap from placing leave.
     Read at the tap, from the day as it stood; unset for every other sheet, which follows the day live (a PO placed
     from the bid sheet closes that sheet — the next tap on the greyed day opens the Post out sheet). */
  const [open, setOpen] = useState<{ id: string; callsign: string; date: string; posting?: 'po' | 'pi' } | null>(null)
  const close = () => { setOpen(null); setPlaceAt(null) }
  /* the published note editor opened FROM the tap list, for one Input */
  const [listRemark, setListRemark] = useState<{ at: string; row: any } | null>(null)
  // The DRAG-SELECTION (owner, 27 Aug 26): the rectangle the last drag left,
  // and the sheet it opens. `moveSel` is the selection currently being MOVED
  // (Task E) — sheet closed, waiting for a drop. Both cleared on a stage/war
  // change so a stale block cannot act on the wrong screen.
  const [sel, setSel] = useState<Selection | null>(null)
  const [moveSel, setMoveSel] = useState<Selection | null>(null)
  const [moveErr, setMoveErr] = useState('')
  // Phone move-mode: the day a tap has STAGED, awaiting a Confirm (there is no
  // undo, so a phone drop is a two-step — preview then commit, owner 27 Aug 26).
  // Desktop lands on the click and never sets this.
  const [movePreview, setMovePreview] = useState<string | null>(null)
  // The EVENT counterpart of moveSel (owner, 31 Aug 26 — "drag an existing event
  // to move it"): the event span being moved (its own line + from/to), waiting
  // for a drop onto a day. Same phone stage/desktop-commit split, same
  // clear-on-stage-change guard below.
  const [eventMoveSel, setEventMoveSel] = useState<{ line: number; from: string; to: string } | null>(null)
  const [eventMoveErr, setEventMoveErr] = useState('')
  const [eventMovePreview, setEventMovePreview] = useState<string | null>(null)
  // Whether the open cell is a POSTED-OUT day (admin tapped a greyed cell to
  // undo it, owner 18 Aug 26). A day before the person joined is blank, not a
  // post-out, so it is excluded — there is nothing to undo there.
  const openPerson = open ? people.find(p => p.id === open.id) : undefined
  const openPostedOut = open?.posting
    ? open.posting === 'po' && !!openPerson && openPerson.to !== null
    : !!open && !!openPerson && postingSheetFor(openPerson, open.date) === 'po'   // D320: by stint
  // …and its mirror at the other end: a day BEFORE the person posted in
  // (owner, 20 Sep 26). For an ADMIN this opens the post-in sheet, exactly as
  // a posted-out day opens the post-out one; for a member it falls through to
  // the bid picker, which is answer C's "filed or bid" on a pre-joining day.
  const openNotYetArrived = open?.posting
    ? open.posting === 'pi' && !!openPerson && openPerson.from !== null
    : !!open && !!openPerson && postingSheetFor(openPerson, open.date) === 'pi'   // D320: by stint
  /* "Place leave or OIL here instead" (owner, 20 Sep 26 — "we should also allow
     putting inputs when we click on days that were posted out"). An admin's tap
     on a day outside someone's time in the squadron opens the POSTING sheet,
     which is right for the common case but left him no way to file the clearing
     leave that made him open the day. Everyone else could already: the man
     himself taps his own day and gets the bid sheet, and the Inputs page takes
     any date. This remembers the ONE cell he asked to place on, so the posting
     sheet stands aside for the bid sheet — for that cell only, until it closes.
     Keyed by CELL rather than a boolean, so opening a different day never
     arrives already switched. */
  const [placeAt, setPlaceAt] = useState<string | null>(null)
  const openKey = open ? `${open.id}|${open.date}` : ''
  const placing = !!open && placeAt === openKey
  // ONE selected figure, shared by every row, tracked by its stable ID so a
  // reorder keeps the SAME figure on screen rather than whatever now sits in
  // its old slot. Giving each row its own would let them desync — row 1
  // showing +LVE while row 2 shows −MED TOT — worse than no column at all.
  // `visibleFigures()` (the admin's order, minus anything hidden, 6 Sep 26) —
  // not `orderedFigures(figureOrder)` — so a hidden figure drops out of the
  // cycle, the picker and the dots at once, everywhere this column shows.
  // Memoised on the store's own version so the list is the SAME array between
  // store changes: the drawer's rows are memoised against it (FiguresDrawer),
  // and a fresh array every render would defeat them.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const figures = useMemo(() => visibleFigures(), [version])
  const [shownId, setShownId] = useState(DEFAULT_FIGURE_ID)
  const [picking, setPicking] = useState(false)
  // The figures DRAWER (owner, 6 Sep 26): every figure at once, popped out
  // beside the names over the days. Open on a desktop, closed on a phone — a
  // view preference, session-only, either role. Decided once at mount from the
  // same width query the phone flag uses; jsdom (no matchMedia) opens closed so
  // the unit suite sees the grid it always saw.
  const [figuresOpen, setFiguresOpen] = useState(() =>
    typeof window.matchMedia === 'function' && !window.matchMedia('(max-width: 700px)').matches)
  // Where the drawer sits and how wide it came out: the real header row's top
  // inside `.mx-outer`, the names column's right edge, the header row's height
  // and the drawer's own measured widths (its right edge and its columns feed
  // the stuck header's frozen copy). All MEASURED — never guessed — like
  // `bandTop`; null while closed or before the first layout (jsdom).
  const [drawerAt, setDrawerAt] = useState<{ top: number; left: number; headH: number; width: number; cols: number[] } | null>(null)
  const drawerRef = useRef<HTMLDivElement>(null)
  // Stable, for the same reason `figures` is: it is a memoised row's prop.
  const onDrawerBox = useCallback((person: string, figureId: string) => setBalOpen({ person, figureId }), [])
  // Whose counter was tapped, and WHICH figure to break down (owner, 17 Aug
  // 26). A counter-cell tap opens the column's shown figure; a row tapped
  // inside the person-figures sheet names its own.
  const [balOpen, setBalOpen] = useState<{ person: string; figureId: string } | null>(null)
  // Whose CALLSIGN was tapped — the all-figures sheet, for every role
  // (owner, same day: "everyone should be able to click on that person's
  // name and see these logics").
  const [whoOpen, setWhoOpen] = useState<string | null>(null)
  // The QUALIFICATIONS popover (owner, 3 Sep 26 — "hover the mouse over the
  // person to see the qualifications they hold"). A person wears only their CAT
  // chip; every other qualification (SC DAY, TF, NVG…) lives here, shown on a
  // desktop hover or a phone tap of the chip. Positioned in screen coordinates
  // so the frozen callsign column's overflow can never clip it. null = hidden.
  const [qualPop, setQualPop] = useState<{ id: string; x: number; y: number } | null>(null)
  // The OIL TRACKER (owner, 2 Sep 26): open on everyone (the toolbar button)
  // or on one person, scrolled to their row (the Cinch sheet's OIL BAL row).
  // null = closed. It carried a `focus` day as well until 6 Sep 26, for a grid
  // write to light the credit it had just made; the write-opens-the-tracker
  // route was reversed the same day, so both the field and the prop are gone.
  const [oilTracker, setOilTracker] = useState<{ person: string | null } | null>(null)
  // Which event cell the admin has tapped to edit, or null. Keyed by line +
  // day; the Event sheet reads the current text or band off the store.
  // `to` is set only when a DRAG selected a span (owner, 27 Aug 26) — the sheet
  // then opens pre-set to that range; a single click leaves it undefined.
  const [eventEdit, setEventEdit] = useState<{ line: number; date: string; to?: string } | null>(null)
  // Which manning count row's explainer is open (owner, 19 Aug 26 — a tap on
  // the row's name says what it counts and where its colours turn on).
  const [manningInfo, setManningInfo] = useState<string | null>(null)
  // The counter form (owner, 19 Aug 26): `false` closed, `null` building a
  // NEW counter, an id editing that one. Reached from + Counter in the
  // Rearrange tools and from the explainer sheet's Edit counter… button.
  const [counterEdit, setCounterEdit] = useState<string | null | false>(false)
  // The ⚙ SETTINGS sheet (owner, 3 Sep 26) — all admin config (counters, event
  // rows, Show SANS, the roster groups), opened from the top-row ⚙.
  const [settings, setSettings] = useState(false)
  // Edit-mode roster rearranging (owner, 18 Aug 26). Admin-only view state: it
  // turns the drag handles on, so an admin reading the grid does not nudge a
  // row by accident. Started from the ⠿ in the grid corner (owner, 3 Sep 26).
  const [arranging, setArranging] = useState(false)
  // "Reset counters" arms rather than firing (it discards custom counters);
  // disarmed whenever the Settings sheet closes so it never sits armed unseen.
  const [armCounterReset, setArmCounterReset] = useState(false)
  useEffect(() => { if (!settings) setArmCounterReset(false) }, [settings])
  // Pointer-based drag (owner, 18 Aug 26 — the roster rearranges on a phone
  // too, where HTML5 drag-and-drop does nothing). `dragId`/`dragOverRef` are
  // refs because they change many times a second during a drag and must not
  // repaint the grid; the two bits of STATE mirror them only for the row
  // highlight. One window pointermove/pointerup pair is attached for the life
  // of a drag and torn down on release.
  const dragId = useRef<string | null>(null)
  /* `after` says which HALF of the hovered row the pointer is in (review fix,
     19 Aug 26). Insert-before-only had two dead spots: dropping a row on the
     row directly beneath it re-inserted it exactly where it was (a silent
     no-op), and the last position of the roster was unreachable — the store's
     move-to-end path (beforeId null) had no gesture that produced it. The
     lower half of a row now means "after this row", so both work. */
  /* `el` is the hovered row's own element, so the drop can read the ordered
     list from ITS container (bug hunt, 4 Sep 26): the ⚙ groups list and the
     grid's category headings share one `data-grow` vocabulary, so a
     document-wide query while both were on screen (settings open in rearrange
     mode) mixed the two lists and could land a "drop after the last group"
     before the first. */
  const dragOverRef = useRef<{ id: string, after: boolean, el: Element } | null>(null)
  // The teardown for a drag in flight, so an unmount (role change, war switch)
  // can end it — otherwise its window listeners leak and the row stays stuck
  // in the .dragging highlight.
  const dragCleanup = useRef<(() => void) | null>(null)
  /* ONE LIFT, EVERY DRAG (owner, 6 Sep 26): the grid's overlay frame (rendered
     last in .mx-outer with a constant className, so React never writes to it
     again — this ref is its only writer) and the landing to play once the
     store's move has re-rendered the rows. Refs, not state: the frame must cost
     nothing per frame and nothing per render. */
  const liftRef = useRef<HTMLDivElement | null>(null)
  const landRef = useRef<{ sel: string; surface: 'grid' | 'list' } | null>(null)
  const [draggingId, setDraggingId] = useState<string | null>(null)
  const [dragOver, setDragOver] = useState<string | null>(null)
  const [dragAfter, setDragAfter] = useState(false)

  /* ONE drag machine, two kinds of row (owner, 28 Aug 26 — "the drag and drop
     rows function is already designed on other areas of the app"). The roster
     rows and the manning count rows now reorder by the SAME pointer drag; a
     `cfg` says which DOM rows to hit-test, how to read a row's id, and which
     store move to commit. Manning rows are hit-tested by `data-mrow` rather
     than a `data-testid` prefix, because their day CELLS are `count-<id>-<date>`
     and a `[data-testid^="count-"]` closest() would catch a cell, not the row. */
  function startRowDrag(e: React.PointerEvent, id: string, cfg: RowDragCfg) {
    if (e.button != null && e.button !== 0) return // primary pointer only
    e.preventDefault()
    dragId.current = id
    setDraggingId(id)
    /* the frame goes up in the same tick as the grip's pointerdown — one
       measurement, then nothing until the drop. A GRID row (person, heading,
       manning) is composite, so it gets the frame; a Settings LIST row is one
       element and already wears the recipe through its prop-driven `dragging`
       class (matrix.css), so it needs nothing here. */
    const grip = e.currentTarget as Element
    const surface: 'grid' | 'list' = grip.closest('.mx-wrap') ? 'grid' : 'list'
    const rowEl = grip.closest(cfg.sel) as HTMLElement | null
    const outer = mxOuterRef.current, wrap = wrapRef.current
    if (surface === 'grid' && rowEl && outer && wrap) frameLift(liftRef.current, boxOf(outer, rowEl, wrap))
    const move = (ev: PointerEvent) => {
      const el = document.elementFromPoint(ev.clientX, ev.clientY)
      const row = el && (el as Element).closest ? (el as Element).closest(cfg.sel) : null
      const overId = row ? cfg.idOf(row) : null
      /* which half decides before/after; a zero-height rect (jsdom) reads as
         "before", keeping the old semantics where layout cannot answer */
      let after = false
      if (row) {
        const r = (row as HTMLElement).getBoundingClientRect()
        after = r.height > 0 && ev.clientY > r.top + r.height / 2
      }
      const cur = dragOverRef.current
      if (overId !== (cur?.id ?? null) || after !== (cur?.after ?? false)) {
        dragOverRef.current = overId && row ? { id: overId, after, el: row } : null
        setDragOver(overId); setDragAfter(after)
      }
    }
    // `commit` is false for a cancel (a system gesture, multi-touch, or the
    // grid unmounting mid-drag): tear down without moving anything. Without a
    // pointercancel path the pointerup never comes and the listeners — and the
    // stuck highlight — leak, most likely on the phone drag this was built for.
    const end = (commit: boolean) => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', cancel)
      dragCleanup.current = null
      const from = dragId.current
      const over = dragOverRef.current
      dragId.current = null
      dragOverRef.current = null
      setDraggingId(null)
      setDragOver(null)
      setDragAfter(false)
      // The lift is over either way — a commit re-places the frame at the
      // landing below, a cancel simply leaves it hidden.
      frameLift(liftRef.current, null)
      if (commit && from && over) {
        if (over.id !== from) {
          /* "after row X" resolves to "before the row that follows X" in the
             RENDERED order — the DOM is what the user is looking at, and the
             hit-test above already trusts it. No follower means the true end
             of the roster, the store's beforeId:null path (unreachable from
             this gesture before the rework). Resolving to `from` itself means
             the drop lands exactly where the row already is — skip, or the
             store's before-itself guard would have to save us. */
          let beforeId: string | null = over.id
          if (over.after) {
            /* The follower comes from the hovered row's OWN list (its parent), not
               the whole document — see dragOverRef. */
            const scope: ParentNode = over.el.parentElement ?? document
            const rows = [...scope.querySelectorAll(cfg.sel)]
              .map(el => cfg.idOf(el)).filter((x): x is string => x != null)
            const ix = rows.indexOf(over.id)
            beforeId = ix >= 0 ? (rows[ix + 1] ?? null) : over.id
          }
          if (beforeId !== from) {
            cfg.move(from, beforeId)
            /* A manning reorder shuffles the rows of the frozen LEFT column, whose
               grip/eye tools live in a `position: sticky` cell. iOS Safari does not
               reliably repaint a sticky column after that DOM churn, so the just
               -moved rows can sit drawn WITHOUT their tools until something forces a
               redraw (owner, 30 Aug 26 — "sometimes I see these showing, sometimes I
               do not … after I tried to drag and drop multiple times"). A one-frame
               self-assignment of the scroller's own scrollLeft re-solves every sticky
               offset in the scrollport and repaints them; it moves nothing, and —
               unlike a transform on the sticky cell itself — cannot break the
               stickiness. Manning kind only; the roster/group drags don't touch this
               column. */
            if (cfg === MANNING_DRAG) {
              const w = wrapRef.current
              if (w) requestAnimationFrame(() => { w.scrollLeft = w.scrollLeft })
            }
          }
        }
        /* EVERY committed drop flashes, including one that moved nothing — a row
           released on itself, or "after the row above it", which resolves to
           where it already is. The owner's ask is "once I drop the item, it
           should flash to show where the new item ended up", and in place IS
           where it ended up; the alternative is a drop that answers with
           nothing at all (review, 6 Sep 26). A CANCEL still shows nothing:
           pointercancel, an unmount, or a release over no row never reaches
           here (`over` is null).
             It is measured AFTER React commits: this listener is a native
           window handler, so the store's notify and the state clears above are
           batched into one commit that has not happened yet, and the layout
           effect below reads this ref there.
             AND IT IS SET AFTER cfg.move(), where every other surface marks
           BEFORE its write (rowdrag.ts, InputsCal.tsx, drag.ts) — safe here, and
           only here, for that same batching reason: those three hand their mark
           to a DOM that an innerHTML rebuild replaces during the very call that
           follows, so the mark has to exist first. This one is read by a layout
           effect of the commit that `cfg.move`'s notify schedules, and React
           batches a native listener's updates to the end of this handler, so
           nothing has re-rendered by the time this line runs. The order that
           matters is ref-before-RETURN, not ref-before-move; writing it here
           keeps it beside the `beforeId !== from` decision it depends on. */
        landRef.current = { sel: cfg.landSel(from), surface }
      }
    }
    const up = () => end(true)
    const cancel = () => end(false)
    dragCleanup.current = () => end(false)
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', cancel)
  }

  // A drag in flight must not outlive the grid, and rearrange mode is the
  // admin's alone: end any drag and drop out of arrange mode the moment the
  // component unmounts or the role stops being admin (a logout mid-arrange).
  useEffect(() => () => { dragCleanup.current?.() }, [])
  useEffect(() => { if (role !== 'admin' && arranging) setArranging(false) }, [role, arranging])
  /* the admin's editors close when the role in force stops being admin — the admin's switch to the member view (D292;
     Astra's code read 5, 27 Sep 26: Edit aircrew — gone since D461 — and the counter form stayed open with live controls), so switching back
     never reopens a stale draft either */
  useEffect(() => { if (role !== 'admin') setCounterEdit(false) }, [role])
  // Falls back to the first visible figure when `shownId` names one an admin
  // has since hidden (or a stale saved id) — `shownIx` is then DERIVED from
  // `shown`, not the other way round, so the dots and the cycle never point
  // past the figure actually on screen.
  const shown = figures.find(f => f.id === shownId) ?? figures[0]!
  const shownIx = figures.indexOf(shown)
  /** Put a figure in the column — the ONE gated way in (6 Sep 26 review).
   *
   *  A hidden figure never becomes the column's: an admin who hid it should not
   *  have the column jump to something the picker, the drawer and the cycle no
   *  longer offer. That rule was written on the leave-just-entered snap and
   *  nowhere else, so the two OIL paths (a tracker grant, an admin's hand-typed
   *  OIL day) walked straight past it and could park the column on a figure the
   *  dots did not contain. One body now, so a fourth caller cannot miss it. */
  const showFigure = (id: string) => { if (figures.some(f => f.id === id)) setShownId(id) }
  // Everything a figure needs to read a person's number — the store's one
  // builder, so this column, the sheets and the tracker read the same OIL
  // policy and the same "today" (a hand-built literal here used to drift).
  // Once per store change, not per render — a row prop (see PersonRow).
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const figureCtx = useMemo(() => figureCtxOf(), [version])
  /* WHAT A BALANCE WOULD READ AFTER A LEAVE FILL — one question for the two sheets that fill leave, so both ask the
     same thing with the same number before taking someone below zero: the one-day sheet (a day or a picked range) and
     the drag-selection sheet, which asks too since his ruling D418 (29 Sep 26 — "Drag asks too"). The store answers it
     (`balanceAfterFill`) from the balance column's own figure, read of the wars as the fill would leave them. */
  const balanceAfter = (personId: string, dates: readonly string[], code: string) => balanceAfterFill(personId, dates, code)
  const cycle = (by: number) => setShownId(figures[(shownIx + by + figures.length) % figures.length].id)

  // Swipe across the counter column to cycle it — the fast path, beside the
  // sheet's guaranteed one. Bound on the wrapper rather than on each cell so
  // one pair of listeners covers a column of twenty-odd, and filtered to
  // touches that START on a `.bal` cell so a swipe anywhere else still
  // scrolls the grid, which is what a horizontal drag must go on doing.
  const swipe = useRef<{ x: number; y: number } | null>(null)
  // `figArmed` is the figure select's own flag, declared with that gesture's
  // block further down (search FIGURE SELECT): it says a hold-and-drag took
  // this touch, and these two handlers are the only readers.
  const onTouchStart = (e: TouchEvent) => {
    figArmed.current = false
    const on = (e.target as HTMLElement).closest?.('.bal')
    swipe.current = on ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : null
  }
  const onTouchEnd = (e: TouchEvent) => {
    const from = swipe.current
    swipe.current = null
    // A hold-and-drag that ARMED a figure selection during this touch is not a
    // swipe, however far the finger travelled: the select owns it (6 Sep 26).
    if (figArmed.current) { figArmed.current = false; return }
    if (!from) return
    const dx = e.changedTouches[0].clientX - from.x
    const dy = e.changedTouches[0].clientY - from.y
    // Horizontal, and decisively so: 40px across and more sideways than up,
    // or every scroll of the rows would flip the counter under the thumb.
    if (Math.abs(dx) < 40 || Math.abs(dx) < Math.abs(dy)) return
    cycle(dx < 0 ? 1 : -1)
  }

  // Jumping to a month is how a year-long war is navigable at all: 365
  // columns is roughly 13,600px, and nobody finds September by dragging.
  const wrapRef = useRef<HTMLDivElement>(null)
  // Drag-select wiring: ONE delegated pointer listener on `.mx-wrap` (never
  // per-cell — the grid is ~28k nodes), reading live state through a ref so
  // the gesture always sees the current roster/dates/mode without re-binding.
  // Assigned just before the return, where rosterSequence and the mode flags
  // are in scope.
  const selCtxRef = useRef<SelectCtx | null>(null)
  useEffect(() => {
    const w = wrapRef.current
    if (!w) return
    return wireSelect(w, {
      order: () => selCtxRef.current?.order() ?? [],
      dates: () => selCtxRef.current?.dates() ?? [],
      enabled: () => selCtxRef.current?.enabled() ?? false,
      onSelect: s => selCtxRef.current?.onSelect(s),
      eventsEnabled: () => selCtxRef.current?.eventsEnabled?.() ?? false,
      onEventSelect: s => selCtxRef.current?.onEventSelect?.(s),
      leftEdge: () => selCtxRef.current?.leftEdge?.() ?? w.getBoundingClientRect().left,
    })
  }, [])
  // A stage or war change drops any open selection or in-flight move, so a
  // block picked on one screen can never act on another. An UNDO/REDO does the
  // same (lwHistEpoch, bumped on every restore): a restore can clear the very
  // cells a move or an open sheet was acting on, and leaving that gesture live
  // stranded the grid in move mode — the next drag read as a landing and no
  // sheet opened (bug test, 30 Aug 26). moveErr goes too, so no stale banner
  // message lingers.
  const histEpoch = lwHistEpoch()
  useEffect(() => { setSel(null); setMoveSel(null); setMovePreview(null); setMoveErr(''); setEventMoveSel(null); setEventMovePreview(null); setEventMoveErr('') }, [period.stage, period.id, histEpoch])
  /* ...and a WAR change closes the sheet open on the old war (the absence-record re-test, W5-F3, 26 Sep 26): left open,
     its controls still wrote to the day it was opened on — in the war no longer on screen. The Sheet now holds the
     keyboard too, so the switch cannot be reached from inside one; this is the second guard, for any other road to a
     switch (an undo that snaps the war, a reload of the picker). */
  useEffect(() => { setOpen(null); setPlaceAt(null); setEventEdit(null) }, [period.id])   // the event sheet too (Fable F4)
  // MOVE MODE is wired further down, after the `phone` breakpoint state it
  // reads to choose commit-on-click (desktop) vs preview-then-Confirm (phone).
  // The frozen-column overlay's own anchors (see the .mxband block below and
  // in matrix.css). `mxOuterRef` is the page-flow box the overlay is absolutely
  // placed inside; `rosterBodyRef` is the one row group it must line up with.
  const mxOuterRef = useRef<HTMLDivElement>(null)
  const bandRef = useRef<HTMLDivElement>(null)
  const rosterBodyRef = useRef<HTMLTableSectionElement>(null)
  const [phone, setPhone] = useState(false)
  /* THE PHONE'S TWO-STEP FOLLOWS THE SCREEN AS IT IS NOW (Astra's final read, 4, 27 Sep 26): the move's tap handler is
     wired once, when the move begins, and read `phone` as it was then — a move begun at desktop width and carried on
     after the window narrowed landed at once, with no Confirm. It reads this ref at the tap instead; a change of width
     takes down a staged landing (the effect below). */
  const phoneRef = useRef(false)
  phoneRef.current = phone
  useEffect(() => {
    setMovePreview(null); setEventMovePreview(null)
    const w = wrapRef.current
    if (w) clearLanding(w)
  }, [phone])
  const [bandTop, setBandTop] = useState<number | null>(null)

  // FIGURE SELECT (owner, 6 Sep 26): a run of people down one figure column,
  // for the docked balance bar (BalanceBar). Bound on `.mx-outer` — the one
  // ancestor of the real column, the band's copy and the drawer — so a drag
  // works on whichever copy of a box the finger is on. Live state through a
  // ref, like the day grid's; the committed selection is React state so the
  // highlight survives the re-render Save causes. The bind sits here rather
  // than beside the day grid's because it needs `mxOuterRef` in scope; the
  // effect runs after mount either way.
  const [figSel, setFigSel] = useState<FigureSelection | null>(null)
  const figSelCtxRef = useRef<FigureSelectCtx | null>(null)
  // Set the instant a figure drag ARMS during a touch: the counter column's
  // swipe-to-cycle (onTouchEnd) must stand down for that touch, or a slow
  // hold-and-drag that travelled 40px sideways would flip the column under
  // the selection it just made.
  const figArmed = useRef(false)
  useEffect(() => {
    const o = mxOuterRef.current
    if (!o) return
    return wireFigureSelect(o, {
      order: () => figSelCtxRef.current?.order() ?? [],
      selectable: id => figSelCtxRef.current?.selectable(id) ?? false,
      enabled: () => figSelCtxRef.current?.enabled() ?? false,
      onArm: () => { figArmed.current = true },
      onSelect: s => figSelCtxRef.current?.onSelect(s),
    })
  }, [])
  // A drawer toggle drops the selection too, and it needs its OWN effect: the
  // clear above must keep its own dependency list, or opening the figures
  // would also throw away a day-grid selection that has nothing to do with it.
  //   `role` is in here for the same reason (review, 6 Sep 26): the balance bar
  // is mounted only for an admin, so a "view as member" flip mid-selection took
  // the bar off the screen and left the run lit with nothing to act on it —
  // a highlight the reader could not clear or use.
  //   The VISIBLE FIGURES are in here too (review, 6 Sep 26). `toggleFigure`
  // bumps none of the others, so hiding the very figure a run was selected on
  // left the selection alive and unreachable — nothing on screen, and showing
  // the figure again brought the run back lit, as if it had been waiting. It is
  // the identity of the shown list, not its length: swapping one figure for
  // another is the same change to a live run.
  const figIds = figures.map(f => f.id).join('|')
  useEffect(() => { setFigSel(null) }, [period.stage, period.id, histEpoch, figuresOpen, role, figIds])

  // A press outside the bar and the boxes drops the selection (the tracker's
  // own rule, owner 2 Sep 26 — no Deselect button); a press ON a box is the
  // next drag or a tap for the breakdown, and is left alone. Escape clears it
  // too, unless a sheet is up — the sheet's own Escape goes first.
  useEffect(() => {
    if (!figSel) return
    const onDown = (e: PointerEvent) => {
      const t = e.target as HTMLElement | null
      if (t?.closest('[data-testid="balance-bar"]') || t?.closest('td.figbox[data-fig][data-person]')) return
      // A sheet is up: it owns this press, exactly as Escape below yields to it
      // (review, 6 Sep 26 — the two disagreed, so a tap on a sheet's scrim
      // dropped a run that the same sheet's Escape would have left alone).
      if (document.querySelector('.bidsheet')) return
      setFigSel(null)
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' || document.querySelector('.bidsheet')) return
      e.stopPropagation()
      setFigSel(null)
    }
    document.addEventListener('pointerdown', onDown, true)
    window.addEventListener('keydown', onKey, true)
    return () => { document.removeEventListener('pointerdown', onDown, true); window.removeEventListener('keydown', onKey, true) }
  }, [figSel])

  /* WHAT COUNTS AS THE GRID WHILE A MOVE IS ON (D262): the card — its counts, month buttons, header, the days and the
     figures drawer — plus the parts of it drawn fixed on top of the page (the floating date header, the desktop's
     scrollbar at the foot of the screen). The mouse's edge scroll runs only over it; a click on an empty spot of the
     page AROUND it ends the move. The days' left edge is the drag-select's own (past the frozen columns / drawer). */
  const cardRef = useRef<HTMLDivElement>(null)
  const inGrid = (t: Element): boolean =>
    !!cardRef.current?.contains(t) || !!t.closest('[data-testid="sticky-head"], [data-testid="hscroll"]')
  const moveLeftEdge = (): number => {
    const w = wrapRef.current
    return selCtxRef.current?.leftEdge?.() ?? (w ? w.getBoundingClientRect().left : -Infinity)
  }
  /* …and LEAVING THE LEAVE WAR ENDS IT (D262 — Fable's S9): the page is kept alive off screen, and a move left on
     carried its ghost onto the next page and kept its listeners on every click there. Leaving is the plainest
     "somewhere outside the grid". */
  useEffect(() => subLwScreen(() => {
    if (isLwOnScreen()) return
    setMoveSel(null); setMovePreview(null); setMoveErr('')
    setEventMoveSel(null); setEventMovePreview(null); setEventMoveErr('')
  }), [])

  // MOVE MODE (owner, 27 Aug 26). The picked block is dropped onto a new day.
  // `movers` are the inputs PRESENT in the selection — the empty cells the user
  // swept up are dropped, so a loose box no longer refuses as "nothing"; the
  // earliest of them (`moveAnchor`) is the block's first input, and it lands on
  // the day tapped, the rest shifting with it (gaps between inputs kept). The
  // landing is previewed live on desktop (hover) and staged before a Confirm on
  // phone (no undo). `daysBetween(moveAnchor, target)` is the shared delta.
  /* THE RECORDS, NOT THE DAYS (owner, D265 / D266, 27 Sep 26 — [LW-MOVE-STANDARD]): `movers` are the RECORDS the move
     carries — every record on the picked days this role may move (a block, the one-day sheet, a picked range), or the
     one the day's list picked by its id (`moveSel.only`). A bid beside an OIL award moves alone; the award stays, and
     `moveStays` names what stays for the banner. The count on the banner and the ghost is records ("2 entries" for a
     morning and an afternoon bid on one day). */
  const movers = useMemo<MoveRec[]>(() => (moveSel ? movableRecords(moveSel.cells, moveSel.only) : []), [moveSel, version])
  const moveStays = useMemo(() => (moveSel ? stayingIn(moveSel.cells, movers) : []), [moveSel, movers, version])
  const moveAnchor = useMemo(() => earliestDate(movers), [movers])
  /* THE LIVE RECORDS, NOT THE ONES OF THE MOMENT THE MOVE BEGAN (Astra's final read, 4; Fable's note, 27 Sep 26): the move
     machine (`wireMove`, wired once per `moveSel`) keeps its callbacks for the whole move, and they used to hold the
     records of the render that wired them — a record changed or gone under a move was still judged as it was. They
     read the records through this ref, which every render keeps current. */
  const moveLive = useRef({ movers, moveAnchor })
  moveLive.current = { movers, moveAnchor }
  const landingFor = (targetDate: string): Cell[] => {
    const { movers, moveAnchor } = moveLive.current
    if (moveAnchor === null) return []
    const seen = new Set<string>()
    const out: Cell[] = []
    for (const c of movers) {
      const cell = { personId: c.personId, date: addDays(c.date, daysBetween(moveAnchor, targetDate)) }
      const k = `${cell.personId}|${cell.date}`
      if (!seen.has(k)) { seen.add(k); out.push(cell) }
    }
    return out
  }
  /* Paint the landing ONLY when the atomic commit would accept it —
     `moveRecordsProblem` is the validation half of `moveRecords` itself, so the
     preview cannot show half a landing (the off-grid cells simply not
     painting) that the commit then wholly refuses. A refused hover/stage
     clears the paint and says why in the banner instead. */
  const previewAt = (targetDate: string): boolean => {
    const { movers, moveAnchor } = moveLive.current
    const w = wrapRef.current
    if (!w || moveAnchor === null) return false
    const delta = daysBetween(moveAnchor, targetDate)
    if (delta === 0) { setMoveErr(''); paintLanding(w, landingFor(targetDate)); return true }
    const problem = moveRecordsProblem(movers, delta)
    if (problem) { clearLanding(w); setMoveErr(moveReason(problem)); return false }
    setMoveErr('')
    paintLanding(w, landingFor(targetDate))
    return true
  }
  /* A DAY IT IS ALREADY ON (D262 — Fable's S6): the move machine's delta 0 read "Nothing to move." as if the chip had
     gone, and a phone staged a Confirm that then failed. It says where it is, and the move stays on. */
  const onItsOwnDay = (targetDate: string): boolean => { const { moveAnchor } = moveLive.current; return moveAnchor !== null && daysBetween(moveAnchor, targetDate) === 0 }
  const ownDayWords = () => `${moveLive.current.movers.length === 1 ? 'It is' : 'They are'} already on that day — pick another day.`
  const commitMove = (targetDate: string) => {
    const { movers, moveAnchor } = moveLive.current
    const w = wrapRef.current
    if (moveAnchor === null) { setMoveSel(null); setMovePreview(null); return }
    if (onItsOwnDay(targetDate)) { if (w) clearLanding(w); setMovePreview(null); setMoveErr(ownDayWords()); return }
    const r = moveRecords(movers, daysBetween(moveAnchor, targetDate))
    if (w) clearLanding(w)
    if (r === 'moved') { setMoveSel(null); setMovePreview(null); setMoveErr('') }
    else { setMoveErr(moveReason(r)); setMovePreview(null) }   // keep the mode, say why
  }
  useEffect(() => {
    const w = wrapRef.current
    if (!moveSel || !w) return
    setMoveErr(''); setMovePreview(null)
    const cleanup = wireMove(w, {
      count: movers.length,
      onHover: date => previewAt(date),                     // desktop live preview
      onPick: date => {
        // Desktop lands on the click (the hover WAS the preview); a phone has no
        // hover, so a tap stages the landing and waits for Confirm — but only a
        // landing the store would accept stages (a refused one shows its reason
        // where the Confirm button would be, never a Confirm under an error).
        if (phoneRef.current && onItsOwnDay(date)) { clearLanding(w); setMovePreview(null); setMoveErr(ownDayWords()); return }
        if (phoneRef.current) setMovePreview(previewAt(date) ? date : null)
        else commitMove(date)
      },
      onCancel: () => { clearLanding(w); setMoveSel(null); setMovePreview(null); setMoveErr('') },
      onOff: () => { clearLanding(w); setMoveErr('') },
      leftEdge: moveLeftEdge,
      isGrid: inGrid,
    })
    return () => { clearLanding(w); cleanup() }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moveSel])
  /* WHAT WAS PICKED UP IS GONE (Astra's final read, 4): a record changed or removed under a move (a sync pass — Undo, a
     stage or war change and leaving the tab already end the move) left the banner reading "0 entries" and a tap ending
     the move with no word. It says so; the next tap (or Cancel) ends the move, landing nothing. */
  useEffect(() => {
    if (!moveSel || movers.length > 0) return
    const w = wrapRef.current
    if (w) clearLanding(w)
    setMovePreview(null)
    setMoveErr('That record changed or is no longer there — nothing to move.')
  }, [moveSel, movers.length])

  // ---- EVENT move mode (owner, 31 Aug 26 — "drag an existing event to move it,
  // like LL") — the event-line twin of the roster move above. `wireMove` is
  // shared; only the target-date resolver (`eventMoveDateAt`, which reads the
  // event line's own cells) and the landing painter (`paintEventLanding`)
  // differ. The event's own start (`from`) is the anchor, so the day tapped
  // becomes the new start and the whole band/day slides with it. Previewed live
  // on desktop, staged before a Confirm on a phone — exactly like the roster.
  const eventMoveReason = (r: Exclude<EventMoveResult, 'moved'>): string =>
    r.reason === 'outside' ? 'That would run off this leave war.'
      : r.reason === 'overlap' ? 'Those days already carry an event on this line.'
        : 'Nothing to move.'
  const eventSpanDates = (from: string, to: string): string[] => {
    const out: string[] = []
    for (let d = from; d <= to; d = addDays(d, 1)) out.push(d)
    return out
  }
  const previewEventAt = (targetDate: string): boolean => {
    const w = wrapRef.current
    if (!w || !eventMoveSel) return false
    const { line, from, to } = eventMoveSel
    const delta = daysBetween(from, targetDate)
    if (delta === 0) { setEventMoveErr(''); paintEventLanding(w, line, eventSpanDates(from, to)); return true }
    const problem = moveEventProblem(line, from, to, delta)
    if (problem) { clearLanding(w); setEventMoveErr(eventMoveReason(problem)); return false }
    setEventMoveErr('')
    paintEventLanding(w, line, eventSpanDates(from, to).map(d => addDays(d, delta)))
    return true
  }
  const commitEventMove = (targetDate: string) => {
    const w = wrapRef.current
    if (!eventMoveSel) return
    const { line, from, to } = eventMoveSel
    const r = moveEvent(line, from, to, daysBetween(from, targetDate))
    if (w) clearLanding(w)
    if (r === 'moved') { setEventMoveSel(null); setEventMovePreview(null); setEventMoveErr('') }
    else { setEventMoveErr(eventMoveReason(r)); setEventMovePreview(null) }   // keep the mode, say why
  }
  useEffect(() => {
    const w = wrapRef.current
    if (!eventMoveSel || !w) return
    setEventMoveErr(''); setEventMovePreview(null)
    const cleanup = wireMove(w, {
      count: 1,
      dateAt: eventMoveDateAt,
      onHover: date => previewEventAt(date),
      onPick: date => { if (phoneRef.current) setEventMovePreview(previewEventAt(date) ? date : null); else commitEventMove(date) },
      onCancel: () => { clearLanding(w); setEventMoveSel(null); setEventMovePreview(null); setEventMoveErr('') },
      onOff: () => { clearLanding(w); setEventMoveErr('') },
      leftEdge: moveLeftEdge,
      isGrid: inGrid,
    })
    return () => { clearLanding(w); cleanup() }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventMoveSel])

  const months = monthsIn(period.start, period.end)

  // The month the grid should OPEN on — the start of this war's bidding window
  // (owner, 7 Sep 26). The column window below is built AROUND it, not around
  // January, so the months the reader is about to see are the ones drawn first
  // (the preload), and — on the desktop, where the fill then rebuilds the whole
  // year outward from here — the landing does not drift back to January as the
  // left months fill in (which it did when the window reset to month 0 and the
  // jump raced the fill). `LeaveWarPage`/`selectWar` do the actual scroll via
  // `focusDate`; this only decides which columns exist when they land.
  const defaultMonth = (() => {
    const k = defaultFocusDate(period).slice(0, 7)
    const i = months.findIndex(m => m.first.slice(0, 7) === k)
    return i < 0 ? 0 : i
  })()

  // ---- THE COLUMN WINDOW (Phase 2 of the speed work, 3 Sep 26) -------------
  // Which months are DRAWN. Arithmetic and the why in colwindow.ts; here is the
  // measuring and the scrolling. `null` = the whole war: a short war, or no
  // layout at all — jsdom reports every rect 0×0, so the lazy initialiser sees
  // no width and the unit suites keep seeing the full year exactly as before;
  // the browser gate is what proves the window. Everything that reads "the
  // columns" below reads `drawnDays` / `drawnDates` / `drawnMonths`; the full
  // `dates` stays for what is about the WAR, not the screen — the manning
  // verdicts, the lock set, the sheets' date spans, the "365 days" caption.
  const hasLayout = () => typeof document !== 'undefined' && document.documentElement.getBoundingClientRect().width > 0
  const [colWinRaw, setColWin] = useState<ColWin | null>(() => (hasLayout() ? windowAround(months.length, defaultMonth) : null))
  // The stored window is only ever read CLAMPED to the current war's months:
  // a war switch renders once with the old window against the new months
  // before the reset effect below lands, and a one-month war under a stale
  // {0,3} must draw whole, not index past its months (a real crash found by
  // the "creates a leave war" browser test — the grid vanished behind an
  // error, and the picker with it).
  const colWin = colWinRaw && months.length >= WINDOW_FROM_MONTHS ? clampWin(colWinRaw, months.length) : null
  const colWinRef = useRef(colWin)
  colWinRef.current = colWin
  // THE PLACEHOLDERS (owner, 5 Sep 26 — "do the placeholders + moving", picked
  // off a mockup of four scrolling styles). One empty cell before the first
  // drawn day and one after the last, in EVERY row, standing in for the undrawn
  // months at their widths — so the scroller spans the whole year from the
  // first paint, a flick never runs into a drawn edge, and months are drawn IN
  // PLACE while the scroll is still moving (the fill engine below). Which sides
  // exist is render knowledge (the window's edges); how WIDE they are is
  // written imperatively as two CSS variables (`applyPlaceholders`), because
  // those widths come from measurement and change as months draw, and a state
  // write would re-render the ~25k-node grid for a number two cells read.
  // Every row carries the same cells (header included) — the 20 Aug 26
  // column-virtualisation that misaligned on iOS gave SOME rows colSpan spacers
  // over the header's still-full columns, and WebKit reconciles rows of
  // differing cell counts differently from Blink; here no row differs.
  const padL = !!colWin && colWin.lo > 0
  const padR = !!colWin && colWin.hi < months.length - 1
  // The placeholder widths are written STRAIGHT ONTO THE CELLS as inline
  // styles, not as a CSS variable on an ancestor (traced 6 Sep 26): a custom
  // property changing on `.mx-outer` — any property, even an unused one —
  // makes Chrome re-style every element under it, ~7,000 on the full year,
  // ~0.4–0.8s on the slow laptop, and it was written on EVERY month draw. An
  // inline width on the ~130 placeholder cells costs ~5ms and re-styles nothing
  // else. Cells mount and unmount with the rows (row window, folds, the mirror
  // header), so each registers itself through these stable ref hooks, takes the
  // current width the moment it mounts, and `applyPlaceholders` rewrites the
  // registered set when a width changes.
  const phWRef = useRef<{ l: string; r: string }>({ l: '0px', r: '0px' })
  const phCellsRef = useRef<{ l: Set<HTMLElement>; r: Set<HTMLElement> }>({ l: new Set(), r: new Set() })
  const phHook = (side: 'l' | 'r'): RefCallback<HTMLTableCellElement> => el => {
    if (!el) return
    const set = phCellsRef.current[side]
    set.add(el)
    setPhWidth(el, phWRef.current[side])
    return () => { set.delete(el) }
  }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const phL = useCallback(phHook('l'), [])
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const phR = useCallback(phHook('r'), [])
  // Each month's MEASURED width (layout px, zoom divided out) once it has been
  // drawn, by war+zoom: a pruned month's placeholder is then exactly as wide as
  // the month, so re-drawing it moves nothing — provided the grid's rows are
  // still the ones it was measured with, which is what `gen` records (see
  // `widthGen` below). A month never drawn falls back to an estimate (the
  // average day width × its days) — see colwindow.ts for why that estimate is
  // never swapped for the real month LEFT of the view while the scroll is moving.
  const monthPxRef = useRef<{ key: string; px: (number | null)[]; gen: (object | null)[] }>({ key: '', px: [], gen: [] })
  // Is the Leave War tab on screen right now? A ref, not React state, so the
  // fill loop below can read it every idle beat without a re-render, and
  // flipping it (state/screen.ts) never repaints the ~25k-node grid. Seeded from
  // the live signal so a first mount that is ALREADY the current page (a direct
  // visit) starts on-screen, and a hidden pre-warm mount starts off-screen.
  const onScreenRef = useRef(isLwOnScreen())
  // The first month the viewport currently overlaps (absolute index, drawn or
  // placeholder), tracked on every scroll event (`measureStrip`) — so when the
  // tab is left we can shrink the drawn window to a few months AROUND where the
  // reader was, not blindly.
  const viewMonthRef = useRef(0)
  // The visible months (absolute indices) for the phone's rolling target — the
  // window the prefetch keeps a runway ahead of, updated on every scroll event.
  const liveVisRef = useRef<{ lo: number; hi: number }>({ lo: 0, hi: 1 })
  // Restart the background fill loop after it has parked (the tab was shown, or a
  // scroll moved the phone's rolling target). Set by the fill effect each render.
  const kickFillRef = useRef<() => void>(() => {})
  const monthIndexOf = (date: string): number => {
    const k = date.slice(0, 7)
    const i = months.findIndex(m => m.first.slice(0, 7) === k)
    return i < 0 ? 0 : i
  }
  const drawnMonths = colWin ? months.slice(colWin.lo, colWin.hi + 1) : months
  const drawnDays = useMemo(() => {
    if (!colWin) return period.days
    const from = months[colWin.lo]!.first.slice(0, 7), to = months[colWin.hi]!.first.slice(0, 7)
    return period.days.filter(d => { const k = d.date.slice(0, 7); return k >= from && k <= to })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [colWin?.lo, colWin?.hi, version])
  const drawnDates = useMemo(() => drawnDays.map(d => d.date), [drawnDays])
  // The drawn days SLICED BY MONTH, each slice keeping its identity for as long
  // as the war's days do (the cache lives with `version`, like drawnDays):
  // PersonMonth is memoised on the slice, so a window step re-renders only the
  // month it adds and every other month's cells bail out at the memo.
  const monthDaysCache = useMemo(() => new Map<string, DayInfo[]>(), [version])
  const drawnMonthDays = useMemo(() => {
    const keys: string[] = []
    for (const d of drawnDays) { const k = d.date.slice(0, 7); if (keys[keys.length - 1] !== k) keys.push(k) }
    return keys.map(k => {
      let s = monthDaysCache.get(k)
      if (!s) { s = period.days.filter(d => d.date.slice(0, 7) === k); monthDaysCache.set(k, s) }
      return s
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drawnDays, monthDaysCache])
  // The day-column slots a full-width row spans: the drawn days plus the
  // placeholder cell on each side that exists.
  const dayCols = drawnDates.length + (padL ? 1 : 0) + (padR ? 1 : 0)
  // The LIVE columns for anything that runs off a timer or a listener — the
  // scroll-rest measure, the pre-grow, a resize. Those closures are minted
  // by an earlier render, and the window can change between the event and
  // the callback (the 250 ms pre-grow fires right after the first open; a
  // store change can land mid-scroll): measured against the closure's own,
  // by-then-stale column list, a month that IS drawn reads as absent and
  // the measure silently no-ops. Closed as a hazard while chasing a gate
  // failure that turned out to be the test's own year-wide assumption; kept
  // because the hazard is real. Every measure reads this ref, never its
  // closure.
  const liveRef = useRef({ drawnMonths, drawnDates, people, rowSpans })
  liveRef.current = { drawnMonths, drawnDates, people, rowSpans }
  const coarsePointer = () => typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches
  // The war's month structure for the placeholders' width estimate (see
  // `monthPx`): days per month. Constant for the war and needs no layout, so a
  // memo, not a measurement.
  const yearMonths = useMemo(() => {
    const monthDays = months.map(() => 0)
    const idxOf = new Map(months.map((m, i) => [m.first.slice(0, 7), i]))
    for (const d of period.days) { const i = idxOf.get(d.date.slice(0, 7)); if (i != null) monthDays[i]++ }
    return { monthDays }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period.id])
  // A month-strip jump to an undrawn month: draw around it first, scroll once
  // those columns exist (the anchor layout effect below finishes it).
  const pendingJumpRef = useRef<string | null>(null)
  // A window change that moved columns LEFT of the viewport: the anchor
  // correction must run even on a coarse pointer (the fling is already dead —
  // the window only grows left there once the scroll sits at its bound).
  const colShiftRef = useRef(false)
  // A different war is a different set of months: start its window over.
  const warRef = useRef(period.id)
  useEffect(() => {
    if (warRef.current === period.id) return
    warRef.current = period.id
    const next = hasLayout() ? windowAround(months.length, defaultMonth) : null
    setColWin(prev => (prev && next && prev.lo === next.lo && prev.hi === next.hi ? prev : next))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period.id])

  // The month BRACKET above the dates (owner, 18 Aug 26 — "draw a line at the
  // top of the dates that bracket the month u are looking at"): one spanning
  // cell per month, derived from the loaded days so a partial first or last
  // month brackets exactly the days it actually has on screen.
  const brackets = (() => {
    const out: { key: string; label: string; count: number }[] = []
    for (const d of drawnDates) {
      const key = d.slice(0, 7)
      const last = out[out.length - 1]
      if (last && last.key === key) last.count++
      else out.push({ key, label: MONTHS[Number(d.slice(5, 7)) - 1]!, count: 1 })
    }
    return out
  })()

  // Measured live rather than read off the CSS custom properties: the two
  // frozen columns change width at the phone breakpoint, and a hard-coded
  // offset would be wrong on one of the two devices. Shared by the jump and
  // by the in-view readout, which both need to know where the day columns
  // actually begin.
  // ---- header-cell lookups (3 Sep 26) -------------------------------------
  // Every geometry read below wants "the header cell for date X". Searching
  // for it from the grid WRAPPER walked all ~25,000 nodes per lookup, and the
  // mount sequence (strip geometry, the row window, the bid box, the anchor)
  // does thirty-odd of them — measured as the single largest frame of a 10s
  // first open at 4x. The header is its own tbody of ~370 cells, so the same
  // selector scoped there is a hundredth of the walk. Same nodes, same answer.
  const headRef = useRef<HTMLTableSectionElement>(null)
  const headCell = (date: string | undefined): HTMLElement | null =>
    date === undefined ? null : headRef.current?.querySelector<HTMLElement>(`[data-testid="head-${date}"]`) ?? null

  // Where the visible day strip BEGINS: the width of everything painted OVER
  // the day columns and frozen there. Normally the callsign + counter pair —
  // but while the FIGURES drawer is open (6 Sep 26) the frozen part is the
  // callsign column plus the DRAWER, which stands over the days from that
  // column's right edge out. Taken from the drawer's own box rather than by
  // adding eight column widths: one rect read either way, and the box is what
  // the reader actually sees.
  //
  // Every caller depends on this being honest — a month jump lands its month
  // just past this edge (`jumpTo`), the anchor correction holds the first
  // column past it across a redraw, and the month-strip readout credits the
  // month the reader is over rather than one hidden underneath. Left at the
  // closed pair, a jump put 1 September NINE columns under the drawer:
  // scrolled-to and invisible at the same time, the exact fault the jump's own
  // e2e was written to stop (measured 6 Sep 26; pinned by "a month jump lands
  // the month clear of the drawer, not under it").
  const frozenWidth = (wrap: HTMLElement): number => {
    const who = wrap.querySelector<HTMLElement>('.who')?.getBoundingClientRect().width ?? 0
    const drawer = figuresOpen ? (drawerRef.current?.getBoundingClientRect().width ?? 0) : 0
    if (drawer) return who + drawer
    return who + (wrap.querySelector<HTMLElement>('.bal')?.getBoundingClientRect().width ?? 0)
  }

  const jumpTo = (date: string) => {
    const wrap = wrapRef.current
    if (!wrap) return
    const win = colWinRef.current
    const mi = monthIndexOf(date)
    // Tell the fill engine where the view is ABOUT to be, before the scroll
    // event does: its first beat after the window change can land before that
    // event, and reading the stale pre-jump view it would see a window "nowhere
    // near the view" and replace it — undoing the jump. The scroll event then
    // confirms the same months.
    liveVisRef.current = { lo: mi, hi: mi }
    viewMonthRef.current = mi
    if (win && (mi < win.lo || mi > win.hi)) {
      // Not drawn yet. Draw a window around it; the anchor layout effect
      // scrolls to the cell in the same commit those columns appear.
      pendingJumpRef.current = date
      anchorRef.current = null
      setColWin(windowAround(months.length, mi))
      return
    }
    const cell = headCell(date)
    if (!cell) return
    // Mark this as a jump so the anchor correction below re-centres it even on
    // touch (see jumpAtRef): a jump can cross many month boundaries at once,
    // hiding rows and shrinking columns enough to leave the target far off the
    // frozen edge if the re-centre is skipped.
    jumpAtRef.current = Date.now()
    // Scrolling BY a delta rather than TO an absolute keeps this correct
    // wherever the grid happens to be scrolled already.
    wrap.scrollLeft += cell.getBoundingClientRect().left - wrap.getBoundingClientRect().left - frozenWidth(wrap)
  }

  // Which month the grid is showing, so the strip says where you ARE and not
  // only where you can go. Held as state rather than derived during render
  // because it is a fact about scroll position, which no render sees.
  // WHICH MONTH IS SHOWING — held in a ref and painted onto the buttons by
  // hand, NOT in React state (20 Aug 26). It was `useState`, and because this
  // component renders the whole ~25,000-node grid, every month boundary a
  // scroll crossed re-rendered all of it to move one highlight. Measured over
  // five paired 120-frame drags across the year, alternating in one browser
  // session to cancel machine drift: with the setState, 1437ms of main-thread
  // blocking, 18 long tasks, worst frozen frame 120ms; without it, 581ms, 6
  // tasks, 64ms — no overlap between the two sets of five. That re-render is
  // the "stuttery, lags the grid" sideways scroll the owner has now reported
  // three times, and it is why the previous two fixes did not land: the rAF
  // pump added on 19 Aug 26 was being starved by this, not running too slowly.
  //
  // Twelve class toggles cost nothing and touch no React tree, so the readout
  // stays live on every scroll event as it must ("the strip has to say where
  // you ARE while you move"). The ref is still the source of truth the render
  // below reads, so a re-render from any OTHER cause repaints the right
  // button rather than dropping the highlight.
  const inViewRef = useRef<string | null>(null)
  const monthsRef = useRef<HTMLDivElement>(null)
  const paintInView = (v: string | null) => {
    if (v === inViewRef.current) return
    inViewRef.current = v
    const box = monthsRef.current
    if (!box) return
    // `.months` holds month buttons and nothing else — the zoom control is
    // deliberately outside it (see the comment at that markup).
    const kids = box.children
    for (let i = 0; i < kids.length && i < months.length; i++) {
      const el = kids[i] as HTMLElement
      const on = months[i]!.label === v
      el.classList.toggle('on', on)
      if (on) el.setAttribute('aria-current', 'true')
      else el.removeAttribute('aria-current')
    }
  }

  // The visible month WINDOW — 'yyyy-mm|yyyy-mm', first and last months with
  // any day column on screen (owner, 19 Aug 26: a posted-out person's row
  // disappears "once I hit the next month"). '' means "no measurement" —
  // jsdom, or not laid out yet — and the row filter shows everyone then,
  // which is also what keeps every unit test honest about the full roster.
  // The state is only WRITTEN when the visible ROW SET actually changes
  // (visSigRef below): a drag across the whole year crosses eleven month
  // boundaries, and eleven full repaints of a ~28k-node table is what the
  // scroll-responsiveness gate exists to refuse.
  const [visWindow, setVisWindow] = useState('')
  const visSigRef = useRef<string | null>(null)
  /* THE MONTHS ACTUALLY ON SCREEN, always (the absence-record re-test, W5-F2, 26 Sep 26 — the re-walk found its real
     trigger). The state above is only written when the ROW SET changes, so SEP → JUL — the same people — left it at
     September; a man then posted out from a July date was asked "is he here in September?" and his July row, with
     everything on it, vanished until another month was pressed. The row filter reads THIS note, written at every
     measure without a repaint; the state stays the repaint trigger, so the scroll gate's saving is kept. */
  const visWinRef = useRef('')
  // Where a named day column sat the instant the row set changed, so the
  // repaint can put it back. Removing (or restoring) a row lets the table's
  // auto layout re-narrow every column that row's chips had widened — all of
  // them UPSTREAM of the view — which otherwise yanks the grid sideways under
  // the reader and lands a month jump short (measured 165px off at SEP, from
  // the demo's one posted-out man leaving the roster).
  const anchorRef = useRef<{ date: string; left: number } | null>(null)
  // When the last scrollLeft move was a programmatic month/day JUMP, not a
  // finger flick. The anchor correction below is skipped on touch to protect a
  // fling's momentum, but a jump has no fling to protect and MUST re-centre or
  // it lands the wrong column at the frozen edge once posted-out rows hide. A
  // timestamp, not a boolean, so it auto-expires: a jump fires one or two
  // reflows within a fraction of a second, and a later flick can never be
  // mistaken for the jump once the window has passed.
  const jumpAtRef = useRef(0)

  // The grid ZOOM (owner, 18 Aug 26 — "a zoom function for mobile leave
  // war"). Stepped +/− buttons rather than pinch: pinch fights the browser's
  // own page zoom and the frozen columns, and a button cannot half-work.
  // `zoom` (not transform) so layout, scroll width and the sticky offsets all
  // scale together. View state, session-only, like the counter choice.
  // A PHONE OPENS ONE STEP OUT (owner, 6 Sep 26 — "can this be the default
  // zoom? Like zoom 1 click out"): 0.8 there, 1 on a desktop, read once at
  // mount from the same 700px query the phone flag uses (no layout yet, so
  // this is the only place the initial value can come from; jsdom has no
  // matchMedia and stays at 1). The buttons live in the counter block's top
  // row at BOTH widths since the same day (they used to ride the month strip,
  // phone-only) — a desktop can step too now.
  const ZOOMS = [0.6, 0.8, 1, 1.2, 1.4]
  const [zoom, setZoom] = useState(() =>
    typeof window.matchMedia === 'function' && window.matchMedia('(max-width: 700px)').matches ? 0.8 : 1)
  const zoomStep = (by: number) => {
    const i = ZOOMS.indexOf(zoom)
    setZoom(ZOOMS[Math.min(ZOOMS.length - 1, Math.max(0, i + by))]!)
  }
  // The grid tables' zoom, plus `--lwz` (6 Sep 26) so a control that must keep
  // a REAL tap size at any zoom can divide it back out (the counter picker's
  // `min-height: calc(40px / var(--lwz))`, matrix.css): a phone opens at 0.8
  // and the picker fell to 32px tall, under the 36px floor the owner's own
  // complaint set. On the TABLE, not an ancestor, and it changes only when the
  // zoom steps — a restyle the zoom itself already costs, never per frame.
  const zoomStyle = zoom !== 1 ? ({ zoom, '--lwz': zoom } as import('react').CSSProperties) : undefined

  // The manning counts block (CREW SETS … SXO) collapses on a tap, for EITHER
  // role (owner, 19 Aug 26 — "allow both admin and norm user to hide it when
  // viewing, click to open or close"). A view preference, session-only like the
  // zoom above; forced open while an admin is Rearranging so the row reorder /
  // hide controls stay reachable.
  const [countsOpen, setCountsOpen] = useState(true)

  /* WHICH CATEGORY GROUPS ARE FOLDED AWAY (owner, 28 Aug 26 — "allow me to
     minimise categories on leave war"). Same doctrine as the manning collapse
     above: a VIEW preference, session-only and open to EITHER role — it hides
     nothing anyone is entitled to see, it just gets a group's rows out of the
     way while reading another. Nothing is folded by default, so the grid opens
     exactly as it always did. The fold is applied in `rosterSequence` (below),
     the one place both the real grid and the frozen overlay read. */
  const [folded, setFolded] = useState<Set<string>>(() => new Set())
  const toggleFold = (g: string) => setFolded(prev => {
    const next = new Set(prev)
    next.has(g) ? next.delete(g) : next.add(g)
    return next
  })

  // WHICH ROWS A MEASURED MONTH WIDTH IS TRUE FOR ([LW-MONTHJUMP-PHONE], 23 Sep
  // 26). A day column is as wide as the widest thing any DRAWN row puts in it
  // (auto table layout), so the same month is narrower once a row that widened
  // it has gone. Measured on the owner's PC: February, measured at the open
  // while a posted-out man's row (ignite) still showed, drew 20px narrower after
  // SEP had hidden him — and a MAR tap on a phone then slid 1 March under the
  // frozen name column, because the fill engine swapped February's placeholder
  // for the real month mid-scroll trusting the old width, with the touch-screen
  // re-anchor skipped. This token changes whenever anything that sets a column's
  // width can have changed — the store's data (bids, events, the roster), the
  // row window, a folded group, the manning rows — and every cached width is
  // stamped with the token it was measured under (`measureStripGeo`). An older
  // stamp is still the best number for the placeholder, so nothing moves when
  // the token changes; it is just no longer EXACT, and `widthExact` keeps the
  // fill engine from swapping it in under a moving scroll: that step waits for
  // rest, where the anchor correction absorbs the difference.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const widthGen = useMemo(() => ({}), [version, visWindow, folded, countsOpen, arranging])
  // The CURRENT token lives in a ref, because one input never reaches a render:
  // the manning Archive is CountRows' own state (a tap there must not re-render
  // this grid), so it replaces the token directly (`onArchiveChange`). A render
  // only overwrites the ref when its own inputs moved, never with a stale memo.
  const widthGenRef = useRef<object>(widthGen)
  const widthGenSeenRef = useRef(widthGen)
  if (widthGenSeenRef.current !== widthGen) { widthGenSeenRef.current = widthGen; widthGenRef.current = widthGen }
  // What a width change must refresh, published by the effects that own it: the
  // strip/cache/placeholder/bottom-bar geometry, and the frozen header's pinned
  // column widths (Astra LW-102 — both used to wait for a zoom, a resize or a
  // scroll, so a wider chip placed while the header was frozen left its dates
  // off the columns beneath). Called on every token change below.
  const remeasureRef = useRef<() => void>(() => {})
  const repinRef = useRef<() => void>(() => {})
  // ...and the open-bidding outline (Astra LW-103, pre-existing): the Archive's
  // rows sit ABOVE the dates, so opening it pushes the header and roster down,
  // and the outline — placed off the header — kept its old top until the next
  // store change or zoom. Its own effect never hears a change local to the block.
  const measureBidBoxRef = useRef<() => void>(() => {})
  const onArchiveChange = useCallback(() => {
    widthGenRef.current = {}
    remeasureRef.current()
    repinRef.current()
    measureBidBoxRef.current()
  }, [])

  /* THE CONFIGURED GROUPS (owner, 28 Aug 26 — the admin group editor). With the
     default list these answer exactly as the old `groupOf` / `GROUP_LABEL` did,
     so an untouched squadron is unchanged. Read once per render and shared by
     both the real grid and the frozen overlay, so the two cannot disagree about
     who sits where. */
  const groupDefs = groupsInOrder()
  const groupPriority = groupPriorityIds()
  const homeOf = (p: Person) => assignGroup(p, groupDefs, groupPriority)
  const labelOfGroup = (id: string) =>
    id === OTHER_ID ? OTHER_LABEL : (() => {
      const d = groupDefs.find(x => x.id === id)
      return d ? groupLabel(d, qualCatalog) : id
    })()
  /* The per-group swatch class. Built-in ids give back the same `g-sxo`,
     `g-ip`… classes the stylesheet already paints; a qualification id is
     slugged so a colon or space can never break the class. */
  const groupClass = (id: string) => `g-${id.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`

  /* What the quals popover lists for a person: ONLY the qualifications the
     admin has put on the page as groups (owner, 3 Sep 26 — "only the
     qualifications that were added to display will be shown when i hover"),
     in page order, each in the colour picked for that group; plus SXO in its
     gold whenever the SXO group is on the page (the owner counts SXO among
     their quals). A qualification held but not displayed is not listed, so the
     popover reads as the page's own legend. */
  const shownQuals = (p: Person): { label: string; color: string }[] => {
    const out: { label: string; color: string }[] = []
    // `groupDefs` is this render's one read of the page's groups (above) —
    // asked per row, twice (grid + frozen overlay), so not re-derived here.
    for (const d of groupDefs) {
      if (d.kind === 'qual' && matchesGroup(p, d)) {
        out.push({ label: labelOfGroup(d.id), color: groupColorOf(d.id, groupColors) ?? '#39424D' })
      } else if (d.kind === 'cat' && d.g === 'SXO' && p.sxo) {
        out.push({ label: 'SXO', color: '#E8B23B' })
      }
    }
    return out
  }
  /* Open the quals popover anchored to the chip just interacted with. Placed in
     fixed (screen) coordinates read from the chip's rect, clamped to stay on
     screen and flipped above the chip when it would fall off the bottom —
     `popAt` (popat.ts), shared with the drawer's title pop-up so the two
     screen-fixed popups cannot drift. 240 is `.qualpop`'s own max-width. */
  const openQualsAt = (id: string, el: HTMLElement) =>
    setQualPop({ id, ...popAt(el.getBoundingClientRect(), 240, 108) })
  // The chip's quals per person, once per store change (a row prop — a fresh
  // array per render would defeat the row memo, see PersonRow).
  const qualsOf = useMemo(() => {
    const m = new Map<string, QualPill[]>()
    for (const p of people) m.set(p.id, shownQuals(p))
    return m
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version])
  // The row's event-time callbacks, handed over as ONE stable ref so the memo
  // never sees a new function prop; the row reads `.current` at event time,
  // so every handler sees this render's live state (qualPop, the drag).
  const rowApi = useRef<RowApi>(null!)
  rowApi.current = {
    startRowDrag,
    setWhoOpen,
    setBalOpen,
    /* the tap pins the posting sheet it opens (W3-F5) — read off the day as it stands at the tap */
    setOpen: v => {
      const p = people.find(x => x.id === v.id)
      /* D320: by stint — an earlier stint's day is ordinary; only the gap before the current stint opens its Post in */
      const posting = !p ? undefined : postingSheetFor(p, v.date)
      setOpen(posting ? { ...v, posting } : v)
    },
    chipEnter: openQualsAt,
    chipLeave: () => setQualPop(null),
    chipClick: (p, el) => { if (qualPop?.id === p.id) setQualPop(null); else openQualsAt(p.id, el) },
  }
  /* The chip: the person's CAT, coloured by CAT (an SXO keeps gold wherever they
     sit). When they hold a displayed qualification it becomes a live control —
     hover (desktop) or tap (phone) to list them; the click is swallowed so it
     never also opens the figures sheet the callsign owns. */
  const catChip = (p: Person, testid?: string) => {
    const quals = shownQuals(p)
    const has = quals.length > 0
    return (
      <span
        className={`catchip ${catClass(p)}${has ? ' has-quals' : ''}`}
        data-testid={testid}
        aria-label={has ? `${p.callsign} qualifications: ${quals.map(q => q.label).join(', ')}` : undefined}
        onPointerEnter={has ? e => { if (e.pointerType === 'mouse') openQualsAt(p.id, e.currentTarget) } : undefined}
        onPointerLeave={has ? e => { if (e.pointerType === 'mouse') setQualPop(null) } : undefined}
        // A second tap on the SAME chip closes it (the phone has no pointer to
        // leave with); a tap on another chip moves it there.
        onClick={has ? e => { e.stopPropagation(); if (qualPop?.id === p.id) setQualPop(null); else openQualsAt(p.id, e.currentTarget) } : undefined}
      >{catText(p) || 'GND'}</span>
    )
  }
  /* While the popover is up: it is anchored in screen coordinates, so any scroll
     or resize leaves it stranded — close it. And a pointer-down anywhere that is
     not a chip or the popover itself dismisses it (the phone's tap-away, and the
     desktop's click-elsewhere) — done with a listener rather than a full-screen
     scrim, which would sit over the chip and swallow the very click that opens
     it, and block the grid while open. */
  useEffect(() => {
    if (!qualPop) return
    const close = () => setQualPop(null)
    const onDown = (e: PointerEvent) => {
      const t = e.target as HTMLElement | null
      if (t && !t.closest('.qualpop') && !t.closest('.catchip')) setQualPop(null)
    }
    /* Escape peels the popover first, before any sheet's own Escape (Sheet.tsx
       listens on `document`; the window capture runs ahead of it). */
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return
      // Kept-mounted guard (as Sheet.tsx): act only while Leave War is showing.
      const pg = document.getElementById('page-leavewar')
      if (pg && !pg.classList.contains('on')) return
      e.stopPropagation()
      setQualPop(null)
    }
    window.addEventListener('scroll', close, true)
    window.addEventListener('resize', close)
    document.addEventListener('pointerdown', onDown, true)
    window.addEventListener('keydown', onKey, true)
    return () => {
      window.removeEventListener('scroll', close, true)
      window.removeEventListener('resize', close)
      document.removeEventListener('pointerdown', onDown, true)
      window.removeEventListener('keydown', onKey, true)
    }
  }, [qualPop])

  // The month strip's buttons are ABSOLUTELY positioned (they must not widen
  // the frozen columns — see matrix.css), so the sticky cell they sit in has to
  // RESERVE their height by hand. That height was a hardcoded 72px (two wrapped
  // rows), but a phone wraps them to three and a higher zoom to more, so the
  // last months (NOV/DEC) spilled out of the cell and collided with the bracket
  // bar below (owner, 19 Aug 26). Measure the strip's real height and reserve
  // exactly that instead — dividing the table's CSS `zoom` back out, since the
  // cell lives inside it, so the value we set is layout px not doubled by zoom.
  const mstrowRef = useRef<HTMLDivElement>(null)
  const mstickRef = useRef<HTMLTableCellElement>(null)
  const [stripH, setStripH] = useState<number | null>(null)

  // ---- the frozen header on a phone (owner, 18 Aug 26: "when the callsign
  // row almost reaches outside the phone view, it will freeze at the top") --
  //
  // The page's one-vertical-scroll rule (10 Aug 26, the .mx-wrap comment in
  // matrix.css) stands: the wrapper still scrolls horizontally only and the
  // page still carries the vertical axis, so CSS sticky cannot pin the header
  // — its scrollport never moves vertically. Instead a fixed MIRROR of the
  // bracket + header rows appears once the real rows pass under the top bar,
  // and disappears the moment they come back. The mirror is its own tiny
  // horizontal scroller kept in lockstep with the grid's, which is what lets
  // the same `.who`/`.bal` sticky-left CSS freeze its lead columns for free.
  // Its column widths are MEASURED off the live header (the events row is
  // what widens a column, and only layout knows by how much) and pinned via
  // a fixed-layout colgroup. On DESKTOP too now (owner, 27 Aug 26 — "freeze top
  // panel for leave war on desktop … when I scroll down the top bar that has the
  // dates goes out of view, the top bar will freeze just like how the mobile
  // does it"): the app top bar stays pinned at the top (sticky, z-index 60), so
  // the mirror freezes just below it (its lower edge) the moment the real header
  // would slide under, at every width. No width gate any more.
  const mirrorRef = useRef<HTMLDivElement>(null)
  const [stuck, setStuck] = useState<{ top: number; left: number; width: number; cols: number[] } | null>(null)

  // Can this browser drive the frozen bar's horizontal follow on the COMPOSITOR
  // via a CSS scroll-driven animation (owner, 28 Aug 26 — "the top bar not
  // catching up to the horizontal scroll … glue it, keep the feel")? When yes,
  // the bar's day columns are TRANSLATED by the grid's own scroll timeline, so
  // they stay locked to the grid during a fling instead of the main-thread JS
  // follow lagging a frame or two behind (which is what he saw). When no (older
  // browsers, and jsdom — where CSS.supports is absent/false), we fall back to
  // the JS mirror below, unchanged. Detected once: support does not change mid
  // session. `scroll-timeline` + `timeline-scope` together are the two features
  // the approach needs (a named timeline on the scroller, hoisted into scope for
  // the fixed bar, which is not a descendant of the scroller).
  const [sdaActive] = useState(() => {
    try {
      return typeof CSS !== 'undefined' && typeof CSS.supports === 'function' &&
        CSS.supports('scroll-timeline: --x x') && CSS.supports('timeline-scope: --x')
    } catch { return false }
  })

  // ---- the desktop horizontal scrollbar, pinned to the foot of the SCREEN
  // (owner, 22 Aug 26: "on desktop the horizontal scroll is not tagged to the
  // screen. I need to scroll all the way down to scroll") ---------------------
  //
  // `.mx-wrap` scrolls sideways with NO height cap (the one-vertical-scroll
  // rule at the top of matrix.css), so its own horizontal scrollbar rides the
  // FOOT of a year-tall grid — unreachable until the whole page is scrolled
  // down. This is a proxy for it (the Raptor `hsSet`/`hsSync` idiom): a fixed
  // slim strip at the bottom of the viewport, as wide as the grid, whose inner
  // spacer is as wide as the grid's CONTENT so the browser sizes its thumb for
  // free. It drives `.mx-wrap.scrollLeft` and is driven back by it, both writes
  // compare-guarded so the pair settles instead of ping-ponging. Shown only
  // while the grid's own scrollbar is BELOW the fold, so the two never stack.
  // Desktop only — a phone finger-scrolls the grid and carries its own frozen
  // header; and never in jsdom, which has no layout to measure.
  const hbarRef = useRef<HTMLDivElement>(null)
  const [hbar, setHbar] = useState<{ left: number; width: number; scrollW: number } | null>(null)
  // ---- THE YEAR-WIDE SCROLLBAR (owner, 4 Sep 26 — "the scroll bar at the
  // bottom keeps adjusting … make it linear … halfway I'm already at the edge")
  // The Phase-2 column window draws only ~2–4 months, so this proxy bar's spacer
  // — sized to the DRAWN content — spanned only those months: the thumb filled
  // most of the bar, "halfway" was the edge, and it RESIZED every time the
  // window grew. The bar became a YEAR-wide SCRUBBER over an ESTIMATED year
  // width, jumping the grid to the dragged-to day on release. Since the
  // PLACEHOLDERS (5 Sep 26) the grid's own scroller is year-wide, so the bar is
  // a plain proxy again — its spacer is the grid's scrollWidth and a drag SLIDES
  // the grid, the fill drawing the months under the view as it goes. Desktop
  // only (a phone finger-scrolls the grid and shows no proxy bar).
  const hbarUserTsRef = useRef(0)              // last time the bar itself was dragged
  const hbarWantRef = useRef<number | null>(null) // the follow-write we expect back as an echo
  // The measured average day-column width + the frozen-column width, cached by
  // war+zoom — the ESTIMATE a placeholder uses for a month never yet drawn (see
  // `applyPlaceholders`). Only a new war or a zoom step re-measures. Taken from
  // whatever is drawn at first measure; two months is plenty representative.
  const avgDayWRef = useRef<{ key: string; avg: number; frozen: number } | null>(null)

  useEffect(() => {
    setStuck(null)
    // jsdom has no layout — the mirror is a browser-only creature, and a
    // 0-height header (jsdom, or not yet laid out) never activates.
    if (typeof window.matchMedia !== 'function') return
    // `force` re-measures the pinned widths even while already stuck. A plain
    // scroll keeps them (cheap, and the widths don't change as you scroll), but a
    // rotate/resize changes EVERY column width — and without a fresh measurement
    // the mirror kept the old orientation's widths until a scroll un-stuck and
    // re-pinned it (owner, 30 Aug 26 — "flip my screen horizontally … the top bar
    // is cut off to what the vertical view was … I need to scroll up then back
    // down to reset the frozen bar").
    const pin = (force: boolean) => {
      const head = headRef.current
      if (!head) { setStuck(prev => (prev ? null : prev)); return }
      const r = head.getBoundingClientRect()
      if (r.height === 0) return // jsdom, or not laid out yet — never activate
      // The app top bar stays pinned (sticky, both widths), so "the top" is its
      // LOWER edge: the mirror freezes there the instant the real header would
      // slide under it. Both phone and desktop now (owner, 27 Aug 26).
      const topEdge = document.querySelector('.topbar')?.getBoundingClientRect().bottom ?? 0
      if (r.top >= topEdge) { setStuck(prev => (prev ? null : prev)); return }
      setStuck(prev => {
        if (prev && !force) return prev
        const wrap = wrapRef.current
        if (!wrap) return prev
        const wr = wrap.getBoundingClientRect()
        const cells = Array.from(head.querySelectorAll('tr:last-child > th')) as HTMLElement[]
        const cols = cells.map(c => c.getBoundingClientRect().width)
        if (cols.length === 0 || cols.some(w => !w)) return prev
        const next = { top: topEdge, left: wr.left, width: wr.width, cols }
        // A forced re-pin that measured the same bar keeps the old object, so
        // re-measuring on every store change costs no re-render of this grid.
        return prev && sameStuck(prev, next) ? prev : next
      })
    }
    repinRef.current = () => pin(true)
    const onScroll = () => pin(false)
    // A rotate/resize fires BEFORE iOS has settled the new viewport, so an
    // immediate read would take the OLD geometry — re-measure on the next two
    // frames AND once more after a beat, forcing fresh widths each time.
    let raf = 0
    let t: ReturnType<typeof setTimeout> | undefined
    const remeasure = () => {
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => requestAnimationFrame(() => pin(true)))
      clearTimeout(t); t = setTimeout(() => pin(true), 300)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', remeasure)
    window.addEventListener('orientationchange', remeasure)
    window.visualViewport?.addEventListener('resize', remeasure)
    onScroll()
    return () => {
      repinRef.current = () => {}
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', remeasure)
      window.removeEventListener('orientationchange', remeasure)
      window.visualViewport?.removeEventListener('resize', remeasure)
      cancelAnimationFrame(raf); clearTimeout(t)
    }
    // `zoom` is a dep because it changes every measured width the mirror pins.
    // `visWindow` too (19 Aug 26): a row-set change lets auto layout re-narrow
    // the columns a removed row's chips had widened, and a stuck mirror
    // pinning the OLD widths would sit misaligned over the new ones.
    // `folded` (28 Aug 26) is the same kind of row-set change — minimising a
    // category takes its rows (and their chips) out of the table. The window's
    // EDGES (5 Sep 26): two windows a month apart can hold the same day count,
    // and the pinned widths would be the wrong months'. `arranging` (6 Sep 26):
    // Rearrange widens the frozen name column (`.mx-arranging`), so a stuck
    // mirror pinned at the old width would sit a grip's width off the grid.
    // `figuresOpen` (6 Sep 26): the header row grows for the drawer's titles, so
    // where it crosses under the top bar — and so whether the mirror is stuck at
    // all — moves with it.
  }, [period.id, drawnDates.length, colWin?.lo, colWin?.hi, zoom, visWindow, folded, arranging, figuresOpen])

  // ...and RE-PIN on any change that can widen a column while the bar is up
  // (Astra LW-102, 23 Sep 26): a wider chip or an event written by anyone, the
  // manning rows, the Archive (via `onArchiveChange`). Measured on the built
  // bundle: a half-day OIL chip ("*OIL") widens a narrow day column by ~10px,
  // and every frozen date to its right then sat that far off its column until
  // a scroll un-stuck the bar. A layout effect, so the fresh widths land in the
  // frame the change paints in; the value check in `pin` makes it free when
  // nothing moved. Pinned by "a column that widens while the dates are frozen
  // re-measures the frozen bar" (e2e/leavewar.spec.ts).
  useLayoutEffect(() => { repinRef.current() }, [widthGen])

  // The mirror starts life at the grid's current horizontal position, and the
  // two scrollers keep each other in lockstep from then on. Assigning an
  // unchanged scrollLeft fires no event, so the pair settles instead of
  // ping-ponging.
  //
  // A LAYOUT effect, so the position is set BEFORE the bar's first frame is
  // painted (owner's video, 23 Sep 26 — "the frozen bar scrolling rapidly
  // horizontally when they scroll the page down"). The bar mounts afresh every
  // time the page scrolls it into view, and as a plain effect this ran AFTER
  // that first paint: for one frame the day columns sat at the START of the
  // year, then jumped to where the grid was — 5,135px on a desktop parked in
  // August, measured on the built bundle, every time the page scrolled down.
  // Pinned by "the frozen bar is in step with the grid the moment it appears"
  // (e2e/leavewar.spec.ts).
  useLayoutEffect(() => {
    if (stuck && mirrorRef.current && wrapRef.current) {
      const w = wrapRef.current
      if (sdaActive) {
        // Scroll-driven path: the track must NOT be scrolled (the inner table is
        // translated instead — a scrollLeft here would double the travel). Just
        // make sure the bar knows the grid's travel before it appears, so its
        // very first painted frame is already in step; a stale or zero
        // --lwx-max would pin the day columns at the left until the next layout.
        // On the bar's own box, not `.mx-outer`: a custom property changing on
        // the grid's ancestor re-styles the whole grid (see applyPlaceholders).
        mirrorRef.current.style.setProperty('--lwx-max', String(Math.max(0, (w.scrollWidth - w.clientWidth) / zoom)))
        // ...AND hold the day columns where the grid is until the browser has
        // STARTED the scroll-linked animation. Knowing the travel was not
        // enough: a freshly created animation is not applied on the frame it is
        // created in (measured on the built bundle — the bar's first frame had
        // no transform at all with `--lwx-max` already set), so the year's first
        // columns still flashed. This inline translate is the same number the
        // animation will produce (its keyframe runs 0 → −travel across the
        // whole scroll range, so at scrollLeft s it sits at −s/zoom); once the
        // animation runs it outranks an inline style anyway, and the hold is
        // dropped then, so it can never go stale on a later scroll. The
        // keyframe's `from` is STATED for this (matrix.css `lwx-follow`): an
        // implicit one would start from this held value and blend with it.
        const anim = mirrorRef.current.querySelector<HTMLElement>('.mxfixed-anim')
        const run = anim?.getAnimations?.()[0]
        if (anim && run) {
          anim.style.transform = `translateX(${-w.scrollLeft / zoom}px)`
          run.ready.then(() => { anim.style.transform = '' }, () => { anim.style.transform = '' })
        }
      } else {
        // JS-mirror fallback: start the mirror at the grid's position.
        mirrorRef.current.scrollLeft = w.scrollLeft
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stuck])

  // The bottom scrollbar starts at the grid's current position the moment it
  // appears, so its thumb is never a frame out of step on show. A LAYOUT effect
  // for the reason the frozen header's is (above): the bar mounts afresh each
  // time the page scrolls it into view, and a plain effect placed the thumb one
  // painted frame late — at the start of the year, then a jump.
  useLayoutEffect(() => { if (hbar) syncHbar() }, [hbar])

  // Show / hide / size the bottom scrollbar on vertical page scroll and on
  // resize. Re-bound on the layout signals that change the grid's scroll width
  // or its box (a zoom step, a row-set reflow, a war swap, the counts block
  // folding, and the phone/desktop switch) so the measured spacer stays right.
  useEffect(() => {
    measureHbar()
    window.addEventListener('scroll', measureHbar, { passive: true })
    window.addEventListener('resize', measureHbar)
    return () => {
      window.removeEventListener('scroll', measureHbar)
      window.removeEventListener('resize', measureHbar)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phone, zoom, visWindow, period.id, drawnDates.length, countsOpen, folded])
  // The mirror FOLLOWS the grid and never drives it (owner, 20 Aug 26 — the
  // sixth report, and the one that found it: "when the top bar freezes the
  // sideways scroll can only move a bit and halts quickly"). It used to be a
  // two-way sync — the mirror's own `scroll` event wrote its position back onto
  // the grid. On iOS that is fatal to a fling: the grid flings on the
  // compositor, the mirror lags it by a frame, and its scroll handler then
  // writes that STALE position back onto the grid, snapping it back and killing
  // the fling — which is exactly the "moves a bit then halts". So the write-back
  // is gone, and `.mxfixed-scroll` is `overflow-x: hidden` (matrix.css) so the
  // header cannot be dragged out of step with the grid either. `syncMirror`
  // (grid → mirror) is all that remains, and setting the mirror's own scrollLeft
  // never touches the grid.
  const syncMirror = () => {
    // In the scroll-driven path the bar's inner table is TRANSLATED by the grid's
    // scroll timeline (compositor). Writing the track's scrollLeft here too would
    // move it a SECOND time — the day columns would travel double and shoot off
    // the left. The animation owns the follow; there is nothing to sync.
    if (sdaActive) return
    const m = mirrorRef.current, w = wrapRef.current
    if (m && w && m.scrollLeft !== w.scrollLeft) m.scrollLeft = w.scrollLeft
  }

  // The year-wide scrubber FOLLOWS the grid. Since the placeholders (5 Sep 26)
  // the grid's own scroller IS year-wide — the bar's spacer is simply its
  // scrollWidth — so the follow is a straight copy of scrollLeft, no year-space
  // estimate needed. Suppressed for a beat after the bar itself is dragged
  // (`hbarUserTsRef`), so the grid never writes the thumb back out from under
  // the finger. No-op when the bar is not shown (ref is null).
  //
  // ...and ONE catch-up follow when that beat ends ([LW-HBAR-RESYNC], 23 Sep
  // 26). A follow asked for inside the beat used to be dropped, and nothing
  // asked again until the grid next scrolled — so a month button pressed
  // straight after a drag moved the grid to September and left the thumb at
  // January (forced 5 of 5; one run in four on the owner's fast PC). The
  // catch-up re-runs this, so a drag still going when it fires just waits
  // another beat. Pinned by the scrubber test in e2e/leavewar.spec.ts.
  const HBAR_HOLD_MS = 250
  const hbarCatchUpRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const syncHbar = () => {
    const h = hbarRef.current, wrap = wrapRef.current
    if (!h || !wrap) return
    const hold = HBAR_HOLD_MS - (Date.now() - hbarUserTsRef.current)
    if (hold > 0) {
      if (hbarCatchUpRef.current == null) {
        hbarCatchUpRef.current = setTimeout(() => { hbarCatchUpRef.current = null; syncHbar() }, hold + 10)
      }
      return
    }
    const v = Math.min(Math.max(0, h.scrollWidth - h.clientWidth), Math.max(0, wrap.scrollLeft))
    if (Math.abs(h.scrollLeft - v) <= 1) return
    hbarWantRef.current = v
    h.scrollLeft = v
  }
  // ...and dragging the scrubber SLIDES the grid: the bar's position maps
  // straight onto the grid's real scroll, and the grid's own scroll handler
  // lights the month strip and kicks the fill, which draws the months under the
  // moving view in place (the placeholders make every position real). It used
  // to JUMP on release while months were still filling in, because the scroller
  // only spanned the drawn months; that ration is gone with them.
  const onHbarScroll = () => {
    const h = hbarRef.current, wrap = wrapRef.current
    if (!h || !wrap) return
    // Our own follow-write (syncHbar) echoes back as a scroll event — ignore it.
    if (hbarWantRef.current != null && Math.abs(h.scrollLeft - hbarWantRef.current) <= 1) { hbarWantRef.current = null; return }
    hbarWantRef.current = null
    hbarUserTsRef.current = Date.now()
    const hMax = h.scrollWidth - h.clientWidth
    const wMax = wrap.scrollWidth - wrap.clientWidth
    wrap.scrollLeft = hMax > 0 ? Math.round((h.scrollLeft / hMax) * wMax) : 0
  }
  // Only write state when the bar's presence or dimensions actually change:
  // measureHbar runs on every vertical page scroll, and this component renders
  // a ~25,000-node grid — a setState per wheel-tick is exactly the cost the
  // rest of this file bends over backwards to avoid.
  const applyHbar = (next: { left: number; width: number; scrollW: number } | null) =>
    setHbar(prev => {
      if (!prev && !next) return prev
      if (prev && next && prev.left === next.left && prev.width === next.width && prev.scrollW === next.scrollW) return prev
      return next
    })
  // Decide whether the proxy is wanted, and at what size. Cheap reads only (one
  // rect + scrollWidth). It is NOT wanted when: this is a phone (its own
  // scroll); the grid does not overflow sideways; there is no layout yet (jsdom
  // 0×0); the grid's own scrollbar is already on screen (its bottom is at or
  // above the fold — showing both would stack two bars); or the grid has been
  // scrolled entirely out of view.
  const measureHbar = () => {
    const w = wrapRef.current
    if (!w || phone) { applyHbar(null); return }
    const overflow = w.scrollWidth - w.clientWidth
    const r = w.getBoundingClientRect()
    if (overflow <= 1 || r.width === 0 || r.bottom <= window.innerHeight || r.bottom <= 0 || r.top >= window.innerHeight) {
      applyHbar(null); return
    }
    // The spacer is the grid's own scroll width — year-wide since the
    // placeholders (5 Sep 26), so the thumb is year-proportional and only ever
    // shifts by the few pixels an estimated month gains or loses when drawn.
    applyHbar({ left: r.left, width: r.width, scrollW: w.scrollWidth })
  }

  // The frozen header tracks the grid on a requestAnimationFrame LOOP, not
  // straight off the scroll event (owner, 19 Aug 26 — a sideways scroll felt
  // stuttery and the header lagged the grid, "trying to catch up"). A touch
  // scroll moves `.mx-wrap` on the compositor at full frame rate, but its
  // `scroll` event fires on the main thread COALESCED — often fewer than once
  // a frame during a fling — so copying the mirror's position from the event
  // alone always lands a frame or more behind, which reads as the header
  // chasing the grid. Sampling `wrap.scrollLeft` inside rAF instead writes the
  // match in the same frame the grid paints, so the two move as one. The loop
  // runs ONLY while a scroll is in flight — each scroll event re-arms a short
  // stop timer — so an idle page still idles rather than spinning rAF forever.
  const rafRef = useRef<number | null>(null)
  const pumpStopRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const stopPump = () => {
    if (rafRef.current != null) { cancelAnimationFrame(rafRef.current); rafRef.current = null }
    if (pumpStopRef.current) { clearTimeout(pumpStopRef.current); pumpStopRef.current = null }
  }
  const pump = () => {
    syncMirror()
    rafRef.current = requestAnimationFrame(pump)
  }
  const startPump = () => {
    if (rafRef.current == null) rafRef.current = requestAnimationFrame(pump)
    if (pumpStopRef.current) clearTimeout(pumpStopRef.current)
    // Outlive the scroll-rest window the row reflow uses, so the last few
    // settling frames are still tracked before the loop lets go.
    pumpStopRef.current = setTimeout(stopPump, 200)
  }
  // The mirror only exists while stuck; stop the loop the moment it thaws so
  // it never runs with nothing to drive.
  useEffect(() => { if (!stuck) stopPump() }, [stuck])

  // The bracket row and the header row, rendered once in the grid and again
  // inside the phone mirror. The mirror copy carries no test ids — two nodes
  // answering one id would break every query that expects the real one.
  //
  // `drawer` is the stuck mirror's FROZEN copy only (see the render below):
  // there the counter column is replaced by the drawer's own title columns, so
  // the frozen pair is one + however many figures show, and the brackets start
  // that many columns in. The real grid never takes it — the drawer is an
  // overlay, and every real row keeps identical cells.
  const bracketRow = (testids: boolean, drawer = false) => (
    <tr className="mbrak" data-testid={testids ? 'month-bracket' : undefined}>
      {/* The corner cell above CS/Name. The admin's ⠿ REARRANGE toggle moved UP
          to the card-header row (owner, 5 Sep 26 — "the rearrange button goes
          after [settings]"); it now carries the DRAWER's switch (owner, 6 Sep
          26) — the one empty frozen cell, sitting directly above the column it
          unfolds. The stuck mirror draws the same copy (no testid, one id one
          node) so the switch is reachable however far the roster has scrolled. */}
      <th className="brakhd" colSpan={drawer ? 1 + figures.length : 2}>
        <button
          className={`figbar${figuresOpen ? ' on' : ''}`}
          data-testid={testids ? 'figures-toggle' : undefined}
          aria-expanded={figuresOpen}
          title={figuresOpen ? 'Hide the figures' : 'Show every figure'}
          onClick={() => setFiguresOpen(o => !o)}
        >
          {figuresOpen ? '▾' : '▸'} FIGURES
        </button>
      </th>
      {padL && <th className="lwph lwph-l" ref={phL} />}
      {brackets.map(b => (
        <th key={b.key} className="brakm" data-testid={testids ? `bracket-${b.key}` : undefined} colSpan={b.count}>
          <div className="brakin">
            <span className="brakl">{b.label}</span>
          </div>
        </th>
      ))}
      {padR && <th className="lwph lwph-r" ref={phR} />}
    </tr>
  )

  const headerRow = (testids: boolean, drawer = false) => (
    <tr>
      {/* CS/Name (owner, 26 Aug 26): the column holds aircrew callsigns AND
          ground-crew names, and the short form fits the phone's 76px frozen
          column; the Quals page's Personnel view says the long form
          (Callsign/Name) where there is room. */}
      <th className="who">CS/Name</th>
      {/* The stuck mirror's frozen copy, while the drawer is open: the drawer's
          own sideways titles in place of the one chip, so scrolling the page
          down does not take the legend with it. Read-only — the live titles are
          the drawer's own, a few pixels below. */}
      {drawer && figures.map(f => (
        <th key={f.id} className={figClass(figures, f.id)} data-fig={f.id}>
          <FigureTitle figure={f} />
        </th>
      ))}
      {/* The counter selector lives in the column header, which is the only
          place a 40px-wide column has room for a control. The WHOLE header is
          the control (the two 13px arrows were too small to hit from a
          phone): tapping anywhere on it opens the full-width counter sheet,
          and swiping across the column (handled on `.mx-wrap`) is the fast
          path. The column is frozen beside the callsign so the figure stays
          on screen however far the grid scrolls. */}
      {!drawer && <th className="bal" data-testid={testids ? 'counter-head' : undefined}>
        <button
          className="cpick"
          data-testid={testids ? 'counter-pick' : undefined}
          aria-label={`Showing ${shown.label}. Choose what this column shows`}
          onClick={() => setPicking(true)}
        >
          <span className="cname" data-testid={testids ? 'counter-name' : undefined}>{shown.title}</span>
          <span className="cdots" aria-hidden="true">
            {figures.map((f, i) => (
              <span key={f.id} className={`cdot${i === shownIx ? ' on' : ''}`} />
            ))}
          </span>
          {/* A tap hint (owner, 18 Aug 26): the whole header has been the
              control since the arrows were pulled, but on a phone nothing
              SAID so; this little finger does. aria-hidden — the button's own
              label already tells a screen reader it is tappable. */}
          <span className="ctap" aria-hidden="true">
            <svg viewBox="0 0 20 20" width="12" height="12" fill="none"
              stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M7.5 9V4.4a1.5 1.5 0 0 1 3 0V8.5" />
              <path d="M10.5 8.6V7.2a1.4 1.4 0 0 1 2.8 0v3.9c0 2.7-1.8 4.4-4.3 4.4-1.7 0-3-.8-3.8-2.2L4 11.1a1.25 1.25 0 0 1 2.1-1.3l1 1.4" />
            </svg>
          </span>
        </button>
      </th>}
      {padL && <th className="lwph lwph-l" ref={phL} />}
      {drawnDays.map(d => {
        const mon = monthLabel(d.date)
        return (
          <th
            key={d.date}
            data-testid={testids ? `head-${d.date}` : undefined}
            className={`day${d.blocked ? ' blocked' : ''}${isWeekend(d.date) ? ' weekend' : ''}${evKind.has(d.date) ? ` ${evKind.get(d.date)}` : ''}${lockedDate(d.date) ? ' locked' : ''}${d.date === focusDate ? ' focus' : ''}`}
            title={[d.blocked ? d.blockedReason : '', d.events.filter(Boolean).join(' / ')]
              .filter(Boolean)
              .join(' — ')}
          >
            {mon && <span className="mon">{mon}</span>}
            {/* The day of the week, on every column: "which Tuesday" is the
                question somebody bidding actually asks. Owner, 10 Aug 26. */}
            <span className="dow">{dayName(d.date)}</span>
            {d.date.slice(8)}
          </th>
        )
      })}
      {padR && <th className="lwph lwph-r" ref={phR} />}
    </tr>
  )

  // The month spans + the visible view bounds — the thirteen rect reads both
  // the strip readout and the row window are computed from. One rect per month
  // plus the last column, not one per day: thirteen reads on a year rather than
  // 365, which is what makes measuring this on every scroll event affordable.
  const readSpans = () => {
    const wrap = wrapRef.current
    const { drawnMonths, drawnDates } = liveRef.current
    if (!wrap || drawnMonths.length === 0 || drawnDates.length === 0) return null
    const headLeft = (date: string) =>
      headCell(date)?.getBoundingClientRect().left
    const lastHead = headCell(drawnDates[drawnDates.length - 1])
    if (!lastHead) return null
    const edges = drawnMonths.map(m => headLeft(m.first))
    if (edges.some(e => e === undefined)) return null
    const end = lastHead.getBoundingClientRect().right
    const spans = drawnMonths.map((m, i) => ({
      label: m.label,
      left: edges[i]!,
      // A month runs up to where the next one starts; the last runs to the
      // right edge of the final column.
      right: i + 1 < edges.length ? edges[i + 1]! : end,
    }))
    const wr = wrap.getBoundingClientRect()
    // The visible strip starts where the day columns do — the frozen columns
    // sit ON TOP of them, so counting from the wrapper's own left edge would
    // credit whichever month is hidden underneath the callsigns.
    const viewL = wr.left + frozenWidth(wrap)
    const viewR = wr.right
    return { wrap, spans, end, viewL, viewR }
  }

  // ---- the month-strip readout, and why it is CACHED (20 Aug 26) ----------
  //
  // This runs on every scroll event, and until now it called readSpans() each
  // time — 15 `querySelector` searches across a 25,000-node grid plus 16
  // `getBoundingClientRect` reads, every one of which forces a synchronous
  // layout flush. It was described here as "cheap". It was not: measured with
  // the strip readout switched off and back on again over an identical
  // 120-frame drag across the year, it accounted for 82% of ALL main-thread
  // blocking during a scroll — 2932ms of blocking down to 519ms, 27 long
  // tasks down to 5, and the worst single frozen frame 503ms down to 65ms.
  // That is the "stuttery, laggy" sideways scroll the owner reported three
  // times; the rAF pump added on 19 Aug 26 could not fix it, because the
  // pump was being starved by this, not running too slowly.
  //
  // The fix is that NONE of that measuring has to happen while scrolling. A
  // month's edges move only when the COLUMNS change — a different war, a zoom
  // step, a row-set reflow, a resize. Their offsets within the scroller's
  // content are otherwise constant, and scrolling just slides the window over
  // them. So the geometry is measured once per layout change into
  // `stripGeoRef`, in CONTENT space (offsets from the start of the scrollable
  // content, not from the viewport), and a scroll event then only has to read
  // `scrollLeft` and do arithmetic. monthInView is documented as working in
  // "whatever one coordinate space the caller is using", which is what makes
  // content space a drop-in.
  //
  // measureWindow below is deliberately NOT converted: it runs at scroll REST,
  // where its cost is invisible, and its anchor correction works in viewport
  // coordinates that would have to be converted in lockstep with it.
  const stripGeoRef = useRef<{ spans: { label: string; left: number; right: number }[]; frozen: number; client: number } | null>(null)

  const measureStripGeo = () => {
    const wrap = wrapRef.current
    const { drawnMonths, drawnDates } = liveRef.current
    if (!wrap || drawnMonths.length === 0 || drawnDates.length === 0) { stripGeoRef.current = null; return }
    // The scroll-driven frozen bar (sdaActive) translates its day columns from 0
    // to -(--lwx-max)px across the grid's whole scroll range, so --lwx-max must
    // equal the grid's max scrollLeft — divided back out of the mirror table's
    // own zoom, since the transform lands in that table's zoomed local space
    // (mirror render below). It only shifts on a real layout change (resize,
    // zoom, row-window, war), which is exactly when this runs; never per frame.
    // Written on the bar's own box (null until the bar is stuck — the stuck
    // effect seeds it then), never on `.mx-outer`: a custom property changing on
    // the grid's ancestor re-styles the whole grid (see applyPlaceholders).
    if (sdaActive) {
      mirrorRef.current?.style.setProperty('--lwx-max', String(Math.max(0, (wrap.scrollWidth - wrap.clientWidth) / zoom)))
    }
    const wr = wrap.getBoundingClientRect()
    const sl = wrap.scrollLeft
    // viewport px -> content px: constant across any scroll position
    const contentL = (el: HTMLElement) => el.getBoundingClientRect().left - wr.left + sl
    const head = (d: string) => headCell(d)
    const firsts = drawnMonths.map(m => head(m.first))
    const lastHead = head(drawnDates[drawnDates.length - 1]!)
    if (!lastHead || firsts.some(e => !e)) { stripGeoRef.current = null; return }
    const edges = firsts.map(e => contentL(e!))
    const end = lastHead.getBoundingClientRect().right - wr.left + sl
    // jsdom reports every rect 0x0; a zero-width geometry would make every
    // month's overlap 0 and the readout permanently null, so leave the cache
    // empty and let measureStrip no-op exactly as it did before.
    if (end <= edges[0]!) { stripGeoRef.current = null; return }
    const drawn = drawnMonths.map((m, i) => ({
      label: m.label,
      left: edges[i]!,
      right: i + 1 < edges.length ? edges[i + 1]! : end,
    }))
    const frozen = frozenWidth(wrap)
    // The placeholders' day-width estimate rides this same measurement, and
    // the drawn months' real widths go into the cache the placeholders read.
    measureAvgDayW(drawn, frozen)
    const win = colWinRef.current
    const lo = win?.lo ?? 0
    const cache = monthPxCache()
    for (let i = 0; i < drawn.length; i++) {
      cache.px[lo + i] = (drawn[i]!.right - drawn[i]!.left) / zoom
      cache.gen[lo + i] = widthGenRef.current // measured under THESE rows (see widthGen)
    }
    // One span per month of the WAR, drawn or placeholder — the undrawn months
    // laid out at their placeholder widths on either side of the measured ones,
    // so the readout lights the month a placeholder stands for and the fill
    // engine knows which months the view is over before they exist.
    const spans: { label: string; left: number; right: number }[] = []
    let x = drawn[0]!.left
    for (let m = lo - 1; m >= 0; m--) x -= monthPx(m) * zoom
    for (let m = 0; m < lo; m++) { const w = monthPx(m) * zoom; spans.push({ label: months[m]!.label, left: x, right: x + w }); x += w }
    for (const s of drawn) spans.push(s)
    x = end
    for (let m = lo + drawn.length; m < months.length; m++) { const w = monthPx(m) * zoom; spans.push({ label: months[m]!.label, left: x, right: x + w }); x += w }
    stripGeoRef.current = {
      spans,
      frozen,
      // the wrapper's own rect, not clientWidth: every other edge above is
      // measured from a rect, and mixing the two invites an off-by-a-scrollbar
      client: wr.width,
    }
    // Newly cached widths can change a placeholder's width (a month that was
    // an estimate is now measured) — write them through before the next paint.
    applyPlaceholders()
  }

  // Lock in the average day-column width (and the frozen width) the first time
  // the strip geometry is measured for this war+zoom; reused thereafter so a
  // never-drawn month's estimate does not wander as the window grows.
  const measureAvgDayW = (drawn: { left: number; right: number }[], frozen: number) => {
    const n = liveRef.current.drawnDates.length
    if (drawn.length === 0 || n === 0) return
    const key = `${period.id}|${zoom}`
    if (avgDayWRef.current?.key === key) return
    const avg = (drawn[drawn.length - 1]!.right - drawn[0]!.left) / n
    if (avg > 0) avgDayWRef.current = { key, avg, frozen }
  }
  // The per-month width cache for this war+zoom (a zoom step changes every
  // width; a new war is a new set of months) — started fresh when the key moves.
  const monthPxCache = () => {
    const key = `${period.id}|${zoom}`
    if (monthPxRef.current.key !== key) monthPxRef.current = { key, px: months.map(() => null), gen: months.map(() => null) }
    return monthPxRef.current
  }
  // A month's width in LAYOUT px (the table's own space, zoom divided out — the
  // placeholder's `width` is set in that space): measured if it has ever been
  // drawn, else the average day width × its days, else a plain guess for the
  // beat before the first measurement. A width measured under different rows
  // is still used here — it is the best number there is, and changing the
  // placeholder under the reader would move the grid for nothing.
  const monthPx = (m: number): number => {
    const cached = monthPxCache().px[m]
    if (cached != null) return cached
    const a = avgDayWRef.current
    return (a ? a.avg / zoom : 30) * (yearMonths.monthDays[m] ?? 30)
  }
  // Will drawing month `m` in place of its placeholder move nothing? Only when
  // its width was measured under the rows on screen NOW (`widthGen`) — the one
  // case where the placeholder is exactly as wide as the month it stands for.
  const widthExact = (m: number): boolean => {
    const c = monthPxCache()
    return c.px[m] != null && c.gen[m] === widthGenRef.current
  }
  // Size the placeholder cells: the sum of the undrawn months on each side,
  // written as an inline width on every registered placeholder cell (each
  // row's, and the mirror header's copy) — React never sets a style on these
  // cells, so the widths survive its renders, and a cell that mounts later
  // takes the current width through its ref hook (`phL`/`phR` above). Runs in
  // the layout effects below, in the same commit as the window change, so a
  // month swapping between placeholder and drawn never paints at two widths.
  // Skipped when nothing changed: the cells are the only thing touched, but a
  // no-op write still dirties their style.
  const applyPlaceholders = () => {
    const win = colWinRef.current
    let l = 0, r = 0
    if (win) {
      for (let m = 0; m < win.lo; m++) l += monthPx(m)
      for (let m = win.hi + 1; m < months.length; m++) r += monthPx(m)
    }
    const next = { l: `${l.toFixed(2)}px`, r: `${r.toFixed(2)}px` }
    const prev = phWRef.current
    phWRef.current = next
    if (next.l !== prev.l) for (const el of phCellsRef.current.l) setPhWidth(el, next.l)
    if (next.r !== prev.r) for (const el of phCellsRef.current.r) setPhWidth(el, next.r)
  }

  // The hot path: no DOM search, no rect read, no forced layout — one
  // scrollLeft read and a walk over twelve cached numbers. React still bails
  // when the answer is unchanged, so a scroll inside one month re-renders
  // nothing at all.
  const measureStrip = () => {
    const wrap = wrapRef.current
    if (!wrap) return
    // SELF-HEALING. The cache is normally filled by the layout effects below,
    // but those run at mount, and a grid that has no layout yet at that moment
    // (webfonts still loading, the tab opened in the background) would leave
    // the cache empty and the readout dead until the next zoom, resize or war
    // change. Filling it on first use costs one measurement in that case and
    // nothing at all in the normal one, where the effects got there first.
    if (!stripGeoRef.current) measureStripGeo()
    const g = stripGeoRef.current
    if (!g) return
    const sl = wrap.scrollLeft
    paintInView(monthInView(g.spans, sl + g.frozen, sl + g.client))
    // Which months (absolute indices, drawn or placeholder) the view is over —
    // what the fill engine's rolling target follows, and where the grid shrinks
    // to around when the tab is left. Same twelve numbers, no extra read.
    const vis = visibleSpan(g.spans, sl + g.frozen, sl + g.client)
    if (vis) {
      liveVisRef.current = { lo: vis.visLo, hi: vis.visHi }
      viewMonthRef.current = vis.visLo
    }
  }

  // The row WINDOW for the roster filter — the expensive half. Changing it
  // repaints the whole ~28k-node grid AND fires the anchor correction below
  // (`scrollLeft +=`), which writes scrollLeft and so KILLS a touch fling's
  // momentum dead: the scroll visibly stops at the month a posted-out row
  // leaves. So this is NEVER run mid-scroll — the wrap's onScroll defers it to
  // scroll REST (idleRef below), where the grid is still and moving scrollLeft
  // is invisible. Only from a real layout: jsdom reports every rect 0×0, the
  // spans have no width, and a zero-width "window" must leave visWindow at ''
  // (show everyone) rather than hide the whole roster.
  // The first drawn column at or past the frozen edge, and where it sits —
  // what a column-set change (rows hidden, months added or dropped on the
  // left) puts back in the same place. Binary search — column lefts are
  // monotonic — so ~9 rect reads. Shared by the row window and the column
  // window so the two corrections cannot disagree.
  const anchorNow = (wrap: HTMLElement): { date: string; left: number } | null => {
    const { drawnDates } = liveRef.current
    if (drawnDates.length === 0) return null
    const viewL = wrap.getBoundingClientRect().left + frozenWidth(wrap)
    const at = (i: number) => headCell(drawnDates[i])?.getBoundingClientRect().left ?? 0
    let lo = 0, hi = drawnDates.length - 1, best = 0
    while (lo <= hi) {
      const mid = (lo + hi) >> 1
      if (at(mid) >= viewL - 1) { best = mid; hi = mid - 1 } else lo = mid + 1
    }
    return { date: drawnDates[best]!, left: at(best) }
  }

  const measureWindow = () => {
    const m = readSpans()
    if (!m) return
    const { wrap, spans, end, viewL, viewR } = m
    if (end > spans[0]!.left && viewR > viewL) {
      // >2px of overlap, not >0: a month jump aligns the next month's first
      // column to the frozen edge by integer scrollLeft, and a sub-pixel
      // sliver of the month being LEFT must not count as still viewing it.
      const { drawnMonths, people } = liveRef.current
      const vis = spans
        .map((s, i) => ({ s, key: drawnMonths[i]!.first.slice(0, 7) }))
        .filter(x => Math.min(x.s.right, viewR) - Math.max(x.s.left, viewL) > 2)
      if (vis.length) {
        const win = `${vis[0]!.key}|${vis[vis.length - 1]!.key}`
        visWinRef.current = win   // the true months, whether or not the rows change (W5-F2)
        const sig = people.filter(p => rowInWindow(p, win, liveRef.current.rowSpans)).map(p => p.id).join(',')
        if (sig !== visSigRef.current) {
          // Capture where the FIRST VISIBLE DAY column sits NOW; the layout
          // effect below puts it back after the repaint (see anchorRef and
          // anchorNow: the day at the view's left edge, not the month's first
          // day — a hidden row's chips widened columns on BOTH sides of any
          // other anchor, and compensating an off-screen one leaves the
          // residual on screen).
          anchorRef.current = anchorNow(wrap)
          visSigRef.current = sig
          setVisWindow(win)
        }
      }
    }
  }

  // The scroll-settle debounce. iOS/Android inertia keeps firing scroll events
  // frame by frame until the fling stops, then goes silent, so "no scroll for
  // SCROLL_REST_MS" is what "at rest" means across browsers (scrollend is
  // still patchy on Safari). While the events keep coming the timer keeps
  // resetting, so the heavy row-window work fires exactly once, the instant
  // the scroll comes to rest — never under a moving finger.
  const SCROLL_REST_MS = 120
  const idleRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  // When the grid was last scrolled — the background fill waits for this to go
  // quiet before drawing a month, so a fill draw never lands under a moving
  // scroll (which is the very freeze this whole thing exists to avoid).
  const lastScrollTsRef = useRef(0)
  const onWrapScroll = () => {
    lastScrollTsRef.current = Date.now()
    // The frozen-column overlay sits ON TOP of the real columns. At rest
    // (scrollLeft 0) it must let a tap fall THROUGH to the real cell beneath —
    // that cell still carries the handler, the testid and the focus seat — so
    // it is `pointer-events: none` until the year has actually scrolled the
    // real cell away, at which point the overlay is the only copy left to tap
    // and must catch it. Written straight onto the node's inline style (never
    // React state — a setState here would re-render the whole ~25k-node grid
    // on every scroll, the very cost this overlay exists to remove). It has to
    // be the INLINE style, not a toggled class: React owns `.mx-outer`'s
    // className and would wipe an imperatively-added class on its next render,
    // but it never sets `pointer-events`, so this property is left alone.
    if (bandRef.current) bandRef.current.style.pointerEvents = (wrapRef.current?.scrollLeft ?? 0) > 0 ? 'auto' : 'none'
    measureStrip()
    // Draw WHILE MOVING (owner, 5 Sep 26): the view's months just moved
    // (measureStrip updated them), so wake the fill engine now — it draws the
    // next month in place if the drawn edge is within the runway, or parks again
    // at once if not (arithmetic, no DOM). The scroller is year-wide, so there is
    // always somewhere to scroll; this is what puts the columns under the finger
    // before it gets there.
    kickFillRef.current()
    // Match this frame straight away, then keep matching every frame on the
    // rAF loop until the scroll rests — the immediate write covers the case
    // where the loop has not spun up yet, the loop covers the frames the
    // coalesced scroll event skips.
    syncMirror()
    // Keep the desktop bottom scrollbar's thumb in step with the grid (no-op
    // when it is not shown — the ref is null then).
    syncHbar()
    startPump()
    if (idleRef.current) clearTimeout(idleRef.current)
    idleRef.current = setTimeout(() => {
      idleRef.current = null
      measureWindow()
      // At rest the fill may also PRUNE the trailing months and draw an
      // estimated-width month on the left (the anchor makes that invisible now
      // the grid is still) — the steps it holds back while moving.
      kickFillRef.current()
    }, SCROLL_REST_MS)
  }
  useEffect(() => () => {
    if (idleRef.current) clearTimeout(idleRef.current)
    if (hbarCatchUpRef.current) clearTimeout(hbarCatchUpRef.current)
    stopPump()
  }, [])

  // The WINDOW half measured when the war changes (that rebuilds every column)
  // and when a month draw lands (the view may now sit over real columns where
  // it sat over a placeholder). A draw can land WHILE THE GRID IS STILL MOVING
  // (the in-motion fill kicked from every scroll event), and this must never
  // reflow the row set under a moving finger or write scrollLeft into a fling
  // — so while the rest debounce is pending the run is skipped: the rest
  // handler measures the window once the scroll settles, and a draw it kicks
  // lands at rest and runs here (bug-hunt fix, 6 Sep 26). The strip half is
  // NOT repeated: the layout effect below (same deps, plus zoom / visWindow)
  // has already measured it in this very commit, and doing it twice cost a
  // second set of header lookups and rect reads on every first open (3 Sep 26).
  useEffect(() => {
    if (idleRef.current) return
    measureWindow()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period.id, drawnDates.length])

  // How many months the drawn window holds while the tab is HIDDEN (a pre-warm
  // mount, or after the tab is left) — small, so the browser re-styles a few
  // months on reveal instead of the whole year (owner, 5 Sep 26, after
  // measurement showed the full-year reveal costs ~1.4s). The phone's rolling
  // runway: a few months AHEAD of the finger, one behind.
  const HIDDEN_MONTHS = 3
  const PHONE_BEFORE = 1
  const PHONE_AFTER = 3
  // The pre-warm draws only while the user has been hands-off this long, so a
  // draw never lands under a keystroke on the login-to-week path or a puck drag.
  const PREWARM_IDLE_MS = 2000

  // THE ONE DRAW-TOWARD-A-TARGET ENGINE (owner, 4–5 Sep 26 — "fill in the
  // background", then "shrink when I leave, rebuild on return", then the phone's
  // "load the next months as I approach the edge", then "do the placeholders +
  // moving"). One loop, one target per mode, one month per beat — colwindow.ts
  // `stepToward` is the arithmetic:
  //   · phone → a ROLLING window a few months ahead of the visible ones
  //     (`rollingTarget`), so a flick meets drawn columns, never a stuck edge,
  //     and the trailing months are pruned so the phone's DOM stays light;
  //   · desktop, tab ON screen → the WHOLE year, so scrolling runs end to end
  //     with nothing left to draw and the bottom scrollbar slides;
  //   · desktop, tab OFF screen (a pre-warm mount, or just left) → capped at a few
  //     months, and only drawn while the user is idle (`msSinceInput`) — this is
  //     the pre-warm that makes the first open instant, and the small window that
  //     makes the next return instant.
  // WHILE THE SCROLL IS MOVING the engine keeps drawing — that is the whole
  // point of the placeholders: the months under and ahead of the moving view
  // land in place, so the reader sees columns arrive rather than a stuck edge.
  // Each draw is still one synchronous month-build on the main thread (the
  // freeze the owner felt on the mockup and chose), so it is rationed to the
  // steps that cannot hop the content under the finger — `stepAllowedInMotion`:
  // growth only, and on the left only over a month whose width is already
  // measured. A prune, and a left grow over an estimated width, wait for rest,
  // where the anchor correction hides the shift. In motion the beat is a short
  // timeout (requestIdleCallback is starved by an active scroll); at rest it is
  // an idle callback, so a beat never competes with a paint. The loop PARKS when
  // the window matches its target and is resumed by `kickFillRef` — from every
  // scroll event (the view moved), from scroll rest (the held-back steps), and
  // from the on-screen effect (tab shown). jsdom lays nothing out, so colWin is
  // null (draw-whole) and this no-ops; the browser gate proves it.
  const fillIdleRef = useRef<{ id: number; idle: boolean } | null>(null)
  useEffect(() => {
    if (!colWin) return
    let live = true
    const moving = () => Date.now() - lastScrollTsRef.current < SCROLL_REST_MS + 40
    const rideIdle = (fn: () => void): { id: number; idle: boolean } =>
      typeof (window as { requestIdleCallback?: unknown }).requestIdleCallback === 'function'
        ? { id: (window as unknown as { requestIdleCallback: (cb: () => void, o: { timeout: number }) => number }).requestIdleCallback(fn, { timeout: 500 }), idle: true }
        : { id: window.setTimeout(fn, 48), idle: false }
    const rideSoon = (fn: () => void): { id: number; idle: boolean } => ({ id: window.setTimeout(fn, 16), idle: false })
    const drop = (h: { id: number; idle: boolean }) => {
      if (h.idle && typeof (window as { cancelIdleCallback?: unknown }).cancelIdleCallback === 'function') {
        (window as unknown as { cancelIdleCallback: (id: number) => void }).cancelIdleCallback(h.id)
      } else clearTimeout(h.id)
    }
    const schedule = () => { if (fillIdleRef.current == null) fillIdleRef.current = (moving() ? rideSoon : rideIdle)(tick) }
    const tick = () => {
      fillIdleRef.current = null
      if (!live) return
      // While the tab is hidden a draw must wait for the app to be genuinely
      // idle, so it never lands under a keystroke or a puck drag on another page.
      const idleOk = onScreenRef.current || msSinceInput() > PREWARM_IDLE_MS
      if (!idleOk) { schedule(); return }
      const win = colWinRef.current
      if (!win) return
      const last = months.length - 1
      const v = liveVisRef.current
      // THE VIEW COMES FIRST. The scroller is year-wide, so a scrubber drag or a
      // long fling can park the view over placeholders nowhere near the drawn
      // window; stepping toward it a month at a time would draw every unseen
      // month in between before the one on screen. So when the drawn window is
      // not even adjacent to the visible months, REPLACE it with them — the
      // months on screen land in one draw, and the steps below add the runway
      // (or the rest of the year) outward from there. No anchor: everything
      // left of the view keeps its width (drawn months become placeholders of
      // the same measured width), so the view's left edge holds still.
      if (onScreenRef.current && (v.lo > win.hi + 1 || v.hi < win.lo - 1)) {
        anchorRef.current = null
        colShiftRef.current = false
        setColWin(clampWin({ lo: v.lo, hi: v.hi }, months.length))
        return
      }
      let tLo: number, tHi: number
      if (phone) {
        const t = rollingTarget(months.length, v.lo, v.hi, PHONE_BEFORE, PHONE_AFTER)
        tLo = t.lo; tHi = t.hi
      } else if (onScreenRef.current) {
        tLo = 0; tHi = last                                   // the whole year
      } else {
        tLo = win.lo; tHi = Math.min(last, win.lo + HIDDEN_MONTHS - 1) // capped while hidden
      }
      const next = stepToward(win, months.length, tLo, tHi)
      if (next.lo === win.lo && next.hi === win.hi) return    // parked — kickFillRef resumes
      const inMotion = moving()
      // `widthExact`, not "measured once": a month measured while other rows
      // showed is not the width it will draw at now ([LW-MONTHJUMP-PHONE]).
      if (inMotion && !stepAllowedInMotion(win, next, widthExact)) {
        // Not safe under a moving scroll: look again once the moving window has
        // passed. The scroll-rest kick itself lands INSIDE that window (it fires
        // 120 ms after the last scroll event, the window is 160), so it cannot be
        // the retry — without this the held-back prune / left grow would wait for
        // the next scroll, and a phone parked after a long fling kept all twelve
        // months (caught on the built bundle, 5 Sep 26).
        fillIdleRef.current = { id: window.setTimeout(tick, SCROLL_REST_MS), idle: false }
        return
      }
      // A month added or dropped on the LEFT shifts the content; keep the reader's
      // column in place with the same anchor the jump path uses. At rest that is
      // invisible. In motion the step only ever swaps a placeholder for a month
      // of the SAME width — `widthExact` above, measured under the rows on screen
      // now — so the shift is nil, and on a touch screen the anchor is skipped
      // altogether, because the `scrollLeft` write that would fix a stray pixel
      // is exactly what kills a fling (the 30 Aug history). A rightward step
      // writes none.
      if (next.lo !== win.lo && !(inMotion && coarsePointer())) {
        const wrap = wrapRef.current
        if (wrap) { anchorRef.current = anchorNow(wrap); colShiftRef.current = true }
      }
      setColWin(next) // re-runs this effect, which schedules the next beat
    }
    kickFillRef.current = () => { if (live) schedule() }
    schedule()
    return () => {
      live = false
      kickFillRef.current = () => {}
      if (fillIdleRef.current != null) { drop(fillIdleRef.current); fillIdleRef.current = null }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phone, colWin?.lo, colWin?.hi, months.length])

  // SHRINK ON LEAVE, REBUILD ON RETURN (owner, 5 Sep 26). Desktop only — the
  // phone already windows. When the tab is LEFT, drop the drawn window back to a
  // few months around where the reader was, so the next reveal wakes a small
  // grid (the fill above then rebuilds the year once the tab is shown again, its
  // left-anchor keeping the reader's month in place as the earlier months fill in
  // behind them). Only on a real on→off / off→on transition, never on the first
  // mount (a fresh pre-warm mount is left to the fill's hidden cap; a direct
  // visit is left to fill the year). The signal is a listener set, not the store,
  // so none of this re-renders the grid (state/screen.ts).
  const prevOnRef = useRef(onScreenRef.current)
  useEffect(() => {
    const apply = () => {
      const on = isLwOnScreen()
      const prev = prevOnRef.current
      prevOnRef.current = on
      onScreenRef.current = on
      if (phone) return
      const win = colWinRef.current
      if (!win) return                       // short war drawn whole — nothing to window
      if (on) { if (!prev) kickFillRef.current(); return } // shown → resume filling the year
      if (!prev) return                      // already hidden at mount → the fill's cap handles it
      // on → off: shrink around the reader's month. The months dropped become
      // placeholders at their MEASURED widths, so nothing moves and the scroll
      // position is exactly where the reader left it on return — the fill then
      // re-expands from there.
      const last = months.length - 1
      const view = Math.max(0, Math.min(viewMonthRef.current, last))
      const small = clampWin({ lo: view, hi: view + HIDDEN_MONTHS - 1 }, months.length)
      if (small.lo !== win.lo || small.hi !== win.hi) {
        anchorRef.current = null
        colShiftRef.current = false
        setColWin(small)
      }
    }
    apply()
    return subLwScreen(apply)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phone, months.length])

  // Everything else that moves a column edge, and so invalidates the cached
  // strip geometry: a zoom step (every width changes), a row-set reflow (the
  // hidden rows' chips were widening columns — the very thing anchorRef exists
  // to compensate), and a viewport resize (the wrapper's own width and the
  // frozen columns both change). Layout effect so the re-measure lands in the
  // same frame as the change that caused it, before any scroll can read a
  // stale cache. The strip is re-read straight after, so the readout is right
  // immediately rather than at the next scroll event.
  useLayoutEffect(() => {
    // The placeholders FIRST, from the cache and the estimate, so the drawn
    // months are measured at their final positions (a left placeholder shifts
    // everything after it); measureStripGeo writes them again once it has cached
    // the widths it just measured. measureHbar/syncHbar too: the proxy spacer
    // tracks the grid's scroll width and the thumb its position.
    const remeasure = () => { applyPlaceholders(); measureStripGeo(); measureStrip(); measureHbar(); syncHbar() }
    remeasureRef.current = remeasure
    remeasure()
    window.addEventListener('resize', remeasure)
    return () => window.removeEventListener('resize', remeasure)
    // The window's EDGES are deps, not only the drawn-day count: two windows a
    // month apart can hold the same number of days (Mar+Apr and May+Jun both
    // span 61), and the placeholders and spans would be a month off.
    // `arranging` (6 Sep 26): Rearrange widens the frozen name column, which
    // moves every day column's edge and the grid's scroll width.
    // `figuresOpen` AND `drawerAt?.width` (6 Sep 26, review): the FIGURES
    // drawer moves the frozen EDGE — `frozenWidth` reads the drawer while it is
    // open — and this effect is the only thing that re-measures it into
    // `stripGeoRef.current.frozen`, which `measureStrip` then reads on every
    // scroll event. Without a dep, the strip readout (and the `visibleSpan` the
    // fill engine's rolling target follows) goes on using the width it last
    // cached — the closed pair's, ~250px too far left on a desktop — until an
    // unrelated zoom, resize, war change or window edge happens to refresh it.
    // The self-heal in `measureStrip` cannot cover it: it only fires when the
    // cache is null, and here it is merely stale.
    //
    // `figuresOpen` alone was not enough, and the shape of the miss is the
    // lesson: it catches the drawer APPEARING but not the drawer CHANGING
    // WIDTH while it is out — an admin hiding a figure in the picker, or the
    // undo of that hide, takes a column off or puts one back and the cached
    // edge stays a column short. So the canonical signal is the measured width
    // itself: `drawerAt` is value-guarded (its own effect only publishes a new
    // object when a number really moved), so this dep fires on every real edge
    // move — including the ones nobody has thought of yet — and on none of the
    // renders in between. `figuresOpen` stays beside it because it is what
    // takes the width back to `undefined` on close.
    // `widthGen` (23 Sep 26, Astra LW-102): anything that can widen a drawn
    // column — a chip, an event, the manning rows — moves every month edge
    // after it, and this is the only thing that re-measures them (and stamps
    // the drawn months' widths as exact under the new rows). The Archive's
    // change never reaches a render, so `onArchiveChange` calls it directly.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zoom, visWindow, period.id, drawnDates.length, colWin?.lo, colWin?.hi, arranging, figuresOpen, drawerAt?.width, widthGen])

  // Put the anchored column back after a row-set repaint (see anchorRef).
  // Layout effect, not effect: the correction must land in the same frame as
  // the narrowed columns or the reader sees the grid jump and snap back. The
  // scroll it makes re-fires the strip/window measure; the signature compare
  // then finds the same row set and stops — no loop.
  //
  // BUT NOT DURING A FINGER FLICK (owner, 30 Aug 26 — "the nudge restarts every
  // time I scroll horizontally"; his own diagnosis, confirmed). When a person
  // posts out and their roster row disappears crossing into a new month, that
  // row's leave content was widening some day columns, so they shrink and this
  // WRITES `wrap.scrollLeft` to keep the same column in place. On iOS (all
  // iPhone browsers are WebKit) ANY programmatic scrollLeft write kills the
  // inertial fling stone dead — even one meant for "scroll rest", because the
  // coalesced coast leaves a lull the 120ms idle mistakes for a stop. So on a
  // coarse pointer, when the reflow was triggered by a FLICK, we skip the
  // re-centre and let the coast run: the row still hides (the feature and the
  // manning counts are unchanged — only the visual re-centre is dropped), and
  // the worst case is a small one-time shift as a post-out boundary passes,
  // far better than the scroll dying on every flick.
  //
  // A programmatic JUMP is the exception (jumpAtRef): it has no fling to
  // protect and MUST re-centre, or a month button that crosses several post-out
  // boundaries lands its target well off the frozen edge. The two are
  // indistinguishable here — both arrive at scroll-rest — so jumpTo timestamps
  // itself and we treat a reflow inside that short window as a jump. A
  // mouse/trackpad (fine pointer, no touch inertia to protect) always
  // re-centres, so desktop is unchanged.
  useLayoutEffect(() => {
    // A month-strip jump that had to draw its month first lands here, in the
    // commit that drew it: the scroll the jump could not make yet.
    const pj = pendingJumpRef.current
    if (pj) {
      pendingJumpRef.current = null
      anchorRef.current = null
      const wrap = wrapRef.current, cell = headCell(pj)
      if (wrap && cell) {
        jumpAtRef.current = Date.now()
        wrap.scrollLeft += cell.getBoundingClientRect().left - wrap.getBoundingClientRect().left - frozenWidth(wrap)
      }
      return
    }
    const a = anchorRef.current
    anchorRef.current = null
    const colShift = colShiftRef.current
    colShiftRef.current = false
    if (!a) return
    const wrap = wrapRef.current
    const cell = headCell(a.date)
    if (!wrap || !cell) return
    const coarse = coarsePointer()
    // The window has to hold the programmatic scroll, the 120ms rest debounce
    // and the grid's repaint; 1200ms is comfortably clear of all three and
    // still far shorter than the gap before a deliberate follow-up flick.
    const fromJump = Date.now() - jumpAtRef.current < 1200
    if (coarse && !fromJump && !colShift) return
    const shift = cell.getBoundingClientRect().left - a.left
    if (Math.abs(shift) > 1) wrap.scrollLeft += shift
  }, [visWindow, colWin?.lo, colWin?.hi])

  // Reserve exactly the month strip's own height on its sticky cell, so the
  // wrapped rows (three on a phone, more at a high zoom) never overflow into
  // the bracket bar below (see mstrowRef above). Layout effect so the cell is
  // sized before paint — no flash of the collided state. Re-measures on the
  // zoom (which re-wraps the buttons), the war change, and a viewport resize.
  useLayoutEffect(() => {
    const measure = () => {
      const strow = mstrowRef.current, cell = mstickRef.current
      if (!strow || !cell) return
      const sr = strow.getBoundingClientRect()
      const cr = cell.getBoundingClientRect()
      if (sr.height === 0) return // jsdom / not laid out — leave the CSS floor
      // Screen px from the cell's top to the strip's bottom, + a little
      // breathing room, divided back out of the table zoom the cell sits in.
      // Floored at the desktop one-row height so a single-row strip never
      // shrinks the cell below what it was.
      setStripH(Math.max(44, (sr.bottom - cr.top + 6) / (zoom || 1)))
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [zoom, period.id, drawnDates.length])

  // ---- the OPEN-BIDDING box (owner, 1 Sep 26) -----------------------------
  // A glowing dark-green rectangle around the columns open for bidding, so it
  // is obvious at a glance which dates the squadron may bid on. Shown ONLY
  // while bidding is OPEN (stage 'open'); a draft / closed / published war
  // shows none — the box means "open right NOW". The span is the period's
  // bidFrom..bidTo (null bounds = the whole war open, so the box wraps every
  // column). The owner chose the deeper, more faded green over a brighter one.
  //
  // ONE absolutely-positioned overlay inside `.mx-wrap` (which is
  // position:relative), NOT per-cell borders: a single element gives the clean
  // continuous glow the owner approved, and — being part of the scroller's
  // own content — it tracks the horizontal scroll for FREE, so there is no
  // scroll handler and none of the fling-killing scrollLeft writes the rest of
  // this file guards against. Its z-index (1, matrix.css) sits it ABOVE the
  // day cells but BELOW the frozen callsign/counter columns (z 2/3) and the
  // scrolled-in band overlay (z 4), so its left edge hides behind them exactly
  // as a day cell does when the year scrolls under the frozen columns.
  // Measured in the same layout signals as the month strip; jsdom (every rect
  // 0×0) leaves it null, which also keeps every geometry-free test honest.
  const [bidBox, setBidBox] = useState<{ left: number; top: number; width: number; height: number; cutL: boolean; cutR: boolean } | null>(null)
  const measureBidBox = () => {
    const wrap = wrapRef.current, head = headRef.current
    if (!wrap || !head) return
    if (period.stage !== 'open') { setBidBox(prev => (prev ? null : prev)); return }
    const open = period.days.filter(d => inBidWindow(period, d.date))
    if (open.length === 0 || drawnDates.length === 0) { setBidBox(prev => (prev ? null : prev)); return }
    // Only the drawn part is measurable. A bound outside the window cuts that
    // side of the box (matrix.css .cut-l / .cut-r) — no false edge at the seam.
    const first = drawnDates[0]!, last = drawnDates[drawnDates.length - 1]!
    const shown = open.filter(d => d.date >= first && d.date <= last)
    if (shown.length === 0) { setBidBox(prev => (prev ? null : prev)); return }
    const cutL = open[0]!.date < first, cutR = open[open.length - 1]!.date > last
    const fh = headCell(shown[0]!.date)
    const lh = headCell(shown[shown.length - 1]!.date)
    const table = wrap.querySelector<HTMLElement>('table.mx')
    if (!fh || !lh || !table) return
    const wr = wrap.getBoundingClientRect()
    if (wr.width === 0) return // jsdom / not laid out — leave it null
    const fr = fh.getBoundingClientRect(), lr = lh.getBoundingClientRect()
    if (fr.width === 0) return
    const hr = head.getBoundingClientRect(), tr = table.getBoundingClientRect()
    // Content coordinates (add scrollLeft so the value is stable wherever the
    // grid is scrolled — the browser re-offsets the absolute child as it
    // scrolls). The header tbody top is the month-bracket row; the box runs
    // from there to the foot of the roster.
    const left = fr.left - wr.left + wrap.scrollLeft
    const right = lr.right - wr.left + wrap.scrollLeft
    const top = hr.top - wr.top
    const next = { left, top, width: right - left, height: tr.bottom - hr.top, cutL, cutR }
    setBidBox(prev => (prev && prev.left === next.left && prev.top === next.top && prev.width === next.width && prev.height === next.height && prev.cutL === next.cutL && prev.cutR === next.cutR ? prev : next))
  }
  measureBidBoxRef.current = measureBidBox // this render's, for `onArchiveChange`
  useLayoutEffect(() => {
    measureBidBox()
    window.addEventListener('resize', measureBidBox)
    return () => window.removeEventListener('resize', measureBidBox)
    // `version` is here because the box's HEIGHT is the whole table's: any
    // store change that adds or removes a ROW while a war is open — a counter
    // built or deleted, a member joining the roster, a CAT sub-heading
    // appearing — changes the table's height with every other dep unchanged,
    // and the box read one row short/long until the next zoom or resize
    // (bug-hunt fix, 1 Sep 26). Re-measuring on every store commit is four
    // rect reads against an identity-guarded setState — nothing next to the
    // repaint that same commit already paid for. The window's EDGES are deps
    // too, not only the drawn-day count (same reason as the strip effect
    // above: Mar+Apr and May+Jun both span 61 days, and the box is placed off
    // the first and last drawn day — bug-hunt fix, 6 Sep 26).
    // `figuresOpen` (6 Sep 26): the drawer grows the header row to 62px, so the
    // table is that much taller and the box would stand a header short.
    // `arranging` (7 Sep 26): Rearrange WIDENS the frozen name column
    // (`.mx-arranging` re-sets `--who-w`), pushing the day columns right — so
    // the box's LEFT edge, placed off the first day's header cell, must be
    // re-measured or it stays at its narrower-column position and hides behind
    // the now-wider frozen columns (z 2/3 paint over the box's z 1). The
    // owner saw exactly this: the left green border gone in Rearrange, the
    // right one fine (its edge is far from the frozen columns). Its two sibling
    // measure effects (the month strip, the frozen-mirror geometry) already
    // carry `arranging` for the same reason; this one had been missed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version, period.id, period.stage, period.bidFrom, period.bidTo, zoom, visWindow, drawnDates.length, colWin?.lo, colWin?.hi, countsOpen, folded, figuresOpen, arranging])

  // iOS WebKit settles the frozen-column width change a FRAME LATER than the
  // synchronous layout-effect above reads it: on LEAVING Rearrange the column
  // shrinks back (`--who-w`), but WebKit still reported the wider geometry when
  // the effect measured, so the box kept its wider left and its edge sat
  // displaced INTO the grid until the next scroll (owner, 7 Sep 26 — "after I
  // close rearrange icon I get this green border displaced"). Re-measure on the
  // next two frames, when the reflow has landed. The identity guard inside
  // `measureBidBox` (setBidBox bails when nothing moved) makes this a no-op
  // wherever the synchronous read already settled — Chromium here measures the
  // final geometry at once, so this only ever CORRECTS a stale read, never adds
  // a render. Keyed on `arranging` so it costs two frames on the toggle only.
  // (No WebKit in this container — verified not to regress Chromium; the fix
  // rides the owner's iPhone check.)
  useEffect(() => {
    let raf2 = 0
    const raf1 = requestAnimationFrame(() => { measureBidBox(); raf2 = requestAnimationFrame(measureBidBox) })
    return () => { cancelAnimationFrame(raf1); if (raf2) cancelAnimationFrame(raf2) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [arranging])

  // ---- the frozen roster columns, drawn ONCE (owner, 20 Aug 26 — the third
  // look at the sideways stutter) --------------------------------------------
  //
  // The callsign and counter columns were `position: sticky` on every one of
  // ~80 rows, and a sideways drag made the browser re-solve all ~160 of those
  // pins every frame — measured as the bulk of the per-frame cost the stutter
  // was made of. Instead the two columns are drawn a SECOND time, ONCE, in an
  // overlay that lives OUTSIDE `.mx-wrap` (the sideways scroller): a sideways
  // scroll never moves it and never re-solves anything, and the real columns
  // underneath are set free to scroll away. Because the overlay is a sibling of
  // the grid in the same page-flow box, it rides the page's own vertical scroll
  // with the grid for free — so the ONLY thing it must be told is where the
  // roster begins, one number, never read on scroll.
  //
  // Phone only, like the frozen header: the sideways stutter lives on the phone
  // and the desktop keeps its untouched sticky path. Suspended while ARRANGING
  // — that mode adds per-row drag handles the overlay does not carry, and it is
  // an admin edit, not the scroll-perf path.
  useEffect(() => {
    if (typeof window.matchMedia !== 'function') return
    const mq = window.matchMedia('(max-width: 700px)')
    const on = () => setPhone(mq.matches)
    on()
    mq.addEventListener?.('change', on)
    return () => mq.removeEventListener?.('change', on)
  }, [])

  const bandActive = phone && !arranging

  // ...and how TALL each of the overlay's rows must be. `bandTop` alone lines
  // its FIRST row up with the roster's; every row below that only stays in
  // step if the two tables agree on every height above it — and they do not.
  // A person row carrying a code chip in ANY of its 365 day cells is 23px
  // where an empty one is 22 (the chip's line box runs a pixel taller than the
  // balance cell's bare text), and the overlay draws no day cells at all, so
  // it cannot grow with it. The error is CUMULATIVE: measured on this
  // container's Chromium it reached 14px — most of a row — by the bottom of
  // the demo roster, which is the owner's 20 Aug 26 report of the names
  // sitting beside the wrong rows.
  //
  // So the overlay never GUESSES a row height, and this is deliberately not
  // fixed by making the grid's own rows uniform: that would be a bet on one
  // engine's line-box arithmetic, and the reverted column virtualisation
  // (HANDOFF) is this repo's standing lesson that two independently laid out
  // tables agree on nothing you have not measured. It copies the height the
  // real row actually took, on whatever engine is rendering — the same
  // discipline as the frozen header's measured colgroup above.
  //
  // `height` on a <tr> is a MINIMUM, which is all this needs: the overlay
  // draws a strict subset of the real row's content (the same two cells, minus
  // the personnel label, which is `display:none` on a phone anyway), so its
  // natural height is never the taller of the two.
  //
  // Written straight onto the nodes, never through state — a setState here
  // would re-render the ~25,000-node grid, the very cost this overlay exists
  // to remove. Every read is taken before any write, so one layout settles the
  // lot instead of thrashing row by row. Heights come back as VISUAL pixels,
  // so the table's `zoom` is divided out on the way in, exactly as the
  // mirror's measured column widths are.
  //
  // Two overlays need this now — the phone's frozen band and the figures
  // drawer (6 Sep 26) — so it takes the overlay, the box its twins live in and
  // the attribute naming each twin. The band's twins are the roster rows alone
  // (`rosterBodyRef`); the drawer also copies the EVENT rows, which sit in
  // their own tbody, so it hands over the whole table.
  const syncOverlayHeights = (overlay: HTMLElement | null, body: HTMLElement | null, keyAttr: string) => {
    if (!overlay || !body) return
    const rows = Array.from(overlay.querySelectorAll<HTMLTableRowElement>(`tbody.mxbody > tr[${keyAttr}]`))
    const want = rows.map(tr => {
      const key = tr.getAttribute(keyAttr)
      const real = key ? body.querySelector<HTMLElement>(`[data-testid="${key}"]`) : null
      return real ? real.getBoundingClientRect().height : 0
    })
    // jsdom reports every rect 0x0, and a row the window has filtered out has
    // no real twin at all; a 0 written here would collapse the overlay rather
    // than align it, so an unmeasurable row is left exactly as it was.
    rows.forEach((tr, i) => { if (want[i]! > 0) tr.style.height = `${want[i]! / zoom}px` })
  }
  const syncBandHeights = () => syncOverlayHeights(bandRef.current, rosterBodyRef.current, 'data-band-key')
  const syncDrawerHeights = () =>
    syncOverlayHeights(drawerRef.current, wrapRef.current?.querySelector<HTMLElement>('table.mx') ?? null, 'data-drawer-key')

  useLayoutEffect(() => {
    if (!bandActive) { setBandTop(null); return }
    const measure = () => {
      const outer = mxOuterRef.current, body = rosterBodyRef.current
      if (!outer || !body) return
      const br = body.getBoundingClientRect()
      if (br.height === 0) { setBandTop(null); return } // jsdom / not laid out
      setBandTop(br.top - outer.getBoundingClientRect().top)
      // A resize re-wraps nothing here, but it does change the day columns'
      // widths and so which rows carry a chip on screen at all; re-read the
      // heights on the same signal rather than waiting for a render that a
      // resize alone does not cause.
      syncBandHeights()
    }
    measure()
    // A row ABOVE the roster changing height (an event edited, the manning
    // block collapsed, the strip re-wrapped) moves the roster's top — catch it
    // without listing every cause. Never fires on a sideways scroll: that moves
    // no edge the observer watches.
    const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(measure) : null
    if (ro && mxOuterRef.current) ro.observe(mxOuterRef.current)
    window.addEventListener('resize', measure)
    return () => { ro?.disconnect(); window.removeEventListener('resize', measure) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bandActive, zoom, visWindow, period.id, drawnDates.length, countsOpen, folded])

  // ---- where the DRAWER sits (owner, 6 Sep 26) ------------------------------
  //
  // The same discipline as the band, one row higher: the drawer hangs off the
  // real HEADER row (not the roster), because it covers the header's day cells
  // with its own sideways titles. Four numbers, all measured: the header row's
  // top and the names column's right edge (where the closed counter column
  // begins, so the drawer's first column lands exactly on it and no box moves
  // when it opens), the header row's height (the real row GROWS to 62px for the
  // titles via `.mx-figures`, so the drawer is told what that came to rather
  // than repeating the arithmetic), and the drawer's own width and column
  // widths, which the stuck header's frozen copy needs to grow to match.
  //
  // The `.who` cell is read at whatever the sideways scroll has left it at —
  // it is sticky, so its right edge is the column's width wherever the year
  // sits. Heights come back as VISUAL pixels (the table wears the grid's
  // zoom), so `headH` divides it back out for a row inside the drawer's own
  // zoomed table, while `left`/`width` stay visual: the drawer's box is a plain
  // absolute div in `.mx-outer`, outside any zoom.
  useLayoutEffect(() => {
    if (!figuresOpen) { setDrawerAt(null); return }
    const measure = () => {
      const outer = mxOuterRef.current, head = headRef.current, drawer = drawerRef.current
      if (!outer || !head || !drawer) return
      const headRow = head.querySelector<HTMLElement>('tr:last-child')
      const who = headRow?.querySelector<HTMLElement>('th.who')
      if (!headRow || !who) return
      const hr = headRow.getBoundingClientRect(), o = outer.getBoundingClientRect()
      if (hr.height === 0) { setDrawerAt(null); return }   // jsdom / not laid out
      const next = {
        top: hr.top - o.top,
        left: who.getBoundingClientRect().right - o.left,
        headH: hr.height / zoom,
        width: drawer.getBoundingClientRect().width,
        cols: Array.from(drawer.querySelectorAll<HTMLElement>('th.fig')).map(th => th.getBoundingClientRect().width),
      }
      // Value-guarded: this runs from a ResizeObserver, and a fresh object every
      // time would re-render the grid on its own echo.
      setDrawerAt(prev => (prev && prev.top === next.top && prev.left === next.left && prev.headH === next.headH &&
        prev.width === next.width && prev.cols.length === next.cols.length && prev.cols.every((w, i) => w === next.cols[i])
        ? prev : next))
      syncDrawerHeights()
    }
    measure()
    const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(measure) : null
    if (ro && mxOuterRef.current) ro.observe(mxOuterRef.current)
    window.addEventListener('resize', measure)
    return () => { ro?.disconnect(); window.removeEventListener('resize', measure) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [figuresOpen, zoom, visWindow, period.id, drawnDates.length, countsOpen, folded, figures.length, arranging])

  // How wide the drawer came out, in the GRID's own pixels, published to the
  // stylesheet as `--drawer-w` — read by the month-bracket LABEL, which sticks
  // "just clear of the frozen columns" and has to be told that the frozen part
  // is now the drawer (`.mx-figures` override of `.brakl`, matrix.css). Without
  // it the label kept the closed pair's offset: on a desktop, where the drawer
  // opens open, it sat over the drawer's own columns un-stuck and vanished
  // under the opaque frozen copy of the stuck bar (6 Sep 26 review).
  //
  // A custom property on `.mx-outer` restyles the whole grid, and the standing
  // rule (CLAUDE.md, the column window) is that one must never ride a FRAME.
  // This one rides a MODE: `drawerAt` is value-guarded, so this runs on
  // open/close, a zoom step and a resize — the same taps that already toggle
  // `mx-figures` on this very node. A per-frame value must never join it here.
  useLayoutEffect(() => {
    const outer = mxOuterRef.current
    if (!outer) return
    if (!figuresOpen || !drawerAt) { outer.style.removeProperty('--drawer-w'); return }
    // Visual px in, grid px out: `--who-w` and the label's `left` live inside
    // the zoomed table, and the drawer's own box does not.
    outer.style.setProperty('--drawer-w', `${drawerAt.width / zoom}px`)
  }, [figuresOpen, drawerAt, zoom])

  // Re-pinned on EVERY render, not on a dependency list: a bid placed, a
  // decision made or a figure switched can put a chip into a day cell or take
  // one out, which moves that row's height by the pixel above — and there is
  // no cheap signal for "some cell's content changed". It is affordable
  // precisely because this component does NOT re-render on scroll (the reason
  // the overlay exists), so this runs on real edits, not on frames. Layout
  // effect, so the heights land in the same frame as the rows they answer.
  useLayoutEffect(() => {
    if (bandActive) syncBandHeights()
    if (figuresOpen) syncDrawerHeights()
  })

  /* The landing flash, in the SAME commit as the reorder (a dep list would run
     a frame late, an rAF after cfg.move() is not ordered against React's
     scheduler). Grid: the moved <tr> — keyed rows MOVE, they do not remount —
     measured against the outer and the wrap's visible span, exactly as at arm.
     List: the Settings row, found OUTSIDE the wrap because the grid's heading
     shares its data-grow. */
  useLayoutEffect(() => {
    const land = landRef.current
    if (!land) return
    landRef.current = null
    const outer = mxOuterRef.current, wrap = wrapRef.current
    if (land.surface === 'grid') {
      const row = wrap?.querySelector<HTMLElement>(land.sel)
      if (row && outer && wrap) frameLand(liftRef.current, boxOf(outer, row, wrap))
      return
    }
    const el = [...document.querySelectorAll<HTMLElement>(land.sel)].find(n => !wrap || !wrap.contains(n))
    // landOn takes `lift` and `lift-land` off itself before re-adding, so there
    // is nothing to clear first (review, 6 Sep 26 — the liftOff here was dead).
    if (el) landOn(el)
  })

  // The roster's row SEQUENCE — group headings, CAT sub-headings and people, in
  // display order — computed so the real grid and the frozen overlay draw the
  // SAME rows in the SAME order. The overlay must not invent its own order or
  // it would sit a row out of step with the grid; the frozencols order test
  // pins the two together. This mirrors the inline logic in the roster <tbody>
  // render below on purpose — change one and the test catches the other.
  type RSeq =
    | { kind: 'group'; g: string; label: string; n: number }
    | { kind: 'catsub'; g: string; cat: string }
    | { kind: 'person'; p: Person }
  const rosterSequence = (): RSeq[] => {
    const roster = displayRoster().filter(p => rowInWindow(p, visWinRef.current, rowSpans))
    const out: RSeq[] = []
    let prevG: string | null = null
    let prevCat = ''
    for (const p of roster) {
      const g = homeOf(p)
      if (g !== prevG) {
        out.push({ kind: 'group', g, label: labelOfGroup(g), n: roster.filter(x => homeOf(x) === g).length })
        prevG = g
        prevCat = ''
      }
      /* A FOLDED group keeps its heading and drops everything under it (owner,
         28 Aug 26 — "allow me to minimise categories on leave war"). The filter
         lives HERE, in the one sequence both the real grid and the frozen
         overlay read, so the two cannot fold out of step — the failure the
         frozen-column order test exists to catch. The heading's `· N` count is
         built from the unfiltered roster above, so a folded group still says
         how many people it is hiding. */
      if (folded.has(g)) continue
      /* CAT sub-headings belong to the two built-in OPS groups only — a person
         drawn under a QUALIFICATION group is not "in CAT B" for display
         purposes, and a CAT rule inside a qual heading would read as a claim
         about the qualification. */
      const cat = (g === 'OPSP' || g === 'OPSW') ? opsCatOf(p) : ''
      if (cat && cat !== prevCat) { out.push({ kind: 'catsub', g, cat }); prevCat = cat }
      out.push({ kind: 'person', p })
    }
    return out
  }

  // The DRAWER's rows, in the same grid order, each keyed to the real row's own
  // testid so its height can be copied across (`syncOverlayHeights`). The
  // drawer starts at the header row, so what it covers is the event lines and
  // then the roster — an event line and a heading show one empty box across the
  // block, since neither has a figure. Read from `rosterSequence` for the same
  // reason the band does: one order, so the two cannot fall out of step.
  const drawerRows = (): DrawerRow[] => [
    ...Array.from({ length: eventRows }, (_, line) => ({ kind: 'blank' as const, key: `event-row-${line}` })),
    ...rosterSequence().map((item): DrawerRow =>
      item.kind === 'group' ? { kind: 'group', key: `group-${item.g}`, folded: folded.has(item.g) }
        : item.kind === 'catsub' ? { kind: 'catsub', key: `subcat-${item.g}-${item.cat}` }
          : { kind: 'person', key: `row-${item.p.id}`, p: item.p, me: item.p.id === viewer }),
  ]

  // The under-manned list asks for a day the same way the month strip asks
  // for a month, through the one `jumpTo` above — so a target lands clear of
  // both frozen columns without that measurement existing twice.
  //
  // Keyed on `focusSeq` rather than `focusDate`: choosing the same day again
  // has to snap back to it after the grid has been dragged away, and a date
  // alone cannot express that. jsdom reports every rect as 0, which makes the
  // jump a harmless no-op there; the browser gate is what proves it moves.
  useEffect(() => {
    if (focusDate) jumpTo(focusDate)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusSeq, focusDate])

  // Every "may this be written" question now goes through `canEditCell`,
  // which folds the stage, the role and the bidding window into one answer
  // for one date. `canEdit` is what the stage strip and the role toggle ask —
  // "is the sheet writable at all" — and has no date to narrow itself with.
  const deciding = canDecide(period.stage, role)

  // The dotted-orange "moved" mark is only meaningful once bidding has CLOSED
  // (owner, 27 Aug 26). While a war is still open for bidding, people shuffle
  // their own bids around freely — a moved mark on every re-placed bid is just
  // noise. It becomes worth showing only after close, when a shift is the
  // admin deliberately moving someone's input off the date they bid. This gates
  // the DISPLAY; the store gates the RECORD (an open move stores no shiftedFrom
  // at all, so a bid moved while open stays clean even after the war closes) —
  // one `biddingClosed` body behind both so the two cannot disagree.
  const movedShown = biddingClosed(period.stage)

  // Published-stage remarks editor (owner, 27 Aug 26 — "after the leave war is
  // published … click on their inputs … and edit the remarks. but the admin
  // can also … the same for all"). A click on an approved leave at PUBLISHED
  // opens the note editor for the run's OWN person (a member editing their own
  // leave) or for an admin (anyone). `viewer` is the war's mirror of Raptor's
  // "view as" — the member's own person. It takes precedence over the
  // read-only Raptor sheet and the bid/decision sheets below, and exists only
  // at published; `leaveInputAt` runs once per open cell, never per grid cell.
  const remarkRow = open && period.stage === 'published'
    ? leaveInputAt(open.id, open.date, grid[open.id]?.[open.date])
    : null
  /* [ARCH-STACK] step 4 — a day holding more than one record (the corner
     mark), or leave dated outside the person's time in the squadron (owner
     answer C), opens THE TAP LIST: every record on its own line with its own
     actions (design §25 OA10-001). It comes before every single-record sheet
     below, which stay exactly as they were for a one-record day. */
  const openView = open ? views[open.id]?.[open.date] : undefined
  const listOpen = !!open && !!openView && (openView.mark !== '' ||
    (!!openPerson && !inSquadron(openPerson, open.date) && !!openView.main && codeOf(openView.main.code)?.spends != null))
  const canRemark = !listOpen && !!remarkRow && (role === 'admin' || (!!open && open.id === viewer))
  /* THE FREE HALF BESIDE INPUTS-FILED LEAVE (CURRENT-STATE item D). When the
     cell is locked to the Inputs page but only HALF of it is actually spoken
     for, the tap opens the bid picker on the free half instead of the
     read-only sheet — with the locked half named on it, so nothing about the
     lock becomes invisible. Everything else about a Raptor-owned cell is
     unchanged: both halves held, or nobody who may edit, and the read-only
     sheet opens exactly as it did. */
  /* The OIL AWARD on the open cell, for the +OIL panel to name and change — when the day holds exactly ONE (a day
     holding several is changed from the day's list, one at a time; `openAwards` counts them). A credit the published
     schedule earned is the schedule's to change. Awards are ledger entries drawn on the day ([OIL-AWARD-IS-A-GRANT]). */
  const openAwards = open ? awardsOnDay(open.id, open.date) : []
  const openCredit = openAwards.length === 1 ? oilOnDay(open!.id, open!.date).find(c => c.award) : undefined
  /* EVERY credit on the open cell, schedule's first, then the awards — what the day window reads back on one click
     (owner, 21 Sep 26). The read-only schedule sheet reads the SCHEDULE's own (Fable's plan read N3). */
  const openOil = open ? oilOnDay(open.id, open.date) : []
  const openAnyCredit = openOil[0]
  /* A DAY THE SCHEDULE HAS ALREADY EARNED ON STILL TAKES AN AWARD (N16,
     21 Sep 26). The owner ruled the two add up and that the same two facts
     must not be kept or lost depending on which was entered first. The STORE
     obeys that — but the screen did not: a day holding only the schedule's
     credit reads as Raptor's, so the tap opened the read-only sheet, which
     has no +OIL control and no other door offers one. Award-then-publish
     worked; publish-then-award was unreachable, so half the ruling existed
     only in the tests. Found by review and confirmed in the running app.
     Admin only, and only when the day holds no LEAVE the Inputs page owns —
     that cell is still the Inputs page's to change. */
  const openWorkOnly = !!open && !!openView && role === 'admin'
    && openView.all.length > 0 && openView.all.every(c => c.kind === 'credit')
    && !openView.all.some(c => c.kind === 'credit' && !c.auto)
  const openFreeHalf = open && raptorOwns(states, open.id, open.date)
    && canEditCell(period, role, open.date) && canEditRow(role, viewer, open.id)
    ? freeHalfBeside(openView)
    : null

  // Which sheet a click opens follows from three things: the stage, the role,
  // and what the cell already holds.
  //
  // A cell Raptor owns always opens, at every stage and for either role, but
  // only ever onto the read-only sheet — a member who cannot edit anything
  // still deserves to be told why that particular cell is green and why
  // nothing here will change it.
  //
  // Deciding needs an existing bid to decide: a course, a sick day and an
  // empty cell are all things nobody asked for.
  // "Does a tap here open something" lives in `cellOpenable` (module level, the
  // row's own body) — the comment block above is its rationale.

  // A day the squadron may not bid on, drawn as such. Without this the window
  // is invisible: a member taps an October cell, nothing happens, and the app
  // reads as broken rather than as closed. Admin sees no lock — the window
  // does not bind them, so drawing one would be a lie about their own screen.
  // A Set per store change rather than a predicate per cell (3 Sep 26): the
  // cells asked this ~18,000 times per build, once per person per day, when
  // the answer only varies by DAY — 365 answers. Also a stable row prop.
  const lockedCols = useMemo(() => {
    const out = new Set<string>()
    for (const d of period.days) if (!canEditCell(period, role, d.date)) out.add(d.date)
    return out
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version])
  const lockedDate = (date: string): boolean => lockedCols.has(date)

  // Feed the drag-select controller live state. A member may DRAG only while
  // the war is OPEN (batch fill). The published remarks editor is a SINGLE
  // click, not a drag — a block of runs has no one note to edit — so a member
  // still cannot drag at published. An admin may drag at every stage.
  selCtxRef.current = {
    // A member drags only WITHIN their own row: the rectangle's rows come from
    // this list, so limiting it to the viewer keeps a member's drag on their
    // own row (a date range still selects freely along it) while an admin
    // drags across everyone (owner, 27 Aug 26). The write path refuses other
    // rows regardless; this is what keeps the SELECTION itself from spanning
    // rows a member could never fill, so no confusing "skipped" appears.
    order: () => rosterSequence()
      .filter(r => r.kind === 'person')
      .map(r => (r as { p: Person }).p.id)
      .filter(id => canEditRow(role, viewer, id)),
    dates: () => drawnDates,
    enabled: () => !arranging && !moveSel && !eventMoveSel && (role === 'admin' || period.stage === 'open'),
    onSelect: s => setSel(s),
    // Events are the admin's (the store refuses a member write anyway); a drag
    // along one event line opens the event sheet pre-set to that date span
    // (owner, 27 Aug 26). from === to (a one-cell drag) opens on the single day.
    eventsEnabled: () => role === 'admin' && !arranging && !moveSel && !eventMoveSel,
    onEventSelect: s => setEventEdit({ line: s.line, date: s.from, to: s.from === s.to ? undefined : s.to }),
    // The days begin past the frozen block — the name/counter pair, or the
    // drawer while it is open (frozenWidth is already drawer-aware).
    //   No wrap means nothing to measure, and `0` would be a LIE the band could
    // act on — a real client-x at the screen's left edge. `-Infinity` is the
    // only value that reads as "no left band", and the `??` at the wiring site
    // cannot rescue it for us: `0` is not nullish, so it would pass straight
    // through (review, 6 Sep 26).
    leftEdge: () => { const w = wrapRef.current; return w ? w.getBoundingClientRect().left + frozenWidth(w) : -Infinity },
  }

  // ...and the FIGURE drag the same way (owner, 6 Sep 26): a run of people down
  // one figure column, for the docked balance bar. The admin's alone — a member
  // never keys a balance — and never while another gesture holds the grid.
  figSelCtxRef.current = {
    order: () => rosterSequence().filter(r => r.kind === 'person').map(r => (r as { p: Person }).p.id),
    selectable: id => selectableFigure(figures.find(f => f.id === id)),
    enabled: () => role === 'admin' && !arranging && !moveSel && !eventMoveSel,
    // A second drag in the SAME pool adds to the selection; one in another pool
    // starts over (owner, 6 Sep 26 — one pool per drag).
    onSelect: s => setFigSel(prev => (prev && prev.fig === s.fig ? { fig: s.fig, ids: [...new Set([...prev.ids, ...s.ids])] } : s)),
  }
  // The selection in roster order, and its figure — consumed by the balance bar
  // (Task 3), which is where they are read; computed here because this is where
  // the roster order and the live figure list are. A figure hidden after the
  // drag, or a person gone from the roster, drops out.
  const figSelFigure = figSel ? figures.find(f => f.id === figSel.fig) : undefined
  const figSelIds = figSel ? figSelCtxRef.current.order().filter(id => figSel.ids.includes(id)) : []
  const csOf = (id: string): string => displayRoster().find(p => p.id === id)?.callsign ?? id

  return (
    <div className="stage">
      <div className="card" ref={cardRef}>
        {/* ONE compact row (owner, 5 Sep 26 — "all in 1 row to minimise row
            height space"): Manning · ⚙ · Rearrange on the left, OIL tracker on
            the right. The old "JAN – DEC 26 · 365 days · 50 people" line was
            dropped (owner, same day); the war's NAME still lives in the Period
            picker in the page chrome above, so nothing is stranded. */}
        <div className="card-hd">
          {/* Manning LEADS the row, sitting directly above the counter rows it
              shows/hides (owner, 5 Sep 26 — "move the manning to be infused with
              the counter rows … still with a drop down"). EITHER role (owner,
              19 Aug 26); a plain view toggle, above the scroll so it does not
              ride the grid it hides. */}
          <button
            className="rtbtn countstoggle"
            data-testid="counts-toggle"
            aria-expanded={countsOpen}
            title={countsOpen ? 'Hide the manning counts' : 'Show the manning counts'}
            onClick={() => setCountsOpen(o => !o)}
          >
            {countsOpen ? '▾' : '▸'} Manning
          </button>
          {role === 'admin' && (
            <>
              {/* ONE ⚙ SETTINGS button (owner, 3 Sep 26). Every admin CONFIG
                  control — counters, event rows, Show SANS, the roster groups —
                  folds into the sheet it opens. */}
              <button
                className="rtbtn gear"
                data-testid="settings-open"
                title="Settings — counters, event rows and roster groups"
                aria-label="Settings — counters, event rows and roster groups"
                onClick={() => setSettings(true)}
              >
                ⚙
              </button>
              {/* REARRANGE toggle — moved here from the grid corner (owner, 5 Sep
                  26 — "the rearrange button goes after [settings]"). The actual
                  rearranging is HANDS-ON-GRID: this only turns the on-grid drag
                  handles on and off, and it is the ONE way in and out (owner,
                  6 Sep 26 — "delete this whole blue section … when I click on it,
                  it exits the rearrange mode"): the old strip under the header
                  (Auto-sort + Done) is gone. Lights accent (`.on`) while live so
                  it is obvious the handles are on and that tapping again leaves.
                  On a phone it is the ⇅ icon alone (the word rides `.rtlbl`,
                  hidden ≤430px — "just show an arrow up and down icon"); desktop
                  keeps the word. Admin only. */}
              <button
                className={`rtbtn${arranging ? ' on' : ''}`}
                data-testid="roster-arrange"
                aria-pressed={arranging}
                aria-label={arranging ? 'Finish rearranging the roster' : 'Rearrange the roster'}
                title={arranging ? 'Finish rearranging — tap again to leave' : 'Rearrange the roster — drag people and category blocks'}
                onClick={() => setArranging(a => !a)}
              >
                ⇅<span className="rtlbl"> {arranging ? 'Rearranging' : 'Rearrange'}</span>
              </button>
            </>
          )}
          {/* The OIL TRACKER (owner, 2 Sep 26): every person's OIL balance, the
              ledger behind each, and the admin's crediting. BOTH roles — a member
              reads, an admin edits; the sheet decides which controls to draw and
              the store refuses a member's write. It sits RIGHT AFTER the last
              control, not pushed to the far edge (owner, 5 Sep 26 — "the oil
              tracker can be right of rearrange … in normal user it's just right
              of manning"): no spring, so admin reads Manning · ⚙ · Rearrange · OIL
              and a member reads Manning · OIL, each cluster left. "tracker" drops
              on a phone (`.rtlbl`) so the row still holds one line. */}
          <button
            className="rtbtn"
            data-testid="oil-tracker"
            title="OIL balances, credits and history"
            onClick={() => setOilTracker({ person: null })}
          >
            ◷ OIL<span className="rtlbl"> tracker</span>
          </button>
          {/* The grid ZOOM, − then +, right after OIL at BOTH widths (owner,
              6 Sep 26 — "put the zoom + - button after oil/oil tracker. But
              make sure it's still 1 row on the mobile"). Both roles — it is a
              view control. Moved here from the end of the month strip, where
              it was phone-only; the strip's tests and readers treat every
              button there as a month, so it never belonged among them. A
              phone opens one step out (see `zoom`). */}
          <span className="lwzoom" data-testid="lw-zoom">
            <button
              className="rtbtn zoom"
              data-testid="lw-zoom-out"
              aria-label="Zoom out"
              title="Zoom out"
              disabled={zoom === ZOOMS[0]}
              onClick={() => zoomStep(-1)}
            >−</button>
            <button
              className="rtbtn zoom"
              data-testid="lw-zoom-in"
              aria-label="Zoom in"
              title="Zoom in"
              disabled={zoom === ZOOMS[ZOOMS.length - 1]}
              onClick={() => zoomStep(1)}
            >＋</button>
          </span>
        </div>
        {/* The on-grid REARRANGE BAR (3 Sep 26: "⠿ Rearranging — drag people…",
            Auto-sort, Done) is GONE (owner, 6 Sep 26 — "delete this whole blue
            section when rearrange is selected. Auto sort will be removed"). The
            header toggle above is the way in and out; the store's
            `autoSortRoster` stays for the tests and a future home. Don't bring
            the strip back — it cost a row of height on a phone for a sentence.
            `mx-arranging` (admin Rearrange) widens the frozen NAME column by the
            grip's footprint so callsigns read whole beside the ⠿ (owner, same
            day — "the CS/name will not be causing the puck names to be
            shortened … same as before rearrange was selected"): a class on this
            wrapper, like `mx-banded`, which the same tap already toggles on a
            phone — one restyle per mode change, never per frame. */}
        <div
          /* `mx-figures` grows the real header row to the sideways titles'
             height while the drawer is open (matrix.css), so the drawer's rows
             and the day rows beside it stay level. One class toggled on
             open/close — the same "one restyle per mode change, never per
             frame" footing as `mx-banded` and `mx-arranging`. */
          className={`mx-outer${bandActive && bandTop != null ? ' mx-banded' : ''}${sdaActive ? ' lw-sda' : ''}${arranging && role === 'admin' ? ' mx-arranging' : ''}${figuresOpen ? ' mx-figures' : ''}`}
          ref={mxOuterRef}
        >
        <div
          className="mx-wrap"
          ref={wrapRef}
          onScroll={onWrapScroll}
          onTouchStart={onTouchStart}
          onTouchEnd={onTouchEnd}
        >
          <table className="mx" style={zoomStyle}>
            {/* THE ROW ORDER IS THE OWNER'S (18 Aug 26, arrows on a
                screenshot): counts first, then the month buttons, then the
                callsign + dates header, then the event rows, then the roster.
                The header row is a tbody (`.mxhead`), not a thead — CSS
                paints a thead at the TOP of the table wherever it sits in
                the DOM, which would undo this whole arrangement. */}
            {/* Collapsed away on the view toggle, but always shown while an
                admin is Rearranging — that is where the per-row reorder / hide
                controls live, and hiding the block would hide them too. */}
            {(countsOpen || (arranging && role === 'admin')) && (
              <CountRows
                verdicts={verdicts}
                dates={drawnDates}
                order={orderedManningIds()}
                hidden={manningHidden}
                arranging={arranging}
                admin={role === 'admin'}
                onInfo={setManningInfo}
                onRowDragStart={(e, ruleId) => startRowDrag(e, ruleId, MANNING_DRAG)}
                draggingId={draggingId}
                dragOver={dragOver}
                dragAfter={dragAfter}
                padL={padL}
                padR={padR}
                phL={phL}
                phR={phR}
                onArchiveChange={onArchiveChange}
              />
            )}
            {/* The month strip, now a row of the grid so it sits between the
                counts and the header (owner's arrows). The buttons live in a
                sticky two-column cell and overflow visibly across the fill
                cell — the grphd technique — so they stay pinned to the left
                edge while the year scrolls under them. */}
            <tbody className="mstripe">
              <tr>
                <td className="mstick" colSpan={2} ref={mstickRef} style={stripH ? { height: stripH } : undefined}>
                  {/* The strip cancels the grid's zoom (6 Sep 26): it is
                      navigation chrome, not grid content, and once a phone
                      opened one step out its 9px labels rendered at ~7px and
                      "MAR"/"NOV" clipped on a 360px phone. Nested `zoom`
                      multiplies, so 1/zoom here puts the strip back at natural
                      size at every step; `stripH` still divides by the grid's
                      zoom because the cell it sizes is in the grid's units. */}
                  <div className="mstrow" ref={mstrowRef} style={zoom !== 1 ? { zoom: 1 / zoom } : undefined}>
                    <div className="months" data-testid="month-strip" ref={monthsRef}>
                      {months.map(m => (
                        <button
                          key={m.first}
                          className={`mjump${m.label === inViewRef.current ? ' on' : ''}`}
                          data-testid={`month-${m.label.replace(' ', '-')}`}
                          aria-current={m.label === inViewRef.current ? 'true' : undefined}
                          title={`Jump to ${m.label}`}
                          onClick={() => jumpTo(m.first)}
                        >
                          {m.label}
                        </button>
                      ))}
                    </div>
                    {/* The zoom pair used to ride the end of this strip
                        (phone-only); it moved to the counter block's top row
                        after OIL (owner, 6 Sep 26), which is what freed the
                        strip to hold all twelve months on ONE line on a phone. */}
                  </div>
                </td>
                <td className="mfill" colSpan={dayCols} />
              </tr>
            </tbody>
            <tbody className="mxhead" ref={headRef}>
              {bracketRow(true)}
              {headerRow(true)}
            </tbody>
            {/* Above the roster, below the header — an event is the REASON a
                day is thin, so it reads right under the date it explains. */}
            <EventRows
              days={drawnDays}
              bands={period.bands}
              defs={eventDefs}
              rows={eventRows}
              editable={role === 'admin'}
              /* ONE MOVE AT A TIME (Astra's final read, 1, 27 Sep 26): with a chip picked up, a tap on an event row opened
                 its sheet, whose Move started a SECOND move — and one click then moved both. While any move is on, the
                 event rows open nothing. */
              onEdit={(line, date) => { if (moveSel || eventMoveSel) return; setEventEdit({ line, date }) }}
              padL={padL}
              padR={padR}
              phL={phL}
              phR={phR}
            />
            <tbody className="mxbody" ref={rosterBodyRef}>
              {(() => {
                // The roster in DISPLAY order (owner, 18 Aug 26): the admin's
                // hand-order, or the categorised default. A group heading is
                // emitted at every top-level boundary, and a CAT sub-heading
                // inside an ops group — the sub-heading is desktop-only in CSS,
                // per the owner ("if it takes up too much space on mobile…").
                //
                // FILTERED to the visible month window (owner, 19 Aug 26 —
                // rowInWindow above): the heads/counts below derive from the
                // filtered list, so an emptied group takes its heading with
                // it. visWindow '' (jsdom, first paint) shows everyone.
                const roster = displayRoster().filter(p => rowInWindow(p, visWinRef.current, rowSpans))
                const span = 2 + dayCols
                let prevG: string | null = null
                let prevCat = ''
                return roster.map(p => {
                  const g = homeOf(p)
                  const heads: any[] = []
                  if (g !== prevG) {
                    const n = roster.filter(x => homeOf(x) === g).length
                    heads.push(
                      <tr key={`grp-${g}`} className={`grp ${groupClass(g)}${folded.has(g) ? ' folded' : ''}${draggingId === g ? ' dragging' : ''}${dragOver === g && draggingId !== g ? (dragAfter ? ' dragover after' : ' dragover') : ''}`} data-testid={`group-${g}`} data-grow={arranging && g !== OTHER_ID && g !== SANS_GROUP_ID ? g : undefined}>
                        {/* The label sits in a sticky td spanning only the two
                            frozen columns — the SAME technique .who/.bal use —
                            so it stays pinned to the left as the year scrolls;
                            its text overflows visibly over the empty fill cell
                            beside it. (A sticky div inside a full-width colSpan
                            td does not stick — it rides off to the right.)

                            The TD is the fold target, not the div inside it:
                            `.grphd-in` is deliberately `width: 0` (it must add
                            no min-width, or the frozen callsign column grows to
                            fit "Personnel · N"), and a zero-width control cannot
                            be tapped. Same reasoning as the balance cell, where
                            the td is the target so a nested button cannot cost
                            the column its number. */}
                        <td
                          className="grphd"
                          colSpan={2}
                          data-testid={`groupfold-${g}`}
                          role="button"
                          tabIndex={0}
                          aria-expanded={!folded.has(g)}
                          aria-label={`${labelOfGroup(g)} — ${folded.has(g) ? 'show' : 'hide'} these rows`}
                          title={folded.has(g) ? `Show the ${labelOfGroup(g)} rows` : `Hide the ${labelOfGroup(g)} rows`}
                          onClick={() => toggleFold(g)}
                          onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleFold(g) } }}
                        >
                          <div className="grphd-in">
                            {/* The category-heading drag grip (owner, 3 Sep 26 —
                                reorder the blocks on the grid). Only while
                                rearranging, and only for a movable group (not the
                                auto SANS group, not Everyone-else). Its pointerdown
                                starts the drag and its click is swallowed, so a tap
                                on the grip never folds the group. */}
                            {arranging && g !== OTHER_ID && g !== SANS_GROUP_ID && (
                              <span
                                className="ghd-grip"
                                data-testid={`gdrag-${g}`}
                                title={`Drag to move ${labelOfGroup(g)}`}
                                style={{ touchAction: 'none' }}
                                onPointerDown={e => { e.stopPropagation(); startRowDrag(e, g, GROUP_DRAG) }}
                                onClick={e => e.stopPropagation()}
                              >⠿</span>
                            )}
                            <span className="gsw" aria-hidden="true" style={groupColorOf(g, groupColors) ? { background: groupColorOf(g, groupColors) } : undefined} />
                            <span className="gcar" aria-hidden="true">{folded.has(g) ? '▸' : '▾'}</span>
                            <span className="gname">{labelOfGroup(g)}</span>
                            <span className="gcount">· {n}</span>
                          </div>
                        </td>
                        <td className="grpfill" colSpan={span - 2} />
                      </tr>,
                    )
                    prevG = g
                    prevCat = ''
                  }
                  /* Folded: the heading stands alone and everything under it is
                     dropped (owner, 28 Aug 26). The first person of the group
                     still emits the heading collected above; the rest emit
                     nothing. `rosterSequence` applies the identical filter, so
                     the frozen overlay folds in lockstep. */
                  if (folded.has(g)) {
                    return heads.length ? <Fragment key={p.id}>{heads}</Fragment> : null
                  }
                  const cat = (g === 'OPSP' || g === 'OPSW') ? opsCatOf(p) : ''
                  if (cat && cat !== prevCat) {
                    heads.push(
                      <tr key={`sub-${g}-${cat}`} className="catsub" data-testid={`subcat-${g}-${cat}`}>
                        <td className="catsub-in" colSpan={2}>CAT {cat}</td>
                        <td className="catsub-fill" colSpan={span - 2} />
                      </tr>,
                    )
                    prevCat = cat
                  }
                  return (
                    <Fragment key={p.id}>
                      {heads}
                      {/* The row itself is a memoised component (3 Sep 26):
                          opening a sheet, hovering a chip or dragging a row
                          used to rebuild all ~18,000 cells; now only a row
                          whose own inputs changed repaints. Every store
                          change still repaints every row via `version`. */}
                      <PersonRow
                        p={p}
                        version={version}
                        period={period}
                        monthDays={drawnMonthDays}
                        grid={grid}
                        states={states}
                        views={views}
                        role={role}
                        viewer={viewer}
                        deciding={deciding}
                        movedShown={movedShown}
                        shown={shown}
                        figureCtx={figureCtx}
                        figSel={figSel && figSel.fig === shown.id && figSel.ids.includes(p.id) ? shown.id : null}
                        evKind={evKind}
                        lockedCols={lockedCols}
                        quals={qualsOf.get(p.id) ?? NO_QUALS}
                        me={p.id === viewer}
                        arranging={arranging}
                        dragging={draggingId === p.id}
                        over={draggingId && dragOver === p.id && draggingId !== p.id ? (dragAfter ? 'dragover after' : 'dragover') : ''}
                        api={rowApi}
                        padL={padL}
                        padR={padR}
                        phL={phL}
                        phR={phR}
                      />
                    </Fragment>
                  )
                })
              })()}
            </tbody>
          </table>
          {/* The open-bidding box (see measureBidBox). A sibling of the table
              inside `.mx-wrap`, so it scrolls sideways with the grid; null
              unless bidding is open and laid out. */}
          {bidBox && (
            <div
              className={`lw-bidbox${bidBox.cutL ? ' cut-l' : ''}${bidBox.cutR ? ' cut-r' : ''}`}
              data-testid="bid-box"
              aria-hidden="true"
              style={{ left: bidBox.left, top: bidBox.top, width: bidBox.width, height: bidBox.height }}
            />
          )}
        </div>
        {/* The phone's frozen header — the fixed mirror described above the
            sticky machinery. Sits under the top bar (z 55 < the bar's 60 and
            the sheets' 79/80) and never renders in jsdom, where nothing has
            a height to scroll past. */}
        {stuck && ((s: { top: number; left: number; width: number; cols: number[] }) => {
          // The drawer's titles ride the FROZEN copy alone, never the scrolling
          // layer (6 Sep 26). The scrolling layer's day columns are glued to the
          // grid's own — by a translate on the compositor, or by a copied
          // scrollLeft — so its geometry has to stay the grid's: give it the
          // drawer's seven extra columns and every date in the bar would sit
          // that far right of the column it names. The frozen copy is clipped to
          // its own width and carries no day columns anyone can see, so it is
          // free to be as wide as the drawer.
          const mirrorDrawer = figuresOpen && !!drawerAt && drawerAt.cols.length === figures.length
          const colsFor = (drawer: boolean) =>
            drawer ? [s.cols[0] ?? 0, ...drawerAt!.cols, ...s.cols.slice(2)] : s.cols
          // The measured widths are visual px (they include the zoom), and the
          // mirror table wears the same zoom so its text sizes match — so its
          // layout widths are the measurements divided back out, or the zoom
          // would apply twice.
          const table = (extra: string, drawer = false) => {
            const cols = colsFor(drawer)
            return (
              <table
                className={`mx${extra ? ' ' + extra : ''}`}
                style={{ tableLayout: 'fixed', width: cols.reduce((a, b) => a + b, 0) / zoom, ...(zoomStyle ?? null) }}
              >
                <colgroup>
                  {cols.map((w, i) => (
                    <col key={i} style={{ width: w / zoom }} />
                  ))}
                </colgroup>
                <tbody className="mxhead">
                  {bracketRow(false, drawer)}
                  {headerRow(false, drawer)}
                </tbody>
              </table>
            )
          }
          return (
            <div
              className="mxfixed"
              data-testid="sticky-head"
              style={{ top: s.top, left: s.left, width: s.width }}
            >
              {/* The scrolling layer. In the JS-mirror fallback this is a real
                  horizontal scroller (matrix.css) and `syncMirror` writes its
                  scrollLeft. In the scroll-driven path (`.lw-sda`) it does not
                  scroll — the `.mxfixed-anim` table inside is TRANSLATED by the
                  grid's scroll timeline on the compositor, so it stays glued to
                  the grid during a fling with no main-thread follow. */}
              <div className={`mxfixed-scroll${sdaActive ? ' mxfixed-track' : ''}`} ref={mirrorRef}>
                {table(sdaActive ? 'mxfixed-anim' : '')}
              </div>
              {/* The bar's frozen LEFT columns, in the scroll-driven path only.
                  A translated table cannot keep `position: sticky`, so the
                  callsign + counter columns are drawn as a static copy pinned
                  over the left and clipped to their own width; the day columns
                  translate UNDER it. It is the tappable/opaque copy (the counter
                  picker still works while scrolled); the scrolling layer's own
                  who/bal are made pointer-events:none in matrix.css so taps land
                  here, and this copy is aria-hidden so the scrolling layer stays
                  the single accessible one. */}
              {sdaActive && (
                <div
                  className="mxfixed-frozen"
                  aria-hidden="true"
                  /* VISUAL px, NOT divided by the zoom (owner's iPhone, 6 Sep 26 —
                     the stuck bar showed the hatched filler / "MON 27" / "JAN 01"
                     right after LVE BAL, out of step with the grid). This box is
                     a plain div beside the track, outside any zoomed table — only
                     the <col>s INSIDE it live in zoomed space and take the
                     division. Divided, it was 25% too wide at the phone's 0.8
                     (131px against the grid's 107) and revealed the copy's third
                     cell; at 1.2 it would clip the balance column. Latent since
                     the zoom shipped, surfaced by the one-step-out default.
                     While the DRAWER is open the frozen pair IS the drawer, so
                     the clip runs to the drawer's own right edge — measured in
                     the same visual pixels, off the same box. */
                  style={{ width: mirrorDrawer ? drawerAt!.left + drawerAt!.width : (s.cols[0] || 0) + (s.cols[1] || 0) }}
                >
                  {table('', mirrorDrawer)}
                </div>
              )}
            </div>
          )
        })(stuck)}
        {/* The frozen roster columns, drawn once. Sibling of `.mx-wrap`, not a
            child — a child would ride the sideways scroll it exists to sit out.
            aria-hidden and its buttons out of the tab order: the REAL columns
            underneath (scrolled off to the left, still in the DOM) keep the
            testids, focus order and screen-reader seat; this copy only has to
            be tappable where the year has scrolled the real ones away. */}
        {bandActive && (
          <div
            className="mxband"
            ref={bandRef}
            aria-hidden="true"
            data-testid="frozen-cols"
            style={{ top: bandTop ?? 0, ...(bandTop == null ? { visibility: 'hidden' as const } : null) }}
          >
            <table className="mx" style={zoomStyle}>
              <tbody className="mxbody">
                {rosterSequence().map(item => {
                  if (item.kind === 'group') return (
                    /* The overlay's own copy of the heading, and it carries the
                       fold handler too: once the year has scrolled sideways the
                       overlay is `pointer-events: auto` and is the copy the
                       reader can actually tap (the real heading has slid away
                       under it). No role/tabIndex here — the whole band is
                       aria-hidden and the real heading above is the accessible
                       control. */
                    <tr key={`b-grp-${item.g}`} data-band-key={`group-${item.g}`} className={`grp ${groupClass(item.g)}${folded.has(item.g) ? ' folded' : ''}`}>
                      <td className="grphd" colSpan={2} onClick={() => toggleFold(item.g)}>
                        <div className="grphd-in">
                          <span className="gsw" style={groupColorOf(item.g, groupColors) ? { background: groupColorOf(item.g, groupColors) } : undefined} />
                          <span className="gcar">{folded.has(item.g) ? '▸' : '▾'}</span>
                          <span className="gname">{item.label}</span>
                          <span className="gcount">· {item.n}</span>
                        </div>
                      </td>
                    </tr>
                  )
                  if (item.kind === 'catsub') return (
                    <tr key={`b-sub-${item.g}-${item.cat}`} data-band-key={`subcat-${item.g}-${item.cat}`} className="catsub">
                      <td className="catsub-in" colSpan={2}>CAT {item.cat}</td>
                    </tr>
                  )
                  const p = item.p
                  const lines = figureLines(shown, figureCtx, p.id)
                  return (
                    // `data-band-id`, NOT a testid: the real row keeps `row-…`
                    // and `bal-…`, and two nodes answering one testid would
                    // break every query that expects the one real match. e2e
                    // still needs to find a given person in the overlay to prove
                    // it lines up with — and stays put over — the real row.
                    // The SAME `<FigureCell>` as the real cell (no testid — the
                    // overlay never answers one) so the phone's frozen copy
                    // shows the two-line box too, and the two cannot drift.
                    <tr key={`b-${p.id}`} data-band-id={p.id} data-band-key={`row-${p.id}`} className={p.id === viewer ? 'me' : undefined}>
                      <td className="who">
                        <div className="whorow">
                          <button className="whoedit" tabIndex={-1} onClick={() => setWhoOpen(p.id)}>
                            <span className={`cs seat-${p.seat}`}>{p.callsign}</span>
                            {p.to !== null && outcomeOf(p) === 'sans' && <span className="po-sans-tag">SANS</span>}
                            {catChip(p)}
                          </button>
                        </div>
                      </td>
                      <FigureCell
                        figure={shown}
                        lines={lines}
                        personId={p.id}
                        extraClass="bal act"
                        dataFig={shown.id}
                        dataPerson={p.id}
                        selected={!!figSel && figSel.fig === shown.id && figSel.ids.includes(p.id)}
                        onClick={() => setBalOpen({ person: p.id, figureId: shown.id })}
                      />
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
        {/* THE FIGURES DRAWER (owner, 6 Sep 26) — the band's sibling and its
            mirror image: the band draws the two frozen columns over the LEFT of
            the days, the drawer draws every figure over the RIGHT of them. Both
            are overlays outside `.mx-wrap`, drawn once, placed from measured
            numbers and never from guessed ones. */}
        {figuresOpen && (
          <FiguresDrawer
            figures={figures}
            ctx={figureCtx}
            rows={drawerRows()}
            zoom={zoom}
            top={drawerAt?.top ?? null}
            left={drawerAt?.left ?? 0}
            headH={drawerAt?.headH ?? 40}
            rootRef={drawerRef}
            arranging={arranging && role === 'admin'}
            selFor={id => (figSel && figSel.ids.includes(id) ? figSel.fig : null)}
            onBox={onDrawerBox}
          />
        )}
        {/* THE LIFT FRAME (owner, 6 Sep 26): one box round a picked-up row, and
            the flash where it lands — src/ui/lift.ts. Last in the outer so it
            paints over the band and the drawer; a constant className, so React
            never touches it after mount. */}
        <div className="lift-frame" data-testid="lift-frame" aria-hidden="true" ref={liftRef} />
      </div>
      </div>

      {/* The desktop horizontal scrollbar, fixed to the foot of the SCREEN
          (owner, 22 Aug 26). A proxy for `.mx-wrap`'s own scrollbar, which
          rides the bottom of a year-tall grid out of reach; its `left`/`width`
          overlay the grid and the inner spacer is as wide as the grid content
          so the browser sizes the thumb. Shown only while the real scrollbar
          is below the fold. Never in jsdom or on a phone — Matrix mounts it
          off a live desktop measurement. */}
      {hbar && (
        <div
          className="mx-hbar"
          data-testid="hscroll"
          ref={hbarRef}
          style={{ left: hbar.left, width: hbar.width }}
          onScroll={onHbarScroll}
        >
          <div className="mx-hbar-in" style={{ width: hbar.scrollW }} />
        </div>
      )}

      {/* Rendered outside `.mx-wrap` on purpose: that wrapper scrolls, and a
          sheet inside it would be clipped by its own scroller. Keyed by the
          cell so opening a second one remounts rather than carrying the
          first's portion choice across. */}
      {/* The published-stage remarks editor wins FIRST where it applies (an
          approved leave, the viewer's own or an admin's any) — even over the
          Raptor sheet, because on a published war editing the note is the
          point, and the note lives on the same Raptor row the read-only sheet
          would only point at. */}
      {open && listOpen && !(listRemark && listRemark.at === `${open.id}|${open.date}`) && (
        <DayListSheet
          key={`dl-${open.id}-${open.date}`}
          personId={open.id}
          callsign={open.callsign}
          date={open.date}
          view={openView!}
          role={role}
          viewer={viewer}
          period={period}
          onEditRemark={row => setListRemark({ at: `${open.id}|${open.date}`, row })}
          /* ONE RECORD, PICKED BY ITS ID (owner, D266 — "the same move modality and I can choose what to move"): the list
             closes and the grid's move mode carries exactly that record — no date box — by the same machine and landing
             rules as a single chip and a block (D262) */
          onMove={rec => {
            setSel(null)
            close()
            setEventMoveSel(null); setEventMovePreview(null)
            setMoveSel({ people: [rec.personId], from: rec.date, to: rec.date, cells: [{ personId: rec.personId, date: rec.date }], only: [rec] })
          }}
          onClose={close}
        />
      )}
      {open && listRemark && listRemark.at === `${open.id}|${open.date}` && (
        <RemarksSheet
          key={`dlrmk-${open.id}-${open.date}`}
          callsign={open.callsign}
          row={listRemark.row}
          code={grid[open.id]?.[open.date] ?? ''}
          onClose={() => setListRemark(null)}
        />
      )}
      {open && canRemark && (
        <RemarksSheet
          key={`rmk-${open.id}-${open.date}`}
          callsign={open.callsign}
          row={remarkRow}
          code={grid[open.id]?.[open.date] ?? ''}
          onClose={close}
        />
      )}
      {/* Raptor's ownership is checked next and short-circuits both other
          sheets. That cell is approved elsewhere: offering a picker or a
          decision on it would offer an action the store will refuse, which
          is worse than offering nothing. */}
      {open && !listOpen && !canRemark && raptorOwns(states, open.id, open.date) && !openFreeHalf && !openWorkOnly && (
        <RaptorSheet
          callsign={open.callsign}
          date={open.date}
          code={grid[open.id]?.[open.date] ?? ''}
          /* An OIL credit the app earned opens here too, and it is not leave
             from the Inputs page — the sheet says which it is, and reads the
             credit back in the same three lines as everywhere else. */
          creditShown={openAnyCredit && !openAnyCredit.award
            ? {
              code: openAnyCredit.code,
              days: openAnyCredit.days,
              note: openAnyCredit.note,
              giver: creditGiver({ auto: true, ...(openAnyCredit.via ? { via: openAnyCredit.via } : {}) }),
              spans: openAnyCredit.spans,
              via: openAnyCredit.via,
            }
            : null}
          onClose={close}
        />
      )}
      {/* HIS OWN OIL AWARD, READ ONLY (owner, D261, 27 Sep 26), wherever the bid sheet will not open for him — outside
          the bidding window, once bidding has closed, on a published war. Where it does open (inside the window) its
          foot reads the award back already, so this stands aside. */}
      {open && !listOpen && !canRemark && openCredit && ownAwardAlone(openView, viewer, open.id)
        && !(canEditCell(period, role, open.date) && canEditRow(role, viewer, open.id)) && (
        <AwardSheet
          callsign={open.callsign}
          date={open.date}
          award={{ code: openCredit.code, days: openCredit.days, note: openCredit.note, giver: openCredit.givenBy ?? '', entered: openCredit.enteredName }}
          onClose={close}
        />
      )}
      {/* The drag-selection sheet — batched fill / decide / delete / move over
          the whole rectangle (owner, 27 Aug 26). Independent of the single-cell
          `open`; a drag never sets `open`. */}
      {sel && (
        <SelectSheet
          sel={sel}
          people={csOf}
          /* the ask before a fill takes anyone below zero (D418) */
          wouldLeave={balanceAfter}
          role={role}
          canDecide={canDecide(period.stage, role)}
          /* never on a deleted man (his posting is final — [POST-OUT-OUTCOMES], Fable F3) */
          onPostOut={role === 'admin' && !sel.people.some(id => people.find(p => p.id === id)?.gone || postingLocked(id)) ? (pid, from, outcome) => postOutOr(pid, from, outcome) : undefined}
          hasAccount={hasAccount}
          onMove={s => { setEventMoveSel(null); setEventMovePreview(null); setMoveSel(s) }}
          /* a PARTIAL write keeps the sheet up (keepOpen) so its "N written,
             M skipped" note is actually read — closing here killed the note
             in the same tap that set it (27 Aug 26 overnight find) */
          onDone={(_changed, keepOpen) => { if (!keepOpen) setSel(null) }}
          onClose={() => setSel(null)}
        />
      )}
      {/* The balance bar — a drag down one figure column, one number for the
          run (owner, 6 Sep 26). Up while the selection lives; Save writes ONE
          ledger batch (grantTo) and the changed boxes flash on their own. The
          role is read HERE, not only where the drag arms: an admin's "view as
          member" flip lands mid-selection and must take the write control off
          the screen with it (absent, not disabled — the house rule). */}
      {role === 'admin' && figSel && selectableFigure(figSelFigure) && figSelIds.length > 0 && (
        <BalanceBar figure={figSelFigure} ids={figSelIds} onDone={() => setFigSel(null)} onClose={() => setFigSel(null)} />
      )}
      {/* Move mode: a slim banner. On desktop a ghost follows the mouse (from
          wireMove) and a CLICK lands the block at once; on phone a TAP stages
          the landing (`movePreview`) and the banner turns into Confirm/Cancel,
          since there is no hover to preview with and no undo. A refusal shows
          here and keeps the mode. The count is `movers` — the inputs present,
          not the raw rectangle. */}
      {moveSel && (
        <div className="mv-banner" data-testid="move-banner">
          <span className="mv-msg">
            {moveErr
              ? moveErr
              : movePreview
                ? `Move ${movers.length} ${movers.length === 1 ? 'entry' : 'entries'} here?`
                : `Tap a day to move ${movers.length} ${movers.length === 1 ? 'entry' : 'entries'}${stayWords(moveStays)}`}
          </span>
          {movePreview && (
            <button className="dchip confirm" data-testid="move-confirm" onClick={() => commitMove(movePreview)}>Confirm</button>
          )}
          <button
            className="dchip"
            data-testid="move-cancel"
            onClick={() => { const w = wrapRef.current; if (w) clearLanding(w); setMoveSel(null); setMovePreview(null) }}
          >Cancel</button>
        </div>
      )}
      {/* The EVENT move banner (owner, 31 Aug 26) — the same slim bar as the
          roster move, for the event picked up from its sheet's "Move…" button. */}
      {eventMoveSel && (
        <div className="mv-banner" data-testid="event-move-banner">
          <span className="mv-msg">
            {eventMoveErr
              ? eventMoveErr
              : eventMovePreview
                ? 'Move this event here?'
                : 'Tap a day to move this event'}
          </span>
          {eventMovePreview && (
            <button className="dchip confirm" data-testid="event-move-confirm" onClick={() => commitEventMove(eventMovePreview)}>Confirm</button>
          )}
          <button
            className="dchip"
            data-testid="event-move-cancel"
            onClick={() => { const w = wrapRef.current; if (w) clearLanding(w); setEventMoveSel(null); setEventMovePreview(null) }}
          >Cancel</button>
        </div>
      )}
      {/* A posted-out cell an admin tapped: the ONE control it offers is Undo,
          and it short-circuits every bid/decision sheet below (owner, 18 Aug
          26). */}
      {open && !listOpen && !canRemark && openPostedOut && role === 'admin' && !placing && !openPerson?.gone && (
        <PostOutSheet
          callsign={open.callsign}
          date={open.date}
          /* openPostedOut already proves `to` is set — a greyed day is a day
             AFTER it. The sheet talks in the PO date (first day gone), which
             is the day after the stored last-day-in. */
          poFrom={addDays(openPerson!.to!, 1)}
          outcome={outcomeOf(openPerson) ?? 'none'}
          hasAccount={hasAccount(open.id)}
          blockedFor={o => postingBlocked(open.id, o)}
          /* [ONE-DOOR] (Fable F1 / Astra 2): archived on Admin → Users — Restore there is the one way back; the store's
             lock, installed by the sync, as the account and block lookups are (the war never reads Raptor's people) */
          lockedWhy={postingLocked(open.id)}
          onChange={(from, outcome) => postOutOr(open.id, from, outcome)}
          /* the archive the Post out made goes too (W5-F1); refused, with where to go, when a man on the roster now holds
             his callsign (D286 (1) — Fable's scenario 2: it closed and did nothing) */
          onUndo={() => { const why = undoPostOutProblem(open.id); if (why) return why; undoPostOut(open.id); close() }}
          onPlace={() => setPlaceAt(openKey)}
          onClose={close}
        />
      )}
      {/* …and the mirror at the other end: a day BEFORE the person posted in,
          tapped by an admin. Same one-control shape as the post-out sheet,
          and it short-circuits the bid picker below exactly as that one does
          (owner, 20 Sep 26). A MEMBER tapping their own pre-joining day falls
          through to the picker instead, which is answer C's "filed or bid". */}
      {open && !listOpen && !canRemark && openNotYetArrived && role === 'admin' && !placing && !openPerson?.gone && (
        <PostInSheet
          callsign={open.callsign}
          date={open.date}
          /* openNotYetArrived already proves `from` is set. The sheet talks in
             the PI date itself — the first day they ARE here — where the
             post-out sheet has to add a day to the stored last-day-in. */
          piFrom={openPerson!.from!}
          /* D320: back from a posting — the day after his last earlier stint closed */
          backFrom={openPerson!.past && openPerson!.past.length ? addDays(openPerson!.past[openPerson!.past.length - 1].to, 1) : null}
          /* [ONE-DOOR] (the walk's design, Fable 4.2): archived on Admin → Users — read only, as the Post out sheet */
          lockedWhy={postingLocked(open.id)}
          onChange={from => postInOr(open.id, from)}
          onUndo={() => { setPostIn(open.id, null); close() }}
          onPlace={() => setPlaceAt(openKey)}
          onClose={close}
        />
      )}
      {/* An admin at `closed` can BOTH edit and decide, so the two are not
          mutually exclusive and the order between them matters. Deciding
          wins on a cell that holds a bid, because that is what the stage is
          for; the picker still opens on an empty one, so an admin can add
          leave to a closed sheet without a second control. */}
      {picking && (
        <CounterSheet shownId={shown.id} onPick={setShownId} onClose={() => setPicking(false)} />
      )}
      {/* The tapped person's breakdown of one figure — the column's shown
          one from a counter-cell tap, or whichever row was tapped in the
          person-figures sheet. Guarded on the person still existing — an
          admin can delete a row while any sheet is up. Looked up in the FULL catalogue, not the
          column's `figures` (visible-only, 6 Sep 26): the figure this sheet
          was asked for was chosen before it opened, and an admin can hide a
          figure at any moment — including while this very sheet is up — so a
          lookup that depended on visibility would answer a stale id by
          silently substituting whatever the column happens to be showing. The
          reader would then be reading someone's MED TOT under a heading that
          says CCL, which is worse than showing a figure that has just left the
          picker. An unknown id (a stale saved order) falls back to the shown
          one. */}
      {balOpen && people.some(p => p.id === balOpen.person) && (
        <FigureBreakdownSheet
          figure={orderedFigures(figureOrder).find(f => f.id === balOpen.figureId) ?? shown}
          person={people.find(p => p.id === balOpen.person)!}
          onClose={() => setBalOpen(null)}
        />
      )}
      {/* The tapped person's ALL-FIGURES sheet — every role's way in from a
          callsign. A figure row hands over to the breakdown above. (Its
          admin's "Edit person" is gone — D460, D461: seat, band and SXO change
          only on Quals.) */}
      {whoOpen && people.some(p => p.id === whoOpen) && (
        <PersonFiguresSheet
          person={people.find(p => p.id === whoOpen)!}
          onOpenFigure={figureId => { setBalOpen({ person: whoOpen, figureId }); setWhoOpen(null) }}
          onOpenOil={() => { setOilTracker({ person: whoOpen }); setWhoOpen(null) }}
          onSetBalance={role === 'admin' ? (counter, target) => { setBalance(whoOpen, counter, target) } : undefined}
          onClose={() => setWhoOpen(null)}
        />
      )}
      {/* The qualifications popover (owner, 3 Sep 26). A person wears only their
          CAT chip; this is where every other qualification shows, on a desktop
          hover or a phone tap of the chip. It ignores pointer events (never eats
          a tap) and is dismissed by the outside-pointer listener above. */}
      {qualPop && people.some(p => p.id === qualPop.id) && (() => {
        const p = people.find(x => x.id === qualPop.id)!
        const quals = shownQuals(p)
        return (
          <div className="qualpop" role="tooltip" data-testid="qualpop" style={{ left: qualPop.x, top: qualPop.y }}>
            <div className="qualpop-hd">{p.callsign} · quals</div>
            {quals.length
              ? (
                <div className="qualpop-list">
                  {quals.map(q => (
                    <span className="qualpill" key={q.label} style={{ background: q.color, color: inkFor(q.color) }}>{q.label}</span>
                  ))}
                </div>
              )
              : <div className="qualpop-none">No qualifications recorded</div>}
          </div>
        )
      })()}
      {/* The OIL tracker — everyone's balances, or one person's ledger. The
          person guard matches the sheets above: a row can go while it is up. */}
      {oilTracker && (oilTracker.person === null || people.some(p => p.id === oilTracker.person)) && (
        <OilTracker
          key={oilTracker.person ?? '*'}
          person={oilTracker.person}
          onClose={() => setOilTracker(null)}
          /* A credit lands → the column shows +OIL (owner, 2 Sep 26; id
             renamed 6 Sep 26 when OIL BAL and OIL USED merged into one
             balance figure, 'oil'). */
          onGranted={() => showFigure('oil')}
        />
      )}
      {eventEdit && role === 'admin' && (
        <EventSheet
          key={`${eventEdit.line}-${eventEdit.date}-${eventEdit.to ?? ''}`}
          line={eventEdit.line}
          date={eventEdit.date}
          to={eventEdit.to}
          onClose={() => setEventEdit(null)}
          onMove={m => { setEventEdit(null); setSel(null); setMoveSel(null); setMovePreview(null); setEventMoveSel(m) }}
        />
      )}
      {/* A manning row's explainer — every role's way in from the row's name;
          what it OFFERS (the amber/red fields) is derived from the role
          inside, so a role change while it is open cannot leave the fields
          on a member's screen. Keyed so switching rows resets the drafts. */}
      {manningInfo && (
        <ManningSheet
          key={manningInfo}
          ruleId={manningInfo}
          onClose={() => setManningInfo(null)}
          onEdit={id => { setManningInfo(null); setCounterEdit(id) }}
        />
      )}
      {/* The counter form — new counter (null) or a rework of one row's rule.
          Keyed so switching counters resets every draft field. */}
      {counterEdit !== false && role === 'admin' && (
        <CounterForm key={counterEdit ?? 'new'} ruleId={counterEdit} onClose={() => setCounterEdit(false)} />
      )}
      {/* The ⚙ SETTINGS sheet — all admin config (counters, event rows, Show
          SANS, the roster groups). Admin only at the affordance AND at every
          store writer it calls — the standing role doctrine. The who-wins list
          reorders through the one drag machine (the display order is dragged on
          the grid instead, see the category headings below). */}
      {settings && role === 'admin' && (
        <SettingsSheet
          onClose={() => setSettings(false)}
          // + Counter opens the counter builder, a sheet of its own — close the
          // settings sheet so the two do not stack (both `.bidsheet`, same z-index,
          // so an open settings row would sit over the builder and eat its taps).
          onAddCounter={() => { setSettings(false); setCounterEdit(null) }}
          armCounterReset={armCounterReset}
          onResetCounters={() => {
            if (!armCounterReset) { setArmCounterReset(true); return }
            setArmCounterReset(false)
            resetManningRules()
          }}
          disarmCounterReset={() => setArmCounterReset(false)}
          onGroupDragStart={(e, id) => startRowDrag(e, id, GROUP_DRAG)}
          onPriorityDragStart={(e, id) => startRowDrag(e, id, GROUP_PRIO_DRAG)}
          draggingId={draggingId}
          dragOver={dragOver}
          dragAfter={dragAfter}
        />
      )}
      {/* a member may bid CLEARING leave after their own posting-out (owner
          answer C, 20 Sep 26) — the admin's tap there stays the PO sheet */}
      {open && !listOpen && !canRemark && (placing || ((!openPostedOut || role !== 'admin') && (!openNotYetArrived || role !== 'admin'))) && (!raptorOwns(states, open.id, open.date) || !!openFreeHalf || openWorkOnly)
        && canEditCell(period, role, open.date) && canEditRow(role, viewer, open.id) && (
        <BidPicker
          key={`${open.id}-${open.date}`}
          callsign={open.callsign}
          personId={open.id}
          date={open.date}
          current={grid[open.id]?.[open.date] ?? ''}
          dates={dates}
          /* Item D: only the free half is on offer, and the sheet says what
             holds the other one. */
          onlyPortion={openFreeHalf}
          heldBy={openFreeHalf ? displayCell(grid[open.id]?.[open.date] ?? '') : undefined}
          /* Admin-only: post this person out (owner, 18 Aug 26; any date and
             the archive switch, 19 Aug 26). The store sets their posting-out
             date; the greyed boxes and the manpower exclusion follow from it,
             and sync.ts's auto-archive pass reads the switch. */
          /* [ONE-DOOR]: not for a man archived on Admin → Users — his postings are read only there (the walk's pictures,
             27 Sep 26: the button could only be refused, and then said so twice); leave and OIL still place */
          onPostOut={role === 'admin' && !openPerson?.gone && !postingLocked(open.id)
            ? (from, outcome) => { const why = postOutOr(open.id, from, outcome); if (why) return why; close() }
            : undefined}
          hasAccount={hasAccount(open.id)}
          blockedFor={o => postingBlocked(open.id, o)}
          /* Admin-only, the mirror of the above (owner, 20 Sep 26): the first
             day they ARE in the squadron. */
          onPostIn={role === 'admin' && !openPerson?.gone && !postingLocked(open.id)
            ? from => { const why = postInOr(open.id, from); if (why) return why; close() }
            : undefined}
          /* Admin-only: record that he WORKED this day and earned OIL (owner,
             20 Sep 26). ANY day — the weekend/public-holiday rule belongs to
             the automatic pass that reads the published schedule, not to a
             credit the squadron types itself. Hours are read the way every
             other time box in the app is (`08:00`, `8:00`, `0800`, `800`);
             blank means the whole day. */
          credit={role === 'admin' && openCredit
            ? { code: openCredit.code, days: openCredit.days, note: openCredit.note, givenBy: openCredit.givenBy }
            : null}
          /* a day holding SEVERAL awards: the +OIL panel changes none of them — the day's list carries each */
          awardCount={role === 'admin' ? openAwards.length : 0}
          /* Read back on one click, for anyone who can see the day — a member
             reading his own OIL is entitled to know why it is there and who
             gave it, the same as an admin (owner, 21 Sep 26). */
          /* THE FOUR ANSWERS TO AN INPUT, IN EVERY STAGE (owner, 21 Sep 26).
             An admin, and a cell that actually holds a bid to answer — a
             course, a medical, an OIL credit and an empty day are not things
             anybody asked for. `canDecide` is deliberately NOT the gate: it
             means closed-or-published, and the whole point of his ruling is
             that the window is the same while bidding is still open. */
          decide={canDecide(period.stage, role) && !openFreeHalf && isBiddable(grid[open.id]?.[open.date])
            ? { state: stateOf(states, open.id, open.date), movedFrom: movedShown ? shiftedFrom(states, open.id, open.date) : undefined }
            : null}
          /* ONE CHIP, ONE MOVE (owner, D262, 27 Sep 26): the sheet's Move picks the chip up into the grid's own move
             mode — the drag-selection's, so a single chip and a block move by one machine and one set of landing
             rules (moveCells: refused whole with its reason, the dotted mark once bidding is closed, lands
             undecided). A day that holds nothing this screen may move says so on the sheet instead. */
          onMove={cells => {
            /* the day tapped, or every day of a picked range (D335) — the records on them this role may move (D265) */
            if (!movableRecords(cells).length) return 'There is nothing here that can be moved.'
            const dates = cells.map(c => c.date).sort()
            setSel(null)
            close()
            setEventMoveSel(null); setEventMovePreview(null)
            setMoveSel({ people: [open.id], from: dates[0]!, to: dates[dates.length - 1]!, cells })
          }}
          creditShown={openAnyCredit
            ? {
              code: openAnyCredit.code,
              days: openAnyCredit.days,
              note: openAnyCredit.note,
              giver: creditGiver({ auto: !openAnyCredit.award, ...(openAnyCredit.via ? { via: openAnyCredit.via } : {}), ...(openAnyCredit.givenBy ? { givenBy: openAnyCredit.givenBy } : {}) }),
              auto: !openAnyCredit.award,
              spans: openAnyCredit.spans,
              via: openAnyCredit.via,
              ...(openAnyCredit.award && openAnyCredit.enteredName ? { entered: openAnyCredit.enteredName } : {}),
            }
            : null}
          onCreditClear={role === 'admin' && openCredit
            ? () => { clearRecordById(open.id, open.date, openCredit.id); close() }
            : undefined}
          onCredit={role === 'admin'
            ? (_code, days, note, givenBy) => {
              /* the AMOUNT is the award (FO / HO is only its label); a blank box is a day, as the panel shows */
              const raw = days.trim()
              const n = raw ? Number(raw) : 1
              if (!Number.isFinite(n)) return 'Type how many days'
              const problem = setDayAward(open.id, open.date, n, { note, givenBy })
              if (!problem) showFigure('oil')
              return problem
            }
            : undefined}
          /* No medical here: medical is member-filed only (owner, 13 Sep 26).
             Everyone files a medical input with its certificate on Raptor's
             Inputs page; the war displays it read-only, never creates it. */
          /* The column follows the leave just entered, to the BALANCE it
             comes off (owner, 6 Sep 26) — ask for OIL and it snaps to +OIL.
             The owner's ask, and it makes the figure answer the question the
             bidder is holding in their head at that moment. `figureForLeave`
             (counters.ts) is the one map: LL/OL both come off LVE, every
             other balance-bearing type snaps to its own, ATT C/HL/OML feed
             MED TOT, and a type with no figure (EL, ATT B) simply returns
             null and does not snap. Through `showFigure`, which is where the
             "must still be VISIBLE" gate now lives for every caller. */
          onWrote={code => {
            const cell = parseCell(code)
            const earns = (codeOf(code)?.earnsOil ?? 0) > 0
            if (cell) {
              const id = figureForLeave(cell.type)
              if (id) showFigure(id)
            }
            /* A write on the grid keeps you ON the grid (owner, 6 Sep 26 —
               "it should never bring me to the oil tracker page"), reversing
               the 2 Sep rule that sent an admin's manual OIL straight to the
               tracker to type a reason. Being thrown off the grid mid-pass
               cost more than the reason was worth, and the tracker is one tap
               away on the OIL button when he does want it. What survives is
               the COLUMN: an FO/HO day EARNS oil, so the figure that just grew
               is the one left on screen — the balance answers for the write
               without moving the reader. */
            if (earns) showFigure('oil')
          }}
          /* What the balance would read AFTER this write, so the sheet can
             ask before taking someone negative — the shared body above. */
          wouldLeave={(code, dates) => balanceAfter(open.id, dates, code)}
          onClose={close}
        />
      )}
      {/* THE SEPARATE DECISION SHEET IS GONE (owner, 21 Sep 26). It opened
          only once bidding had closed, so the same input answered to different
          controls depending on which day of the cycle you clicked it — and
          moving one man's one day needed a drag-select. Its three buttons now
          live on the ONE day window above, in every stage, and its Move is the
          grid's own move mode (D262, 27 Sep 26), which retired its date box;
          the unmounted `DecisionSheet` went with it. */}
    </div>
  )
}
