/* DRAG-TO-SELECT on the Leave War grid (owner, 27 Aug 26 — "all users … can
   left click, to drag to select whatever items … like a row of LL").

   Two halves, split the way `caldrag.ts` splits: a PURE geometry core
   (`rectCells`) that turns an anchor + focus cell into the rectangle of cells
   between them, DOM-free and unit-tested; and a POINTER CONTROLLER
   (`wireSelect`) that lives on the one `.mx-wrap` scroller — never per-cell,
   the grid is ~28k nodes and every perf note in Matrix.tsx forbids that — and
   hit-tests with `elementFromPoint().closest('[data-testid^="cell-"]')`, the
   same shape `startRowDrag` already uses here.

   The grid's sideways scroll is sacred (the owner reported it broken three
   times), so the gesture ARMS before it claims anything: a mouse arms at a
   4px move; a finger must HOLD 180ms, and a slide past 26px before that cedes
   to the native scroll. Only after arming is `touch-action` suppressed. An
   un-armed press is an ordinary click — every existing cell test (plain
   `fireEvent.click`) still opens its single-cell sheet untouched.

   Feel constants are caldrag's verbatim, for one muscle memory across the app. */

export type Cell = { personId: string; date: string }
/** A selection of days. `only` names the records a move carries when one was PICKED (the day's list, D266); absent,
 *  a move carries every record on `cells` this role may move (D265). */
export type Selection = { people: string[]; from: string; to: string; cells: Cell[]; only?: Array<{ personId: string; date: string; id: string }> }
// An EVENT selection (owner, 27 Aug 26) — a date span on ONE event line. Events
// live one row each, so there is no people axis; a drag never crosses lines.
export type EventCell = { line: number; date: string }
export type EventSelection = { line: number; from: string; to: string; dates: string[] }

/* caldrag.ts's own numbers */
const HOLD = 180        // ms a finger must dwell before a drag arms
const TOUCH_TAP_WAIT = 400  // ms the swallow waits for the tap a finger leaves after a drag (W4-1)
const SLOWARM = 140     // ms down after which a slide past GIVEUP arms a
                        // SELECT instead of ceding — a slow, deliberate drag,
                        // never a quick scroll flick (owner, 27 Aug 26)
const GIVEUP = 26       // a pre-arm slide past this is a scroll, not a select
                        // (any smaller wobble during the dwell is simply
                        // tolerated — there is no second, tighter threshold)
const MOUSE_SLOP = 4    // a mouse arms on this move, no dwell
const EDGE = 36         // px from an edge that auto-scrolls during a MOUSE drag
const EDGE_STEP = 18    // px per frame of a mouse edge auto-scroll (constant)
const TOUCH_EDGE = 48   // wider edge band for a finger, which is a fatter target
const TOUCH_STEP_MAX = 15 // px per frame at the very edge; RAMPED down to 0 across
                        // the band so the finger throttles the speed by how far it
                        // pushes — the fix for the 27 Aug "columns slid away" feel

/* The grid scrolls SIDEWAYS inside `.mx-wrap` (its `overflow-x`) but UP/DOWN
   with the page — `.mx-wrap` has no height cap, so its vertical overflow lives
   on an ancestor or the document (matrix.css). So a sideways edge-scroll moves
   `wrap.scrollLeft`, but a vertical one moves whatever actually scrolls the
   rows: the nearest scrollable ancestor, else the document. Resolved once per
   armed drag (the DOM doesn't restructure mid-gesture). */
type VScroll = { el: Element; isDoc: boolean }
const findVScroll = (wrap: HTMLElement): VScroll => {
  for (let n = wrap.parentElement; n && n !== document.body; n = n.parentElement) {
    const oy = getComputedStyle(n).overflowY
    if ((oy === 'auto' || oy === 'scroll') && n.scrollHeight > n.clientHeight + 1) return { el: n, isDoc: false }
  }
  return { el: document.scrollingElement || document.documentElement, isDoc: true }
}

/* testid is `cell-<person>-<YYYY-MM-DD>`; the date is always the last 10
   chars, so a person id may hold anything and this still splits cleanly */
export function parseCellId(testid: string | null | undefined): Cell | null {
  if (!testid || !testid.startsWith('cell-')) return null
  const rest = testid.slice(5)
  if (rest.length < 12) return null
  const date = rest.slice(-10)
  const personId = rest.slice(0, -11) // drop the '-' before the date too
  if (!personId) return null
  return { personId, date }
}

/** The rectangle of cells between anchor and focus, in the grid's own row and
 *  column order. `null` if either endpoint is off the given order/date lists
 *  (a stale hit-test), so the caller paints nothing rather than guessing. */
export function rectCells(order: string[], dates: string[], a: Cell, f: Cell): Selection | null {
  const ai = order.indexOf(a.personId), fi = order.indexOf(f.personId)
  const ad = dates.indexOf(a.date), fd = dates.indexOf(f.date)
  if (ai < 0 || fi < 0 || ad < 0 || fd < 0) return null
  const r0 = Math.min(ai, fi), r1 = Math.max(ai, fi)
  const c0 = Math.min(ad, fd), c1 = Math.max(ad, fd)
  const people = order.slice(r0, r1 + 1)
  const days = dates.slice(c0, c1 + 1)
  const cells: Cell[] = []
  for (const personId of people) for (const date of days) cells.push({ personId, date })
  return { people, from: days[0], to: days[days.length - 1], cells }
}

/* An event DAY cell is `event-<line>-<YYYY-MM-DD>`. The band (`event-band-…`),
   blocked (`event-blocked-…`) and row (`event-row-…`) testids share the prefix
   but are not per-day cells, so this matches ONLY the plain day cell. */
export function parseEventCell(testid: string | null | undefined): EventCell | null {
  const m = /^event-(\d+)-(\d{4}-\d{2}-\d{2})$/.exec(testid ?? '')
  return m ? { line: Number(m[1]), date: m[2] } : null
}

/** The run of one event LINE between two dates, in the grid's own column order.
 *  Events are one row each, so a drag never spans lines — the anchor's line
 *  wins and only the date span matters. `null` if either date is off the given
 *  date list (a stale hit-test), so the caller paints nothing rather than guess. */
export function eventRange(dates: string[], line: number, a: string, f: string): EventSelection | null {
  const ai = dates.indexOf(a), fi = dates.indexOf(f)
  if (ai < 0 || fi < 0) return null
  const c0 = Math.min(ai, fi), c1 = Math.max(ai, fi)
  const span = dates.slice(c0, c1 + 1)
  return { line, from: span[0], to: span[span.length - 1], dates: span }
}

export interface SelectCtx {
  order: () => string[]     // visible person ids, top → bottom
  dates: () => string[]     // ordered day strings, left → right
  enabled: () => boolean    // selection allowed right now (not arranging, a sheet closed, …)
  onSelect: (sel: Selection) => void
  // Events (admin only): a drag along ONE event line selects a date span and
  // opens the event sheet for it (owner, 27 Aug 26). `eventsEnabled` absent or
  // false ⇒ event cells are not selectable (a member, or the rows are gone).
  eventsEnabled?: () => boolean
  onEventSelect?: (sel: EventSelection) => void
  /** Client-x where the day columns begin — past the frozen name/counter pair,
   *  or past the figures drawer while it is open. The drag's LEFT auto-scroll
   *  band starts there rather than at the wrap's own edge, which is buried
   *  under them (owner, 6 Sep 26). Absent = the wrap's left edge. */
  leftEdge?: () => number
}
/* elementFromPoint works in client coords regardless of the table's CSS
   `zoom`, so the hit-test needs no un-scaling. */

const cellAt = (x: number, y: number): Cell | null =>
  parseCellId((document.elementFromPoint(x, y) as HTMLElement | null)?.closest('[data-testid^="cell-"]')?.getAttribute('data-testid'))
const eventAt = (x: number, y: number): EventCell | null =>
  parseEventCell((document.elementFromPoint(x, y) as HTMLElement | null)?.closest('[data-testid^="event-"]')?.getAttribute('data-testid'))

/** Attach the one selection listener to `.mx-wrap`. Returns a teardown. */
type Hit = { kind: 'roster'; cell: Cell } | { kind: 'event'; cell: EventCell }

/* ---- THE GESTURE CORE ------------------------------------------------------
   Everything about ARMING a drag — the mouse slop, the finger's hold, the
   slow-drag-arms rule, pointer capture, the non-passive touchmove scroll lock,
   the context-menu swallow, edge auto-scroll and the one-shot click swallow on
   release — lives here once, parameterised by WHAT is being selected. The grid
   (`wireSelect`: people × days cells, or a date span on an event line), the
   OIL tracker (`wireRowSelect`: a run of people rows — owner, 2 Sep 26, "use
   the same mechanics as the leave war grid") and the figure columns
   (`wireFigureSelect`: a run of people down one figure, 6 Sep 26) are three
   callers of the same machine, so the phone learns one rhythm for all of them. */
interface GestureBase<A, P> {
  enabled: () => boolean
  /** The thing under the pointer on pointerdown, or null when the press is
   *  not on something selectable (an ordinary click, then). */
  hit: (target: HTMLElement) => A | null
  /** The selection for the anchor with the pointer at (x, y): the ids to
   *  paint and the payload to hand off on release. The caller holds its own
   *  "last thing the finger was over" so a gap or an edge-scroll never
   *  collapses the selection. `null` paints nothing. */
  current: (anchor: A, x: number, y: number) => { ids: string[]; payload: P } | null
  /** Fires the moment the drag ARMS (a finger's hold landed, a mouse crossed
   *  the slop): a caller's chance to tell a sibling gesture to stand down. */
  onArm?: () => void
  onSelect: (payload: P) => void
  /** Called on every teardown so the caller can drop its held focus. */
  reset?: () => void
  /** The element that scrolls the rows VERTICALLY. The grid resolves the
   *  nearest scrolling ancestor (its wrap has no height cap); a modal whose
   *  wrap scrolls both ways passes itself. */
  vscroll?: (wrap: HTMLElement) => VScroll
  /** Client-x where the CONTENT begins, past whatever frozen thing stands in
   *  front of the wrap's own left edge — the frozen name/counter columns, or
   *  the figures drawer while it is open. The left edge band starts there, so
   *  a finger approaching the visible days' left edge auto-scrolls (owner,
   *  6 Sep 26 — "let me auto scroll left when my drag is approaching the edge
   *  of the expanded counters … likewise the counter on the left"). Absent =
   *  the wrap's own left edge: every existing caller and test is untouched. */
  leftEdge?: () => number
  /** How GENTLE this caller's edge auto-scroll is. `rate` multiplies the
   *  per-frame step; `dwellMs` is how long the pointer must sit inside a band
   *  before that band scrolls at all, timed from the frame it ENTERED the band
   *  and started again whenever it leaves and comes back. Defaults `1` and `0`
   *  — absent, every existing caller is byte-identical.
   *    Only the FIGURE select asks for it (6 Sep 26 bug hunt). Painting a
   *  rectangle of days wants the grid's own quick run to the next month; a
   *  figure drag is a run of PEOPLE a number is about to be written to, so a
   *  finger that merely finishes near the foot of the screen must not keep
   *  collecting names. Measured on the built bundle before this: a three-row
   *  drag ending in the bottom band ran the page 259px in ~0.7s and lit
   *  FOURTEEN people.
   *    The dwell is deliberately longer than a drag's own moves take, so it is
   *  a RESTING finger the scroll waits for, not merely one that has crossed the
   *  band on its way down — see `wireFigureSelect` for the measured numbers. */
  edge?: { rate?: number; dwellMs?: number }
}
/* WHICH NODE, and HOW it is marked — both are either/or, and the type says so
   rather than leaving a caller to pass a `cls` it does not use (6 Sep 26
   review). `node` is the thing drawn once; `nodes` is a thing drawn in more
   than one place at once (a figure box has a real cell, the band's copy and a
   drawer box, and every copy must light). `cls` toggles a class; `mark`
   replaces it where the node's className is React's to rewrite on every render
   (FigureCell rebuilds `wide`/`flash` on every store change) — an attribute
   React never rendered survives that rewrite, a class painted from outside
   does not. */
type GesturePaint =
  | { node: (id: string) => Element | null; nodes?: never }
  | { nodes: (id: string) => Element[]; node?: never }
type GestureMark =
  | { cls: string; mark?: never }
  | { mark: (el: Element, on: boolean) => void; cls?: never }
type GestureSpec<A, P> = GestureBase<A, P> & GesturePaint & GestureMark

function wireGesture<A, P>(wrap: HTMLElement, spec: GestureSpec<A, P>): () => void {
  let anchor: A | null = null
  let armed = false
  let pid = -1
  let sx = 0, sy = 0
  let holdTimer: any = null
  let slowTimer: any = null       // fires at SLOWARM; flips slowReady
  let slowReady = false           // the finger has been down long enough that a
                                  // slide now reads as a slow drag, not a flick
  let painted = new Set<string>()  // ids currently wearing spec.cls
  let raf = 0
  let lastX = 0, lastY = 0
  let touchGesture = false   // this drag started from a finger, not a mouse
  let vscroll: VScroll | null = null  // the vertical scroller, resolved in arm()
  let held = 0               // edge bands the PRESS sat inside (bitmask, see bandsAt)
  // The DWELL clock, one entry per band the pointer is currently inside, holding
  // the moment it entered. A band that is left is deleted, so coming back starts
  // the wait again — the pointer must SIT in a band, not brush through it. Only
  // filled when a caller asked for a dwell (spec.edge.dwellMs); the day grid
  // never touches it. See edgeScroll.
  const enteredAt = new Map<number, number>()

  const nodesOf = (id: string): Element[] => {
    if (spec.nodes) return spec.nodes(id)
    const n = spec.node?.(id)
    return n ? [n] : []
  }
  const markEl = (el: Element, on: boolean) => { if (spec.mark) spec.mark(el, on); else el.classList.toggle(spec.cls!, on) }
  const clearPaint = () => {
    for (const id of painted) for (const el of nodesOf(id)) markEl(el, false)
    painted = new Set()
  }
  const paintIds = (ids: string[]) => {
    const want = new Set(ids)
    for (const id of painted) if (!want.has(id)) for (const el of nodesOf(id)) markEl(el, false)
    for (const id of want) if (!painted.has(id)) for (const el of nodesOf(id)) markEl(el, true)
    painted = want
  }

  const current = () => (anchor === null ? null : spec.current(anchor, lastX, lastY))

  const repaint = () => {
    if (!armed || anchor === null) return
    const s = current()
    paintIds(s ? s.ids : [])
  }

  // Auto-scroll the grid when a drag reaches an edge, so a selection can run
  // PAST what the screen shows — SIDEWAYS onto more days, and UP/DOWN onto more
  // people (owner, 30 Aug 26 — "auto scroll to the edge to continue selecting
  // more grids … in case I want to put longer inputs" → "up down scroller too").
  // It runs ONLY during an armed drag-select, never during a normal scroll (that
  // scroll never arms), so the grid's sacred sideways fling is untouched.
  //   Touch was turned OFF here on 27 Aug 26 because the mouse's CONSTANT speed
  // made the day columns "slide away under the finger" — out of control on a
  // ~390px phone. It is back on for touch with a RAMP: the speed grows the
  // closer the finger is to the true edge and is zero at the band's inner lip,
  // so a light push creeps and a firm push at the very edge runs — the finger
  // throttles it, which is exactly what the constant speed lacked. The mouse
  // keeps its original constant step (desktop has the room and the precision).
  //   The horizontal axis moves `wrap.scrollLeft` against the wrap's own rect;
  // the vertical axis moves the resolved `vscroll` — the page for the grid,
  // whose rows scroll with the page and whose wrap is taller than the screen —
  // against the VIEWPORT (or the scroller's own rect). As the page scrolls
  // under a held finger, elementFromPoint at the same point returns the new
  // row, so the selection extends onto it.
  const ramp = (into: number) => TOUCH_STEP_MAX * Math.min(1, into / TOUCH_EDGE)
  // The four edge bands as a bitmask, and which of them a point sits inside —
  // the mouse's fixed band or the finger's wider one, against the wrap
  // sideways and the resolved vertical scroller (the viewport for the page,
  // else the scroller's own rect) up and down.
  const BL = 1, BR = 2, BT = 4, BB = 8
  const bandsAt = (x: number, y: number): number => {
    const r = wrap.getBoundingClientRect()
    const vs = vscroll ?? (vscroll = (spec.vscroll ?? findVScroll)(wrap))
    const vTop = vs.isDoc ? 0 : vs.el.getBoundingClientRect().top
    const vBot = vs.isDoc ? (window.innerHeight || vs.el.clientHeight) : vs.el.getBoundingClientRect().bottom
    const w = touchGesture ? TOUCH_EDGE : EDGE
    // The LEFT band starts where the CONTENT does, not where the box does: on
    // this grid the frozen columns (or the open figures drawer) stand in front
    // of the wrap's own left edge, so a band measured from `r.left` sat behind
    // them and no finger could ever reach it. The RIGHT band keeps `r.right` —
    // nothing is parked over that side.
    const left = spec.leftEdge ? spec.leftEdge() : r.left
    return (x < left + w ? BL : 0) | (x > r.right - w ? BR : 0) | (y < vTop + w ? BT : 0) | (y > vBot - w ? BB : 0)
  }
  // A band the press STARTED inside must be LEFT before it scrolls. Without
  // this a row at the bottom of the screen could not be drag-selected
  // sideways: the pointer was already in the bottom band when the drag armed,
  // so the page ran downward 18px a frame under a finger that never moved
  // vertically, the rows slid up beneath it and the selection ballooned onto a
  // dozen people — or, when a category heading was what slid under the release
  // point, the last day column was dropped (the e2e "drag-selecting a row"
  // flake, 2 Sep 26). `held` is the set of bands the press sat in; a band
  // clears the moment the pointer is seen outside it and stays cleared.
  const noteEdge = () => { if (held) held &= bandsAt(lastX, lastY) }
  const edgeScroll = () => {
    raf = 0
    if (!armed) return
    const r = wrap.getBoundingClientRect()
    let dx = 0, dy = 0
    // vertical bounds: the viewport for the page, else the scroller's own rect
    const vs = vscroll ?? (vscroll = (spec.vscroll ?? findVScroll)(wrap))
    const vTop = vs.isDoc ? 0 : vs.el.getBoundingClientRect().top
    const vBot = vs.isDoc ? (window.innerHeight || vs.el.clientHeight) : vs.el.getBoundingClientRect().bottom
    // The left band's origin — see `bandsAt`: the content's own left edge, past
    // the frozen columns or the open drawer standing in front of the wrap's.
    const left = spec.leftEdge ? spec.leftEdge() : r.left
    if (touchGesture) {
      const intoR = lastX - (r.right - TOUCH_EDGE), intoL = (left + TOUCH_EDGE) - lastX
      if (intoR > 0) dx = ramp(intoR); else if (intoL > 0) dx = -ramp(intoL)
      const intoB = lastY - (vBot - TOUCH_EDGE), intoT = (vTop + TOUCH_EDGE) - lastY
      if (intoB > 0) dy = ramp(intoB); else if (intoT > 0) dy = -ramp(intoT)
    } else {
      if (lastX > r.right - EDGE) dx = EDGE_STEP; else if (lastX < left + EDGE) dx = -EDGE_STEP
      if (lastY > vBot - EDGE) dy = EDGE_STEP; else if (lastY < vTop + EDGE) dy = -EDGE_STEP
    }
    // A caller may ask for a GENTLER run than the day grid's (spec.edge): the
    // step is scaled, and a band must be sat in for `dwellMs` before it moves at
    // all. Both default to no-ops, so the grid's own feel is untouched.
    const rate = spec.edge?.rate ?? 1
    if (rate !== 1) { dx *= rate; dy *= rate }
    noteEdge()
    // The HELD-band rule first: a band the press sat in is dead until the
    // pointer has left it, whatever the dwell says.
    if ((dx > 0 && held & BR) || (dx < 0 && held & BL)) dx = 0
    if ((dy > 0 && held & BB) || (dy < 0 && held & BT)) dy = 0
    const dwellMs = spec.edge?.dwellMs ?? 0
    if (dwellMs > 0) {
      // Timed from the frame the pointer ENTERED each band, and reset the moment
      // it leaves — so a drag that merely ends near the edge pauses there and
      // stops, while one deliberately parked in the band still runs on.
      const now = Date.now()
      const inBands = bandsAt(lastX, lastY)
      for (const b of [BL, BR, BT, BB]) {
        if (inBands & b) { if (!enteredAt.has(b)) enteredAt.set(b, now) }
        else enteredAt.delete(b)
      }
      const waiting = (b: number) => now - (enteredAt.get(b) ?? now) < dwellMs
      if ((dx > 0 && waiting(BR)) || (dx < 0 && waiting(BL))) dx = 0
      if ((dy > 0 && waiting(BB)) || (dy < 0 && waiting(BT))) dy = 0
    }
    if (dx) wrap.scrollLeft += dx
    if (dy) vs.el.scrollTop += dy
    if (dx || dy) repaint()
    if (armed) raf = requestAnimationFrame(edgeScroll)
  }

  const arm = () => {
    armed = true
    if (holdTimer) { clearTimeout(holdTimer); holdTimer = null }
    if (slowTimer) { clearTimeout(slowTimer); slowTimer = null }
    // Capture the pointer only now that a DRAG is real. Taking it on
    // pointerdown breaks a plain tap: Chromium retargets the click that
    // follows a captured pointerup to the capturing element (the wrap), so
    // the cell's own onClick — the single-cell input sheet — never fires.
    // The window-level move/up listeners already track the drag without it;
    // capture is just belt-and-braces for a fast touch drag.
    if (pid >= 0) { try { wrap.setPointerCapture(pid) } catch { /* jsdom / not capturable */ } }
    wrap.style.touchAction = 'none'
    // Say — loudly — that the select has GRABBED. A phone user needs to SEE the
    // long-press take before they drag, or they never learn the rhythm and the
    // drag reads as broken (owner, 27 Aug 26 — "I can't select a range … stuck
    // with 1 input"): `.selecting` makes the wash brighter and the ring thicker
    // than the resting highlight (matrix.css), and Android gets a short haptic.
    // iOS has no web vibrate, so the visual cue carries it there.
    // ...as a class AND an attribute, and the attribute is the durable one: a
    // wrap whose className React OWNS (the figure select's `.mx-outer`, rebuilt
    // from `mx-banded`/`lw-sda`/`mx-arranging`/`mx-figures`) loses the class on
    // the next render — a phone drag whose edge auto-scroll turned the band on
    // would go dim mid-drag. The class stays for the day grid's own recipe,
    // which is keyed on it (6 Sep 26 review).
    wrap.classList.add('selecting')
    wrap.setAttribute('data-selecting', '1')
    try { (navigator as { vibrate?: (ms: number) => void }).vibrate?.(12) } catch { /* unsupported */ }
    // The bands the PRESS sat in (the press point, not the arming move — a
    // mouse arms a few px on, a finger arms still). See noteEdge.
    held = bandsAt(sx, sy)
    // Lock the scroll now, and ONLY now: the non-passive touchmove listener
    // exists for the life of an armed drag and nowhere else, so a normal
    // sideways scroll never runs JS per frame (that scroll is sacred). See the
    // onTouchMove note.
    wrap.addEventListener('touchmove', onTouchMove, { passive: false })
    document.addEventListener('contextmenu', onCtxMenu, true)
    repaint()
    spec.onArm?.()
    // Edge auto-scroll runs for both a mouse and a finger now (owner, 30 Aug 26):
    // touch ramps its speed by finger depth (see edgeScroll). The rAF is stopped
    // in teardown(), so it can never outlive the armed drag.
    if (!raf) raf = requestAnimationFrame(edgeScroll)
  }

  const onMove = (e: PointerEvent) => {
    if (anchor === null) return
    // Only the gesture's OWN pointer moves it — a second finger brushing the
    // grid mid-drag must not steer (or, worse, disarm) the selection.
    if (e.pointerId !== pid) return
    lastX = e.clientX; lastY = e.clientY
    if (!armed) {
      const dx = Math.abs(e.clientX - sx), dy = Math.abs(e.clientY - sy)
      const moved = Math.max(dx, dy)
      if (e.pointerType === 'mouse') { if (moved >= MOUSE_SLOP) arm() }
      else if (moved > GIVEUP) {
        // A slide past GIVEUP before the still-hold armed. If the finger has
        // already been down past SLOWARM (slowReady), this is a SLOW, deliberate
        // drag the user began without pausing first — arm the select rather
        // than lose it (owner, 27 Aug 26 — "I can't select a range … stuck with
        // 1 input"). A quick scroll flick crosses GIVEUP long before SLOWARM,
        // so the grid's sacred sideways scroll still wins it: cede.
        if (slowReady) arm()
        else { teardown(); clearPaint() }
      }
      return
    }
    e.preventDefault()
    // Read on the move as well as per frame, so a band left and re-entered
    // between two frames still counts as left.
    noteEdge()
    repaint()
  }

  // Swallow the click the browser fires on the anchor after this pointer
  // ends: after a COMMITTED drag (its single-cell onClick would open the
  // wrong sheet) and, since 6 Sep 26, after a CANCELLED armed one — an iOS
  // system gesture cutting a hold short fires pointercancel, and the trailing
  // click then opened a breakdown over a selection the user thought they had.
  // One-shot AND a 0ms sweep, so a drag that produces no trailing click never
  // leaves a listener to eat the next real one.
  //   A FINGER'S TAP COMES LATER (the absence-record re-test, W4-1, 26 Sep 26 — found by the phone walk): the tap a
  // touch leaves behind arrives ~20–30 ms after the lift, and the 0 ms sweep had already retired the swallow — so a
  // finger held on ONE day and lifted opened the selection sheet, and its own tap landed on the day and closed it.
  // A touch gesture waits TOUCH_TAP_WAIT for its tap; a mouse keeps the 0 ms sweep, so a desktop's next real click is
  // never eaten. (A second deliberate tap inside that window is not a thing a hand does.)
  //   It also ends at the NEXT press (a new gesture beginning means the old one's tap has come or never will — a
  // finger dragged across days sends none) and when the grid goes away, so a waiting swallow can never eat a real
  // tap that starts fresh (the Inputs calendar's click eater, caldrag.ts, keeps the same three exits).
  let endSwallow: (() => void) | null = null
  const swallowNextClick = (touch: boolean) => {
    endSwallow?.()
    /* stopIMMEDIATEpropagation (the re-walk, 26 Sep 26 — W4's re-walker): on a touch screen the sheet this gesture just
       opened puts its own tap shield on the document too (Sheet.tsx useGridPan), and it closes the sheet on a click
       under it; plain stopPropagation does not stop another listener on the same node, so the swallowed tap still
       closed the sheet 22 ms after it opened. The swallow is added first (before the sheet mounts), so it runs first. */
    const swallow = (ev: Event) => { ev.stopImmediatePropagation(); ev.preventDefault(); off() }
    const off = () => {
      document.removeEventListener('click', swallow, true)
      document.removeEventListener('pointerdown', off, true)
      clearTimeout(timer)
      if (endSwallow === off) endSwallow = null
    }
    document.addEventListener('click', swallow, true)
    document.addEventListener('pointerdown', off, true)
    const timer = setTimeout(off, touch ? TOUCH_TAP_WAIT : 0)
    endSwallow = off
  }
  const finish = (commit: boolean) => {
    const wasArmed = armed, touch = touchGesture
    // Read the selection BEFORE teardown nulls the anchor.
    const s = commit && armed && anchor !== null ? current() : null
    teardown()
    if (wasArmed) swallowNextClick(touch)
    if (s) spec.onSelect(s.payload)
    clearPaint()
  }

  // Commit only on the gesture's own pointer, and only on the PRIMARY button
  // going up: a second finger lifting, or a right button pressed-and-released
  // mid-left-drag, used to commit the rectangle at wherever the cursor
  // happened to be.
  const onUp = (e: PointerEvent) => {
    if (e.pointerId !== pid) return
    if (e.button > 0) return
    finish(true)
  }
  // While a drag is ARMED, a right-click must not pop the browser menu over
  // the selection wash (move mode swallows its own; this covers the drag).
  const onCtxMenu = (e: Event) => { if (armed) e.preventDefault() }

  function teardown() {
    if (holdTimer) { clearTimeout(holdTimer); holdTimer = null }
    if (slowTimer) { clearTimeout(slowTimer); slowTimer = null }
    slowReady = false
    if (raf) { cancelAnimationFrame(raf); raf = 0 }
    window.removeEventListener('pointermove', onMove, true)
    window.removeEventListener('pointerup', onUp, true)
    window.removeEventListener('pointercancel', onCancel, true)
    document.removeEventListener('contextmenu', onCtxMenu, true)
    if (pid >= 0) { try { wrap.releasePointerCapture(pid) } catch { /* not captured */ } }
    wrap.removeEventListener('touchmove', onTouchMove)
    wrap.style.touchAction = ''
    wrap.classList.remove('selecting')
    wrap.removeAttribute('data-selecting')
    anchor = null; armed = false; pid = -1; vscroll = null; held = 0   // re-resolve next drag
    enteredAt.clear()
    spec.reset?.()
  }
  const onCancel = (e: PointerEvent) => {
    if (e.pointerId !== pid) return   // a second pointer's cancel is not ours
    const wasArmed = armed, touch = touchGesture
    teardown(); clearPaint()
    if (wasArmed) swallowNextClick(touch)
  }

  // THE SCROLL LOCK (owner, 27 Aug 26 — "when I hold then drag … I can't
  // select a date range, I'm stuck with just adding 1 input"). On touch the
  // browser decides at touchstart whether the finger scrolls the grid, and a
  // pointermove's preventDefault does NOT change that — so once the drag
  // moved, the grid scrolled and the browser fired pointercancel, killing the
  // armed selection mid-drag. The only thing that stops the scroll is a
  // NON-PASSIVE touchmove preventDefault. This listener is added in arm() and
  // removed in teardown(), so it exists ONLY during an armed drag: the
  // long-press fires arm() before the finger has moved, so the very first move
  // is already caught and no scroll ever starts, while a quick drag that never
  // held never adds it at all — the grid's sideways scroll (sacred, reported
  // broken three times) keeps its fully-passive fast path.
  const onTouchMove = (e: TouchEvent) => { if (armed) e.preventDefault() }

  const onDown = (e: PointerEvent) => {
    if (!spec.enabled()) return
    if (e.button !== undefined && e.button !== 0) return   // left / primary only
    // One gesture at a time: a second finger landing mid-drag used to RESET
    // the state (anchor kept, armed dropped, pid re-aimed), so the armed
    // selection silently evaporated on lift. The first pointer owns the
    // gesture until it ends.
    if (anchor !== null) return
    const a = spec.hit(e.target as HTMLElement)
    if (a === null) return   // not a selectable thing (who / bal / handle / a band / events off)
    anchor = a
    armed = false; pid = e.pointerId
    touchGesture = e.pointerType !== 'mouse'
    sx = e.clientX; sy = e.clientY; lastX = e.clientX; lastY = e.clientY
    // NB: pointer capture is taken in arm(), not here — see the note there.
    window.addEventListener('pointermove', onMove, true)
    window.addEventListener('pointerup', onUp, true)
    window.addEventListener('pointercancel', onCancel, true)
    if (e.pointerType !== 'mouse') {
      holdTimer = setTimeout(arm, HOLD)
      slowReady = false
      slowTimer = setTimeout(() => { slowReady = true }, SLOWARM)
    }
  }

  wrap.addEventListener('pointerdown', onDown)
  return () => { wrap.removeEventListener('pointerdown', onDown); teardown(); clearPaint(); endSwallow?.() }
}

export function wireSelect(wrap: HTMLElement, ctx: SelectCtx): () => void {
  let lastFocus: Cell | null = null      // last roster cell the finger was over
  let lastFocusDate: string | null = null // last event date the finger was over
  type Payload = { roster?: Selection; event?: EventSelection }

  return wireGesture<Hit, Payload>(wrap, {
    enabled: ctx.enabled,
    cls: 'selcell',
    node: id => wrap.querySelector(`[data-testid="${id}"]`),
    leftEdge: ctx.leftEdge,
    reset: () => { lastFocus = null; lastFocusDate = null },
    hit: el => {
      const roster = parseCellId(el?.closest?.('[data-testid^="cell-"]')?.getAttribute('data-testid'))
      const event = roster ? null : parseEventCell(el?.closest?.('[data-testid^="event-"]')?.getAttribute('data-testid'))
      if (roster) return { kind: 'roster', cell: roster }
      if (event && (ctx.eventsEnabled?.() ?? false)) return { kind: 'event', cell: event }
      return null
    },
    // The selection under the current focus point, as the ids to paint plus the
    // typed payload to hand off on release. Roster and event anchors take separate
    // axes: a roster drag is a people×days rectangle; an event drag is a date span
    // on the anchor's own line (the focus supplies only the COLUMN — its row is
    // ignored, so a finger straying onto another row still extends the span).
    //   When the finger is NOT over a cell — a gap between rows, or the empty area
    // an edge auto-scroll runs the grid past — we HOLD the last cell it was over
    // rather than collapsing to the anchor. Without this a drag to the bottom edge
    // vanished the moment the auto-scroll ran the last row above the finger.
    current: (anchor, x, y) => {
      if (anchor.kind === 'roster') {
        const hit = cellAt(x, y)
        if (hit) lastFocus = hit
        const raw = hit ?? lastFocus ?? anchor.cell
        // The focus may land on a row OUTSIDE the selectable order — a scoped
        // member's drag straying onto another person (the row list is the viewer
        // alone), or a held focus (below) left pointing at a row the order no
        // longer carries. Clamp its PERSON to the anchor's row, keeping the DATE,
        // so the selection stays on a valid row and still spans the days dragged.
        // Without this the stray produced an empty rect (rectCells → null) and the
        // sheet never opened — a scoped member could not drag-fill at all.
        const f = ctx.order().includes(raw.personId) ? raw : { personId: anchor.cell.personId, date: raw.date }
        const sel = rectCells(ctx.order(), ctx.dates(), anchor.cell, f)
        return sel ? { ids: sel.cells.map(c => `cell-${c.personId}-${c.date}`), payload: { roster: sel } } : null
      }
      const hitDate = cellAt(x, y)?.date ?? eventAt(x, y)?.date
      if (hitDate) lastFocusDate = hitDate
      const fd = hitDate ?? lastFocusDate ?? anchor.cell.date
      const sel = eventRange(ctx.dates(), anchor.cell.line, anchor.cell.date, fd)
      return sel ? { ids: sel.dates.map(d => `event-${sel.line}-${d}`), payload: { event: sel } } : null
    },
    onSelect: p => {
      if (p.roster) ctx.onSelect(p.roster)
      else if (p.event) ctx.onEventSelect?.(p.event)
    },
  })
}

/* ---- ROW SELECT (the OIL tracker, owner 2 Sep 26) -------------------------
   A run of PEOPLE rows, one axis. The press must land on a row's PICK target
   (`[data-oilpick]` — the name cell), so the history strip beside it keeps
   its ordinary sideways scroll and never starts a selection; the drag then
   extends over any part of the rows below or above (`[data-oilrow]`). Same
   hold-then-drag on a finger, same slop on a mouse, same scroll lock. */
export interface RowSelectCtx {
  order: () => string[]     // selectable row ids, top → bottom
  enabled: () => boolean
  onSelect: (ids: string[]) => void
}

/** The run of rows between two ids in `order`; `null` off the list. */
export function rowRun(order: string[], a: string, f: string): string[] | null {
  const ai = order.indexOf(a), fi = order.indexOf(f)
  if (ai < 0 || fi < 0) return null
  return order.slice(Math.min(ai, fi), Math.max(ai, fi) + 1)
}

const rowAt = (x: number, y: number): string | null =>
  (document.elementFromPoint(x, y) as HTMLElement | null)?.closest('[data-oilrow]')?.getAttribute('data-oilrow') ?? null

export function wireRowSelect(wrap: HTMLElement, ctx: RowSelectCtx): () => void {
  let lastFocus: string | null = null
  return wireGesture<string, string[]>(wrap, {
    enabled: ctx.enabled,
    cls: 'selrow',
    node: id => wrap.querySelector(`[data-oilrow="${id}"]`),
    reset: () => { lastFocus = null },
    vscroll: w => ({ el: w, isDoc: false }),
    hit: el => {
      const pick = el?.closest?.('[data-oilpick]')?.closest('[data-oilrow]')?.getAttribute('data-oilrow') ?? null
      return pick && ctx.order().includes(pick) ? pick : null
    },
    current: (anchor, x, y) => {
      const hit = rowAt(x, y)
      if (hit && ctx.order().includes(hit)) lastFocus = hit
      const run = rowRun(ctx.order(), anchor, lastFocus ?? anchor)
      return run ? { ids: run, payload: run } : null
    },
    onSelect: ctx.onSelect,
  })
}

/* ---- FIGURE SELECT (the counter column and the figures drawer, owner 6 Sep
   26 — "drag as many as I like and key one number into them all") ----------
   A run of PEOPLE down ONE figure column. The anchor's figure fixes the pool
   (the run never widens sideways — one pool per drag, the owner's call); the
   focus is whichever person's box is under the pointer, in any of a box's
   three copies (the real cell, the band's copy, a drawer box), all addressed
   by `data-fig` + `data-person`. Bound on `.mx-outer`, the one ancestor of all
   three. Painted as an ATTRIBUTE (see the pair below), never a class —
   FigureCell rebuilds its className on every store change, which is exactly the
   moment Save lands. A heading, a sub-heading or an event row under the pointer
   holds the last person (`lastFocus`), the grid's own rule. */
export interface FigureSelectCtx {
  order: () => string[]                     // person ids, top → bottom, people only
  selectable: (figId: string) => boolean    // a balance with a counter; a total never
  enabled: () => boolean
  onArm?: () => void
  onSelect: (sel: FigureSelection) => void
}
export type FigureSelection = { fig: string; ids: string[] }
type FigAnchor = { fig: string; person: string }
/* TWO WRITERS, TWO ATTRIBUTES, and they must never be one (6 Sep 26 review).
   React renders `data-figsel` for the COMMITTED selection; the gesture paints
   `data-figdrag` while a drag is live and wipes its own marks on release.
   Shared, the gesture's clear stripped boxes React already owned — and React
   only writes an attribute whose PROP changed, so it never put them back: a
   second drag overlapping a live selection left a selected person dark, and a
   cancelled drag (which commits nothing, so nothing re-renders) left the whole
   selection dark. Both are lit by the same CSS (matrix.css), so a box under a
   drag looks the same whichever attribute it is wearing. */
export const FIGSEL_ATTR = 'data-figsel'
export const FIGDRAG_ATTR = 'data-figdrag'
const FIGBOX = 'td.figbox[data-fig][data-person]'

const figBoxOf = (el: Element | null | undefined): FigAnchor | null => {
  const box = el?.closest?.(FIGBOX)
  return box ? { fig: box.getAttribute('data-fig')!, person: box.getAttribute('data-person')! } : null
}
const figBoxAt = (x: number, y: number) => figBoxOf(document.elementFromPoint(x, y))

export function wireFigureSelect(outer: HTMLElement, ctx: FigureSelectCtx): () => void {
  let lastFocus: string | null = null
  return wireGesture<FigAnchor, FigureSelection>(outer, {
    enabled: ctx.enabled,
    nodes: id => {
      const i = id.indexOf(':')
      return Array.from(outer.querySelectorAll(`td.figbox[data-fig="${id.slice(0, i)}"][data-person="${id.slice(i + 1)}"]`))
    },
    mark: (el, on) => { if (on) el.setAttribute(FIGDRAG_ATTR, '1'); else el.removeAttribute(FIGDRAG_ATTR) },
    reset: () => { lastFocus = null },
    onArm: ctx.onArm,
    // GENTLE at the edge, unlike the day grid (6 Sep 26 bug hunt). What this
    // run collects is what a number gets written to, so a finger that simply
    // ends its drag in a phone's bottom band must not go on gathering people:
    // 0.3 of the step (≤5px a frame at full depth against the grid's 15), and
    // not until it has RESTED half a second in the band. The numbers are
    // measured, not guessed: the drag that started this ran 259px and lit
    // fourteen; at 0.4 and 220ms it still reached eight, because a drag's own
    // moves burn a short dwell before the finger has even stopped. Half a
    // second outlasts the drag, so the wait only begins once the finger really
    // has come to rest — the same drag now scrolls NOTHING while it is being
    // made (measured: 0px), and then runs at about a third of the day grid's
    // pace, ~7 rows a second at the depth a drag like that ends at. Rested
    // there on purpose a run CAN still be extended past the screen; the bar's
    // count is the check before Save.
    edge: { rate: 0.3, dwellMs: 500 },
    // A HOLD selects, a quick tap still opens the breakdown — the day grid's own
    // rhythm, on the same feel constants. So an admin's press that dwells past
    // HOLD (or a mouse that moves past MOUSE_SLOP) commits a selection of the
    // one person pressed and swallows the trailing click; a plain tap never
    // arms, and the box's own onClick opens that person's figure as it always
    // has. Pinned both ways in the e2e.
    hit: el => {
      const box = figBoxOf(el)
      return box && ctx.selectable(box.fig) && ctx.order().includes(box.person) ? box : null
    },
    current: (anchor, x, y) => {
      const hit = figBoxAt(x, y)
      if (hit && ctx.order().includes(hit.person)) lastFocus = hit.person
      const run = rowRun(ctx.order(), anchor.person, lastFocus ?? anchor.person)
      return run ? { ids: run.map(p => `${anchor.fig}:${p}`), payload: { fig: anchor.fig, ids: run } } : null
    },
    onSelect: ctx.onSelect,
  })
}

/* ---- MOVE MODE (owner, 27 Aug 26) ----------------------------------------
   After "Move…", the sheet closes and the block waits to be dropped. On a
   desktop a faded ghost follows the mouse and a CLICK lands it; on a phone
   there is no hover, so a slim banner (drawn by the matrix) stands in and a
   TAP lands it — and a swipe must scroll, never drop, so only a click that
   is NOT the tail of a scroll commits. The commit click is swallowed in the
   capture phase so the cell's own single-click sheet never opens under it. */
/* WHAT A CLICK OUTSIDE THE GRID MUST NOT CANCEL (D262): a control of any kind, the move's own banner, and a sheet or a
   popup and its shade — a sheet's, the Legend's, the under-manned list's (found writing the walk: a tap on the Legend's
   shade to close it also ended the move). Pressing one is a thing a person does ON PURPOSE, never "an empty area". */
const NOT_EMPTY = 'button, a[href], input, select, textarea, label, summary, [role="button"], [role="dialog"], [role="menu"], [role="menuitem"], [role="tab"], [contenteditable=""], [contenteditable="true"], .bidsheet, .mv-banner, [data-testid$="scrim"]'
/* A move just begun ignores, for this long, a click on the SPOT where Move was pressed (D262, Fable's S1): the sheet's
   Move closes the sheet on the first click of a double-click, and the second then fell on whatever day sat under the
   button. A PLACE as well as a time (the gate run, 27 Sep 26): a time alone also dropped a deliberate click made
   quickly on another day — a double-click's second click lands where the first did, a deliberate one elsewhere. */
const MOVE_SETTLE = 400
const SETTLE_PX = 12
/* where the last press landed — read by a move as it begins (the press that pressed Move). A pointerdown or, for a
   keyboard or test that clicks without pressing, the click itself; module-wide, passive, a plain assignment. */
let LAST_PRESS: { x: number; y: number } | null = null
if (typeof document !== 'undefined') {
  const note = (e: MouseEvent) => { LAST_PRESS = { x: e.clientX, y: e.clientY } }
  document.addEventListener('pointerdown', note as EventListener, true)
  document.addEventListener('click', note, true)
}
/* The click a press-and-drag's own release (or a finger's lift) leaves behind arrives inside this — the gesture core's
   TOUCH_TAP_WAIT and a margin; it is the drag's, not a second pick. */
const DRAG_TAIL = 450

export function wireMove(
  wrap: HTMLElement,
  opts: {
    count: number
    // Desktop only — the mouse hovering a day, so the matrix can paint the
    // landing preview live. A phone has no hover, so this never fires there.
    // (A held drag previews through it on both — D262.)
    onHover: (targetDate: string) => void
    // A click (desktop) or tap (phone) ON a day. The matrix decides what it
    // means: a desktop click lands the block at once (the live hover was the
    // preview); a phone tap STAGES the landing and shows a Confirm bar, since
    // there is no undo and no hover to preview with (owner, 27 Aug 26).
    onPick: (targetDate: string) => void
    onCancel: () => void
    // How to read the target DATE from the pointer's element. Defaults to the
    // roster cell parser (`cell-<person>-<date>`), unchanged; the EVENT move
    // (owner, 31 Aug 26 — "drag an existing event to move it") passes one that
    // also reads an `event-<line>-<date>` cell, so a tap on the event LINE lands
    // it. Only the date is ever used, so one resolver serves both axes.
    dateAt?: (t: EventTarget | null) => string | null
    /** A held drag has left the days: take the landing preview down (the final reads — Fable F3, Astra 2). */
    onOff?: () => void
    /** Client-x where the DAYS begin — past the frozen name / counter columns or the open figures drawer (D262): the
     *  left edge band starts there, as the drag-select's does. Absent = the wrap's own left edge. */
    leftEdge?: () => number
    /** Is this element part of the grid (D262)? The mouse's edge scroll runs only over the grid, and a click on an
     *  EMPTY spot that is not — the page around it, never a control — ends the move ("unless i click on an empty
     *  area outside the leave war grids to cancel that function"). Absent: neither. */
    isGrid?: (t: Element) => boolean
  },
): () => void {
  // The ghost is a HOVER decoration, so it exists only where hover exists: a
  // phone fires compatibility mousemove events around a tap, and those used to
  // unhide the chip at the tap point — a stranded copy of the banner that then
  // teleported tap to tap. `(hover: none)` is the device truth; when
  // matchMedia itself is absent (jsdom) the desktop path stands.
  const hasHover = (() => {
    try { return typeof window.matchMedia !== 'function' || !window.matchMedia('(hover: none)').matches }
    catch { return true }
  })()
  // Inline-styled on purpose: the ghost lives on document.body, OUTSIDE the
  // `#page-leavewar` section every matrix.css rule is scoped under, so a class
  // would not reach it. It is a transient cursor decoration, not chrome.
  const ghost = hasHover ? document.createElement('div') : null
  if (ghost) {
    ghost.setAttribute('data-testid', 'move-ghost')
    ghost.textContent = `Move ${opts.count} ${opts.count === 1 ? 'entry' : 'entries'}`
    Object.assign(ghost.style, {
      position: 'fixed', zIndex: '9999', pointerEvents: 'none', display: 'none',
      padding: '4px 10px', borderRadius: '8px', font: '600 12px/1.2 system-ui, sans-serif',
      color: '#E8F6FB', background: 'rgba(20, 40, 50, .92)',
      border: '1px solid rgba(59, 198, 232, .6)', boxShadow: '0 8px 24px rgba(0,0,0,.5)', opacity: '.9',
    } as Partial<CSSStyleDeclaration>)
    document.body.appendChild(ghost)
  }

  const cellAtTarget = (t: EventTarget | null): Cell | null =>
    parseCellId((t as HTMLElement)?.closest?.('[data-testid^="cell-"]')?.getAttribute('data-testid'))
  // Resolve the target DATE — the caller's own resolver (event move) or the
  // default roster-cell one (unchanged behaviour for the roster move).
  const dateAt = opts.dateAt ?? ((t: EventTarget | null) => cellAtTarget(t)?.date ?? null)

  // The hover preview re-fires only when the hovered DAY changes. Mousemove
  // arrives per pixel (~60-120/s), and the first cut repainted the landing —
  // full-grid querySelector scans — on every one of them; on the ~28k-node
  // grid that is exactly the per-frame work the perf notes forbid.
  let lastHover = ''
  const hover = (date: string | null) => { if (date && date !== lastHover) { lastHover = date; opts.onHover(date) } }
  const off = () => { if (lastHover) { lastHover = ''; opts.onOff?.() } }
  /* A SHEET OPENED MID-MOVE OWNS THE TAP (the final reads, 27 Sep 26 — Fable F2): on a coarse pointer a sheet's shade
     lets a tap through to the grid beneath (Sheet.tsx), and this capture listener, older than the sheet's, read it
     first — staging the chip on the day under the finger, or ending the move, as the tap closed the sheet. */
  const sheetUp = (): boolean => !!document.querySelector('.bidsheet')
  const began = Date.now()
  const pressedAt = LAST_PRESS
  let dragPickedAt = -Infinity

  /* THE MOUSE'S EDGE SCROLL (owner, D262, 27 Sep 26 — "when i drag to the edges of the leave war it should auto
     scroll"). The picked-up chip FOLLOWS the mouse (the ghost), so carrying the mouse to the grid's left or right edge
     is the drag, button held or not: the days scroll under it, at the drag-select's own speed and band, and the
     landing preview follows the day slid under it. Sideways only — a move lands by DATE, on any row, so the page never
     needs to run under a resting mouse to reach it (a held drag, below, still scrolls the page like the drag-select).
     Only over the grid, so the mouse on its way to the banner or the page's own controls moves nothing; and a band the
     mouse was ALREADY in when the move began must be left first (Fable's S2 — the sheet closes under a still mouse),
     the drag-select's held-band rule. A button held is the drag machine's (below), never this loop's. */
  /* THE BANDS ARE THE DAYS' OWN EDGES (the final reads, 27 Sep 26 — Fable F1, F4): measured from where the days begin
     (past the frozen names and the month buttons) to the grid's right edge, and only within the days' box top to
     bottom — the card's own controls (Manning, ⚙, OIL, zoom), the frozen names and the early month buttons are the
     grid's too, and resting the mouse on one used to run the days off toward January. The band is GEOMETRY alone, so
     "left the band" is judged the same whether a button is held or the mouse crosses the banner; whether the mouse is
     over the days (`overGrid`) decides only whether this loop scrolls. At either end of the grid it stops asking for
     frames. */
  let mx = 0, my = 0, overGrid = false, hoverRaf = 0
  let seen = false        // a mousemove has been read since the move began
  let bandsLive = false   // the mouse has been OUTSIDE every band since then
  const band = (): number => {
    const r = wrap.getBoundingClientRect()
    if (my < r.top || my > r.bottom) return 0
    const left = opts.leftEdge ? opts.leftEdge() : r.left
    return mx >= left && mx < left + EDGE ? -1 : mx > r.right - EDGE && mx <= r.right ? 1 : 0
  }
  const edgeStep = () => {
    hoverRaf = 0
    const dir = bandsLive && overGrid ? band() : 0
    if (!dir) return
    const before = wrap.scrollLeft
    wrap.scrollLeft = before + dir * EDGE_STEP
    if (wrap.scrollLeft === before) return          // the grid's end: nothing left to scroll
    hover(dateAt(document.elementFromPoint(mx, my)))
    hoverRaf = requestAnimationFrame(edgeStep)
  }
  const onMouseMove = (e: MouseEvent) => {
    if (ghost) {
      ghost.style.display = ''
      ghost.style.left = `${e.clientX + 14}px`
      ghost.style.top = `${e.clientY + 14}px`
    }
    if (!hasHover) return
    mx = e.clientX; my = e.clientY
    overGrid = e.buttons === 0 && e.target instanceof Element
      && (wrap.contains(e.target) || !!e.target.closest('[data-testid="sticky-head"], [data-testid="hscroll"]'))
    const inBand = band() !== 0
    if (!seen) { seen = true; bandsLive = !inBand } else if (!inBand) bandsLive = true
    if (inBand && overGrid && bandsLive && !hoverRaf) hoverRaf = requestAnimationFrame(edgeStep)
    hover(dateAt(e.target))
  }
  const onLeaveDoc = () => { overGrid = false }

  /* A PRESS-AND-DRAG CARRIES IT TOO, AND LANDS ON THE LIFT (D262 — the agent's reading (c), stated to him: the desktop
     lands on the click OR the release). The drag-select's own machine, pointed at the move: a mouse arms at a few px, a
     finger by HOLDING (a quick swipe still scrolls the grid — that scroll is sacred), the edge bands scroll the days
     and the page exactly as a drag-select's do, the landing preview follows the finger, and the lift picks the day it
     is over — a desktop lands it, a phone stages it for Confirm, as a tap does. Nothing is painted by the machine
     itself: the matrix's landing preview is the paint. The click the release leaves behind is the drag's own, not a
     second pick (`dragPickedAt`). */
  /* A RELEASE OFF THE DAYS LANDS NOTHING (both final reads, 27 Sep 26 — Fable F3, Astra 2): the payload is the day
     under the pointer NOW, never the last one crossed — a drag carried off the grid and let go is a "never mind", as a
     click there is; the landing preview is taken down the moment the pointer leaves the days. */
  let dragDay: string | null = null
  const dragOff = wireGesture<string, string>(wrap, {
    enabled: () => true,
    /* a sheet opened mid-move owns every press (Fable F2 — below) */
    hit: t => (sheetUp() ? null : dateAt(t)),
    current: (_anchor, x, y) => {
      const d = dateAt(document.elementFromPoint(x, y))
      if (d !== dragDay) { dragDay = d; if (d) hover(d); else off() }
      return d ? { ids: [], payload: d } : null
    },
    onSelect: d => { dragPickedAt = Date.now(); opts.onPick(d) },
    reset: () => { dragDay = null },
    node: () => null, cls: 'mvdrag',
    leftEdge: opts.leftEdge,
  })

  // A finger's long press reaches the page as a right-click on Android; only a MOUSE's right-click cancels (Fable's S11).
  let lastPointer = 'mouse'
  const onDown = (e: PointerEvent) => { lastPointer = e.pointerType || 'mouse' }

  const onClick = (e: MouseEvent) => {
    if (sheetUp()) return
    const date = dateAt(e.target)
    /* the second click of a double-click on Move (the same spot, straight away), or the tail of a drag already landed —
       swallowed, never a pick */
    const secondOfDouble = Date.now() - began < MOVE_SETTLE && !!pressedAt && Math.hypot(e.clientX - pressedAt.x, e.clientY - pressedAt.y) < SETTLE_PX
    if (secondOfDouble || Date.now() - dragPickedAt < DRAG_TAIL) {
      if (date) { e.stopPropagation(); e.preventDefault() }
      return
    }
    if (!date) {
      /* AN EMPTY SPOT OUTSIDE THE GRID ENDS THE MOVE (D262). Not a day and not the grid: the page around it. A control
         (the month buttons are the grid's own anyway), a sheet or its shade is a deliberate press, and keeps it on. */
      const t = e.target instanceof Element ? e.target : null
      if (t && opts.isGrid && !opts.isGrid(t) && !t.closest(NOT_EMPTY)) opts.onCancel()
      return
    }
    e.stopPropagation(); e.preventDefault()   // never open the cell's own sheet
    opts.onPick(date)
  }
  const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); opts.onCancel() } }
  // Right-click cancels the move on a desktop (owner, 27 Aug 26 — "if I want to
  // cancel, I can just right click to deselect what I selected"): swallow the
  // browser context menu and drop the block, the mouse equivalent of Escape.
  const onCtx = (e: MouseEvent) => { e.preventDefault(); e.stopPropagation(); if (lastPointer === 'mouse') opts.onCancel() }

  document.addEventListener('mousemove', onMouseMove)
  document.documentElement.addEventListener('mouseleave', onLeaveDoc)
  document.addEventListener('pointerdown', onDown, true)
  document.addEventListener('click', onClick, true)   // capture — beat React's cell onClick
  document.addEventListener('contextmenu', onCtx, true)
  document.addEventListener('keydown', onKey, true)
  return () => {
    document.removeEventListener('mousemove', onMouseMove)
    document.documentElement.removeEventListener('mouseleave', onLeaveDoc)
    document.removeEventListener('pointerdown', onDown, true)
    document.removeEventListener('click', onClick, true)
    document.removeEventListener('contextmenu', onCtx, true)
    document.removeEventListener('keydown', onKey, true)
    if (hoverRaf) { cancelAnimationFrame(hoverRaf); hoverRaf = 0 }
    dragOff()
    ghost?.remove()
  }
}

/** Paint the move-mode LANDING preview onto the grid — where the picked block
 *  will sit if dropped now. Stateless (it clears by the `.mvland` class, not a
 *  tracked set) so the matrix can drive it from either the desktop hover or the
 *  phone's staged tap without threading a painter through. */
export function paintLanding(wrap: HTMLElement, cells: Cell[]): void {
  clearLanding(wrap)
  for (const c of cells) wrap.querySelector(`[data-testid="cell-${c.personId}-${c.date}"]`)?.classList.add('mvland')
}
export function clearLanding(wrap: HTMLElement): void {
  wrap.querySelectorAll('.mvland').forEach(el => el.classList.remove('mvland'))
}

/** Paint the move-mode LANDING preview onto an EVENT line — the days the moved
 *  event will cover if dropped now (owner, 31 Aug 26). Shares the `.mvland`
 *  class and `clearLanding` with the roster painter, so a move is only ever one
 *  kind at a time and one clearer wipes either. */
export function paintEventLanding(wrap: HTMLElement, line: number, dates: string[]): void {
  clearLanding(wrap)
  for (const d of dates) wrap.querySelector(`[data-testid="event-${line}-${d}"]`)?.classList.add('mvland')
}

/** Read the target DATE for an EVENT move from a pointer element — the event
 *  line's own `event-<line>-<date>` cell, or a roster cell in the same column as
 *  a fallback (a tap just below the event row still lands on the day). A merged
 *  `event-band-…` cell resolves to null: you land on a free day, not on another
 *  band. Only the date matters for a move, so either precise cell resolves it. */
export function eventMoveDateAt(t: EventTarget | null): string | null {
  const el = (t as HTMLElement)?.closest?.('[data-testid^="event-"], [data-testid^="cell-"]')
  const id = el?.getAttribute('data-testid')
  return parseEventCell(id)?.date ?? parseCellId(id)?.date ?? null
}

/** The earliest day among a set of cells (min YYYY-MM-DD, which sorts as date
 *  order). The move anchors here so the block's FIRST input lands on the tapped
 *  day (owner, 27 Aug 26 — "drop the leave on the day you tap"); any empty
 *  margin the user swept up before it is simply dropped, and the gaps BETWEEN
 *  inputs ride along because every cell shifts by the same delta. `null` for an
 *  empty set. */
export function earliestDate(cells: Cell[]): string | null {
  let min: string | null = null
  for (const c of cells) if (min === null || c.date < min) min = c.date
  return min
}

/** Whole days between two YYYY-MM-DD dates (b − a), for the move delta. */
export function daysBetween(a: string, b: string): number {
  return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000)
}
