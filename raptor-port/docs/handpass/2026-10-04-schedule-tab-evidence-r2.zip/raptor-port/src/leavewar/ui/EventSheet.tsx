// The Event sheet — where an admin writes, ranges, merges, tags and deletes a
// day event (owner, Aug 26: "click on the event and an edit button is at the
// top").
//
// It carries the whole surface the two inline textareas used to be:
//   · open text for the day (or a range);
//   · a range, chosen on the same calendar the bid window uses;
//   · for a range, MERGE (one bar, the default) or REPEAT (the word in each
//     day);
//   · a TAG (off / no-leave / work) for THIS event — held on the event itself
//     and saved with it (owner, 18 Aug 26: "I don't want u to save it as a
//     type"). It used to mint the typed word into the type library; now the
//     library changes only inside Edit types, and a library word still
//     classifies by match when the event carries no tag of its own;
//   · and, behind the "Edit types" button at the top, the whole type library.
//
// The tag never shows as words in the grid; it reads only as colour (Matrix
// paints the column; the word itself goes red for work).

import { useState } from 'react'
import {
  bandAt,
  classifyEvent,
  dayEventKind,
  EVENT_KINDS,
  type EventKind,
} from '../engine'
import {
  addEventBand,
  addEventType,
  getState,
  removeEventBand,
  removeEventType,
  resetEventTypes,
  setDayEvent,
  setDayEventRange,
  updateEventType,
} from '../state/store'
import { RangePicker, type Range } from './RangePicker'
import { Sheet } from './Sheet'
import { shortSpan } from './dates'
import { useVersion } from './useStore'
import './eventsheet.css'

const KIND_LABEL: Record<EventKind, string> = {
  off: 'PH',
  free: 'Off day',
  nolv: 'No leave',
  work: 'Work',
}

export function EventSheet({ line, date, to, onClose, onMove }: { line: number; date: string; to?: string; onClose: () => void; onMove?: (m: { line: number; from: string; to: string }) => void }) {
  useVersion()
  const { period, eventDefs: defs } = getState()
  // The band (if any) that owns this cell. Editing it means replacing it, so
  // it is captured up front and removed on apply/delete.
  const band = bandAt(period.bands, line, date)
  const day = period.days.find(d => d.date === date)
  // A DRAG opens the sheet already ranged from the swept span (owner, 27 Aug
  // 26); a plain click leaves `to` undefined and opens on the one day.
  const dragged = to !== undefined && to !== date

  const [text, setText] = useState(band ? band.text : (day?.events[line] ?? ''))
  const [scope, setScope] = useState<'day' | 'range'>(band || dragged ? 'range' : 'day')
  // A RANGE opens on ONE MERGED BAR (owner, 28 Aug 26 — "can the default
  // selection be one merged bar instead of repeat each day"). A span of days
  // that share a name is nearly always one thing — an exercise, a detachment,
  // a stand-down — so the bar is the shape a scheduler wants; repeating the
  // word into each cell is the exception, and it is one tap away. An existing
  // band already opened merged, so this only changes the fresh-range case (a
  // plain click that is then ranged, or a drag-swept span).
  const [mode, setMode] = useState<'merge' | 'repeat'>('merge')
  const [range, setRange] = useState<Range | null>(
    band ? { from: band.from, to: band.to } : { from: date, to: to ?? date },
  )
  const [view, setView] = useState<'event' | 'types'>('event')
  const [problem, setProblem] = useState('')

  // THIS event's own tag (owner, 18 Aug 26 — "I don't want u to save it as a
  // type"). Tapping a tag used to write the typed word into the squadron's
  // type library; now the tag is held here and saved ON the event. It starts
  // as whatever instance tag the event already carries; the EFFECTIVE tag the
  // buttons light is that, or failing it the library's word match — so "PH"
  // still reads as an off day without anyone tagging it again.
  const [kind, setKind] = useState<EventKind | null>(
    band ? (band.kind ?? null) : day ? dayEventKind(day, line) : null,
  )
  const tagged = kind ?? classifyEvent(defs, text)

  const apply = () => {
    setProblem('')
    const t = text.trim()

    if (scope === 'day') {
      if (band) removeEventBand(line, band.from)
      setDayEvent(date, line, t, kind)
      return onClose()
    }

    if (!range) return setProblem('Pick the dates first.')

    if (mode === 'repeat') {
      if (band) removeEventBand(line, band.from)
      setDayEventRange(range.from, range.to, line, t, kind)
      return onClose()
    }

    // Merge: one bar across the range. Remove the band being edited first, so
    // it does not read as an overlap with itself — and restore it if the new
    // one is refused, so a failed edit never loses the original.
    if (!t) return setProblem('A merged event needs a label.')
    if (band) removeEventBand(line, band.from)
    const r = addEventBand(line, range.from, range.to, t, kind)
    if (r === 'set') return onClose()
    if (band) addEventBand(line, band.from, band.to, band.text, band.kind ?? null)
    setProblem(
      r === 'overlap'
        ? 'Those dates already carry a merged event on this line.'
        : r === 'outside'
          ? 'Those dates leave this leave war.'
          : r === 'backwards'
            ? 'The end date is before the start date.'
            : 'Only an admin can edit events.',
    )
  }

  const del = () => {
    if (band) removeEventBand(line, band.from)
    else setDayEvent(date, line, '')
    onClose()
  }

  // Choose this event's tag — held locally until Save, never written to the
  // library (that is Edit types' job alone now). Tapping the one already
  // chosen clears it back to untagged.
  const tag = (k: EventKind) => {
    if (!text.trim()) return setProblem('Type a word before tagging it.')
    setProblem('')
    setKind(k === kind ? null : k)
  }

  if (view === 'types') {
    return (
      <Sheet testid="event-types-sheet" label="Event types" onClose={onClose}>
        <div className="bidsheet-hd">
          <span className="who">EVENT TYPES</span>
          <span className="dt">PH · no leave · work</span>
          <button className="x" data-testid="types-back" onClick={() => setView('event')} aria-label="Back">
            ‹
          </button>
        </div>
        <div className="evtypes">
          {/* Keyed by the type's NAME, not its index (bug sweep, 18 Aug 26).
              The name field is uncontrolled (defaultValue, applied once on
              mount), so an index key let a mid-list delete shift the array
              under the same DOM inputs: the row then showed a stale name and
              blurring it renamed the WRONG type. Keying by the stable name
              keeps each row bound to its own type across a delete — the same
              fix the personnel-label input (key={val}) already uses. Names are
              unique by the store's own refusal of a duplicate. */}
          {defs.map((d, i) => (
            <div className="evtype" key={d.name} data-testid={`evtype-${i}`}>
              <input
                className="evtype-name"
                defaultValue={d.name}
                aria-label={`Name of event type ${i + 1}`}
                data-testid={`evtype-name-${i}`}
                onBlur={e => {
                  const err = updateEventType(i, { name: e.target.value })
                  setProblem(err ?? '')
                }}
                onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
              />
              <div className="evkinds">
                {EVENT_KINDS.map(k => (
                  <button
                    key={k}
                    className={`evkind ${k}${d.kind === k ? ' on' : ''}`}
                    data-testid={`evtype-kind-${i}-${k}`}
                    aria-pressed={d.kind === k}
                    onClick={() => setProblem(updateEventType(i, { kind: k }) ?? '')}
                  >
                    {KIND_LABEL[k]}
                  </button>
                ))}
              </div>
              <button
                className="evtype-del"
                data-testid={`evtype-del-${i}`}
                aria-label={`Delete ${d.name}`}
                onClick={() => removeEventType(i)}
              >
                ✕
              </button>
            </div>
          ))}
          <AddType onProblem={setProblem} />
        </div>
        <div className="bidsheet-row">
          <button className="dchip" data-testid="types-reset" onClick={() => resetEventTypes()}>
            Reset to standard
          </button>
          <button className="dchip approve" data-testid="types-done" onClick={() => setView('event')}>
            Done
          </button>
          {problem && <span className="note warn" data-testid="event-problem">{problem}</span>}
        </div>
      </Sheet>
    )
  }

  return (
    <Sheet testid="event-sheet" label="Edit event" onClose={onClose}>
      <div className="bidsheet-hd">
        <span className="who">EVENT {line + 1}</span>
        <span className="dt">{scope === 'range' && range ? shortSpan(range.from, range.to) : shortSpan(date, date)}</span>
        <button className="evtypes-open" data-testid="event-edit-types" onClick={() => setView('types')}>
          Edit types
        </button>
        <button className="x" data-testid="event-cancel" onClick={onClose} aria-label="Cancel">
          ✕
        </button>
      </div>

      <div className="bidsheet-row">
        <input
          className="evtext"
          data-testid="event-text"
          placeholder="Type an event…"
          value={text}
          /* AUTOFOCUS ONLY A FRESH SINGLE-DAY TAP (owner, 31 Aug 26 — "I want
             to see the full window … the calendar takes a lot of vertical
             space"). A phone can't show the keyboard AND the whole calendar at
             once, but the keyboard is only ever needed to type the NAME, never
             to pick dates. So a plain day tap still focuses the field to type
             at once (the sheet is short and Sheet.tsx lifts it clear of the
             keys); a sheet that opens already ranged — a drag-swept span or an
             existing band, the tall case — opens with NO keyboard, so the full
             window (calendar + Save/Delete) shows. Tapping "A range" is a
             button, which drops the keyboard on its own, so switching a day to
             a range reveals the full window too. */
          autoFocus={!(band || dragged)}
          onChange={e => setText(e.target.value)}
          /* Enter/Return closes the keyboard (owner, 1 Sep 26 — "when I press
             enter the keyboard should close"). It blurs the field rather than
             saving: the sheet still has the scope, tag and dates to set, so
             Enter means "done typing the name", the same as the type-name row
             above. Dropping focus dismisses the keyboard, and useKeyboardInset
             then lets the panel fall back to the full window. */
          onKeyDown={e => { if (e.key === 'Enter') e.currentTarget.blur() }}
        />
      </div>

      {/* The saved words, one tap to fill the field. */}
      {defs.length > 0 && (
        <div className="bidsheet-row evquick" data-testid="event-quickpicks">
          {defs.map((d, i) => (
            <button
              key={i}
              className={`evchip ${d.kind}`}
              data-testid={`event-quick-${i}`}
              /* Picking a library word also drops any instance tag chosen for
                 the previous text — the word should light its own library
                 colour, not inherit a tag meant for something else. */
              onClick={() => { setText(d.name); setKind(null) }}
            >
              {d.name}
            </button>
          ))}
        </div>
      )}

      {/* Tag the word. The active tag is lit; tapping one sets it on the type. */}
      <div className="bidsheet-row evtagrow">
        <span className="lab">Tag</span>
        {EVENT_KINDS.map(k => (
          <button
            key={k}
            className={`evkind ${k}${tagged === k ? ' on' : ''}`}
            data-testid={`event-tag-${k}`}
            aria-pressed={tagged === k}
            onClick={() => tag(k)}
          >
            {KIND_LABEL[k]}
          </button>
        ))}
        <span className="evtag-cur" data-testid="event-tag-current">
          {tagged ? KIND_LABEL[tagged] : 'untagged'}
        </span>
      </div>

      {/* One day, or a span. */}
      <div className="bidsheet-row evscope">
        <button
          className={`dchip${scope === 'day' ? ' approve' : ''}`}
          data-testid="event-scope-day"
          onClick={() => setScope('day')}
        >
          This day
        </button>
        <button
          className={`dchip${scope === 'range' ? ' approve' : ''}`}
          data-testid="event-scope-range"
          onClick={() => setScope('range')}
        >
          A range
        </button>
      </div>

      {scope === 'range' && (
        <>
          <div className="bidsheet-row evmode">
            <button
              className={`dchip${mode === 'merge' ? ' approve' : ''}`}
              data-testid="event-mode-merge"
              onClick={() => setMode('merge')}
            >
              One merged bar
            </button>
            <button
              className={`dchip${mode === 'repeat' ? ' approve' : ''}`}
              data-testid="event-mode-repeat"
              onClick={() => setMode('repeat')}
            >
              Repeat each day
            </button>
          </div>
          <div className="bidsheet-row">
            <RangePicker
              testid="event"
              compact
              min={period.start}
              max={period.end}
              value={range}
              onChange={setRange}
            />
          </div>
        </>
      )}

      {/* Save + Delete sit at the RIGHT of the footer, Save in the app's cyan
          (owner, 31 Aug 26 — "move the save and delete buttons to the right …
          Save … make it blue cyan like how it is usually"). Save is `dchip save`,
          not the green `approve` the scope toggles use, so it reads as the one
          commit button. A problem note keeps its place on the LEFT (margin-right
          :auto) so the error never shoves the buttons around. */}
      <div className="bidsheet-row evactions">
        {problem && <span className="note warn" data-testid="event-problem">{problem}</span>}
        {/* MOVE an existing event (owner, 31 Aug 26 — "drag an existing event to
            move it, like LL"). Shown only for a placed event/band; it hands the
            event's own span to the matrix, which runs the same drag-to-a-day move
            mode the roster uses. Closes the sheet first, exactly like the roster
            Move button. */}
        {onMove && (band || (day && day.events[line])) && (
          <button
            className="dchip move"
            data-testid="event-move"
            onClick={() => { onClose(); onMove({ line, from: band ? band.from : date, to: band ? band.to : date }) }}
          >
            Move…
          </button>
        )}
        <button className="dchip save" data-testid="event-apply" onClick={apply}>
          Save
        </button>
        {(band || (day && day.events[line])) && (
          <button className="dchip refuse" data-testid="event-delete" onClick={del}>
            Delete
          </button>
        )}
      </div>
    </Sheet>
  )
}

/** The add-a-type row, its own small state so the name field clears on add. */
function AddType({ onProblem }: { onProblem: (s: string) => void }) {
  const [name, setName] = useState('')
  const [kind, setKind] = useState<EventKind>('off')
  const add = () => {
    const err = addEventType(name, kind)
    if (err) return onProblem(err)
    setName('')
    onProblem('')
  }
  return (
    <div className="evtype evtype-add" data-testid="evtype-add">
      <input
        className="evtype-name"
        placeholder="New type…"
        aria-label="New event type name"
        data-testid="evtype-add-name"
        value={name}
        onChange={e => setName(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && add()}
      />
      <div className="evkinds">
        {EVENT_KINDS.map(k => (
          <button
            key={k}
            className={`evkind ${k}${kind === k ? ' on' : ''}`}
            data-testid={`evtype-add-kind-${k}`}
            aria-pressed={kind === k}
            onClick={() => setKind(k)}
          >
            {KIND_LABEL[k]}
          </button>
        ))}
      </div>
      <button className="evtype-add-btn" data-testid="evtype-add-btn" onClick={add} aria-label="Add event type">
        ＋
      </button>
    </div>
  )
}
