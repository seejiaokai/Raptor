import { act, fireEvent, render, screen, within } from '@testing-library/react'
import { beforeEach, describe, expect, it } from 'vitest'
import type { Person } from '../engine'
import { addGroup, advanceStage, getState, initStore, setBidState, setCell, setGroupColor, setPersLabel, setRole } from '../state/store'
import { memoryBackend } from '../state/storage'
import { fileAbsence } from '../testkit'
import { Matrix } from './Matrix'

beforeEach(() => {
  initStore(memoryBackend())
  // SPLICE's medical is MEMBER-FILED now (owner, 13 Sep 26): the pristine seed
  // has none, so ingest a member-filed ATT C / OML (the way a member's Inputs
  // filing syncs onto the war) to exercise how the grid renders a medical cell.
  fileAbsence('splice', 'ATTC', '2026-01-05')
  fileAbsence('splice', 'OML', '2026-01-06')
})

describe('Matrix', () => {
  it('renders a row for every person with their callsign and a category chip', () => {
    render(<Matrix />)
    const row = screen.getByTestId('row-ramp')
    expect(within(row).getByText('RAMP')).toBeTruthy()
    // Every row wears a colour-coded CAT chip now (18 Aug 26). RAMP is the
    // seed's one SXO, so — rather than an appended (S) — he is LIFTED into the
    // SXO group and his chip takes the SXO colour class; the grouping, not a
    // suffix, is what says he is an SXO.
    expect(within(row).getByTestId('cat-ramp')).toBeTruthy()
    expect(within(row).getByTestId('cat-ramp').className).toContain('q-sxo')
    expect(screen.getByTestId('group-SXO')).toBeTruthy()
    // TATA is an instructor pilot: his chip reads IP and takes the instructor
    // colour, under the IP group.
    expect(within(screen.getByTestId('row-tata')).getByText('IP')).toBeTruthy()
    expect(screen.getByTestId('group-IP')).toBeTruthy()
  })

  // Minimising a category (owner, 28 Aug 26 — "allow me to minimise categories
  // on leave war"). A view preference, either role, nothing folded by default.
  it('folds a category away on its heading, and reopens it', () => {
    render(<Matrix />)
    expect(screen.getByTestId('row-ramp')).toBeTruthy()   // RAMP is the seed's SXO
    fireEvent.click(screen.getByTestId('groupfold-SXO'))
    // the heading survives — it is how the group is reopened — but its rows go
    expect(screen.getByTestId('group-SXO')).toBeTruthy()
    expect(screen.queryByTestId('row-ramp')).toBeNull()
    // another group is untouched
    expect(screen.getByTestId('row-tata')).toBeTruthy()
    fireEvent.click(screen.getByTestId('groupfold-SXO'))
    expect(screen.getByTestId('row-ramp')).toBeTruthy()
  })

  // A folded group still says how many people it is hiding, so the count is
  // built from the unfiltered roster, not from what is left on screen.
  it('keeps the heading count truthful while folded', () => {
    render(<Matrix />)
    // the count only — the caret beside it flips ▾/▸ on purpose
    const count = () => screen.getByTestId('group-SXO').querySelector('.gcount')!.textContent
    const before = count()
    fireEvent.click(screen.getByTestId('groupfold-SXO'))
    expect(count()).toBe(before)
  })

  it('the frozen column heads CS/Name — it holds callsigns and ground-crew names alike (owner, 26 Aug 26)', () => {
    render(<Matrix />)
    const th = document.querySelector('.mx .mxhead th.who')!
    expect(th.textContent).toBe('CS/Name')
  })

  it('a personnel row at rest shows callsign + chip only — the role label is edit-mode only (owner, 26 Aug 26)', () => {
    /* the standalone test seed carries no ground crew (the real app projects
       them off Raptor's roster), so mint one off an existing body; even a
       SET label stays off the resting roster ("no need to indicate initials
       or flight") — it renders only as the Rearrange edit box */
    const st = getState() as any
    st.people.push({ ...st.people[0], id: 'gnd_t', callsign: 'WIDGET', pers: true, seat: 'gnd' })
    setPersLabel('gnd_t', 'Avionics')
    render(<Matrix />)
    const row = screen.getByTestId('row-gnd_t')
    expect(within(row).getByTestId('cat-gnd_t')).toBeTruthy()
    expect(within(row).queryByTestId('perslabel-gnd_t')).toBeNull()
  })

  /* The quals popover (owner, 3 Sep 26 — "hover the mouse over the person to see
     the qualifications they hold"). The chip shows only the CAT; tapping it
     reveals the qualifications the person holds AMONG THOSE ON THE PAGE as
     groups ("only the qualifications that were added to display will be
     shown"), each in the group's picked colour, and does NOT also open the
     figures sheet the callsign owns. TATA is an instructor pilot: not an SXO,
     but SC-DAY and SC-NIGHT qualified. */
  it('a tap on the chip shows the displayed qualifications, in their group colours, not the figures sheet', () => {
    setRole('admin')
    addGroup({ id: 'q:scDay', kind: 'qual', k: 'scDay' })
    setGroupColor('q:scDay', '#E672A6')
    render(<Matrix />)
    const chip = within(screen.getByTestId('row-tata')).getByTestId('cat-tata')
    expect(chip.className).toContain('has-quals')
    fireEvent.click(chip)
    const pop = screen.getByTestId('qualpop')
    expect(pop.textContent).toContain('SC DAY')
    // held, but not displayed as a group — so not listed
    expect(pop.textContent).not.toContain('SC NIGHT')
    // the pill wears the group's picked colour
    const pill = within(pop).getByText('SC DAY')
    expect(pill.style.background.toLowerCase()).toBe('rgb(230, 114, 166)')
    // the click was swallowed — the callsign's figures sheet stayed shut
    expect(screen.queryByTestId('person-figures')).toBeNull()
  })

  /* A second tap on the same chip closes the popover (a phone has no pointer to
     leave with), and Escape closes it too (bug hunt, 4 Sep 26). */
  it('a second tap on the same chip closes the popover; Escape closes it as well', () => {
    setRole('admin')
    addGroup({ id: 'q:scDay', kind: 'qual', k: 'scDay' })
    render(<Matrix />)
    const chip = within(screen.getByTestId('row-tata')).getByTestId('cat-tata')
    fireEvent.click(chip)
    expect(screen.getByTestId('qualpop')).toBeTruthy()
    fireEvent.click(chip)
    expect(screen.queryByTestId('qualpop')).toBeNull()
    fireEvent.click(chip)
    expect(screen.getByTestId('qualpop')).toBeTruthy()
    fireEvent.keyDown(document.body, { key: 'Escape' })
    expect(screen.queryByTestId('qualpop')).toBeNull()
  })

  it('the chip is inert while none of the person\'s qualifications is on the page', () => {
    // the default page has no qualification groups: TATA's SC quals stay hidden
    render(<Matrix />)
    const chip = within(screen.getByTestId('row-tata')).getByTestId('cat-tata')
    expect(chip.className).not.toContain('has-quals')
    fireEvent.click(chip)
    expect(screen.queryByTestId('qualpop')).toBeNull()
  })

  it('an SXO on the page lists SXO in gold', () => {
    render(<Matrix />)
    // RAMP is the seed's SXO; the SXO group is on the default page
    const chip = within(screen.getByTestId('row-ramp')).getByTestId('cat-ramp')
    expect(chip.className).toContain('has-quals')
    fireEvent.click(chip)
    const pill = within(screen.getByTestId('qualpop')).getByText('SXO')
    expect(pill.style.background.toLowerCase()).toBe('rgb(232, 178, 59)')
  })

  it('the chip of a person with no qualifications is inert', () => {
    // mint a ground-crew body off an existing one: no seat colour, no quals
    const st = getState() as any
    st.people.push({ ...st.people[0], id: 'gnd_q', callsign: 'RIGGER', pers: true, seat: 'gnd', sxo: false, scd: false, scn: false, xq: [] })
    render(<Matrix />)
    const chip = within(screen.getByTestId('row-gnd_q')).getByTestId('cat-gnd_q')
    expect(chip.className).not.toContain('has-quals')
    fireEvent.click(chip)
    expect(screen.queryByTestId('qualpop')).toBeNull()
  })

  it('renders a column for every day of the year', () => {
    render(<Matrix />)
    expect(screen.getAllByTestId(/^head-/)).toHaveLength(365)
  })

  it('shows a code in the cell it belongs to', () => {
    setCell('ramp', '2026-01-20', 'LL')
    render(<Matrix />)
    expect(screen.getByTestId('cell-ramp-2026-01-20').textContent).toBe('LL')
  })

  it('marks a blocked day on the date header', () => {
    render(<Matrix />)
    expect(screen.getByTestId('head-2026-03-10').className).toContain('blocked')
    expect(screen.getByTestId('head-2026-01-07').className).not.toContain('blocked')
  })

  it('marks SC duty cells as duty so they read as earning OIL', () => {
    render(<Matrix />)
    expect(screen.getByTestId('cell-tata-2026-01-01').className).toContain('duty')
  })

  it('greys the cells of a posted-out member from the day after they leave', () => {
    render(<Matrix />)
    expect(screen.getByTestId('cell-switcher-2026-01-12').className).not.toContain('gone')
    expect(screen.getByTestId('cell-switcher-2026-01-13').className).toContain('gone')
  })

  it('does not label a member who has not yet arrived as posted out', () => {
    // The seed has nobody with a `from`, which is why this survived past
    // review — give the test its own person rather than relying on seed data.
    const arriving: Person = {
      id: 'newbie', callsign: 'NEWBIE', seat: 'pilot', band: 'ops',
      sxo: false, from: '2026-02-01', to: null,
    }
    getState().people.push(arriving)
    render(<Matrix />)

    const beforeArrival = screen.getByTestId('cell-newbie-2026-01-15')
    expect(beforeArrival.textContent).not.toBe('PO')
    expect(beforeArrival.textContent).toBe('')
    expect(beforeArrival.className).toContain('gone')

    const onArrival = screen.getByTestId('cell-newbie-2026-02-01')
    expect(onArrival.textContent).not.toBe('PO')
    expect(onArrival.className).not.toContain('gone')
  })

  /* D320 ([ONE-DOOR], 27 Sep 26): a man back from a posting — his earlier stint reads as normal, the gap reads away
     (PO, hatched), each stint's last day wears the PO corner, and only a day before his FIRST stint is "not yet
     arrived" (blank) */
  it('D320: an earlier stint reads normal, the gap reads PO, and only before the first stint is blank', () => {
    const back: Person = {
      id: 'backer', callsign: 'BACKER', seat: 'pilot', band: 'ops', sxo: false,
      from: '2026-03-01', to: null, past: [{ from: '2026-01-05', to: '2026-01-20' }],
    }
    getState().people.push(back)
    render(<Matrix />)
    const cell = (d: string) => screen.getByTestId(`cell-backer-${d}`)
    expect(cell('2026-01-02').textContent).toBe('')
    expect(cell('2026-01-02').className).toContain('gone')
    expect(cell('2026-01-10').className).not.toContain('gone')
    expect(cell('2026-01-20').className).toContain('pofin')
    expect(cell('2026-01-25').textContent).toBe('PO')
    expect(cell('2026-01-25').className).toContain('gone')
    expect(cell('2026-02-27').textContent).toBe('PO')
    expect(cell('2026-03-01').className).not.toContain('gone')
  })

  it('suppresses the duty class for a code left on a day outside the roster window', () => {
    // A stale FO on a posted-out member's row must not read as "at work" —
    // they are gone, full stop, regardless of what code sits under them.
    setCell('switcher', '2026-01-13', 'FO')
    render(<Matrix />)
    const cell = screen.getByTestId('cell-switcher-2026-01-13')
    expect(cell.className).toContain('gone')
    expect(cell.className).not.toContain('duty')
    expect(cell.textContent).toBe('PO')
  })

  it('marks a Saturday header as a weekend and a Tuesday as not', () => {
    render(<Matrix />)
    expect(screen.getByTestId('head-2026-01-03').className).toContain('weekend')
    expect(screen.getByTestId('head-2026-01-06').className).not.toContain('weekend')
  })

  it('marks the blocked week\'s Saturday as both blocked and weekend', () => {
    // The seed's exercise week runs through 2026-03-14 (Saturday) precisely
    // so this overlap exists in the data. jsdom computes no cascade, so this
    // only proves both classes are emitted — it cannot see which background
    // wins. That's covered by the e2e spec instead.
    render(<Matrix />)
    const head = screen.getByTestId('head-2026-03-14')
    expect(head.className).toContain('blocked')
    expect(head.className).toContain('weekend')
  })

  // The owner's ask: "I should have a short form day title for each day. Like
  // Mon, Tues Etc." On EVERY column, unlike the month label — the question it
  // answers ("which Tuesday is this") is asked at every column, not only at
  // the turn of a month.
  it('names the weekday on every column', () => {
    render(<Matrix />)
    expect(screen.getByTestId('head-2026-01-05').querySelector('.dow')?.textContent).toBe('MON')
    expect(screen.getByTestId('head-2026-01-06').querySelector('.dow')?.textContent).toBe('TUE')
    expect(screen.getByTestId('head-2026-01-10').querySelector('.dow')?.textContent).toBe('SAT')
    // Including the 1st, where it sits alongside the month label rather than
    // instead of it.
    const jan1 = screen.getByTestId('head-2026-01-01')
    expect(jan1.querySelector('.mon')?.textContent).toBe('JAN')
    expect(jan1.querySelector('.dow')?.textContent).toBe('THU')
  })

  it('labels the first day of a month, and only the first day', () => {
    render(<Matrix />)
    const jan1 = screen.getByTestId('head-2026-01-01')
    expect(jan1.querySelector('.mon')?.textContent).toBe('JAN')
    const jan2 = screen.getByTestId('head-2026-01-02')
    expect(jan2.querySelector('.mon')).toBeNull()
    const feb1 = screen.getByTestId('head-2026-02-01')
    expect(feb1.querySelector('.mon')?.textContent).toBe('FEB')
  })

  it('gives a duty cell the sc chip class and a non-bid code the info chip class', () => {
    render(<Matrix />)
    // Seed: TATA is on FO (a duty code) on 1 Jan; SPLICE is on ATTC (a medical
    // marker) on 5 Jan. This asserted TATA's OIL on 9 Jan as the `.info` case
    // until bid states landed — OIL is leave someone asked for, so it now
    // carries a bid colour instead. `.info` is what remains: the codes nobody
    // bids for, which is medical (ATT C / HL / OML), courses and overseas duty.
    const dutyCell = screen.getByTestId('cell-tata-2026-01-01')
    expect(dutyCell.querySelector('.c.sc')?.textContent).toBe('FO')
    const ordinaryCell = screen.getByTestId('cell-splice-2026-01-05')
    // Stored ATTC, PRINTED as the owner's bare C since 17 Aug 26
    // (displayCell) — the info class is unchanged.
    expect(ordinaryCell.querySelector('.c.info')?.textContent).toBe('C')
  })

  it('carries the am/pm portion class on the chip, derived from the stored asterisk', () => {
    setCell('ramp', '2026-01-20', '*LL')
    setCell('ramp', '2026-01-21', 'LL*')
    setCell('ramp', '2026-01-22', 'LL')
    render(<Matrix />)
    // Assert on the chip element itself, not the `<td>` — the portion class
    // decorates `.c`, and a `<td>`-level assertion would pass even if the
    // class landed on the wrong element.
    const morning = screen.getByTestId('cell-ramp-2026-01-20').querySelector('.c')!
    expect(morning.className).toContain('am')
    expect(morning.className).not.toContain('pm')

    const afternoon = screen.getByTestId('cell-ramp-2026-01-21').querySelector('.c')!
    expect(afternoon.className).toContain('pm')
    expect(afternoon.className).not.toContain('am')

    const wholeDay = screen.getByTestId('cell-ramp-2026-01-22').querySelector('.c')!
    expect(wholeDay.className).not.toContain('am')
    expect(wholeDay.className).not.toContain('pm')
  })

  it('shows both the blocked reason and the day\'s events when both exist', () => {
    // The seed's blocked week carries no events, so this is exercised by
    // hand: a day that is both blocked and carries an event line, which the
    // old `blocked ? reason : events` title would make the event invisible.
    const day = getState().period.days.find(d => d.date === '2026-03-09')!
    day.events = ['Range closure', '']
    render(<Matrix />)
    const head = screen.getByTestId('head-2026-03-09')
    expect(head.title).toContain('Exercise week')
    expect(head.title).toContain('Range closure')
  })
})

describe('weekend banding', () => {
  it('bands the whole column, header and body alike', () => {
    render(<Matrix />)
    // 2026-01-03 is a Saturday, 2026-01-06 a Tuesday.
    expect(screen.getByTestId('head-2026-01-03').className).toContain('weekend')
    expect(screen.getByTestId('cell-ramp-2026-01-03').className).toContain('weekend')
    expect(screen.getByTestId('head-2026-01-06').className).not.toContain('weekend')
    expect(screen.getByTestId('cell-ramp-2026-01-06').className).not.toContain('weekend')
  })
})

describe('bid state on a cell', () => {
  // The owner's colour rule, restated 10 Aug 26: an input nobody has answered
  // carries NO colour, purple means management has acknowledged it, green
  // approved, red refused. Purple used to mean "typed", which made a bid in
  // management's hands look identical to one nobody had touched.
  it('paints approved green, acknowledged purple, refused red, and pending not at all', () => {
    render(<Matrix />)
    expect(screen.getByTestId('cell-jaguar-2026-01-16').querySelector('.c')!.className).toContain('appr')
    expect(screen.getByTestId('cell-asics-2026-02-24').querySelector('.c')!.className).toContain('tbc')
    /* CROSS's 10 Mar: JAGUAR's refused 19 Jan now sits behind the seed's OIL award drawn on that day (D402) */
    expect(screen.getByTestId('cell-cross-2026-03-10').querySelector('.c')!.className).toContain('ref')

    const pending = screen.getByTestId('cell-asics-2026-01-23').querySelector('.c')!.className
    for (const painted of ['appr', 'tbc', 'ref']) expect(pending).not.toContain(painted)
  })

  it('leaves a code nobody bids for as plain information', () => {
    render(<Matrix />)
    expect(screen.getByTestId('cell-tata-2026-01-01').querySelector('.c')!.className).toContain('sc')
    expect(screen.getByTestId('cell-pipper-2026-01-12').querySelector('.c')!.className).toContain('info')
  })

  // Neither duty nor medical may ever take a bid colour: one is a man at
  // work, the other is a man who did not ask for anything. Both are pinned
  // against every bid class rather than just for their own, so a cascade
  // that added `tbc` alongside `sc` would fail here.
  //
  // This does NOT prove the branch ORDER in Matrix.tsx — duty codes carry
  // `bid: false`, so `isDuty` and `isBiddable` are disjoint and reordering
  // them changes nothing. Reading duty first is for the reader, not a guard.
  it('never lets duty or medical take a bid colour', () => {
    render(<Matrix />)
    for (const [id, cls] of [['cell-skin-2026-01-03', 'sc'], ['cell-splice-2026-01-05', 'info']] as const) {
      const name = screen.getByTestId(id).querySelector('.c')!.className
      expect(name).toContain(cls)
      for (const bidClass of ['appr', 'tbc', 'ref']) expect(name).not.toContain(bidClass)
    }
  })

  // A bid with no decision recorded is pending — the seed leaves splice's
  // LL unstated precisely so this path renders on first run — and pending
  // now means NO colour. Asserted against all three painted classes rather
  // than for one, so a cascade that reintroduced any of them fails here.
  it('reads a bid with no decision recorded as pending, and paints it plain', () => {
    render(<Matrix />)
    const cls = screen.getByTestId('cell-splice-2026-01-08').querySelector('.c')!.className
    for (const painted of ['appr', 'tbc', 'ref']) expect(cls).not.toContain(painted)
  })

  it('re-paints when a decision is recorded', () => {
    render(<Matrix />)
    const cls = () => screen.getByTestId('cell-asics-2026-01-23').querySelector('.c')!.className
    expect(cls()).not.toContain('appr')
    act(() => { setRole('admin'); advanceStage(); setBidState('asics', '2026-01-23', 'approved') })
    expect(cls()).toContain('appr')
  })

  // Acknowledging is the step the owner added: it is not a decision, it says
  // management has the bid in hand. A plain input becomes purple, and the
  // counts do not move — an acknowledged bid still removes the person,
  // exactly as a pending one does.
  it('turns a plain pending input purple when it is acknowledged, without moving the counts', () => {
    render(<Matrix />)
    const cls = () => screen.getByTestId('cell-asics-2026-01-23').querySelector('.c')!.className
    expect(cls()).not.toContain('tbc')
    const before = screen.getByTestId('count-opsp-2026-01-23').textContent
    act(() => { setRole('admin'); advanceStage(); setBidState('asics', '2026-01-23', 'acknowledged') })
    expect(cls()).toContain('tbc')
    expect(screen.getByTestId('count-opsp-2026-01-23').textContent).toBe(before)
  })

  // The counts are what a refusal is FOR: pulling a man back into the
  // manning picture. A Matrix that painted the chip but still passed `{}`
  // for the states would pass every assertion above and fail this one.
  it('counts a refused bid as a man at work', () => {
    render(<Matrix />)
    const before = screen.getByTestId('count-opsp-2026-01-23').textContent
    act(() => { setRole('admin'); advanceStage(); setBidState('asics', '2026-01-23', 'refused') })
    expect(screen.getByTestId('count-opsp-2026-01-23').textContent).not.toBe(before)
  })
})

/* The 18 Aug 26 layout order (owner's arrows on a screenshot): counts →
   month buttons → callsign/dates header → event rows → roster. */
describe('the grid row order', () => {
  it('draws counts, then the month strip, then the header, then events, then people', () => {
    render(<Matrix />)
    const table = screen.getByTestId('month-strip').closest('table')!
    const sections = Array.from(table.children).map(el => el.className || el.tagName.toLowerCase())
    // The roster body is `.mxbody` now (20 Aug 26) — the frozen-column overlay
    // measures it by that name and draws a second copy of its two lead columns.
    expect(sections).toEqual(['counts', 'mstripe', 'mxhead', 'events', 'mxbody'])
  })

  it('brackets every month above the dates, spanning its own days', () => {
    render(<Matrix />)
    const jan = screen.getByTestId('bracket-2026-01')
    expect(jan.getAttribute('colspan')).toBe('31')
    expect(jan.textContent).toBe('JAN')
    expect(screen.getByTestId('bracket-2026-02').getAttribute('colspan')).toBe('28')
    // the bracket row sits directly above the header row, inside one tbody
    const head = jan.closest('tbody')!
    expect(head.className).toBe('mxhead')
    expect(head.querySelector('[data-testid="counter-head"]')).toBeTruthy()
  })

  it('never renders the phone header mirror in jsdom (no layout to scroll past)', () => {
    render(<Matrix />)
    expect(screen.queryByTestId('sticky-head')).toBeNull()
  })
})
