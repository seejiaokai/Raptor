// AN ADMIN CAN RECORD THAT SOMEONE WORKED (owner, 20 Sep 26 — "the admin can
// also credit OIL on the leave sheet for convenience. We should enable that
// even on any day"), AND CAN PLACE LEAVE ON A DAY OUTSIDE THEIR POSTING DATES
// ("we should also allow putting inputs when we click on days that were posted
// out").
//
// Both close gaps found by hand-testing, and the first is the more serious: the
// store accepted a hand-typed FO/HO credit, the OIL tracker edited its reason
// and the hours box edited its times — but NOTHING in the app could create
// one. The only writers were the automatic pass off the published schedule and
// the demo seed, so all three editors could only ever reach a credit nobody
// was able to type.
//
// ANY DAY is deliberate and is the owner's ruling. The weekend / public-holiday
// restriction is real, but it belongs to the AUTOMATIC pass, which reads the
// published schedule. A credit an admin types is the squadron recording that a
// man worked with no schedule behind it — which is exactly why it carries a
// reason and who said so, and why it DOES move his OIL balance.

import { fireEvent, render, screen } from '@testing-library/react'
import { beforeEach, describe, expect, it } from 'vitest'
import { balanceOf, isWeekend } from '../engine'
import { creditGiver, readRec } from '../engine/warrecs'
import { awardsOnDay, getState, ingestDutyCredit, initStore, rawState, setCell, setDayAward, setPostOut, setRole, setViewer } from '../state/store'
import { memoryBackend } from '../state/storage'
import { Matrix } from './Matrix'

const P = 'slammed'
const TUE = '2026-01-13'      // an ordinary weekday
const SAT = '2026-01-03'

beforeEach(() => {
  initStore(memoryBackend())
  setRole('admin')
})

/** THE DAY'S AWARD as the sheets read it — a ledger entry since [OIL-AWARD-IS-A-GRANT] (29 Sep 26): its label (drawn from
 *  the amount — half a day HO, else FO), its reason, its giver and its worth */
const creditOn = (person: string, date: string) => {
  const e = awardsOnDay(person, date)[0]
  return e ? { id: e.id, code: e.amount === 0.5 ? 'HO' : 'FO', note: e.reason || undefined, givenBy: e.givenBy, days: e.amount } : undefined
}
/** everything the day is worth: what the schedule EARNED plus every award drawn on it (D400) */
const worthOf = (person: string, date: string) =>
  (getState().views[person]?.[date]?.earnsOil ?? 0) + awardsOnDay(person, date).reduce((n, e) => n + e.amount, 0)

const oilOf = (person: string) => {
  const { openings, ledger, wars } = getState()
  return balanceOf(openings, ledger, wars, person, 'oil')
}

describe('setDayAward', () => {
  it('records the day, the reason, who said so and how many days — in ONE step', () => {
    expect(setDayAward(P, SAT, 2, { note: 'Call-out', givenBy: 'OC Ops' })).toBeNull()
    expect(creditOn(P, SAT)).toMatchObject({
      code: 'FO', note: 'Call-out', givenBy: 'OC Ops', days: 2,
    })
    /* who ENTERED it and when (D200 (2)) — the signed-in person, not the typed giver */
    expect(awardsOnDay(P, SAT)[0]!.enteredAt).toBeTruthy()
  })

  it('lands on ANY day, not only a weekend or a public holiday', () => {
    expect(isWeekend(TUE)).toBe(false)
    const before = oilOf(P)
    expect(setDayAward(P, TUE, 1, { note: 'Recall' })).toBeNull()
    expect(creditOn(P, TUE)?.code).toBe('FO')
    // …and it really does move the balance. That is the point of typing it.
    expect(oilOf(P)).toBe(before + 1)
  })

  it('HO is half a day', () => {
    const before = oilOf(P)
    expect(setDayAward(P, TUE, 0.5)).toBeNull()
    expect(oilOf(P)).toBe(before + 0.5)
  })

  it('a day is worth a day — the ordinary case, and FO', () => {
    expect(setDayAward(P, SAT, 1, { note: 'Duty' })).toBeNull()
    expect(creditOn(P, SAT)).toMatchObject({ code: 'FO', days: 1 })
  })

  it('refuses only where refusing is the truth', () => {
    setRole('member')
    expect(setDayAward(P, SAT, 1)).toContain('admin')
    setRole('admin')
    expect(setDayAward(P, SAT, 9999)).toContain('more than')
    expect(setDayAward(P, SAT, 0)).toContain('how many days')
    expect(creditOn(P, SAT)).toBeUndefined()
  })

  it('lands BESIDE a day the published schedule already earns (N16, 21 Sep 26)', () => {
    /* It used to answer "That day already earns OIL from the published
       schedule" and write nothing. The owner ruled the two add up and never
       affect each other, so refusing here was the app declining to record a
       fact he has said is separate. */
    expect(ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]])).toBe('written')
    expect(setDayAward(P, SAT, 3)).toBeNull()
    /* two facts, two records — the schedule's on the war, the award in the ledger */
    expect(rawState().wars[0]!.recs[P]![SAT]!.filter(r => r.kind === 'credit')).toHaveLength(1)
    expect(awardsOnDay(P, SAT)).toHaveLength(1)
    expect(getState().views[P]?.[SAT]?.earnsOil).toBe(1)          // earned — the schedule's (D400)
    expect(worthOf(P, SAT)).toBe(4)
  })

  it('never refuses for clashing with leave — both land, and an award does not flag the day', () => {
    /* The credit still lands beside the leave — that is the older half of the
       rule. What changed on 20 Sep 26 is the flag: a credit typed in by hand is
       an AWARD, it says nothing about where the man was, so there is nothing
       for an admin to resolve and the day stays grey. */
    expect(setCell(P, SAT, 'LL')).toBe(true)                 // leave first…
    expect(setDayAward(P, SAT, 1)).toBeNull()         // …then the award
    const v = getState().views[P]?.[SAT]
    expect(v?.all.filter(c => c.kind === 'request')).toHaveLength(1)
    expect(v?.all.filter(c => c.kind === 'credit')).toHaveLength(1)
    expect(v?.amber).toBe(false)
  })
})

describe('the OIL control on the day sheet', () => {
  const openSheet = (date: string) => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${date}`))
    fireEvent.click(screen.getByTestId('bid-oil'))
  }

  it('is folded behind one button, because it is the opposite fact to the rows above it', () => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${TUE}`))
    expect(screen.getByTestId('bid-oil')).toBeTruthy()
    expect(screen.queryByTestId('oil-fo')).toBeNull()
  })

  it('writes the whole thing from the sheet, on a WEEKDAY', () => {
    openSheet(TUE)
    fireEvent.change(screen.getByTestId('oil-why'), { target: { value: 'Recall' } })
    fireEvent.change(screen.getByTestId('oil-given-by'), { target: { value: 'OC Ops' } })
    fireEvent.change(screen.getByTestId('oil-days'), { target: { value: '2' } })
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(creditOn(P, TUE)).toMatchObject({
      code: 'FO', note: 'Recall', givenBy: 'OC Ops', days: 2,
    })
  })

  it('says so rather than guessing when the quantity cannot be read', () => {
    openSheet(TUE)
    fireEvent.change(screen.getByTestId('oil-days'), { target: { value: 'lots' } })
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(screen.getByTestId('oil-err').textContent).toContain('how many days')
    expect(creditOn(P, TUE)).toBeUndefined()
  })

  it('a member never sees it', () => {
    setRole('member')
    setViewer(P)
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${TUE}`))
    expect(screen.queryByTestId('bid-oil')).toBeNull()
  })
})

describe('placing leave on a day outside the posting dates', () => {
  it('the posting sheet hands the day to the bid sheet, and back on close', () => {
    setPostOut(P, '2026-02-01')
    render(<Matrix />)
    const day = '2026-09-08'
    fireEvent.click(screen.getByTestId(`cell-${P}-${day}`))
    // The common tap still manages the POSTING — that is what he means most
    // of the time, and it must not change.
    expect(screen.getByTestId('postout-sheet')).toBeTruthy()
    expect(screen.queryByTestId('bid-picker')).toBeNull()
    // …with one button through to placing something.
    fireEvent.click(screen.getByTestId('postout-place'))
    expect(screen.queryByTestId('postout-sheet')).toBeNull()
    expect(screen.getByTestId('bid-picker')).toBeTruthy()
  })

  it('the leave placed there actually lands, on a day he has already left', () => {
    setPostOut(P, '2026-02-01')
    render(<Matrix />)
    const day = '2026-09-08'
    fireEvent.click(screen.getByTestId(`cell-${P}-${day}`))
    fireEvent.click(screen.getByTestId('postout-place'))
    fireEvent.click(screen.getByTestId('bid-LL'))
    expect(getState().grid[P]?.[day]).toBe('LL')
  })

  it('and OIL can be recorded there too, which is why the button says both', () => {
    setPostOut(P, '2026-02-01')
    render(<Matrix />)
    const day = '2026-09-08'
    fireEvent.click(screen.getByTestId(`cell-${P}-${day}`))
    fireEvent.click(screen.getByTestId('postout-place'))
    fireEvent.click(screen.getByTestId('bid-oil'))
    fireEvent.change(screen.getByTestId('oil-why'), { target: { value: 'Clearing' } })
    fireEvent.click(screen.getByTestId('oil-give'))
    expect(creditOn(P, day)?.note).toBe('Clearing')
  })

  it('the switch is for THAT cell only — the next day opens on the posting sheet again', () => {
    setPostOut(P, '2026-02-01')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-2026-09-08`))
    fireEvent.click(screen.getByTestId('postout-place'))
    expect(screen.getByTestId('bid-picker')).toBeTruthy()
    fireEvent.click(screen.getByTestId('bid-cancel'))
    fireEvent.click(screen.getByTestId(`cell-${P}-2026-09-09`))
    expect(screen.getByTestId('postout-sheet')).toBeTruthy()
  })
})

describe('who said so is RECORDED and VISIBLE', () => {
  // Recording it and never showing it would be the same shape as the bug this
  // branch opened with: a man charged for leave his row no longer showed.
  it('shows on the OIL tracker row and can be changed there', () => {
    expect(setDayAward(P, TUE, 1, { note: 'Recall', givenBy: 'OC Ops' })).toBeNull()
    render(<Matrix />)
    fireEvent.click(screen.getByTestId('oil-tracker'))
    const id = creditOn(P, TUE)!.id
    const row = screen.getByTestId(`oil-entry-${id}`)
    expect(row.textContent).toContain('OC Ops')
    fireEvent.click(row)                                   // the one editor every award opens ([OIL-AWARD-IS-A-GRANT])
    expect((screen.getByTestId('oil-edit-given') as HTMLInputElement).value).toBe('OC Ops')
    fireEvent.change(screen.getByTestId('oil-edit-given'), { target: { value: 'SQNCDR' } })
    fireEvent.click(screen.getByTestId('oil-edit-save'))
    expect(creditOn(P, TUE)!.givenBy).toBe('SQNCDR')
  })

  it('shows on the day’s record list', () => {
    // A credit beside a bid is two records, so the tap opens the list rather
    // than a single-record sheet — which is where a person reads what is on
    // their day.
    expect(setCell(P, TUE, 'LL')).toBe(true)
    expect(setDayAward(P, TUE, 1, { note: 'Recall', givenBy: 'OC Ops' })).toBeNull()
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${TUE}`))
    const list = screen.getByTestId('daylist')
    expect(list.textContent).toContain('Recall')
    expect(list.textContent).toContain('OC Ops')
  })
})

/* WHAT THE OIL ON A DAY SAYS, ON ONE CLICK (owner, 21 Sep 26 — "When i click
   on like FO or HO once, At the bottom i want to see the reason, given by and
   days granted"). Three lines, the same three whichever kind of credit it is;
   the app's own credit answers them from the schedule it was earned off. */
describe('the OIL on a day, read back on one click', () => {
  const open = (date: string) => {
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${date}`))
  }

  it('an AWARD shows the reason, the giver and how many days — without opening anything', () => {
    expect(setDayAward(P, TUE, 2, { note: 'Exercise recovery', givenBy: 'OC Ops' })).toBeNull()
    open(TUE)
    expect(screen.getByTestId('oil-detail-why').textContent).toBe('Exercise recovery')
    expect(screen.getByTestId('oil-detail-given').textContent).toBe('OC Ops')
    expect(screen.getByTestId('oil-detail-days').textContent).toBe('2 days')
  })

  it('says so plainly when an award was given with no reason and no name', () => {
    expect(setDayAward(P, TUE, 0.5)).toBeNull()
    open(TUE)
    expect(screen.getByTestId('oil-detail-why').textContent).toBe('Not given')
    expect(screen.getByTestId('oil-detail-given').textContent).toBe('Not given')
    expect(screen.getByTestId('oil-detail-days').textContent).toBe('half a day')
  })

  it('OIL the app earned names the WEEKEND as its giver, and the hours behind it', () => {
    expect(ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]])).toBe('written')
    open(SAT)
    expect(screen.getByTestId('oil-detail-why').textContent).toBe('Duty')
    expect(screen.getByTestId('oil-detail-given').textContent).toBe('Weekend/PH')
    expect(screen.getByTestId('oil-detail-days').textContent).toContain('a day')
    expect(screen.getByTestId('oil-detail-days').textContent).toContain('worked 08:00–18:00')
  })

  it('OIL earned from an accepted duty INPUT says so instead — the two are not the same evidence', () => {
    expect(ingestDutyCredit(P, SAT, 'HO', 'Duty', [[480, 720]], 'input')).toBe('written')
    open(SAT)
    expect(screen.getByTestId('oil-detail-given').textContent).toBe('Duty input')
  })

  it('shows nothing at all on a day with no OIL on it', () => {
    open(TUE)
    expect(screen.queryByTestId('oil-detail')).toBeNull()
  })
})

/* WHAT ASTRA FOUND, 21 Sep 26 — each pinned so it cannot come back. */
describe('the OIL read-back, hardened', () => {
  it('remembers WHERE an automatic credit came from across a reload', () => {
    /* `via` was written and then dropped when the record was read back, so a
       credit earned off an accepted duty INPUT came back reading "Weekend/PH"
       — the wrong evidence, pointing a reader at a schedule that does not back
       it. A protected date is skipped by both halves of the OIL pass, so there
       it would never have healed. */
    const stored = { id: 'c9', kind: 'credit', code: 'FO', oil: 'auto', via: 'input', note: 'Duty' }
    expect(readRec(stored)).toMatchObject({ oil: 'auto', via: 'input' })
    expect(creditGiver(readRec(stored) as any)).toBe('Duty input')
    // a nonsense value is dropped (a hand-typed war credit is no longer a war record at all — D401)
    expect(readRec({ id: 'c7', kind: 'credit', code: 'FO', oil: 'auto', via: 'elsewhere' })).not.toHaveProperty('via')
  })

  it('sends an INPUT-earned credit to the input, not to the schedule', () => {
    /* Both sentences used to say "change the schedule and the OIL follows",
       which for this kind is false: editing the schedule cannot take away a
       credit an accepted duty input is still backing. */
    expect(ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]], 'input')).toBe('written')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${SAT}`))
    expect(screen.getByTestId('raptor-note').textContent).toContain('duty input')
    expect(screen.getByTestId('raptor-note').textContent).not.toContain('published schedule')
  })

  it('…and one the SCHEDULE earned still points at the schedule', () => {
    expect(ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]])).toBe('written')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${SAT}`))
    expect(screen.getByTestId('raptor-note').textContent).toContain('published schedule')
  })
})

/* THE ONE THAT COST A MAN TWO DAYS (Fable, 21 Sep 26). */
describe('an award the schedule later earns on top of', () => {
  it('ADDS UP with the day it worked — 3 + 1 = 4 (N16, 21 Sep 26)', () => {
    /* The takeover was built when a hand-typed credit meant "the squadron
       recorded this work first" — the same fact, so replacing it lost nothing.
       Since the owner's 20 Sep ruling it is an AWARD: days a man is OWED, which
       the schedule knows nothing about. Replacing it took a 3-day award down to
       the one day the Saturday earns, silently. */
    expect(setDayAward(P, SAT, 3, { note: 'Exercise recovery', givenBy: 'OC Ops' })).toBeNull()
    expect(worthOf(P, SAT)).toBe(3)
    expect(ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]])).toBeTruthy()
    /* Was 3 — the takeover kept the LARGER of the two, which was the safe
       reading of a defect while the owner's decision was still open. He
       ruled on 21 Sep that they ADD. */
    expect(worthOf(P, SAT)).toBe(4)
  })

  it('reads BOTH back on the day — the award and the day he worked, told apart', () => {
    /* Two records, so the tap opens the record LIST and there is one detail
       block each. Reading "the" block by a bare testid is what this test used
       to do, and with two on screen it would either throw or silently pin
       whichever came first — which is no assertion at all. Each block is
       addressed by its own record. */
    expect(setDayAward(P, SAT, 3, { note: 'Exercise recovery', givenBy: 'OC Ops' })).toBeNull()
    expect(ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]])).toBeTruthy()
    const recs = rawState().wars[0]!.recs[P]![SAT]!.filter(r => r.kind === 'credit') as any[]
    const award = awardsOnDay(P, SAT)[0]!
    const earned = recs.find(r => r.oil === 'auto')!
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${SAT}`))

    expect(screen.getByTestId(`oil-detail-why-${award.id}`).textContent).toBe('Exercise recovery')
    expect(screen.getByTestId(`oil-detail-given-${award.id}`).textContent).toBe('OC Ops')
    expect(screen.getByTestId(`oil-detail-days-${award.id}`).textContent).toContain('3 days')

    // the schedule's own day says the SCHEDULE gave it, never the admin
    expect(screen.getByTestId(`oil-detail-given-${earned.id}`).textContent).toBe('Weekend/PH')
    expect(screen.getByTestId(`oil-detail-days-${earned.id}`).textContent).toContain('a day')
  })

  it('does not churn: a second pass over the same day writes nothing new', () => {
    /* The pass runs on every change, so a taken-over award it did not
       recognise would be rewritten forever. */
    expect(setDayAward(P, SAT, 3, { note: 'Exercise recovery' })).toBeNull()
    ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]])
    const first = JSON.stringify(creditOn(P, SAT))
    ingestDutyCredit(P, SAT, 'FO', 'Duty', [[480, 1080]])
    expect(JSON.stringify(creditOn(P, SAT))).toBe(first)
  })
})


/* THE OTHER ORDER — publish FIRST, then award (N16, 21 Sep 26). */
describe('a day the schedule has already earned on', () => {
  /* The store always allowed this and a unit test proved it, but NO SCREEN
     offered it: the cell reads as the schedule's, so the tap opened the
     read-only sheet, which has no +OIL. Award-then-publish worked and
     publish-then-award did not, so half the owner's ruling lived only in the
     tests. Found by review, then confirmed by hand in the running app — the
     hand test had walked one order and not the other. */
  it('opens STRAIGHT on the sheet that can take one — no second window', () => {
    /* For a few hours an admin got a read-only sheet first and had to press a
       button to reach this one — two windows, the second carrying everything
       the first did except the "where it came from" line. The owner asked why
       he could not just have the second; the answer was to MOVE that line
       rather than charge a tap for it. */
    expect(ingestDutyCredit(P, SAT, 'HO', 'FLT', [[420, 780]])).toBe('written')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${SAT}`))

    expect(screen.getByTestId('bid-picker')).toBeTruthy()
    expect(screen.queryByTestId('raptor-award')).toBeNull()
    // …and nothing the locked sheet used to say has been lost
    expect(screen.getByTestId('raptor-note').textContent).toContain('published schedule')
    expect(screen.getByTestId('oil-detail-days').textContent).toContain('half a day')

    fireEvent.click(screen.getByTestId('bid-oil'))
    fireEvent.change(screen.getByTestId('oil-days'), { target: { value: '3' } })
    fireEvent.change(screen.getByTestId('oil-why'), { target: { value: 'Exercise recovery' } })
    fireEvent.click(screen.getByTestId('oil-give'))

    expect(rawState().wars[0]!.recs[P]![SAT]!.filter(r => r.kind === 'credit')).toHaveLength(1)
    expect(awardsOnDay(P, SAT)).toHaveLength(1)
    expect(worthOf(P, SAT)).toBe(3.5)
  })

  it('a MEMBER still gets the read-only sheet — there is nothing there for him to do', () => {
    expect(ingestDutyCredit(P, SAT, 'FO', 'FLT', [[480, 1080]])).toBe('written')
    setRole('member'); setViewer(P)
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${SAT}`))
    expect(screen.getByTestId('raptor-sheet')).toBeTruthy()
    expect(screen.getByTestId('raptor-note').textContent).toContain('published schedule')
    expect(screen.queryByTestId('bid-oil')).toBeNull()
  })

  it('does not offer it where an award is already there — that day opens the list', () => {
    setDayAward(P, SAT, 3)
    expect(ingestDutyCredit(P, SAT, 'FO', 'FLT', [[480, 1080]])).toBe('written')
    render(<Matrix />)
    fireEvent.click(screen.getByTestId(`cell-${P}-${SAT}`))
    expect(screen.getByTestId('daylist-sheet')).toBeTruthy()
  })
})
