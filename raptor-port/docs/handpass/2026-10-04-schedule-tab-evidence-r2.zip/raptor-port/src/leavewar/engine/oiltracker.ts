// The OIL TRACKER — one person's OIL as a LEDGER rather than a sum (owner,
// 2 Sep 26: "a tracker sheet which shows when the OIL was credited and
// reason … it will automatically use the oldest OIL that was given … set how
// long OIL can last").
//
// Nothing here is a second record. Every line is DERIVED from what the store
// already holds, the same three facts `counters.ts:balanceOf` sums:
//
//   credits  — the opening figure (`openings[p].oil`), each OIL AWARD in the
//              ledger (`counter: 'oil'`, positive — the ONE kind of hand-given
//              OIL since [OIL-AWARD-IS-A-GRANT], 29 Sep 26, whether given on
//              the grid or here), and every AUTOMATIC FO/HO credit the publish
//              wire wrote (a full or half day earned by weekend/PH work). The
//              automatic credit IS its own record; the tracker reads it, it
//              never mints a ledger entry for it (counters.ts's
//              two-records-of-one-fact rule stands). The grid DRAWS each award
//              on its day too (D402), but that drawing is read here only for
//              the automatic credits — an award is counted once, off the ledger.
//   debits   — every OIL day on the grid (`OIL`, `*OIL`, `OIL*`, gated by
//              the SAME `removesAvailability` the manning rows use, so a
//              refused bid draws nothing and a half day draws 0.5), a
//              negative ledger entry (a correction), and a negative opening.
//
// Then two rules the plain sum cannot express:
//
//   FIFO     — each debit, in date order, draws down the OLDEST credit that
//              still has something left and has not expired by that date.
//              What no credit covers is `unbacked`: an overdraw. Balances go
//              negative in the squadron's own sheet and are never refused
//              (counters.ts), so overdraw is shown, not blocked.
//   EXPIRY   — the admin's `OilPolicy` says how long a credit lasts (N days
//              or N months from its own date) or forever. Whatever is left of
//              a credit on the day it expires is gone — `expired` — and the
//              balance no longer counts it. The opening figure never expires:
//              it is a carried-in number with no date of its own.
//
// With NO expiry policy the balance here is IDENTICAL to `balanceOf(…,'oil')`
// (pinned by test): FIFO only decides WHICH credit a day drew from, not how
// much was drawn. So nothing on screen changed for existing data when this
// module arrived; only a squadron that sets an expiry sees a difference, and
// then the breakdown gains an `expired` row so its parts still sum.
//
// Pure: no store, no clock. `asOf` (today) and the policy are passed in.
// Imports values from charge/codes/period only, and counters as TYPES only —
// counters.ts imports THIS module for the OIL BAL figure, so a value import
// back would be a cycle. The weekend/PH charging rule (charge.ts, 3 Sep 26)
// is read here for the debits, so OIL USED and the tracker's balance move
// together: an OIL day on a Saturday takes nothing from either.

import { chargedDays, viewsOf } from './charge'
import { creditWorth } from './credit'
import { codeOf } from './codes'
import type { FigureCtx } from './counters'
import { addDays, addMonths, isWeekend } from './period'
import type { Win } from './dayview'
import { creditGiver } from './warrecs'

export type OilExpiryUnit = 'days' | 'months'

export interface OilPolicy {
  /** How long a credit lasts from its own date; `null` = forever. */
  expiry: { n: number; unit: OilExpiryUnit } | null
  /** The history window the tracker opens on: this many months back from
   *  today, or `null` for "from the first entry" — the default since 2 Sep
   *  26 (owner: "by default show from the first entry"). */
  historyMonths: number | null
}

export const DEFAULT_OIL_POLICY: OilPolicy = Object.freeze({ expiry: null, historyMonths: null })

/** Sanity bounds for the policy numbers — ten years is already "forever". */
export const MAX_EXPIRY_DAYS = 3660
export const MAX_EXPIRY_MONTHS = 120
export const MAX_HISTORY_MONTHS = 120

const isISO = (s: unknown): s is string => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s)

/** Read an untrusted stored policy: `null` for anything but the shape above,
 *  so the caller falls back to the default rather than half-trusting junk. */
export function readOilPolicy(x: unknown): OilPolicy | null {
  if (!x || typeof x !== 'object' || Array.isArray(x)) return null
  const { expiry, historyMonths } = x as Record<string, unknown>
  let exp: OilPolicy['expiry']
  if (expiry === null || expiry === undefined) exp = null
  else {
    if (!expiry || typeof expiry !== 'object') return null
    const { n, unit } = expiry as Record<string, unknown>
    if (unit !== 'days' && unit !== 'months') return null
    if (typeof n !== 'number' || !Number.isInteger(n) || n < 1) return null
    if (n > (unit === 'days' ? MAX_EXPIRY_DAYS : MAX_EXPIRY_MONTHS)) return null
    exp = { n, unit }
  }
  let hist: number | null
  if (historyMonths === null || historyMonths === undefined) hist = null
  else if (typeof historyMonths === 'number' && Number.isInteger(historyMonths) && historyMonths >= 1 && historyMonths <= MAX_HISTORY_MONTHS) hist = historyMonths
  else return null
  return { expiry: exp, historyMonths: hist }
}

/** The first day a credit dated `date` can no longer be used, or `null` when
 *  it lasts forever (no policy, or an undated carried-in figure). A credit is
 *  usable on days STRICTLY BEFORE this: dated 1 Jan with "30 days" it serves
 *  through 30 Jan and is gone on 31 Jan. */
export function expiryOf(date: string, policy: OilPolicy): string | null {
  if (!policy.expiry || !isISO(date)) return null
  const { n, unit } = policy.expiry
  return unit === 'days' ? addDays(date, n) : addMonths(date, n)
}

export type OilSource = 'opening' | 'auto' | 'grant'

/** One thing that put OIL in: the carried-in figure, a day earned by
 *  weekend/PH work, or an admin's grant. */
export interface OilCredit {
  id: string
  /** `''` for the opening figure — it has no date and sorts first. */
  date: string
  amount: number
  reason: string
  source: OilSource
  /** Who recorded a grant (the admin's callsign, as typed at the time). */
  approvedBy?: string
  /** Who ENTERED an award (a person id — D200 (2)), and when; drawn by his
   *  live callsign where shown. */
  enteredBy?: string
  enteredAt?: string
  /** Who GAVE it, when the admin named someone: a grant's approver (owner,
   *  2 Sep 26) or a hand-typed credit's "on whose say-so" (20 Sep 26). */
  givenBy?: string
  /** The war RECORD this row was read off — what an editor addresses.
   *  Since N16 (21 Sep 26) a day can carry two credits, so a person and a
   *  date no longer name one of them. */
  recId?: string
  /** First day it can no longer be used; `null` = never. */
  expires: string | null
  /** FIFO draws against it, oldest debit first. */
  used: { date: string; amount: number }[]
  /** What is still there as of `asOf`. */
  left: number
  /** What was left when it expired, if it did. */
  expired: number
  /** For an award: the ledger entry behind it (the thing an admin edits). */
  ledgerId?: string
  /** The work hours an AUTOMATIC credit was earned over, read off the
   *  published schedule (clash check B8). Minutes from midnight.
   *  Readonly because it is the contribution's own array, handed straight
   *  through rather than copied — nothing downstream may write to it. */
  hours?: readonly Win[]
}

export type OilDebitSource = 'taken' | 'correction' | 'opening'

/** One thing that took OIL out: an OIL day on the grid, a negative ledger
 *  entry, or a negative carried-in figure. */
export interface OilDebit {
  id: string
  date: string
  amount: number
  reason: string
  source: OilDebitSource
  /** Which credits it drew from, in FIFO order. */
  from: { creditId: string; amount: number }[]
  /** What no credit covered — the overdraw. */
  unbacked: number
  ledgerId?: string
}

export interface OilLedger {
  /** Oldest first. */
  credits: OilCredit[]
  /** Oldest first. */
  debits: OilDebit[]
  /** Σ left − Σ unbacked, as of `asOf`. */
  balance: number
  /** what the app credited itself — the automatic credits (D400) */
  earned: number
  /** every OIL award, however it was given (D400) */
  awarded: number
  /** every correction (a negative OIL entry), summed — ≤ 0 */
  corrections: number
  taken: number
  expired: number
  overdrawn: number
  /** The earliest DATED entry, credit or debit — "from the first entry". */
  first: string | null
}

// Amounts are halves and wholes almost always, but a grant is "any number",
// so a long chain of subtractions is squared back to six places rather than
// carrying a 1e-17 that would render as "-0" or fail an equality.
const r6 = (x: number) => Math.round(x * 1e6) / 1e6 || 0

const CREDIT_RANK: Record<OilSource, number> = { opening: 0, auto: 1, grant: 2 }
const DEBIT_RANK: Record<OilDebitSource, number> = { opening: 0, taken: 1, correction: 2 }

/**
 * A person's whole OIL story: every credit and debit across every war, FIFO-
 * allocated, expiry applied as of `asOf`.
 */
/** WHAT THE BALANCE WOULD BE WITHOUT ONE CREDIT (21 Sep 26).
 *  The unpublish warning has to ask a counterfactual: if this day's earned
 *  credit went, would the man be overdrawn? Subtracting its worth from the
 *  balance is NOT the same question — expiry and FIFO are not linear, so a
 *  credit that has already expired unused is worth nothing to subtract, while
 *  removing a live one can strand a later debit that had drawn on it. The
 *  honest answer is to build the ledger again with that credit left out. */
export type OilOmit = (c: OilCredit) => boolean

export function oilLedgerFor(ctx: FigureCtx, personId: string, policy: OilPolicy, asOf: string, omit?: OilOmit): OilLedger {
  const credits: OilCredit[] = []
  const debits: OilDebit[] = []

  const opening = ctx.openings[personId]?.oil ?? 0
  if (opening > 0) {
    credits.push({ id: `open:${personId}`, date: '', amount: opening, reason: 'opening figure', source: 'opening', expires: null, used: [], left: opening, expired: 0 })
  } else if (opening < 0) {
    debits.push({ id: `open:${personId}`, date: '', amount: -opening, reason: 'opening figure', source: 'opening', from: [], unbacked: 0 })
  }

  for (const e of ctx.ledger) {
    if (e.personId !== personId || e.counter !== 'oil' || !e.amount) continue
    if (e.amount > 0) {
      credits.push({ id: e.id, ledgerId: e.id, date: e.date, amount: e.amount, reason: e.reason, source: 'grant', approvedBy: e.approvedBy, ...(e.givenBy ? { givenBy: e.givenBy } : {}), ...(e.enteredBy ? { enteredBy: e.enteredBy } : {}), ...(e.enteredAt ? { enteredAt: e.enteredAt } : {}), expires: expiryOf(e.date, policy), used: [], left: e.amount, expired: 0 })
    } else {
      debits.push({ id: e.id, ledgerId: e.id, date: e.date, amount: -e.amount, reason: e.reason, source: 'correction', from: [], unbacked: 0 })
    }
  }

  // Which OIL days actually charge — the weekend/PH rule, and the pilots'
  // 15-day run rule, decided ONCE for the person across every war.
  const charged = chargedDays(ctx.sources, personId, ctx)
  ctx.sources.forEach((src, wi) => {
    for (const [date, v] of Object.entries(viewsOf(src)[personId] ?? {})) {
      /* THE AUTOMATIC CREDITS, one entry each. The day also draws its AWARDS
         (D402) — those are ledger entries, read above, so an award is skipped
         here or it would be counted twice ([OIL-AWARD-IS-A-GRANT], 29 Sep 26).
         The reason is the sync wire's note (FLT, SIM + Duty, an input's type —
         owner, 2 Sep 26), else the day's kind; the giver is the evidence behind
         it — the published weekend or holiday, or the accepted duty input
         (owner, 21 Sep 26); the hours come off the published schedule. */
      for (const credit of v.all) {
        if (credit.kind !== 'credit' || !credit.auto) continue
        const amount = creditWorth({ code: credit.code as 'FO' | 'HO', auto: true })
        if (amount <= 0) continue
        const reason = credit.note ?? (isWeekend(date) ? 'weekend duty' : 'PH duty')
        const giver = creditGiver({ auto: true, via: credit.via })
        const hours = credit.wins ?? (credit.win[0] === 0 && credit.win[1] === 1439 ? undefined : [credit.win])
        credits.push({ id: `auto:${wi}:${date}`, recId: credit.id, date, amount, reason, source: 'auto', ...(hours ? { hours } : {}), ...(giver ? { givenBy: giver } : {}), expires: expiryOf(date, policy), used: [], left: amount, expired: 0 })
      }
      for (const t of charged.get(date) ?? []) {
        if (t.counter !== 'oil') continue
        const half = t.half === 'am' ? 'AM' : t.half === 'pm' ? 'PM' : null
        debits.push({ id: `take:${wi}:${date}${t.half ? ':' + t.half : ''}`, date, amount: t.amount, reason: half ? `OIL taken (${half})` : 'OIL taken', source: 'taken', from: [], unbacked: 0 })
      }
    }
  })

  /* The counterfactual: drop the named credit BEFORE the FIFO walk, so every
     debit re-allocates as it would if that credit had never existed.
     Guarded, because with no omission `filter` would be skipped and an
     in-place empty-and-refill would be emptying the very array it is about
     to read back — the same reference — and lose every credit. */
  if (omit) {
    const kept = credits.filter(c => !omit(c))
    credits.length = 0
    credits.push(...kept)
  }
  credits.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : CREDIT_RANK[a.source] - CREDIT_RANK[b.source] || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0)))
  debits.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : DEBIT_RANK[a.source] - DEBIT_RANK[b.source] || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0)))

  // FIFO: each debit walks the credits oldest-first and takes what it can
  // from any that still has something left and is still alive on that day.
  for (const d of debits) {
    let need = d.amount
    for (const c of credits) {
      if (need <= 0) break
      if (c.left <= 0) continue
      if (c.expires !== null && d.date >= c.expires) continue
      const take = Math.min(c.left, need)
      c.left = r6(c.left - take)
      c.used.push({ date: d.date, amount: take })
      d.from.push({ creditId: c.id, amount: take })
      need = r6(need - take)
    }
    d.unbacked = need
  }

  // Expiry, as of today: whatever is left of a credit past its date is gone.
  for (const c of credits) {
    if (c.left > 0 && c.expires !== null && asOf >= c.expires) {
      c.expired = c.left
      c.left = 0
    }
  }

  let earned = 0, awarded = 0, corrections = 0, taken = 0, expired = 0, overdrawn = 0, left = 0
  for (const c of credits) {
    if (c.source === 'auto') earned += c.amount
    else if (c.source === 'grant') awarded += c.amount
    expired += c.expired
    left += c.left
  }
  for (const d of debits) {
    if (d.source === 'taken') taken += d.amount
    else if (d.source === 'correction') corrections -= d.amount
    overdrawn += d.unbacked
  }
  const dated = [...credits, ...debits].map(x => x.date).filter(Boolean).sort()
  return {
    credits, debits,
    balance: r6(left - overdrawn),
    earned: r6(earned), awarded: r6(awarded), corrections: r6(corrections), taken: r6(taken), expired: r6(expired), overdrawn: r6(overdrawn),
    first: dated[0] ?? null,
  }
}

/** The OIL BAL figure: what is left as of `asOf` under the policy. */
export function oilBalanceOf(ctx: FigureCtx, personId: string, policy: OilPolicy, asOf: string): number {
  return oilLedgerFor(ctx, personId, policy, asOf).balance
}

/** Whether a dated entry falls inside a `[from, to]` window (either bound
 *  open when `null`). The undated opening figure is always inside — it is
 *  the carry-in, and a window that hid it would make the balance look wrong
 *  by exactly that much. */
export function inWindow(date: string, from: string | null, to: string | null): boolean {
  if (!date) return true
  if (from && date < from) return false
  if (to && date > to) return false
  return true
}

/** The window the tracker opens on: `historyMonths` back from `asOf`, or
 *  from the first entry (`null` from) when the policy says all. */
export function defaultWindowFrom(policy: OilPolicy, asOf: string): string | null {
  return policy.historyMonths === null ? null : addMonths(asOf, -policy.historyMonths)
}
