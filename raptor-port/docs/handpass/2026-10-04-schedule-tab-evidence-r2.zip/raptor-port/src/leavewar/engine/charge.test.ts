import { describe, expect, it } from 'vitest'
import { chargedDays, legacyViews, LONG_LEAVE_DAYS, type CountCtx, type LeaveSource } from './charge'
import { dayView, AM, PM } from './dayview'
import { balanceOf, drawnFrom, lveConOf, medConOf, takenOf, withFill } from './counters'
import { seedEventDefs } from './eventdefs'
import type { Person } from './people'
import { addDays, buildDays, type Period } from './period'

// The owner's rule (3 Sep 26): leave on a weekend or a public holiday costs
// nothing and counts as nothing — unless a PILOT is 15 days or more into one
// unbroken run of the same pool, in which case every day charges.
//
// Calendar facts the cases lean on (period.test.ts pins the same weekend):
//   2026-01-03 Sat · 2026-01-04 Sun · 2026-01-05 Mon … 2026-01-09 Fri
//   2026-01-10 Sat · 2026-01-11 Sun · 2026-01-12 Mon … 2026-01-16 Fri
//   2026-01-17 Sat · 2026-01-18 Sun · 2026-01-19 Mon

const person = (id: string, seat: Person['seat']): Person =>
  ({ id, callsign: id.toUpperCase(), seat, band: 'ops', sxo: false, from: null, to: null })

const pilotCtx: CountCtx = { eventDefs: seedEventDefs(), people: [person('ace', 'pilot'), person('wiz', 'wso')] }

const period = (start: string, end: string, tweak?: (p: Period) => void): Period => {
  const p: Period = { id: `${start}`, name: 'w', start, end, stage: 'open', bidFrom: null, bidTo: null, days: buildDays(start, end), bands: [] }
  tweak?.(p)
  return p
}

/** `who` holds `code` on every day from `from` for `n` days. */

const span = (from: string, n: number, code: string): Record<string, string> => {
  const out: Record<string, string> = {}
  for (let i = 0; i < n; i++) out[addDays(from, i)] = code
  return out
}

const src = (grid: Record<string, Record<string, string>>, p?: Period, states = {}): LeaveSource => ({ grid, states, period: p })

describe('a weekend or PH day of leave charges nothing', () => {
  it('a Sat/Sun LL draws no annual and shows in no USED figure — but the cell still stands', () => {
    const sources = [src({ wiz: { '2026-01-02': 'LL', '2026-01-03': 'LL', '2026-01-04': 'LL', '2026-01-05': 'LL' } })]
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(2)
    expect(takenOf(sources, 'wiz', 'LL', pilotCtx)).toBe(2)
    expect(lveConOf(sources, 'wiz', pilotCtx)).toBe(2)
    expect(balanceOf({ wiz: { annual: 10 } }, [], sources, 'wiz', 'annual', pilotCtx)).toBe(8)
  })

  it('needs no ctx at all to know a weekend — an engine caller with only a grid gets the rule', () => {
    const sources = [src({ wiz: { '2026-01-03': 'OIL', '2026-01-05': 'OIL' } })]
    expect(drawnFrom(sources, 'wiz', 'oil')).toBe(1)
    expect(takenOf(sources, 'wiz', 'OIL')).toBe(1)
  })

  it('a day the war flags `ph` charges nothing', () => {
    const p = period('2026-01-05', '2026-01-09', p => { p.days[2].ph = true }) // Wed 7th
    const sources = [src({ wiz: span('2026-01-05', 5, 'CCL') }, p)]
    expect(drawnFrom(sources, 'wiz', 'ccl', pilotCtx)).toBe(4)
    expect(takenOf(sources, 'wiz', 'CCL', pilotCtx)).toBe(4)
  })

  it("a day carrying an event word tagged 'off' — the admin's PH — charges nothing, even marked AFTER the leave", () => {
    const p = period('2026-01-05', '2026-01-09')
    const sources = [src({ wiz: span('2026-01-05', 5, 'LL') }, p)]
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(5)
    // The admin types PH on the Thursday. Nothing is stored about the
    // balance, so the next read simply excuses the day.
    p.days[3].events = ['PH']
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(4)
    // …and a band across the week does the same through its own tag.
    p.days[3].events = []
    p.bands = [{ line: 0, from: '2026-01-06', to: '2026-01-06', text: 'closure', kind: 'off' }]
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(4)
  })

  it("a management Off day (`free`) is NOT a holiday here — leave on it still charges", () => {
    const p = period('2026-01-05', '2026-01-09')
    p.days[1].events = ['Off day']
    const sources = [src({ wiz: span('2026-01-05', 5, 'LL') }, p)]
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(5)
  })

  it('medical is untouched — hospitalisation over a weekend is still hospitalisation', () => {
    const sources = [src({ wiz: { '2026-01-02': 'HL', '2026-01-03': 'HL', '2026-01-04': 'HL', '2026-01-05': 'OML' } })]
    expect(medConOf(sources, 'wiz', pilotCtx)).toBe(4)
    expect(takenOf(sources, 'wiz', 'HL', pilotCtx)).toBe(3)
  })

  it('a half day on a weekend is excused too; on a weekday it still charges its half', () => {
    const sources = [src({ wiz: { '2026-01-03': '*LL', '2026-01-05': 'LL*' } })]
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(0.5)
  })
})

describe("the pilots' 15-day rule", () => {
  // Mon 5 Jan → Mon 19 Jan is 15 calendar days holding two weekends.
  const fifteen = span('2026-01-05', 15, 'LL')

  it('a pilot 15 days deep charges every day, the weekends inside included', () => {
    const sources = [src({ ace: fifteen })]
    expect(drawnFrom(sources, 'ace', 'annual', pilotCtx)).toBe(15)
    expect(takenOf(sources, 'ace', 'LL', pilotCtx)).toBe(15)
  })

  it('the same 15 days for a WSO charge the eleven working days only', () => {
    const sources = [src({ wiz: fifteen })]
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(11)
  })

  it('a pilot with nobody on the roster is not a pilot — the rule needs the people to say so', () => {
    const sources = [src({ ace: fifteen })]
    expect(drawnFrom(sources, 'ace', 'annual')).toBe(11)
    expect(drawnFrom(sources, 'ace', 'annual', { people: [] })).toBe(11)
  })

  it('14 days is short: the weekends inside are excused', () => {
    const sources = [src({ ace: span('2026-01-05', 14, 'LL') })]
    expect(drawnFrom(sources, 'ace', 'annual', pilotCtx)).toBe(10)
    expect(LONG_LEAVE_DAYS).toBe(15)
  })

  it('LL then OL is ONE run — both spend the annual pool', () => {
    const grid = { ...span('2026-01-05', 7, 'LL'), ...span('2026-01-12', 8, 'OL') }
    const sources = [src({ ace: grid })]
    expect(drawnFrom(sources, 'ace', 'annual', pilotCtx)).toBe(15)
  })

  it("a day of another leave — the owner's OIL/FCL/CCL/EL/PL/CL — breaks the run, so two 14s stay short", () => {
    // 14 LL, one OIL, then 14 more LL: 29 days away, no run reaches 15.
    const grid = { ...span('2026-01-05', 14, 'LL'), '2026-01-19': 'OIL', ...span('2026-01-20', 14, 'LL') }
    const sources = [src({ ace: grid })]
    // Each 14-day LL block holds four weekend days → 10 charged, twice; the
    // OIL Monday charges its own counter.
    expect(drawnFrom(sources, 'ace', 'annual', pilotCtx)).toBe(20)
    expect(drawnFrom(sources, 'ace', 'oil', pilotCtx)).toBe(1)
    for (const breaker of ['FCL', 'CCL', 'EL', 'PL', 'CL']) {
      const g = { ...span('2026-01-05', 14, 'LL'), '2026-01-19': breaker, ...span('2026-01-20', 14, 'LL') }
      expect(drawnFrom([src({ ace: g })], 'ace', 'annual', pilotCtx), breaker).toBe(20)
    }
  })

  it('a blank day, a medical day or a refused bid breaks the run the same way', () => {
    const blank = { ...span('2026-01-05', 8, 'LL'), ...span('2026-01-14', 8, 'LL') } // 13th empty
    expect(drawnFrom([src({ ace: blank })], 'ace', 'annual', pilotCtx)).toBe(12)
    const med = { ...span('2026-01-05', 8, 'LL'), '2026-01-13': 'OML', ...span('2026-01-14', 8, 'LL') }
    expect(drawnFrom([src({ ace: med })], 'ace', 'annual', pilotCtx)).toBe(12)
    const refused = { ace: { '2026-01-13': { state: 'refused' as const, source: 'bid' as const } } }
    expect(drawnFrom([src({ ace: span('2026-01-05', 17, 'LL') }, undefined, refused)], 'ace', 'annual', pilotCtx)).toBe(12)
  })

  it('a run may cross a war boundary — entitlements are continuous, wars are windows', () => {
    const a = period('2026-01-01', '2026-01-11'), b = period('2026-01-12', '2026-01-31')
    const sources = [
      src({ ace: span('2026-01-05', 7, 'LL') }, a),
      src({ ace: span('2026-01-12', 8, 'LL') }, b),
    ]
    expect(drawnFrom(sources, 'ace', 'annual', pilotCtx)).toBe(15)
  })

  it('a half day BREAKS the run — a continuous run is full days only', () => {
    // 14 full LL then a half day: the half day is not a full day of leave, so
    // it does not extend the run to 15. The 14-day block stays short — its
    // four weekend days are excused (10 charged) — and the half day charges
    // its own half on the Monday.
    const grid = { ...span('2026-01-05', 14, 'LL'), '2026-01-19': 'LL*' }
    expect(drawnFrom([src({ ace: grid })], 'ace', 'annual', pilotCtx)).toBe(10.5)
  })

  it('a half day in the MIDDLE splits a would-be 15-day run into two short ones', () => {
    // 7 full LL, a half day, 7 more full LL: 15 cells of leave, but the half
    // day breaks the run, so neither side reaches 15 and the weekends inside
    // each side are excused. 5–11 Jan holds one weekend (5 charged), the half
    // on the 12th charges 0.5, 13–19 Jan holds one weekend (5 charged).
    const grid = { ...span('2026-01-05', 7, 'LL'), '2026-01-12': 'LL*', ...span('2026-01-13', 7, 'LL') }
    expect(drawnFrom([src({ ace: grid })], 'ace', 'annual', pilotCtx)).toBe(10.5)
  })

  /* owner Q13 (19 Sep 26), CHANGED from the 3 Sep "by counter" reading: the
     15-day rule is for LL and OL only — a long run of CL (or OIL, CCL …) keeps
     its weekends free, pilot or not. */
  it('a long run of CL does NOT charge its weekends — the rule is LL/OL only (owner Q13)', () => {
    expect(drawnFrom([src({ ace: span('2026-01-05', 15, 'CL') })], 'ace', 'cl', pilotCtx)).toBe(11)
    expect(drawnFrom([src({ wiz: span('2026-01-05', 15, 'CL') })], 'wiz', 'cl', pilotCtx)).toBe(11)
  })
  it('14 LL, one FCL, then LL again: no run reaches 15, so the weekends stay free (owner Q13)', () => {
    const cells = { ...span('2026-01-05', 14, 'LL'), ...span('2026-01-19', 1, 'FCL'), ...span('2026-01-20', 14, 'LL') }
    const all = drawnFrom([src({ ace: cells })], 'ace', 'annual', pilotCtx)
    const noWeekends = drawnFrom([src({ wiz: cells })], 'wiz', 'annual', pilotCtx)
    expect(all).toBe(noWeekends)
  })
  it('a morning of LL and an afternoon of OL is a full LL/OL day: it continues the run', () => {
    const cells = { ace: span('2026-01-05', 15, 'LL') }
    const views = legacyViews(cells, {})
    const mid = '2026-01-12'
    const split = { ...views, ace: { ...views.ace, [mid]: dayView([
      { id: 'a', kind: 'absence', code: 'LL', win: AM }, { id: 'b', kind: 'absence', code: 'OL', win: PM }]) } }
    expect(drawnFrom([{ grid: cells, states: {}, views: split }], 'ace', 'annual', pilotCtx)).toBe(15)
    const broken = { ...views, ace: { ...views.ace, [mid]: dayView([
      { id: 'a', kind: 'absence', code: 'LL', win: AM }, { id: 'b', kind: 'absence', code: 'OIL', win: PM }]) } }
    expect(drawnFrom([{ grid: cells, states: {}, views: broken }], 'ace', 'annual', pilotCtx)).toBeLessThan(15)
  })
})

describe('chargedDays', () => {
  it('reports the counter and the amount per charged date, and nothing for an excused one', () => {
    const m = chargedDays([src({ wiz: { '2026-01-02': 'LL', '2026-01-03': '*OIL' } })], 'wiz', pilotCtx)
    expect([...m.entries()]).toEqual([['2026-01-02', [{ date: '2026-01-02', counter: 'annual', amount: 1, type: 'LL' }]]])
  })

  it('is empty for someone with no leave at all', () => {
    expect(chargedDays([src({})], 'nobody', pilotCtx).size).toBe(0)
  })
})

// The calendar a war contributes — which dates are holidays, which carry an
// 'off' event — is looked up through an index remembered per `period.days`
// (charge.ts §DAY_INDEX), because rebuilding it on every call cost the drawer
// ~8× the closed column's engine time. The saving is only worth having if the
// answer is still right the instant a day changes, which is what these pin.
describe('the remembered day index answers for the CURRENT calendar (6 Sep 26)', () => {
  const jan5 = '2026-01-05'   // a Monday — a working day until something says otherwise

  it('a PH marked AFTER the first read gives the day back', () => {
    const p = period('2026-01-01', '2026-01-31')
    const sources = [src({ wiz: { [jan5]: 'LL' } }, p)]
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(1)

    // Exactly the store's own edit shape (`setDayEvent`: `days:
    // w.period.days.map(…)`) — a NEW days array with one new day in it, which
    // is what makes the remembered index a fact about a calendar rather than
    // about a war.
    const marked: Period = { ...p, days: p.days.map(d => (d.date === jan5 ? { ...d, ph: true } : d)) }
    expect(drawnFrom([src({ wiz: { [jan5]: 'LL' } }, marked)], 'wiz', 'annual', pilotCtx)).toBe(0)
    // ...and the original period, untouched, still reads the way it did.
    expect(drawnFrom(sources, 'wiz', 'annual', pilotCtx)).toBe(1)
  })

  it('a merged event band is read live, never remembered', () => {
    // `bands` live on the period and are deliberately outside the index, so a
    // band added to a period whose days array is the SAME array must land at
    // once. Two periods sharing one days array is the shape every non-day edit
    // makes (`{ ...w.period, stage }` and friends keep the array).
    const p = period('2026-01-01', '2026-01-31')
    expect(drawnFrom([src({ wiz: { [jan5]: 'LL' } }, p)], 'wiz', 'annual', pilotCtx)).toBe(1)
    const banded: Period = { ...p, bands: [{ line: 0, from: jan5, to: jan5, text: 'PH', kind: 'off' }] }
    expect(banded.days).toBe(p.days)
    expect(drawnFrom([src({ wiz: { [jan5]: 'LL' } }, banded)], 'wiz', 'annual', pilotCtx)).toBe(0)
  })

  it('still reads the calendar of the war that holds the date, with several in play', () => {
    // The merged map this replaced was filled in source order, so the LAST war
    // naming a date won; the lookup walks the sources backwards to keep that.
    // Here only the second war knows January at all.
    const jan = period('2026-01-01', '2026-01-31', p => { p.days.find(d => d.date === jan5)!.ph = true })
    const feb = period('2026-02-01', '2026-02-28')
    const leave = { wiz: { [jan5]: 'LL' } }
    expect(drawnFrom([src(leave, feb), src({}, jan)], 'wiz', 'annual', pilotCtx)).toBe(0)
    expect(drawnFrom([src(leave, jan), src({}, feb)], 'wiz', 'annual', pilotCtx)).toBe(0)
  })
})

/* THE ASK BEFORE A BALANCE GOES BELOW ZERO READS THIS RULE TOO (his ruling D418, 29 Sep 26): `withFill` is the day
   views as a fill would leave them, and the ask reads a figure of them — so a fill over a weekend must not claim to
   spend the weekend, and a new afternoon beside a morning already held must add its half (Astra's final read). */
describe('withFill — what a fill would spend, by the same rule', () => {
  const YEAR = period('2026-01-01', '2026-12-31')
  const war = (grid: Record<string, Record<string, string>> = {}, states = {}) => [src(grid, YEAR, states)]
  const spend = (sources: LeaveSource[], who: string, counter: 'annual' | 'ccl' | 'fcl', dates: string[], code: string) =>
    drawnFrom(withFill(sources, who, dates, code), who, counter, pilotCtx) - drawnFrom(sources, who, counter, pilotCtx)

  it('a Fri–Mon fill of LL spends two days, not four (the old amount × days said four)', () => {
    expect(spend(war(), 'wiz', 'annual', ['2026-01-02', '2026-01-03', '2026-01-04', '2026-01-05'], 'LL')).toBe(2)
  })

  it('a day already holding the same leave adds nothing; an empty day adds its day', () => {
    expect(spend(war({ wiz: { '2026-01-05': 'LL' } }), 'wiz', 'annual', ['2026-01-05', '2026-01-06'], 'LL')).toBe(1)
  })

  it('a half day spends half; leave on another counter spends none of this one', () => {
    expect(spend(war(), 'wiz', 'annual', ['2026-01-05'], '*LL')).toBe(0.5)
    expect(spend(war(), 'wiz', 'annual', ['2026-01-05'], 'CCL')).toBe(0)
    expect(spend(war(), 'wiz', 'ccl', ['2026-01-05', '2026-01-06', '2026-01-07'], 'CCL')).toBe(3)
  })

  it('an afternoon beside a morning already held adds its half — the morning stays (Astra F1)', () => {
    expect(spend(war({ wiz: { '2026-01-05': '*FCL' } }), 'wiz', 'fcl', ['2026-01-05'], 'FCL*')).toBe(0.5)
    // a morning of LL and an afternoon of OL — both LVE, the day becomes a full LL/OL day
    expect(spend(war({ wiz: { '2026-01-05': '*LL' } }), 'wiz', 'annual', ['2026-01-05'], 'OL*')).toBe(0.5)
    // the other half spends ANOTHER counter: the new half is charged to its own, the old one untouched
    const other = war({ wiz: { '2026-01-05': '*CCL' } })
    expect(spend(other, 'wiz', 'annual', ['2026-01-05'], 'LL*')).toBe(0.5)
    expect(spend(other, 'wiz', 'ccl', ['2026-01-05'], 'LL*')).toBe(0)
  })

  it('a whole day over a morning bid REPLACES it, as the write does — half a day more, not a whole', () => {
    expect(spend(war({ wiz: { '2026-01-05': '*LL' } }), 'wiz', 'annual', ['2026-01-05'], 'LL')).toBe(0.5)
  })

  it("a pilot's run the fill stretches to 15 days charges its weekends too", () => {
    // ace holds LL Mon 5 – Fri 16 Jan (12 days, weekends free: 10 charged); three more days make a 15-day run
    const sources = war({ ace: span('2026-01-05', 12, 'LL') })
    expect(drawnFrom(sources, 'ace', 'annual', pilotCtx)).toBe(10)
    expect(spend(sources, 'ace', 'annual', ['2026-01-17', '2026-01-18', '2026-01-19'], 'LL')).toBe(15 - 10)
  })

  it("the afternoon that completes a pilot's 15th full day charges the whole run (Astra F1)", () => {
    // ace: LL Mon 5 – Sun 18 Jan (14 days) and a morning of LL on Mon 19 — the run is 14 full days, weekends free
    const grid = { ace: { ...span('2026-01-05', 14, 'LL'), '2026-01-19': '*LL' } }
    const sources = war(grid)
    expect(drawnFrom(sources, 'ace', 'annual', pilotCtx)).toBe(10 + 0.5)
    // the afternoon makes the 19th full: 15 full days, every day charged
    expect(spend(sources, 'ace', 'annual', ['2026-01-19'], 'LL*')).toBe(15 - 10.5)
  })

  it('a refused bid on the day stays refused and draws nothing; a date no war holds is left alone', () => {
    const refused = war({ wiz: { '2026-01-05': 'LL' } }, { wiz: { '2026-01-05': { state: 'refused' } } })
    expect(spend(refused, 'wiz', 'annual', ['2026-01-05'], 'LL')).toBe(1)
    expect(spend(war(), 'wiz', 'annual', ['2027-01-05'], 'LL')).toBe(0)
    expect(spend(war(), 'wiz', 'annual', [], 'LL')).toBe(0)
  })
})
