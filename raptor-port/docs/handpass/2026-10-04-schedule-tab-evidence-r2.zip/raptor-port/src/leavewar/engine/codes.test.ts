import { describe, expect, it } from 'vitest'
import { codeOf, displayCell, formatCell, isDuty, isMedical, LEAVE_TYPES, parseCell, portionAmount } from './codes'

describe('portionAmount', () => {
  it('costs a whole day for full, half a day for am or pm', () => {
    expect(portionAmount('full')).toBe(1)
    expect(portionAmount('am')).toBe(0.5)
    expect(portionAmount('pm')).toBe(0.5)
  })
})

describe('parseCell', () => {
  it('parses a bare leave type as a full day', () => {
    expect(parseCell('LL')).toEqual({ type: 'LL', portion: 'full' })
    expect(parseCell('OIL')).toEqual({ type: 'OIL', portion: 'full' })
  })

  it('parses a leading asterisk as the morning', () => {
    expect(parseCell('*LL')).toEqual({ type: 'LL', portion: 'am' })
    expect(parseCell('*OIL')).toEqual({ type: 'OIL', portion: 'am' })
  })

  it('parses a trailing asterisk as the afternoon', () => {
    expect(parseCell('LL*')).toEqual({ type: 'LL', portion: 'pm' })
    expect(parseCell('OIL*')).toEqual({ type: 'OIL', portion: 'pm' })
  })

  it('parses every leave type', () => {
    for (const type of ['LL', 'OL', 'OIL', 'CCL', 'FCL', 'PL', 'EL']) {
      expect(parseCell(type)).toEqual({ type, portion: 'full' })
    }
  })

  it('parses a non-leave marker as a full day with no meaningful portion', () => {
    for (const type of ['ATTC', 'HL', 'OML', 'CSE', 'OD']) {
      expect(parseCell(type)).toEqual({ type, portion: 'full' })
    }
  })

  it('parses OIL-credit markers the same way, since they carry no portion either', () => {
    expect(parseCell('FO')).toEqual({ type: 'FO', portion: 'full' })
    expect(parseCell('HO')).toEqual({ type: 'HO', portion: 'full' })
  })

  it('is tolerant of surrounding whitespace and of case', () => {
    expect(parseCell(' ll ')).toEqual({ type: 'LL', portion: 'full' })
    expect(parseCell(' *ll ')).toEqual({ type: 'LL', portion: 'am' })
    expect(parseCell(' ll* ')).toEqual({ type: 'LL', portion: 'pm' })
  })

  it('rejects an asterisk on both sides, since the notation only ever carries one time marker', () => {
    expect(parseCell('*LL*')).toBeNull()
    expect(parseCell('*OIL*')).toBeNull()
  })

  it('rejects a portion on a course or overseas-duty marker — those never come in halves', () => {
    expect(parseCell('*M')).toBeNull()
    expect(parseCell('CSE*')).toBeNull()
    expect(parseCell('*OD')).toBeNull()
  })

  it('accepts a portion on a medical marker — half-day medical joined 17 Aug 26', () => {
    expect(parseCell('*OML')).toEqual({ type: 'OML', portion: 'am' })
    expect(parseCell('HL*')).toEqual({ type: 'HL', portion: 'pm' })
    expect(parseCell('*ATTC')).toEqual({ type: 'ATTC', portion: 'am' })
    expect(parseCell('ATTB*')).toEqual({ type: 'ATTB', portion: 'pm' })
  })

  it("reads the owner's B/C shorthand as the ATT markers, portions included", () => {
    expect(parseCell('B')).toEqual({ type: 'ATTB', portion: 'full' })
    expect(parseCell('*C')).toEqual({ type: 'ATTC', portion: 'am' })
    expect(parseCell('c*')).toEqual({ type: 'ATTC', portion: 'pm' })
  })

  it('rejects a portion on an OIL-credit marker — credits never carry portions', () => {
    expect(parseCell('*FO')).toBeNull()
    expect(parseCell('HO*')).toBeNull()
  })

  it('rejects an unknown type', () => {
    expect(parseCell('NOPE')).toBeNull()
    expect(parseCell('*NOPE')).toBeNull()
  })

  it('rejects empty, whitespace-only or missing input', () => {
    expect(parseCell('')).toBeNull()
    expect(parseCell('   ')).toBeNull()
    expect(parseCell(undefined)).toBeNull()
    expect(parseCell(null)).toBeNull()
  })

  it('has no PO code — posted out is a roster date, not a code', () => {
    expect(parseCell('PO')).toBeNull()
  })

  it('has no standalone AM or PM code — a portion belongs to a leave type, not on its own', () => {
    expect(parseCell('AM')).toBeNull()
    expect(parseCell('PM')).toBeNull()
    // `HO` used to be pinned null here too, as the retired taken-half legacy
    // code (migrated to `*OIL` long ago). The owner resurrected the letters on
    // 28 Aug 26 with the OPPOSITE meaning — the half-day OIL EARNED credit,
    // beside `FO` — and the two meanings never coexisted in stored data, so
    // `HO` now parses as the credit marker.
    expect(parseCell('HO')).toEqual({ type: 'HO', portion: 'full' })
  })

  it('parses the four medical markers, and no longer the old M', () => {
    for (const type of ['ATTB', 'ATTC', 'HL', 'OML']) {
      expect(parseCell(type)).toEqual({ type, portion: 'full' })
    }
    // `M` was replaced three-for-one by ATT C, HL and OML (owner, Aug 26).
    expect(parseCell('M')).toBeNull()
  })
})

/* THE ONE FOLD BETWEEN WHAT IS STORED AND WHAT A BOX SHOWS. Rewritten on the
   owner's 20 Sep 26 ask, which changed what the marks MEAN: the arrow now
   carries the half of the day, which frees the asterisk to answer the question
   the squadron actually asks of an OIL credit — did a person type this, or did
   the app work it out? These tests asserted the OLD marks, and they move with
   the rule. The STORED grammar is untouched: `parseCell`'s own tests above
   still pin `*LL`, and nothing but the screen changed. */
describe('displayCell', () => {
  it('points an arrow at the half of the day the record sits in', () => {
    expect(displayCell('LL')).toBe('LL')
    expect(displayCell('*LL')).toBe('<LL')
    expect(displayCell('LL*')).toBe('LL>')
  })

  it('shows the ATT markers as the owner’s one-letter shorthand, arrow and all', () => {
    expect(displayCell('ATTB')).toBe('B')
    expect(displayCell('*ATTC')).toBe('<C')
    expect(displayCell('ATTC*')).toBe('C>')
  })

  it('a trailing star means the APP put it there, not a person', () => {
    expect(displayCell('FO', true)).toBe('FO*')
    expect(displayCell('HO', true)).toBe('HO*')
    expect(displayCell('FO')).toBe('FO')          // a person granted this one
  })

  it('leaves anything it cannot parse exactly as it found it', () => {
    for (const raw of ['PO', 'NOPE', '']) expect(displayCell(raw)).toBe(raw)
  })
})

describe('isMedical', () => {
  it('recognises the four markers, portioned or not, shorthand included', () => {
    for (const raw of ['ATTB', 'ATTC', 'HL', '*OML', 'B', 'C*']) expect(isMedical(raw)).toBe(true)
  })

  it('says no to leave, duty, courses and junk', () => {
    for (const raw of ['LL', '*OIL', 'FO', 'CSE', 'OD', 'NOPE', '', undefined]) {
      expect(isMedical(raw as any)).toBe(false)
    }
  })
})

describe('formatCell', () => {
  it('round-trips a full day back to the bare type', () => {
    const cell = { type: 'LL', portion: 'full' } as const
    expect(formatCell(cell)).toBe('LL')
    expect(parseCell(formatCell(cell))).toEqual(cell)
  })

  it('round-trips a morning portion with a leading asterisk', () => {
    const cell = { type: 'OIL', portion: 'am' } as const
    expect(formatCell(cell)).toBe('*OIL')
    expect(parseCell(formatCell(cell))).toEqual(cell)
  })

  it('round-trips an afternoon portion with a trailing asterisk', () => {
    const cell = { type: 'OIL', portion: 'pm' } as const
    expect(formatCell(cell)).toBe('OIL*')
    expect(parseCell(formatCell(cell))).toEqual(cell)
  })

  it('round-trips a non-leave marker unchanged', () => {
    const cell = { type: 'FO', portion: 'full' } as const
    expect(formatCell(cell)).toBe('FO')
    expect(parseCell(formatCell(cell))).toEqual(cell)
  })

  it('throws rather than emit a portion on a duty or course marker, which parseCell would only reject', () => {
    expect(() => formatCell({ type: 'FO', portion: 'am' })).toThrow()
    expect(() => formatCell({ type: 'CSE', portion: 'am' })).toThrow()
  })

  it('round-trips a portioned medical marker like any leave', () => {
    const cell = { type: 'OML', portion: 'pm' } as const
    expect(formatCell(cell)).toBe('OML*')
    expect(parseCell(formatCell(cell))).toEqual(cell)
  })
})

describe('codeOf', () => {
  it('makes a half day cost half a person, not a whole one', () => {
    // Iterates all seven leave types rather than just LL and OIL: the
    // implementation is generic over `type`, so a future change that wrongly
    // special-cased one leave type would slip past a test that only ever
    // checked two of them.
    for (const { type } of LEAVE_TYPES) {
      expect(codeOf(`*${type}`)!.removes).toBe(0.5)
      expect(codeOf(`${type}*`)!.removes).toBe(0.5)
      expect(codeOf(type)!.removes).toBe(1)
    }
  })

  it('spends the right counter, scaled by the portion', () => {
    // Same reasoning as above: every leave type's counter and amount, not
    // just LL and OIL, so a wrongly special-cased type shows up here. Since
    // 2 Sep 26 every leave type spends a counter (the filter is belt and
    // braces for a future free type).
    for (const { type, counter } of LEAVE_TYPES.filter(t => t.counter !== null)) {
      expect(codeOf(type)!.spends).toEqual({ counter, amount: 1 })
      expect(codeOf(`*${type}`)!.spends).toEqual({ counter, amount: 0.5 })
      expect(codeOf(`${type}*`)!.spends).toEqual({ counter, amount: 0.5 })
    }
  })

  it('spends nothing for medical, courses and overseas duty', () => {
    for (const c of ['ATTC', 'HL', 'OML', 'CSE', 'OD']) expect(codeOf(c)!.spends).toBeNull()
  })

  // `OFF` was free leave from 10 Aug 26 to 2 Sep 26. The owner then settled
  // that OFF is never a person's leave — management declares an Off day for
  // everyone (the `free` event kind) — so the code is gone from the
  // catalogue: not biddable, not parseable, and every leave type spends.
  it('no longer knows OFF as a code', () => {
    expect(codeOf('OFF') ?? null).toBeNull()
    expect(codeOf('*OFF') ?? null).toBeNull()
    expect(parseCell('OFF')).toBeNull()
    expect(LEAVE_TYPES.some(t => t.type === 'OFF')).toBe(false)
    expect(LEAVE_TYPES.every(t => t.counter !== null)).toBe(true)
  })

  it('earns OIL only for the OIL-credit markers', () => {
    expect(codeOf('FO')!.earnsOil).toBe(1)
    expect(codeOf('HO')!.earnsOil).toBe(0.5)
    expect(codeOf('LL')!.earnsOil).toBe(0)
  })

  it('marks the OIL-credit markers as duty and never as a bid', () => {
    expect(isDuty('FO')).toBe(true)
    expect(isDuty('HO')).toBe(true)
    expect(isDuty('LL')).toBe(false)
    expect(codeOf('FO')!.bid).toBe(false)
    expect(codeOf('LL')!.bid).toBe(true)
  })

  it('removes nobody for an OIL credit by itself — `duty` is what excludes them, not `removes`', () => {
    // availabilityOf returns on the `c.duty` branch before ever reading
    // `removes` for FO/HO, and the catalogue now says plainly what that
    // branch already assumes: an OIL credit removes 0 on its own account.
    // Someone earning it is at work, not absent — it is `duty: true`, checked
    // on its own line, that keeps them out of the flying count.
    expect(codeOf('FO')!.removes).toBe(0)
    expect(codeOf('HO')!.removes).toBe(0)
  })

  it('does not treat medical, courses or duty as bids', () => {
    for (const c of ['ATTC', 'HL', 'OML', 'CSE', 'OD', 'FO', 'HO']) {
      expect(codeOf(c)!.bid).toBe(false)
    }
  })

  it('has no PO code — posted out is a roster date, not a code', () => {
    expect(codeOf('PO')).toBeUndefined()
  })

  it('is case-insensitive and tolerant of stray whitespace', () => {
    expect(codeOf(' ll ')).toEqual(codeOf('LL'))
  })

  it('returns undefined for an unknown code rather than throwing', () => {
    expect(codeOf('NOPE')).toBeUndefined()
    expect(codeOf('')).toBeUndefined()
  })

  it('no longer recognises AM or PM as codes in their own right — but HO is back as the credit', () => {
    expect(codeOf('AM')).toBeUndefined()
    expect(codeOf('PM')).toBeUndefined()
    // `HO` was pinned undefined here as the retired taken-half legacy code.
    // Resurrected 28 Aug 26 by the owner as the half-day OIL EARNED credit —
    // the old and new meanings never coexisted in stored data (the legacy
    // spelling was migrated to `*OIL` long before), so it now resolves to the
    // credit marker: at work, off flying, earning half a day.
    expect(codeOf('HO')!.earnsOil).toBe(0.5)
    expect(codeOf('HO')!.duty).toBe(true)
  })

  it('recognises the medical markers, whole and half days, and no longer M', () => {
    for (const c of ['ATTC', 'HL', 'OML']) {
      expect(codeOf(c)!.removes).toBe(1)
      expect(codeOf(c)!.bid).toBe(false)
    }
    // A half-day medical removes half the man, exactly like a half-day leave.
    expect(codeOf('*OML')!.removes).toBe(0.5)
    expect(codeOf('HL*')!.removes).toBe(0.5)
    expect(codeOf('M')).toBeUndefined()
  })

  it('ATT B removes nothing from manning — no flying, but at work (matching Raptor’s own meaning)', () => {
    expect(codeOf('ATTB')!.removes).toBe(0)
    expect(codeOf('*ATTB')!.removes).toBe(0)
    expect(codeOf('ATTB')!.bid).toBe(false)
    expect(codeOf('ATTB')!.spends).toBeNull()
    expect(codeOf('ATTB')!.duty).toBe(false)
  })

  it('rejects a portion on a course or OIL-credit marker end to end', () => {
    expect(codeOf('CSE*')).toBeUndefined()
    expect(codeOf('*FO')).toBeUndefined()
    expect(codeOf('HO*')).toBeUndefined()
  })

  it('rejects an asterisk on both sides end to end', () => {
    expect(codeOf('*LL*')).toBeUndefined()
  })
})
