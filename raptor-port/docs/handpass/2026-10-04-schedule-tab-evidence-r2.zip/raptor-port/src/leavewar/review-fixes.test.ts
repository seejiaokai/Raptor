// Pins for the step-4 cross-provider code inspection (Fable + Codex, 20 Sep 26).
// Each test names the finding it closes; each drives the REAL wired stores.
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { INPUTS } from '../engine/inputs'
import { PEOPLE } from '../engine/people'
import { HOOKS } from '../engine/hooks'
import { stashClear, stashPut } from '../engine/weekstash'
import { initStore as raptorInitStore, writeInputs } from '../state/store'
import { setMe, setSession } from '../state/auth'
import { projectPeople } from './state/raptorRoster'
import {
  advanceStage, changeAbsenceById, decideRequestById, getState, getVersion, initStore as lwInitStore, lwEditLists, lwHistInit, rawState, setBidState, setCell, setPeople, setRole, moveRecords,
} from './state/store'
import { memoryBackend } from './state/storage'
import { wireLeaveWarSync } from './sync'
import { dayView, FULL, PM, type Contrib } from './engine/dayview'
import { recContribs } from './engine/warrecs'
import { _resetTimeline } from '../undo/timeline'
import { installGlobalUndo } from '../state/undo-wire'
/* [LW-SPARE-MOVE-DOORS] (28 Sep 26): `moveAbsenceById` (the day's list's old date-box move) is RETIRED — the day's list
   moves one record through the one door, `moveRecords` (D266). These tests keep what they pinned by moving that one leave,
   by its id, through that door: null when it moved, else the refusal's reason. */
const leaveGap = (a: string, b: string) => Math.round((Date.UTC(+b.slice(0, 4), +b.slice(5, 7) - 1, +b.slice(8, 10)) - Date.UTC(+a.slice(0, 4), +a.slice(5, 7) - 1, +a.slice(8, 10))) / 86400000)
const moveLeaveVia = (pid: string, date: string, iid: string, to: string): string | null => { const r = moveRecords([{ personId: pid, date, id: iid, kind: 'absence' }], leaveGap(date, to)); return r === 'moved' ? null : r.reason }


const ISNAP = JSON.stringify(INPUTS)
const toast = HOOKS.toast
let said: string[] = []

beforeEach(() => {
  INPUTS.length = 0
  JSON.parse(ISNAP).forEach((r: any) => INPUTS.push(r))
  stashClear()
  setSession({ user: 'ad', role: 'admin' })
  raptorInitStore()
  lwInitStore(memoryBackend())
  setPeople(projectPeople())
  wireLeaveWarSync()
  _resetTimeline(); lwHistInit(); installGlobalUndo()
  said = []
  HOOKS.toast = (m: any) => { said.push(String(m)) }
})
afterEach(() => { HOOKS.toast = toast; _resetTimeline(); stashClear(); setSession(null); setMe('bane') })

let n = 0
function file(person: string, type: string, date: string, extra: Record<string, any> = {}): boolean {
  const row: any = { iid: `rf${++n}`, person, type, date, yr: 2026, allday: true, remarks: '', mod: '2026-02-01', ...extra }
  if (row.allday === false) delete row.allday
  return writeInputs(() => { INPUTS.unshift(row) })
}
const recsAt = (p: string, d: string) => rawState().wars[0]!.recs[p]?.[d] ?? []
const lwRows = (p: string) => INPUTS.filter((r: any) => r.person === p && r.lw)

describe('Fable #1 / Codex AS4-001 — the war repaints after every absence change', () => {
  it('an Inputs-page filing bumps the war with no manual sync', () => {
    const v = getVersion()
    expect(file('ammo', 'LL', 'Feb 10')).toBe(true)
    expect(getVersion()).toBeGreaterThan(v)
    expect(getState().grid.ammo?.['2026-02-10']).toBe('LL')
  })

  it('deleting approved leave from the tap list bumps the war', () => {
    setRole('admin'); setCell('ammo', '2026-02-10', 'LL'); advanceStage()
    setBidState('ammo', '2026-02-10', 'approved')
    const iid = String(lwRows('ammo')[0].iid)
    const v = getVersion()
    expect(changeAbsenceById('ammo', '2026-02-10', iid, 'removed')).toBeNull()
    expect(getVersion()).toBeGreaterThan(v)
    expect(getState().grid.ammo?.['2026-02-10']).toBeUndefined()
  })
})

describe('Fable #2 — a credit worked in two stretches is ONE credit', () => {
  const credit = { id: 'c1', kind: 'credit' as const, code: 'FO' as const, oil: 'auto' as const, spans: [[480, 630], [840, 960]] as Array<[number, number]> }
  it('earns once, carries no +1, lists once', () => {
    const v = dayView(recContribs([credit]))
    expect(v.earnsOil).toBe(1)
    expect(v.mark).toBe('')
    expect(v.all).toHaveLength(1)
  })
  it('leave in the gap between the stretches is no clash; leave over a stretch is', () => {
    const gap: Contrib = { id: 'l1', kind: 'absence', code: 'LL', win: [631, 839] }
    const over: Contrib = { id: 'l2', kind: 'absence', code: 'LL', win: PM }
    expect(dayView([...recContribs([credit]), gap]).amber).toBe(false)
    expect(dayView([...recContribs([credit]), over]).amber).toBe(true)
  })
})

describe('Fable #3 — a locked week refuses the tap-list change with words, not a crash', () => {
  it('changeAbsenceById on a locked week returns a reason and changes nothing', () => {
    setRole('admin'); setCell('ammo', '2026-02-10', 'LL'); advanceStage()
    setBidState('ammo', '2026-02-10', 'approved')
    const iid = String(lwRows('ammo')[0].iid)
    stashPut('09/02/2026', 'null')          // the week of 9 Feb becomes a locked week
    const before = JSON.stringify(INPUTS)
    const r = changeAbsenceById('ammo', '2026-02-10', iid, 'removed')
    expect(typeof r).toBe('string')
    expect(JSON.stringify(INPUTS)).toBe(before)
  })
})

describe('Fable #4 / Codex AS4-005 — a morning medical over a timed leave across noon keeps its afternoon', () => {
  it('LL 09:00–15:00 + ATT C morning → LL 12:01–15:00', () => {
    expect(file('rocky', 'LL', 'Jul 14', { allday: false, s: 540, e: 900 })).toBe(true)
    expect(file('rocky', 'ATT C', 'Jul 14', { allday: false, half: 'am', s: 0, e: 720 })).toBe(true)
    const ll = INPUTS.filter((r: any) => r.person === 'rocky' && r.type === 'LL')
    expect(ll).toHaveLength(1)
    expect(ll[0].s).toBe(721)
    expect(ll[0].e).toBe(900)
  })
})

describe('Opus scenario — overnight leave and back-to-back leave', () => {
  it('a next-morning medical cuts the tail of an overnight leave instead of being refused', () => {
    expect(file('ammo', 'LL', 'Aug 5', { allday: false, s: 22 * 60, e: 2 * 60 })).toBe(true)
    expect(file('ammo', 'ATT C', 'Aug 6', { allday: false, half: 'am', s: 0, e: 720 })).toBe(true)
    const ll = INPUTS.filter((r: any) => r.person === 'ammo' && r.type === 'LL')
    expect(ll).toHaveLength(1)
    expect(ll[0].s).toBe(22 * 60)
    expect(ll[0].e).toBe(1439)
  })
  it('LL 08:00–10:00 then OL 10:00–11:00 sit back to back — allowed', () => {
    expect(file('ammo', 'LL', 'Feb 10', { allday: false, s: 480, e: 600 })).toBe(true)
    expect(file('ammo', 'OL', 'Feb 10', { allday: false, s: 600, e: 660 })).toBe(true)
  })
})

describe('Codex AS4-002 — un-approving never overwrites a stored request', () => {
  it('a refused request on that time blocks "back to bid" and "refuse", naming it', () => {
    setRole('admin'); setCell('ammo', '2026-02-10', 'LL'); advanceStage()
    setBidState('ammo', '2026-02-10', 'approved')
    const iid = String(lwRows('ammo')[0].iid)
    lwEditLists([{ personId: 'ammo', date: '2026-02-10', drop: [], add: [{ id: 'old-ref', kind: 'request', code: 'OIL', state: 'refused' } as any] }])
    for (const to of ['pending', 'refused'] as const) {
      const r = changeAbsenceById('ammo', '2026-02-10', iid, to)
      expect(r).toMatch(/OIL request on 10 Feb 26/)   // day-first ([LW-ISO-DATES])
      expect(recsAt('ammo', '2026-02-10').find(x => x.id === 'old-ref')).toBeTruthy()
      expect(lwRows('ammo')).toHaveLength(1)
    }
  })
})

describe('Codex AS4-003 / AS4-004 — notices', () => {
  it('two commands in the same millisecond make two groups; OK-seen on one keeps the other', () => {
    setRole('admin'); setCell('ammo', '2026-02-10', 'LL'); setCell('ammo', '2026-02-11', 'LL')
    const now = Date.now
    Date.now = () => 1_790_000_000_000
    try {
      expect(file('ammo', 'ATT C', 'Feb 10')).toBe(true)
      expect(file('ammo', 'ATT C', 'Feb 11')).toBe(true)
    } finally { Date.now = now }
    const a = recsAt('ammo', '2026-02-10').find(r => r.kind === 'notice') as any
    const b = recsAt('ammo', '2026-02-11').find(r => r.kind === 'notice') as any
    expect(a.seq).not.toBe(b.seq)
  })

  /* REPLACED 26 Sep 26 ([ACCOUNTS], D166 (3)/(5); Fable R1-6): the admin's "view as member"
     toggle this pinned is gone. Whose bid it was is now decided by the SIGNED-IN PERSON,
     whatever the role: an admin filing over his OWN bid gets "your … bid" and no notice;
     over someone else's, a notice naming him by callsign. */
  it('an admin filing over his OWN bid leaves no notice; over another\'s, a notice naming him', () => {
    setRole('admin'); setCell('ammo', '2026-02-10', 'LL'); setCell('pain', '2026-02-11', 'LL')
    setMe('ammo')
    expect(file('ammo', 'ATT C', 'Feb 10')).toBe(true)
    expect(recsAt('ammo', '2026-02-10').find(r => r.kind === 'notice')).toBeUndefined()
    expect(file('pain', 'ATT C', 'Feb 11')).toBe(true)
    expect(recsAt('pain', '2026-02-11').find(r => r.kind === 'notice')).toMatchObject({ byWho: PEOPLE.ammo.cs })
  })
})

describe('Codex AS4-006 — the tap list moves ONE leave off a busy day', () => {
  it('moves exactly the chosen Input, keeps the other, and marks the move once bidding is closed', () => {
    setRole('admin')
    setCell('ammo', '2026-02-10', '*LL'); setCell('ammo', '2026-02-10', 'OIL*')
    advanceStage()
    // approve each request on its own (the tap list's per-record decision)
    for (const r of recsAt('ammo', '2026-02-10').filter(x => x.kind === 'request')) {
      expect(decideRequestById('ammo', '2026-02-10', r.id, 'approved')).toBe(true)
    }
    const rows = lwRows('ammo')
    expect(rows.length).toBe(2)
    const am = rows.find((r: any) => r.half === 'am')
    expect(moveLeaveVia('ammo', '2026-02-10', String(am.iid), '2026-02-12')).toBeNull()
    const after = lwRows('ammo')
    expect(after.find((r: any) => r.half === 'am')!.date).toBe('Feb 12')
    expect(after.find((r: any) => r.half === 'pm')!.date).toBe('Feb 10')
    expect(getState().views.ammo['2026-02-12']!.main!.movedFrom).toBe('2026-02-10')
  })
})

describe('Codex round 2 — the per-record doors', () => {
  function approved(p: string, d: string): string {
    setRole('admin'); setCell(p, d, 'LL'); advanceStage()
    setBidState(p, d, 'approved')
    return String(lwRows(p)[0].iid)
  }

  it('AS4-R2-001: moving leave off a locked week is refused, and the war still shows it where it is', () => {
    const iid = approved('ammo', '2026-02-10')
    stashPut('09/02/2026', 'null')
    const r = moveLeaveVia('ammo', '2026-02-10', iid, '2026-02-17')
    expect(typeof r).toBe('string')
    expect(lwRows('ammo')[0].date).toBe('Feb 10')
    expect(getState().grid.ammo?.['2026-02-10']).toBe('LL')
    expect(getState().grid.ammo?.['2026-02-17']).toBeUndefined()
  })

  it('AS4-R2-002: an Input id sent with the wrong person or date moves nothing', () => {
    const iid = approved('ammo', '2026-02-10')
    const before = JSON.stringify(INPUTS)
    expect(typeof moveLeaveVia('rocky', '2026-02-10', iid, '2026-02-12')).toBe('string')
    expect(typeof moveLeaveVia('ammo', '2026-02-11', iid, '2026-02-12')).toBe('string')
    expect(JSON.stringify(INPUTS)).toBe(before)
  })

  it('AS4-R2-003: a war-approved row retyped to a medical is not moved, un-approved or deleted from the war', () => {
    const iid = approved('ammo', '2026-02-10')
    const row = INPUTS.find((r: any) => r.iid === iid)
    writeInputs(() => { row.type = 'ATT C' })    // an admin retyped it; lw stays
    expect(row.lw).toBeTruthy()
    const before = JSON.stringify(INPUTS)
    expect(typeof moveLeaveVia('ammo', '2026-02-10', iid, '2026-02-12')).toBe('string')
    expect(typeof changeAbsenceById('ammo', '2026-02-10', iid, 'pending')).toBe('string')
    expect(typeof changeAbsenceById('ammo', '2026-02-10', iid, 'removed')).toBe('string')
    expect(JSON.stringify(INPUTS)).toBe(before)
  })
})

void FULL
