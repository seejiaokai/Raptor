// The store. A war keeps only its OWN records (requests, OIL credits,
// replaced-bid notices — engine/warrecs.ts); approved and filed absences are
// Raptor Inputs, READ through the merge (state/merge.ts) and changed only
// through the absence door ([ARCH-STACK] step 4). `setCell` is the only path
// that writes a request; every write is saved (one row per record, from the
// command it runs in — state/rows.ts), bumps the version and notifies. A write
// that skips these is invisible and unsaved.

import {
  addDays,
  assignGroup,
  biddingClosed,
  canDecide,
  canEditCell,
  canEditRow,
  DEFAULT_GROUPS,
  offerableGroups,
  orderedGroupIds,
  pruneGroups,
  readGroupDefs,
  SANS_GROUP,
  SANS_GROUP_ID,
  type GroupDef,
  inSquadron,
  isBiddable,
  isDuty,
  isMedical,
  windowFits,
  canReopen,
  nextStage,
  previousStage,
  COUNTERS,
  DEFAULT_FIGURE_ORDER,
  orderedFigures,
  type Figure,
  makeWar,
  overlapping,
  seedLedger,
  seedOpenings,
  seedEventDefs,
  seedPeople,
  seedPeriod,
  seedRequirements,
  seedWars,
  MAX_TEAM_SLOTS,
  MAX_MANNING_RULES,
  SEED_QUAL_CATALOG,
  type CrewFilter,
  type ManningRule,
  type QualDef,
  type RuleCount,
  type TeamSlot,
  autoOrder,
  seatRank,
  groupOf,
  GROUP_ORDER,
  orderedPeople,
  readEventDefs,
  DEFAULT_OIL_POLICY,
  readOilPolicy,
  type OilPolicy,
  type FigureCtx,
  balanceOf,
  codeOf as leaveCodeOf,
  oilLedgerOf,
  withFill,
  grantedTo,
  drawnFrom,
  localToday,
  bandOverlaps,
  warHolding,
  STAGE_ORDER,
  pickDefaultPeriodId,
  defaultFocusDate,
  type BidState,
  type CounterName,
  type DayInfo,
  type EventBand,
  type EventDef,
  type EventKind,
  EVENT_KINDS,
  addEventDef,
  updateEventDef,
  removeEventDef,
  type Grid,
  type LeaveWar,
  type Recs,
  type WarRec,
  type RequestRec,
  type CreditRec,
  type NoticeRec,
  type RequestState,
  type Contrib,
  readRecs,
  readRec,
  listProblem,
  isRetiredAward,
  recsAt,
  withList,
  recContribs,
  newRecId,
  isCredit,
  isOilAward,
  liveRequestsOn,
  portionOfCode,
  requestWin,
  barsWrite,
  forbiddenPair,
  isSickCode,
  isLeaveCode,
  parseCell,
  FULL,
  winsOf,
  MAX_GIVEN_BY,
  MAX_GRANT_DAYS,
  MAX_REC_NOTE,
  type Ledger,
  type LedgerEntry,
  type Openings,
  type Period,
  type Person,
  type Stint,
  type PostOutcome,
  POST_OUTCOMES,
  outcomeOf,
  type Requirements,
  type Role,
  type Threshold,
  type Stage,
  type States,
} from '../engine'
import { mergeWar, absencesAt, absenceVersion, awardsAt, awardRows, awardVersion, setAwardRows, type AwardRows, type MergedWar, type RecordSpans, type Views } from './merge'
import { counterLabel } from '../engine/counters'
import { creditWorth } from '../engine/credit'
import { localBackend, memoryBackend, type StorageBackend } from './storage'
/* [DB-READINESS] group A, phase 3 — the war saved one row per record (state/rows.ts), each list's order on its records
   (command/ord.ts), and the one-time fold of an old store's whole-list records (storage/fold.ts) */
import { lwRows, allRows, WAR, REC, LEDGER, OPENING, PROFILE, parseRecKey, parseOpeningKey, type LwNow } from './rows'
import { mintOrd, byOrd } from '../../command/ord'
import { registerConverter, type Converter } from '../../storage/fold'
import type { Entry } from '../../storage/backend'
/* [ARCH-STACK] Step 2 phase 4 — the shared command layer (see the persist()
   router below). Imported here so a Leave War user edit joins the SAME change
   stream + auth gate every module funnels through. */
import {
  commit as cmdCommit, isCommitting as cmdIsCommitting, deferEffect as cmdDeferEffect,
  definePermission as cmdDefinePermission, anyone as cmdAnyone, registerRecord as cmdRegisterRecord,
  commitProjection as cmdCommitProjection, isInReducer as cmdIsInReducer,
  registerGuardedStore as cmdRegisterGuardedStore, registerEffectContext as cmdRegisterEffectContext,
  isQueued, isOk, onCommit as cmdOnCommit,
} from '../../command'
import type { EnlistableStore as CmdEnlistableStore, RecordEntry as CmdRecordEntry, Scope as CmdScope } from '../../command'

interface State {
  people: Person[]
  /** The manning rules ARE data now (owner, 19 Aug 26 — "instead of hard
   *  coding these permutations, make it editable… and these counters can
   *  also be deleted"): `requirements.default.rules` is the squadron's own
   *  set, persisted WHOLE under `manningdefs` and edited through
   *  `saveManningRule` / `deleteManningRule` / the threshold setters, all
   *  ADMIN-gated. The old numbers-only overlay (`manningthresh`) is still
   *  READ at boot so a squadron's tuned amber/red lines survive the upgrade,
   *  but never written again. This deliberately departs from the
   *  stores-list rule about code-owned definitions: the owner asked for the
   *  definitions themselves, and forward-compat lives in `readManningRules`
   *  dropping any stored rule a later build cannot understand (the seed
   *  fills the gap). */
  requirements: Requirements
  /** The qualification chips the counter form offers — Raptor's live Quals
   *  catalogue, installed by the projection (`setQualCatalog`) exactly like
   *  the roster; never persisted, and the seed's three keys stand in when
   *  the app runs standalone. */
  qualCatalog: QualDef[]
  /** The squadron's EVENT TYPES — the small library that gives a day-event
   *  word its off/no-leave/work meaning (engine/eventdefs.ts). Squadron-wide,
   *  not per-war, and persisted under its own `eventdefs` key. */
  eventDefs: EventDef[]
  /** Every leave war, in the order they were created. Never empty. */
  wars: LeaveWar[]
  /** Which one is on screen. */
  currentId: string

  // ---- derived from `wars` + `currentId`, never assigned directly ----
  // The current war's period, republished at the top level by `withCurrent()`
  // on every change. (Its grid/states/views are the MERGED read's —
  // `getState()` adds them; the raw state never holds them.)
  period: Period
  /** Where each counter started. A balance is this plus the ledger less what
   *  the grid has drawn — never a stored figure, which would be a second
   *  version of a truth the grid already holds. */
  openings: Openings
  ledger: Ledger
  /** The OIL TRACKER's policy (owner, 2 Sep 26): how long a credit lasts
   *  before it expires (or forever) and the history window the tracker opens
   *  on. Squadron-wide, ADMIN-gated, persisted under `oilpolicy`. Read by
   *  every OIL BAL figure through `figureCtxOf`, so a change here re-reads
   *  every balance at once (engine/oiltracker.ts). */
  oilPolicy: OilPolicy
  /** Who the person at the keyboard says they are. Nothing verifies it —
   *  there is no login — so this decides which controls appear, not who is
   *  allowed to use them. See `docs/known-gaps.md`. */
  role: Role
  /** WHICH PERSON is looking at the page — Raptor's "View as" identity,
   *  mirrored here so the matrix can light their row and the counter picker
   *  can answer with THEIR numbers (owner, 17 Aug 26). Like the role it is
   *  neither read nor persisted: Raptor's `setMe` is the one production
   *  writer (plus the boot in main.tsx), so a stored copy could only ever
   *  disagree with the person actually selected. May name someone this
   *  roster does not hold; consumers check membership. */
  viewer: string | null

  /** The counter column's figure order — the ids of `FIGURES`, in the order
   *  the picker lists them and the column cycles them. Persisted (under
   *  `figorder`) and — since the owner's word, 17 Aug 26 ("normal user
   *  should not have authority to change the leave war column arrangement")
   *  — ADMIN-gated at the write path, while the counter *selection* stays
   *  ungated view state. Read leniently: unknown or missing ids are healed
   *  by `orderedFigures`, never rejected. */
  figureOrder: string[]

  /** The roster's row order — person ids, in the order the matrix draws them
   *  (owner, 18 Aug 26). Empty means "categorised": the matrix falls back to
   *  `autoOrder`. The Auto-sort button writes the grouped order; an edit-mode
   *  drag writes a hand-chosen one. ADMIN-gated at the write path, the same
   *  rule as `figureOrder` — a member does not rearrange the roster. Read
   *  leniently: `orderedPeople` drops ids that have left and appends anyone
   *  the saved order predates. */
  rosterOrder: string[]
  /** An admin's free-text labels for ground-crew rows, keyed by person id —
   *  an override of the projected default (Raptor's `flight`). Ground-crew
   *  only; an aircrew id here is simply never read. */
  persLabels: Record<string, string>

  /** The manning COUNT rows' display order (owner, 18 Aug 26) — rule ids
   *  (`'sets'` plus each requirement rule's id), in the order the matrix draws
   *  them. Empty means the natural order the rules appear in. ADMIN-gated, the
   *  same rule as `figureOrder`/`rosterOrder`. Read leniently: unknown ids are
   *  dropped and any not named are appended in natural order. */
  manningOrder: string[]
  /** The manning count rows an admin has hidden (rule ids). A member never sees
   *  a hidden row at all; an admin sees it dimmed in Rearrange mode, so it can
   *  be brought back. ADMIN-gated at the write path. */
  manningHidden: string[]
  /** The figures an admin has hidden from the column's cycle and the drawer
   *  (owner, 6 Sep 26 — "admin should also be able to customise"). Persisted
   *  under `fighidden`, ADMIN-gated at the write path like `figureOrder`; read
   *  leniently (unknown ids are ignored by `visibleFigures`). At least one
   *  figure always stays visible — the column cannot show nothing. */
  figureHidden: string[]
  /** WHICH GROUPS the roster is drawn in, top to bottom (owner, 28 Aug 26 —
   *  the admin group editor). The seven built-ins by default; an admin may add
   *  a group per QUALIFICATION and drag the order. ADMIN-gated, same rule as
   *  `manningOrder`. Read leniently and pruned against the live qual catalogue,
   *  so a group pinned to a deleted Quals column cannot strand an empty
   *  heading. */
  groupDefs: GroupDef[]
  /** WHO CLAIMS someone matching several groups — a person shows exactly once,
   *  and this decides where. By DEFAULT it FOLLOWS the display order (owner,
   *  3 Sep 26 — "the priority order should also change by default in accordance
   *  with the category order"): the group higher on the page wins a tie, so
   *  dragging the page around reorders who-wins with it. Only meaningful once
   *  `groupPriorityCustom` is set — until then this list is ignored and the
   *  display order is used. */
  groupPriority: string[]
  /** Whether the admin has set a CUSTOM who-wins order, breaking the "follows the
   *  display order" default (owner, 3 Sep 26 — "only if the user is not satisfied
   *  then they change the priority order in the settings"). Set the first time the
   *  who-wins list is dragged; cleared by "Match the page order" and by
   *  `resetGroups`. Persisted (`grouppriocustom`), admin-gated like the orders. */
  groupPriorityCustom: boolean
  /** The COLOUR the admin picked for a qualification group (owner, 3 Sep 26 —
   *  "allow me to pick the colour i want"), by group id, `#rrggbb`. Only `q:`
   *  groups take one (the built-ins wear their CAT colours); a group with no
   *  entry falls back to a palette colour derived from its id (ui/groupColor.ts).
   *  Persisted (`groupcolors`), admin-gated, dropped with the group. */
  groupColors: Record<string, string>

  /** How many EVENT rows the matrix draws (owner, 18 Aug 26 — "add more event
   *  rows if needed"). Two by default; an admin can add up to `MAX_EVENT_ROWS`.
   *  Squadron-wide config (persisted `eventrows`), admin-gated. A day's
   *  `events` array grows on demand as rows are written; a row past a day's
   *  stored length reads '' (`dayEvent`). */
  eventRows: number

  /** Whether SANS aircrew ride the Leave War roster (owner, 18 Aug 26 — "we
   *  will not show the SANS in the leave war however there is a function to
   *  still enable this"). OFF by default: SANS offer availability rather than
   *  being planned as squadron manning, so they neither clutter the grid nor
   *  count in its manning rows. The switch is squadron-wide config (persisted
   *  `showsans`), ADMIN-gated at the write path like `eventRows`, and takes
   *  effect through the roster PROJECTION — sync.ts's reprojectRoster passes
   *  it to projectPeople on every notify, so flipping it re-projects at once. */
  showSans: boolean

  /** The day the matrix has been asked to bring into view, or null. */
  focusDate: string | null
  /** Bumped on every request, including a repeat of the same date. The matrix
   *  jumps on a change to THIS, not to `focusDate`: a year is 365 columns, so
   *  the grid is almost never still where it was left, and asking again for
   *  the day you are notionally already on must snap you back to it. A date
   *  alone cannot say "asked again". */
  focusSeq: number

  /* (The war's own seat / band / SXO overrides — `personEdits`, written by its
     "Edit person" sheet — are GONE: D460, D461, 30 Sep 26. Quals is the one
     place a man's seat, band and SXO change; the war shows what the projection
     says, and a stored `personedits` is never read.) */

  /** The SQUADRON WINDOWS an admin set by hand, keyed by person id, each
   *  holding the person AS LAST PROJECTED with the window on it. BOTH ends
   *  live here: the posting-OUT date (`setPostOut`, 18 Aug 26) and — since the
   *  owner's 20 Sep 26 ruling "we need a post in button just like post out" —
   *  the posting-IN date (`setPostIn`). One record for both, because they are
   *  one fact (the person's official time in the squadron) and because the
   *  restore, merge and keep rules below then cannot drift apart. Records
   *  written before the post-in half existed carry `from: null`, which is
   *  exactly what the projection gives, so nothing needs migrating. Persisted (8 Sep 26 bug pass — a PO date vanished on reload): on
   *  every `setPeople` the window is laid back onto the projected person, and
   *  someone the projection no longer has (archived once the date arrived) is
   *  put back from the frozen copy, so the months before they left keep
   *  showing their history — `reprojectRoster`'s keep rule, now surviving a
   *  reboot. An entry exists while EITHER end is set; clearing the last one
   *  removes it. The demo overlay's own `to` (no `poArchive`) is not one of
   *  these and still lasts a session. */
  postOuts: Record<string, Person>
}

/** What every screen reads: the raw state with each war MERGED — its own
 *  records together with the absences derived from the Inputs — and the
 *  current war's projections republished at the top level (design §4.2). */
export interface MergedState extends Omit<State, 'wars'> {
  wars: MergedWar[]
  grid: Grid
  states: States
  views: Views
  /** The months the CURRENT war shows something on, per person — what
   *  stretches a row past the person's official squadron dates so leave dated
   *  outside them can still be seen (merge.ts `RecordSpans`). */
  spans: RecordSpans
}

/** The event-row count and its bounds (owner, 18 Aug 26). Two rows is the
 *  historic default; six is a soft cap so the header block cannot be grown
 *  without limit. */
export const DEFAULT_EVENT_ROWS = 2
export const MAX_EVENT_ROWS = 6

let backend: StorageBackend = memoryBackend()
let state: State = blank()
let version = 0
const listeners = new Set<() => void>()

/** Republish the current war's parts at the top level. Every assignment to
 *  `state` goes through this, so the three derived fields cannot fall out of
 *  step with the war they came from. */
function withCurrent(s: Omit<State, 'period'>): State {
  // Falling back to the first war rather than throwing: a `currentId`
  // naming a war that no longer exists is recoverable, and a blank screen
  // is not.
  // A store can hold NO war since [DB-READINESS] group A, phase 5: a shared store starts with none until an admin
  // creates the first (the page then shows its empty state — LeaveWarPage.tsx), and a started store is read as it
  // stands. `period` is then NO_PERIOD: never stored, no days, a draft — every reader of the current period finds
  // nothing inside it, and no screen shows it.
  const war = s.wars.find(w => w.period.id === s.currentId) ?? s.wars[0]
  return { ...s, period: war ? war.period : NO_PERIOD }
}
/** the current period of a store holding no war (above): code, never data — no id, no days, nothing open */
export const NO_PERIOD: Period = Object.freeze({ id: '', name: '', start: '', end: '', stage: 'draft', bidFrom: null, bidTo: null, days: [], bands: [] }) as unknown as Period

function blank(): State {
  const wars = seedWars()
  return withCurrent({
    people: seedPeople(),
    requirements: seedRequirements(),
    qualCatalog: [...SEED_QUAL_CATALOG],
    eventDefs: seedEventDefs(),
    wars,
    // Open on the war that is OPEN for bidding — else closed, else published,
    // else draft (owner, 7 Sep 26). `pickDefaultPeriodId` is total but returns
    // '' on an empty list, which cannot happen here; the `||` is belt-and-braces
    // so a future change to `seedWars` can never blank the screen.
    currentId: pickDefaultPeriodId(wars.map(w => w.period)) || wars[0].period.id,
    openings: seedOpenings(),
    ledger: seedLedger(),
    oilPolicy: { ...DEFAULT_OIL_POLICY },
    figureOrder: [...DEFAULT_FIGURE_ORDER],
    rosterOrder: [],
    persLabels: {},
    manningOrder: [],
    manningHidden: [],
    figureHidden: [],
    groupDefs: [...DEFAULT_GROUPS],
    groupPriority: [],
    groupPriorityCustom: false,
    groupColors: {},
    eventRows: DEFAULT_EVENT_ROWS,
    showSans: false,
    // The squadron is the common case, so the app opens as one. An admin
    // says so deliberately rather than arriving with the locks already off.
    role: 'member',
    viewer: null,
    focusDate: null,
    focusSeq: 0,
    postOuts: {},
  })
}

function isPlainObject(x: unknown): x is Record<string, unknown> {
  return !!x && typeof x === 'object' && !Array.isArray(x)
}

const COUNTER_NAMES = new Set<string>(COUNTERS)

// Openings are `personId -> counter -> number`. A non-finite figure is the
// dangerous shape here rather than merely a wrong one: NaN propagates
// silently through every sum it touches, so a single bad leaf would turn a
// whole column of balances into "NaN" with nothing to say why.
//
// (`readPeople` stood here until the sync wires: a stored roster is no
// longer read at all — see initStore — so its validator went with it.)

function readOpenings(x: unknown): Openings | null {
  if (!isPlainObject(x)) return null
  const out: Openings = {}
  for (const [id, row] of Object.entries(x)) {
    if (!isPlainObject(row)) return null
    const kept: Partial<Record<CounterName, number>> = {}
    for (const [counter, amount] of Object.entries(row)) {
      if (!COUNTER_NAMES.has(counter)) return null
      if (typeof amount !== 'number' || !Number.isFinite(amount)) return null
      kept[counter as CounterName] = amount
    }
    out[id] = kept
  }
  return out
}

function readLedger(x: unknown): Ledger | null {
  if (!Array.isArray(x)) return null
  const out: Ledger = []
  for (const e of x) {
    if (!isPlainObject(e)) return null
    const { id, personId, counter, amount, date, reason, approvedBy, givenBy } = e
    if (typeof id !== 'string' || typeof personId !== 'string') return null
    if (typeof counter !== 'string' || !COUNTER_NAMES.has(counter)) return null
    if (typeof amount !== 'number' || !Number.isFinite(amount)) return null
    if (typeof date !== 'string') return null
    // A grant with no reason and no approver is the untraceable free text
    // the ledger exists to replace, so it is not a grant. (A blank reason
    // is a plain-pool credit from the grid since 6 Sep 26 — `reasonRequired`
    // gates that at the write path, not here, so this reader is unchanged.)
    if (typeof reason !== 'string' || typeof approvedBy !== 'string') return null
    const entry: LedgerEntry = { id, personId, counter: counter as CounterName, amount, date, reason, approvedBy }
    // `givenBy` is optional decoration (2 Sep 26); a bad one is dropped.
    if (typeof givenBy === 'string' && givenBy.trim()) entry.givenBy = givenBy.trim().slice(0, MAX_GIVEN_BY)
    /* WHO ENTERED IT AND WHEN (owner, D200 (2)) survive a reload — a person id kept as given, and a date-time that
       parses; a bad one is dropped with the entry kept, as `givenBy` is (Fable's plan read F4, 29 Sep 26) */
    const { enteredBy, enteredAt } = e as { enteredBy?: unknown; enteredAt?: unknown }
    if (typeof enteredBy === 'string' && enteredBy) entry.enteredBy = enteredBy
    if (typeof enteredAt === 'string' && !Number.isNaN(Date.parse(enteredAt))) entry.enteredAt = enteredAt
    out.push(entry)
  }
  return out
}

// The figure order is just a list of ids. Validated only as "an array of
// strings" and no more: `orderedFigures` already heals an unknown id (skip) or
// a missing one (append), so tightening it to "known ids only" here would buy
// nothing and would reject a blob written by a build that had a figure this
// one has since renamed. A non-array or a non-string leaf IS rejected — that
// is corruption, and the caller falls back to the default order.
function readFigureOrder(x: unknown): string[] | null {
  if (!Array.isArray(x)) return null
  if (x.some(id => typeof id !== 'string')) return null
  return x as string[]
}

/** A stored id list (the roster order), same shape as the figure order. */
const readIdList = readFigureOrder

/** The stored amber/red overlay of the PRE-definitions build, read at boot
 *  only so an upgraded browser keeps its tuned lines (they migrate into the
 *  rules themselves and persist under `manningdefs` from then on). One bad
 *  entry is dropped rather than rejecting the whole blob (the label-map
 *  rule); an id no rule carries any more is harmless — `requirementsWith`
 *  only reads ids the seed still has. */
function readThreshMap(x: unknown): Record<string, Threshold> | null {
  if (!isPlainObject(x)) return null
  const out: Record<string, Threshold> = {}
  for (const [id, t] of Object.entries(x)) {
    if (!isPlainObject(t)) continue
    const { amber, red } = t as { amber?: unknown; red?: unknown }
    if (typeof amber !== 'number' || !Number.isFinite(amber) || amber < 0) continue
    if (typeof red !== 'number' || !Number.isFinite(red) || red < 0) continue
    out[id] = { amber, red }
  }
  return out
}

/** The seeded requirements with a legacy amber/red overlay laid on top — the
 *  migration path for a browser that customised its lines before the rules
 *  became data. The old overlay knew `sets` as its own key; it is an ordinary
 *  rule now, so the same map read covers it. */
function requirementsWith(overlay: Record<string, Threshold>): Requirements {
  const req = seedRequirements()
  req.default.rules = req.default.rules.map(r =>
    overlay[r.id] ? { ...r, threshold: { ...overlay[r.id] } } : r,
  )
  return req
}

// ---- The stored manning rules (owner, 19 Aug 26) ---------------------------
//
// Read with the label-map tolerance: one rule a later build cannot understand
// is dropped, the rest survive. A stored empty LIST is honoured (the admin
// deleted every counter — a decision, not damage); a non-empty list where
// nothing survived is corruption and falls back to the seed rather than to a
// blank manning block.

const isShortString = (x: unknown): x is string => typeof x === 'string' && x.length > 0 && x.length <= 80

function readStringList(x: unknown): string[] | null {
  if (!Array.isArray(x) || x.length > 24) return null
  return x.every(isShortString) ? [...x] : null
}

function readFilter(x: unknown): CrewFilter | null {
  if (!isPlainObject(x)) return null
  const out: CrewFilter = {}
  const lists: [keyof CrewFilter, unknown][] = [
    ['seats', x.seats], ['cats', x.cats], ['notCats', x.notCats], ['quals', x.quals], ['notQuals', x.notQuals],
  ]
  for (const [key, v] of lists) {
    if (v === undefined) continue
    const list = readStringList(v)
    if (!list) return null
    if (key === 'seats' && !list.every(s => s === 'pilot' || s === 'wso')) return null
    if (list.length) (out as Record<string, unknown>)[key] = list
  }
  return out
}

function readThreshold(x: unknown): Threshold | null {
  if (!isPlainObject(x)) return null
  const { amber, red } = x as { amber?: unknown; red?: unknown }
  if (typeof amber !== 'number' || !Number.isFinite(amber) || amber < 0) return null
  if (typeof red !== 'number' || !Number.isFinite(red) || red < 0) return null
  return { amber, red }
}

function readRuleCount(x: unknown): RuleCount | null {
  if (!isPlainObject(x)) return null
  if (x.kind === 'people') {
    const filter = readFilter(x.filter)
    return filter ? { kind: 'people', filter } : null
  }
  if (x.kind !== 'team' || !Array.isArray(x.slots)) return null
  if (x.slots.length < 1 || x.slots.length > MAX_TEAM_SLOTS) return null
  const slots: TeamSlot[] = []
  for (const s of x.slots) {
    if (!isPlainObject(s)) return null
    const { count } = s as { count?: unknown }
    if (typeof count !== 'number' || !Number.isInteger(count) || count < 1 || count > 9) return null
    const filter = readFilter(s.filter)
    if (!filter) return null
    slots.push({ count, filter })
  }
  const out: RuleCount = { kind: 'team', slots }
  if (x.show === 'people') out.show = 'people'
  if (x.presence === true) out.presence = true
  return out
}

/** One rule, or `null` when it is not usable. Shared by the storage read and
 *  the write path (`saveManningRule`), so nothing malformed can arrive by
 *  either door. */
function readManningRule(x: unknown): ManningRule | null {
  if (!isPlainObject(x)) return null
  if (!isShortString(x.id) || !isShortString(x.label)) return null
  const threshold = readThreshold(x.threshold)
  const count = readRuleCount(x.count)
  if (!threshold || !count) return null
  const out: ManningRule = { id: x.id, label: x.label, count, threshold }
  if (typeof x.desc === 'string' && x.desc.length <= 2000) out.desc = x.desc
  return out
}

function readManningRules(x: unknown): ManningRule[] | null {
  if (!Array.isArray(x) || x.length > MAX_MANNING_RULES) return null
  const out: ManningRule[] = []
  const seen = new Set<string>()
  for (const r of x) {
    const rule = readManningRule(r)
    if (!rule || seen.has(rule.id)) continue
    out.push(rule)
    seen.add(rule.id)
  }
  // A stored EMPTY list is a decision — the admin deleted every counter, and
  // a reload must not resurrect the seed. A non-empty list where every entry
  // was dropped is corruption, and falls back to the seed like any other
  // unreadable blob.
  return out.length || x.length === 0 ? out : null
}

/** A stored id→label map (personnel labels). Non-string values are dropped
 *  rather than rejecting the whole blob — one bad entry should not blank the
 *  admin's other labels. */
/* Untrusted storage for a posting-out entry (8 Sep 26): it must be keyed by its
   own id, name a callsign and carry a date it exists for. (The override record
   read beside it, `personedits`, is gone — D460, D461.) */
/* EITHER END MAKES A WINDOW WORTH KEEPING (22 Sep 26). This insisted on `to`
   being a string, which was right while a posting-OUT date was the only one
   there was. `setPostIn` (owner, 20 Sep 26 — "we need a post in button just like
   post out. Because those dates are official dates") writes the other end
   through the same `windowRecord`, and the WRITE was always correct: the record
   reached storage carrying `from` with `to` null. This reader then threw it
   away, so a man's official joining date was lost on every reload — the same
   failure, in the same record, as the demo overlay's posting-out window that
   `setPeople` now captures, and found the same way: by reading this file again
   after fixing that one.
   The guard is not loosened, only widened to the shape the writer produces: the
   id must still match its key, the callsign must still be a string, and at least
   one end must be a real date with the other a date or null. A record with
   neither end is not a window and is still dropped — `windowRecord` deletes it
   rather than storing it, so one could only arrive from a damaged file. */
/* A DATE HAS TO LOOK LIKE A DATE (the follow-up code read). The first version
   of this accepted any string, and a nonsense `from` is not inert: it is laid
   onto the live person, where `inSquadron` compares it LEXICALLY against real
   `yyyy-mm-dd` values. "June 15" sorts after every 2026 date, so the man reads
   as not yet arrived on every day of the year — out of availability, out of the
   manning counts, out of every crowd a placeholder stands for, silently.
   The same `^\d{4}-\d{2}-\d{2}$` shape `setPostOut`/`setPostIn` demand at the
   write, so the reader now asks for exactly what the writer promises. */
const isDay = (v: unknown): v is string => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)
const dateEnd = (v: unknown): boolean => v === null || isDay(v)
/* D320 ([ONE-DOOR], 27 Sep 26): his closed earlier stints, read as the writers promise them — each `{ from: day | null,
   to: day }` with `from <= to`, oldest first, each ending before the next begins, and the last ending before the
   current stint begins (whose start must then be a day). Anything else is dropped WHOLE (tolerant — D56: a stored list
   the writers never produce is demo data, never repaired by guessing), leaving the current stint as it is. */
function readPast(v: any): Stint[] | undefined {
  const raw = v.past
  if (!Array.isArray(raw) || !raw.length) return undefined
  const out: Stint[] = []
  for (const e of raw as unknown[]) {
    if (!isPlainObject(e)) return undefined
    const s = e as any
    if (!dateEnd(s.from) || !isDay(s.to)) return undefined
    if (s.from !== null && s.from > s.to) return undefined
    const prev = out[out.length - 1]
    if (prev && (s.from === null || s.from <= prev.to)) return undefined
    out.push({ from: s.from, to: s.to })
  }
  if (!isDay(v.from) || v.from <= out[out.length - 1].to) return undefined
  return out
}
function readPostOuts(x: unknown): Record<string, Person> | null {
  if (!isPlainObject(x)) return null
  const out: Record<string, Person> = {}
  for (const [id, v] of Object.entries(x)) {
    if (!isPlainObject(v) || v.id !== id || typeof v.callsign !== 'string') continue
    if (!dateEnd(v.from) || !dateEnd(v.to)) continue
    const past = readPast(v)
    if (!isDay(v.from) && !isDay(v.to) && !past) continue
    const rec: any = { ...v }
    if (past) rec.past = past; else delete rec.past
    out[id] = rec as Person
  }
  return out
}
function readLabelMap(x: unknown): Record<string, string> | null {
  if (!isPlainObject(x)) return null
  const out: Record<string, string> = {}
  for (const [k, v] of Object.entries(x)) if (typeof v === 'string') out[k] = v
  return out
}

/** The picked group colours: only `q:` ids, only `#rrggbb` values survive. */
function readColorMap(x: unknown): Record<string, string> | null {
  if (!isPlainObject(x)) return null
  const out: Record<string, string> = {}
  for (const [k, v] of Object.entries(x)) {
    if (k.startsWith('q:') && typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v)) out[k] = v
  }
  return out
}

// A stored war is its period plus its grid and states. `days` is stored in
// full rather than rebuilt from start/end, because a day carries events, a
// blocked flag and its reason — facts the range cannot regenerate and a
// scheduler would lose on every reload.
function readWar(x: unknown): LeaveWar | null {
  if (!isPlainObject(x)) return null
  const { period, recs } = x
  if (!isPlainObject(period)) return null
  const { id, name, start, end, stage, bidFrom, bidTo, days, bands } = period
  if (typeof id !== 'string' || typeof name !== 'string') return null
  if (typeof start !== 'string' || typeof end !== 'string' || end < start) return null
  if (typeof stage !== 'string' || !STAGE_ORDER.includes(stage as Stage)) return null
  if (!Array.isArray(days)) return null

  // The window is READ LENIENTLY, unlike everything else here, and the
  // asymmetry is deliberate. A war stored before the window existed has
  // neither key, and `undefined` there means "the whole period is open" —
  // which is exactly how that war behaved. Rejecting it would throw away a
  // squadron's grid over a field that did not exist when it was written.
  // A window that is present but not a string, or backwards, or outside the
  // period, IS rejected: that is corruption rather than an older shape.
  const from = bidFrom == null ? null : bidFrom
  const to = bidTo == null ? null : bidTo
  if (from !== null && typeof from !== 'string') return null
  if (to !== null && typeof to !== 'string') return null
  if (from !== null && (from < start || from > end)) return null
  if (to !== null && (to < start || to > end)) return null
  if (from !== null && to !== null && to < from) return null

  const readDays: DayInfo[] = []
  for (const d of days) {
    if (!isPlainObject(d)) return null
    const { date, events, eventKinds, blocked, blockedReason, ph } = d
    if (typeof date !== 'string') return null
    // At LEAST two event lines (the historic default), and any number beyond
    // that (an admin can add rows since 18 Aug 26). Every entry a string.
    if (!Array.isArray(events) || events.length < 2) return null
    if (events.some(e => typeof e !== 'string')) return null
    if (typeof blocked !== 'boolean' || typeof ph !== 'boolean') return null
    if (typeof blockedReason !== 'string') return null
    // Instance tags are READ LENIENTLY, like the window and the bands: absent
    // on every war stored before per-event tags (18 Aug 26) and that means
    // "untagged", which is exactly how those wars behaved. An entry that is
    // not a known kind reads as null rather than failing the day.
    const readKinds: (EventKind | null)[] = Array.isArray(eventKinds)
      ? eventKinds.map(k => (typeof k === 'string' && EVENT_KINDS.includes(k as EventKind) ? (k as EventKind) : null))
      : []
    readDays.push({ date, events: [...events], eventKinds: readKinds, blocked, blockedReason, ph })
  }

  // Bands are READ LENIENTLY, like the window above: a war stored before
  // merged events existed has no `bands` key, and `undefined` there means "no
  // merged labels", which is exactly how that war behaved. A key that is
  // present but not an array, or holds a malformed band, IS rejected — that is
  // corruption, not an older shape. A band whose dates fall outside the period,
  // are backwards, or sit on neither event line is dropped rather than failing
  // the whole war.
  const readBands: EventBand[] = []
  if (bands !== undefined) {
    if (!Array.isArray(bands)) return null
    for (const b of bands) {
      if (!isPlainObject(b)) return null
      const { line, from: bf, to: bt, text, kind } = b
      // Any row an admin can have (variable event rows, 18 Aug 26) — the old
      // `0 | 1` check silently dropped a band on an added row at reload.
      if (typeof line !== 'number' || !Number.isInteger(line) || line < 0 || line >= MAX_EVENT_ROWS) continue
      if (typeof bf !== 'string' || typeof bt !== 'string' || typeof text !== 'string') continue
      if (bt < bf || bf < start || bt > end) continue
      if (bandOverlaps(readBands, line, bf, bt)) continue
      // The band's instance tag, read as leniently as the days' (null when
      // absent or unrecognised).
      const bk = typeof kind === 'string' && EVENT_KINDS.includes(kind as EventKind) ? (kind as EventKind) : null
      readBands.push({ line, from: bf, to: bt, text, kind: bk })
    }
  }

  /* The war's own records ([ARCH-STACK] step 4). An old-shape war (a grid
     and states pair, a source on a record, a stored "approved") is NOT read
     half-way: the whole blob is rejected and the demo re-seeds — reset, don't
     migrate (design §2.2, §9; the schema bump clears it first anyway). */
  const readRecsOrNull = readRecs(recs)
  if (!readRecsOrNull) return null

  return {
    period: {
      id, name, start, end, stage: stage as Stage,
      bidFrom: from as string | null, bidTo: to as string | null,
      days: readDays,
      bands: readBands,
      /* its place among the wars ([DB-READINESS] group A, phase 3); a bad one is dropped and re-minted */
      ...(typeof (period as any).ord === 'number' && Number.isFinite((period as any).ord) ? { ord: (period as any).ord as number } : {}),
    },
    recs: readRecsOrNull,
  }
}

function readWars(x: unknown): LeaveWar[] | null {
  if (!Array.isArray(x) || x.length === 0) return null
  const out: LeaveWar[] = []
  for (const w of x) {
    const war = readWar(w)
    if (!war) return null
    out.push(war)
  }
  // Two wars claiming the same day is the one shape nothing downstream can
  // resolve — `warHolding` would answer with whichever came first and the
  // manning counts would double-count the man. Reject the whole blob.
  for (let i = 0; i < out.length; i++) {
    for (let j = i + 1; j < out.length; j++) {
      if (overlapping(out[i].period, out[j].period)) return null
    }
  }
  if (new Set(out.map(w => w.period.id)).size !== out.length) return null
  return out
}

/** What the backend holds under `key`, or `null` if there is nothing usable
 *  there. `null` covers both "never written" and "written but unreadable" —
 *  the caller's answer to each is the same, which is to fall back. */
function read<T>(key: string, valid: (x: unknown) => x is T): T | null {
  return readStored(key, x => (valid(x) ? x : null))
}

/** As `read`, but the reader may CONVERT rather than merely accept — which
 *  is what the states migration needs. Returning `null` from `parse` means
 *  the stored value is unusable and the caller should fall back. */
function readStored<T>(key: string, parse: (x: unknown) => T | null): T | null {
  const raw = backend.read(key)
  if (!raw) return null
  try {
    return parse(JSON.parse(raw))
  } catch {
    return null
  }
}

/* THE WAR'S ROWS, READ BACK — a started store ([DB-READINESS] group A, phase 3; state/rows.ts). Each row is read with
   the reader the old whole record was read with. A row that will not read — or a record naming a war no row holds, a
   second war claiming a day another already holds, a record that would break its address's rules (two people each
   bidding the same half at once) — is left in storage as it is and not read: never deleted (plan §2.2), said once. Each
   address's records in their order (ord, id); the wars in theirs; the ledger by date. */
function readWorldRows(): { wars: LeaveWar[]; openings: Openings; ledger: Ledger; postOuts: Record<string, Person>; persLabels: Record<string, string> } {
  const periods: Period[] = []
  const recRows: Array<{ key: string; warId: string; pid: string; date: string; rec: WarRec }> = []
  const openings: Openings = {}
  const ledger: Ledger = []
  const postOuts: Record<string, Person> = {}
  const persLabels: Record<string, string> = {}
  const skipped: string[] = []
  const parse = (k: string): any => { try { return JSON.parse(backend.read(k) ?? 'null') } catch { return undefined } }
  for (const k of backend.keys()) {
    if (k.startsWith(WAR)) {
      const w = readWar({ period: parse(k), recs: {} })
      if (w && w.period.id === k.slice(WAR.length)) periods.push(w.period)
      else skipped.push(k)
    } else if (k.startsWith(REC)) {
      const at = parseRecKey(k), x = parse(k)
      /* a hand-typed award from before awards were ledger entries is retired demo data (D401) — skipped, as readRecs does */
      if (isPlainObject(x) && isRetiredAward(x)) continue
      const rec = at && isPlainObject(x) && x.id === at.recId && typeof x.pid === 'string' && x.pid && isDay(x.date) ? readRec(x) : null
      if (at && rec) recRows.push({ key: k, warId: at.warId, pid: x.pid, date: x.date, rec })
      else skipped.push(k)
    } else if (k.startsWith(LEDGER)) {
      const e = readLedger([parse(k)])?.[0]
      if (e && e.id === k.slice(LEDGER.length)) ledger.push(e)
      else skipped.push(k)
    } else if (k.startsWith(OPENING)) {
      const o = parseOpeningKey(k), n = parse(k)
      if (o && readOpenings({ [o.pid]: { [o.counter]: n } })) (openings[o.pid] ??= {})[o.counter as CounterName] = n
      else skipped.push(k)
    } else if (k.startsWith(PROFILE)) {
      const pid = k.slice(PROFILE.length), x = parse(k)
      const post = isPlainObject(x) && x.post !== undefined ? readPostOuts({ [pid]: x.post })?.[pid] : undefined
      if (!isPlainObject(x) || (x.post !== undefined && !post)) { skipped.push(k); continue }
      if (post) postOuts[pid] = post
      if (typeof x.label === 'string' && x.label) persLabels[pid] = x.label
    }
  }
  periods.sort(byOrd((p: Period) => p.id))
  const wars: LeaveWar[] = []
  for (const period of periods) {
    if (wars.some(w => overlapping(w.period, period))) { skipped.push(WAR + period.id); continue }
    wars.push({ period, recs: {} })
  }
  const recOrder = byOrd((r: WarRec) => r.id)
  recRows.sort((a, b) => recOrder(a.rec, b.rec))
  for (const { key, warId, pid, date, rec } of recRows) {
    const war = wars.find(w => w.period.id === warId)
    const list = war ? ((war.recs[pid] ??= {})[date] ??= []) : null
    if (!list || listProblem([...list, rec])) { skipped.push(key); continue }
    list.push(rec)
  }
  ledger.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.enteredAt ?? '') < (b.enteredAt ?? '') ? -1 : (a.enteredAt ?? '') > (b.enteredAt ?? '') ? 1 : a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
  if (skipped.length) console.warn(`leavewar: ${skipped.length} saved row(s) this build cannot read are kept as they are, not read: ${skipped.slice(0, 5).join(', ')}${skipped.length > 5 ? ' …' : ''}`)
  return { wars, openings, ledger, postOuts, persLabels }
}

/* what stands now for the half of a man's profile a command did not change (state/rows.ts lwRows) */
const nowOf = (s: State): LwNow => ({ post: pid => s.postOuts[pid], label: pid => s.persLabels[pid] })

/* the rows the boot itself stored (the seed, before the demo world dressed it) — persistBootWorld removes the ones the
   dressed world no longer has (an opening keyed by a seed person's id) */
let BOOT_KEYS: Set<string> | null = null
/* THE WHOLE WORLD AS ROWS — the first boot's seed (initStore) and the demo world that replaces it (persistBootWorld),
   both inside the boot's one group. The only writes the war makes outside a command. */
/* `recordsOnly` — a SHARED store's first boot ([DB-READINESS] group A, phase 5): its world holds no war, opening, ledger
   entry or window, and its settings-like keys are the code's defaults, which read back the same with no row at all — so
   nothing of the war is stored until someone does something (a demo store's first boot still stores its whole world) */
function writeWorldRows(recordsOnly = false): void {
  const isRecord = (k: string) => [WAR, REC, LEDGER, OPENING, PROFILE].some(p => k.startsWith(p))
  const rows = allRows(lwDecompose(state).values(), nowOf(state)).filter(r => !recordsOnly || isRecord(r.key))
  const keys = new Set(rows.map(r => r.key))
  if (BOOT_KEYS) for (const k of BOOT_KEYS) if (!keys.has(k)) backend.remove(k)
  for (const r of rows) if (r.value !== null) backend.write(r.key, r.value)
  BOOT_KEYS = keys
}

/* EVERY LIST'S ORDER ON ITS RECORDS ([DB-READINESS] group A, phase 3 — plan §8 P3-CELL-DIFF; command/ord.ts). Run at the
   war's apply-end — persistNotify, which every durable write passes — over the addresses the write changed, compared
   with `prev` (the last committed world; null = every address): a record with no place, or one a writer moved out of
   order, takes one from its neighbours; a record still in order keeps its own, so a new bid writes one row. The wars'
   own order (the picker's — the order they were created in) the same way. Records are REPLACED, never mutated: the
   committed world is the undo's before-image. */
function placeRecords(prev: State | null, s: State): State {
  const outOfOrder = (list: readonly any[], idOf: (r: any) => string): boolean => {
    const cmp = byOrd(idOf)
    return list.some((r, i) => typeof r.ord !== 'number' || (i > 0 && cmp(list[i - 1], r) >= 0))
  }
  let wars = s.wars
  if (outOfOrder(wars.map(w => w.period), (p: Period) => p.id)) {
    const ps = wars.map(w => ({ ...w.period }))
    mintOrd(ps, (p: Period) => p.id)
    wars = wars.map((w, i) => (ps[i]!.ord === w.period.ord ? w : { ...w, period: ps[i]! }))
  }
  const placed = wars.map(w => {
    const pw = prev ? prev.wars.find(x => x.period.id === w.period.id) : undefined
    if (pw && pw.recs === w.recs) return w
    let recs = w.recs
    for (const pid of Object.keys(w.recs)) {
      const row = w.recs[pid]!, prow = pw ? pw.recs[pid] : undefined
      if (prow === row) continue
      for (const date of Object.keys(row)) {
        const list = row[date]!
        if ((prow && prow[date] === list) || !outOfOrder(list, (r: WarRec) => r.id)) continue
        const copy = list.map(r => ({ ...r }))
        mintOrd(copy, (r: WarRec) => r.id)
        recs = withList(recs, pid, date, list.map((r, i) => (copy[i]!.ord === r.ord ? r : copy[i]!)))
      }
    }
    return recs === w.recs ? w : { ...w, recs }
  })
  return placed.some((w, i) => w !== s.wars[i]) ? withCurrent({ ...s, wars: placed }) : s
}

/* THE ONE-TIME FOLD OF AN OLD STORE (storage/fold.ts — plan §2.6): the war's whole-list records become its rows — each
   list's order kept as `ord`, the wars' too — and the old records are removed in the same group. Read with the readers
   the boot used on them; a record that will not read is left as it is (never read again). `personedits` is dropped
   whole: the war's Edit person is gone (D461). Pure: it writes the war's own collection only. */
export const leavewarConverter: Converter = {
  name: 'leavewar',
  collections: ['leavewar'],
  convert(snap) {
    const lw: Record<string, string> = (snap as any).leavewar ?? {}
    const json = (k: string): unknown => { try { return JSON.parse(lw[k]!) } catch { return undefined } }
    const recs: Array<{ collection: string; id: string; value: unknown }> = []
    const replaced: string[] = []
    const wars = lw.wars != null ? readWars(json('wars')) : null
    if (wars) {
      const periods = wars.map(w => { const p = { ...w.period }; delete p.ord; return p })
      mintOrd(periods, (p: Period) => p.id)
      wars.forEach((w, i) => {
        recs.push({ collection: 'lw.war', id: w.period.id, value: periods[i] })
        for (const pid of Object.keys(w.recs)) for (const date of Object.keys(w.recs[pid]!)) {
          const list = w.recs[pid]![date]!.map(r => { const c = { ...r }; delete c.ord; return c })
          mintOrd(list, (r: WarRec) => r.id)
          recs.push({ collection: 'lw.cell', id: `${w.period.id}:${pid}:${date}`, value: list })
        }
      })
      replaced.push('wars')
    }
    const openings = lw.openings != null ? readOpenings(json('openings')) : null
    if (openings) {
      for (const pid of Object.keys(openings)) for (const c of Object.keys(openings[pid]!)) recs.push({ collection: 'lw.opening', id: `${pid}:${c}`, value: (openings[pid] as any)[c] })
      replaced.push('openings')
    }
    const ledger = lw.ledger != null ? readLedger(json('ledger')) : null
    if (ledger) { for (const e of ledger) recs.push({ collection: 'lw.ledger', id: e.id, value: e }); replaced.push('ledger') }
    const postOuts = lw.postouts != null ? readPostOuts(json('postouts')) : null
    if (postOuts) { for (const pid of Object.keys(postOuts)) recs.push({ collection: 'lw.postouts', id: pid, value: postOuts[pid] }); replaced.push('postouts') }
    const labels = lw.perslabels != null ? readLabelMap(json('perslabels')) : null
    if (labels) { for (const pid of Object.keys(labels)) if (labels[pid]) recs.push({ collection: 'lw.label', id: pid, value: labels[pid] }); replaced.push('perslabels') }
    if (lw.personedits != null) replaced.push('personedits')
    const out: Entry[] = []
    for (const r of allRows(recs, { post: () => undefined, label: () => undefined })) if (r.value !== null) out.push({ collection: 'leavewar', id: r.key, value: r.value })
    for (const k of replaced) out.push({ collection: 'leavewar', id: k, value: null })
    return out
  },
}
registerConverter(leavewarConverter)

let INIT_HOOK: (() => void) | null = null
/** Test-only: run after every initStore (the Leave War suite's seed absences). */
export function _setInitHook(fn: (() => void) | null): void { INIT_HOOK = fn }

export function initStore(b?: StorageBackend, opts: { started?: boolean; seedDemo?: boolean } = {}): void {
  backend = b ?? localBackend()
  state = blank()
  BOOT_KEYS = null

  /* [DB-READINESS] group A, phase 3 — THE WAR IS READ FROM ITS ROWS (state/rows.ts). Whether the store has STARTED is
     the boot's answer (main.tsx: the stamp's `initialized` — storage/schema.ts), or, standalone and in the tests,
     whether it holds a war row. A started store is read as it stands: no opening, ledger entry or window stored means
     none — never the seed's (a store an admin emptied must not get the demo back). A store that has not started takes
     the seed, and stores it as rows at once (writeWorldRows, at the end).
     PHASE 5 (plan §3 phase 5): a started store holding no war has NONE — the page shows its empty state, never the
     seed's wars; and a store that has not started takes the seed only under the demo policy (`seedDemo`, the default —
     src/bootpolicy.ts): a SHARED store starts with no war, opening, ledger entry or window, and an admin creates its
     first period. */
  const started = opts.started ?? backend.keys().some(k => k.startsWith(WAR))
  const seedDemo = opts.seedDemo ?? true
  const stored = started ? readWorldRows() : null
  const wars = stored ? stored.wars : seedDemo ? seedWars() : []
  /* THE TAB ALWAYS OPENS ON THE WAR BEING WORKED (owner, 7 Sep 26, restated
     and reaffirmed 17 Sep 26): open for bidding first, else bidding-closed,
     else published, else draft. A remembered choice does NOT override it.

     This deliberately IGNORES the stored `current`. It used to win here, and
     that was a REGRESSION nobody made on purpose: before the storage seam
     (8 Sep 26) nothing was ever stored, so this stage pick ran on every load
     and the owner's rule held by accident. Once the Leave War persisted, the
     remembered war started winning from the second visit — so a squadron that
     had glanced at the DRAFT 2027 year would reopen there instead of on the
     year actually open for bidding. `current` is still RECORDED (below, at
     every switch) because it is the reader's last choice and the shared
     database may yet want it per user; it is simply not honoured at boot. */
  const currentId = pickDefaultPeriodId(wars.map(w => w.period)) || (wars[0] ? wars[0].period.id : '')

  const openings = stored ? stored.openings : seedDemo ? seedOpenings() : {}
  const ledger = stored ? stored.ledger : seedDemo ? seedLedger() : []
  const eventDefs = readStored('eventdefs', readEventDefs) ?? seedEventDefs()
  const oilPolicy = readStored('oilpolicy', readOilPolicy) ?? { ...DEFAULT_OIL_POLICY }
  const figureOrder = readStored('figorder', readFigureOrder) ?? [...DEFAULT_FIGURE_ORDER]
  const rosterOrder = readStored('rosterorder', readIdList) ?? []
  /* the personnel labels ride each man's profile row with his posting window (LeavePersonProfile) */
  const persLabels = stored ? stored.persLabels : {}
  const manningOrder = readStored('manningorder', readIdList) ?? []
  const manningHidden = readStored('manninghidden', readIdList) ?? []
  const figureHidden = readStored('fighidden', readIdList) ?? []
  /* Untrusted storage: keep only structurally sound entries. NOT pruned against
     the catalogue here (bug hunt, 4 Sep 26): at boot the catalogue is still the
     seed's three keys, so pruning now threw away every saved TF / NVG / custom
     group — and its picked colour — before Raptor's real column list had a
     chance to land. The list is pruned where the catalogue is real: at every
     read (`groupsInOrder`) and when the catalogue arrives (`setQualCatalog`,
     which also persists the pruned list). */
  const groupDefs = readStored('groupdefs', readGroupDefs) ?? [...DEFAULT_GROUPS]
  const groupPriority = readStored('grouppriority', readIdList) ?? []
  const groupPriorityCustom = readStored('grouppriocustom', x => (typeof x === 'boolean' ? x : null)) ?? false
  const groupColors = readStored('groupcolors', readColorMap) ?? {}
  // The squadron's own rule set, or — for a browser from before rules were
  // data — the seed with its old numbers-only overlay migrated in.
  const storedRules = readStored('manningdefs', readManningRules)
  const requirements: Requirements = storedRules
    ? { default: { rules: storedRules }, overrides: {} }
    : requirementsWith(readStored('manningthresh', readThreshMap) ?? {})
  const eventRows = readStored('eventrows', x =>
    typeof x === 'number' && Number.isInteger(x) && x >= DEFAULT_EVENT_ROWS && x <= MAX_EVENT_ROWS ? x : null,
  ) ?? DEFAULT_EVENT_ROWS
  const showSans = readStored('showsans', x => (typeof x === 'boolean' ? x : null)) ?? false
  const postOuts = stored ? stored.postOuts : {}

  /* The role is neither read nor persisted since the Raptor merge: it is
     derived from the Raptor login on every session change (resetSession in
     ../../state/store.ts calls setRole), so a stored copy could only ever
     disagree with the session that is actually looking at the page. Boot
     leaves the default ('member'); the login that follows sets it. */
  /* PEOPLE are neither read nor persisted since the sync wires, for the same
     reason as the role: the roster is a PROJECTION of Raptor's own PEOPLE
     (state/raptorRoster.ts), installed by main.tsx via setPeople on every
     boot, so a stored copy could only ever disagree with the roster Raptor
     is actually flying. Boot leaves the seed — the vendored unit suite reads
     it pristine — and the projection that follows replaces it. What IS read
     back is what Leave War owns about a person (8 Sep 26): the posting-out
     windows, laid onto the projection by setPeople. (The admin's identity
     overrides it read beside them are gone — D460, D461.) */
  state = withCurrent({ ...state, wars, currentId, openings, ledger, oilPolicy, eventDefs, figureOrder, rosterOrder, persLabels, manningOrder, manningHidden, figureHidden, groupDefs, groupPriority, groupPriorityCustom, groupColors: colorsFor(groupDefs, groupColors), requirements, eventRows, showSans, postOuts })
  /* every list's order on its records — the seed's, and a stored record not yet placed (command/ord.ts) */
  state = placeRecords(null, state)
  /* the committed world is this one: a command the test hook below runs diffs against it, not the last world */
  LW_BASELINE = state

  version = 0
  listeners.clear()
  MERGED = null
  // [ARCH-STACK] step 4 — the Leave War suite's setup files the seed's
  // approved leave as Inputs here (test-only; production files it through
  // installDemoWorld). Never set in the app.
  INIT_HOOK?.()
  /* a store that had not started stores its world now, one row per record — the seed as the boot left it; main.tsx's
     demo world then replaces it with the dressed one (persistBootWorld), inside the same boot group */
  if (!started) writeWorldRows(!seedDemo)
  // Baseline undo/redo to the freshly loaded world. main.tsx re-baselines once
  // more after the demo world and the first sync pass are in (so those boot
  // writes fold into the baseline rather than becoming undo steps); this keeps
  // the stack sane for the standalone unit suite, which boots the store alone.
  lwHistInit()
}

/* THE AWARD INDEX, rebuilt from the ledger whenever the ledger changes
   ([OIL-AWARD-IS-A-GRANT], D402; Fable's plan read F1). Every ledger writer
   replaces the array, so its identity is the key; a reset of the merge cache
   (a world swap in tests) bumps the index version, which also forces a rebuild.
   A person whose OIL awards are the same objects in the same order keeps his
   previous inner map, so the merge re-merges only the people a write touched. */
let LAST_LEDGER: Ledger | null = null
let LAST_AWD_VER = -1
function syncAwardIndex(ledger: Ledger): void {
  if (ledger === LAST_LEDGER && awardVersion() === LAST_AWD_VER) return
  const prev = awardRows()
  const byPerson = new Map<string, LedgerEntry[]>()
  for (const e of ledger) {
    if (!isOilAward(e)) continue
    const list = byPerson.get(e.personId)
    if (list) list.push(e); else byPerson.set(e.personId, [e])
  }
  const next = new Map<string, ReadonlyMap<string, readonly LedgerEntry[]>>()
  for (const [pid, list] of byPerson) {
    const m = new Map<string, LedgerEntry[]>()
    for (const e of list) {
      const day = m.get(e.date)
      if (day) day.push(e); else m.set(e.date, [e])
    }
    /* the SAME days holding the same entries in the same order keep his previous map — compared day by day, so awards
       entered out of date order (3 Jan, 5 Jan, 3 Jan) still match (both final reads, Astra OA-004 / Fable F3) */
    const old = prev.get(pid)
    const same = !!old && old.size === m.size && [...m].every(([d, es]) => {
      const was = old.get(d)
      return !!was && was.length === es.length && es.every((e, i) => e === was[i])
    })
    next.set(pid, same ? old! : m)
  }
  setAwardRows(next as AwardRows)
  LAST_LEDGER = ledger
  LAST_AWD_VER = awardVersion()
}

/* the merged read, cached on the raw state ref, the absence index version and
   the award index version, so a view-only render pays nothing (design §4.2/§4.3) */
let MERGED: { raw: State; ver: number; awd: number; out: MergedState } | null = null
export function getState(): MergedState {
  syncAwardIndex(state.ledger)
  const ver = absenceVersion()
  const awd = awardVersion()
  if (MERGED && MERGED.raw === state && MERGED.ver === ver && MERGED.awd === awd) return MERGED.out
  const wars = state.wars.map(mergeWar)
  const cur = wars.find(w => w.period.id === state.currentId) ?? wars[0]
  /* no war at all (phase 5 — withCurrent): nothing on any person's any day */
  const out: MergedState = cur
    ? { ...state, wars, grid: cur.grid, states: cur.states, views: cur.views, spans: cur.spans }
    : { ...state, wars, grid: {}, states: {}, views: {}, spans: new Map() }
  MERGED = { raw: state, ver, awd, out }
  return out
}

/** The RAW state — the war's own records only. For writers, persistence, the
 *  command layer and tests of the stored shape; screens read getState(). */
export function rawState(): State {
  return state
}

/** A repaint after the absence index changed (sync.ts) — no persist, no
 *  envelope: nothing of the war's own changed (design §4.1). */
export function absencesChanged(): void {
  rawNotify()
}

export function getVersion(): number {
  return version
}

export function subscribe(fn: () => void): () => void {
  listeners.add(fn)
  return () => void listeners.delete(fn)
}

/* [CMDL-FINISH] §2.2 — the pure repaint primitive. The user/reconciler write
   paths repaint through persistNotify (which defers this into the command so the
   cross-side reconcile it wakes runs in phase 8 with the causal seq live); the
   view-only setters (setRole/setViewer/focusDay/setPeople/…) call the bare
   notify() alias below — a repaint with no durable write and no envelope. */
function rawNotify(): void {
  version += 1
  for (const fn of listeners) fn()
}
function notify(): void { rawNotify() }

/* THE DURABLE STEP'S EPILOGUE. Since [DB-READINESS] group A, phase 3 the war is
   saved FROM THE COMMAND STREAM — every command's changes to the war, mapped to
   the rows they land in (state/rows.ts) and written through the war's own door
   by the subscriber lwRegisterCommands installs, inside the command's own saved
   group — so nothing is written here any more: a change outside every command is
   not saved (the persistence funnel, raptor-port/CLAUDE.md). The boot's seed and
   demo world are the one exception, written whole (writeWorldRows). What is left
   here is the durable version and the legacy undo step. (It wrote every big
   record whole until then — `wars`, `openings`, `ledger`, `postouts`, … — the
   fold removes them; `current` and each ⚙ setting are still their own keys,
   written by the same subscriber.) */
function rawPersist(): void {
  LW_SIG++   // [CMDL-FINISH] C9 — the durable version advanced
  // A save IS an undo step: record the durable snapshot now that the backend
  // holds it (the UNDO / REDO block below). Skipped while a restore or a
  // sync-driven write holds the lock, and a no-op when nothing durable moved.
  recordHistory()
}

/* =====================================================================
   [ARCH-STACK] Step 2 phase 4 — the Leave War COMMAND LAYER (ADDITIVE, §5.3)
   ---------------------------------------------------------------------
   Every durable LW write funnels through persist(). A STANDALONE USER edit now
   runs its identical body (rawPersist) inside commit(), emitting the record-level
   change stream — per-populated-cell `lw.cell` / `lw.bid` records plus the coarse
   ledger / balances / oilpolicy / postouts / current / config records (§3.1).

   Everything else runs RAW, exactly as today, so no delicate path changes:
   - LOCKED writes — the four sync reconcilers and undo/redo (historyApply) — the
     lock is the sync loop-breaker, and undo is NOT routed through commit at Step 2
     (§0);
   - a write NESTED in another command (a causal Raptor->LW write) — deferred JOIN;
   - boot/seed persists (before LW_READY, set at the end of the boot lwHistInit).

   The immutable `state` ref IS the snapshot (capture is O(1)); a rollback simply
   reassigns it. LW's snapshot undo stack is left running. lwStore is deliberately
   NOT a guarded store: a causal Raptor->LW write (locked) legitimately changes it
   outside any LW command, and the whole-world guard would wrongly flag that.

   DEFERRED (a documented follow-up; they need the owner's live-scenario sign-off
   on the delicate Raptor<->LW sync loop, which a headless run can't perform):
   sync-reconcilers-as-projection (commitAs) and the causal input-delete->bid-
   delete JOIN into the originating Raptor command's transaction. Until then those
   writes stay raw — additive and behaviour-identical to today.
   ===================================================================== */
let LW_BASELINE: State = state   // the last-persisted state ref — the record source
let LW_READY = false             // enabled after boot (lwHistInit), so seed persists stay raw
let LW_REGISTERED = false
/* [CMDL-FINISH] C9 — a monotonic DURABLE-version counter, bumped only where the
   backend actually changes (rawPersist / restore). signature() returns it so the
   whole-world guard asks "changed?" cheaply, instead of serialising the world
   every commit. Registered guarded at the END of P3 (once routing is complete). */
let LW_SIG = 0
/* [CMDL-FINISH] F1 (§2.2/§2.3) — the causal-envelope router state.
   - LW_RESTORING: the legacy LW undo/redo (historyApply) persists OFF-STREAM —
     it is not a new edit, so it must emit no projection and wake no reconcile as
     a command (C4). Checked FIRST in persistNotify.
   - LW_PROJ_PENDING: coalesces a multi-cell reconcile to ONE lw.sync projection
     per turn (N1/C5) — armed on the first cell, every later cell takes the raw
     branch and does NOT advance LW_BASELINE, so the one projection still diffs
     every cell against the pre-reconcile baseline.
   - LW_SYNC_TURN: F4-1 — an IDLE reconcile (week-nav loadWeek→runOilPass) is
     wrapped in lwSyncTurn, which arms LW_PROJ_PENDING and holds it across the
     turn; this counter stops the defensive idle reset from clearing the flag the
     wrapper just armed. */
let LW_RESTORING = false
let LW_PROJ_PENDING = false
let LW_SYNC_TURN = 0
/* did a DURABLE LW write actually go through the router during the current idle
   turn? lwSyncTurn's trailing projection fires ONLY if so — a view-only setter
   (setRole/setViewer/focusDay) that wakes the reconcilers but changes no cell
   must not trigger a spurious durable persist. */
let LW_TURN_WROTE = false

/* decompose a durable State into its logical records (design §3.1): one record
   per POPULATED grid cell / bid (sparse), plus the coarse side records. */
function lwDecompose(s: State): Map<string, CmdRecordEntry> {
  const m = new Map<string, CmdRecordEntry>()
  for (const w of s.wars) {
    const warId = w.period.id
    /* the war's own period record — id/name/stage/bidFrom/bidTo/days (events/PH/
       blocked). Without this a stage advance, bidding-window change, war rename or
       a brand-new (cell-less) war produces an empty diff and is dropped (Fable-2). */
    m.set(`lw.war/${warId}`, { collection: 'lw.war', id: warId, value: w.period })
    /* [ARCH-STACK] step 4 — ONE record per populated address: the war's own
       list there (requests / credits / notices). Same lw.cell collection and
       warId:pid:date id as before, so undo's war/date snapping reads it
       unchanged; the value is now the list. */
    const recs = (w.recs || {}) as Recs
    for (const pid of Object.keys(recs)) {
      const row = recs[pid] || {}
      for (const date of Object.keys(row)) {
        if (!row[date]?.length) continue
        const id = `${warId}:${pid}:${date}`
        m.set(`lw.cell/${id}`, { collection: 'lw.cell', id, value: row[date] })
      }
    }
  }
  /* ONE RECORD PER LEDGER ENTRY ([OIL-AWARD-IS-A-GRANT], 29 Sep 26 — Fable F6, Astra F11). It was one record for the
     whole ledger, so once every OIL award lived here any other ledger write — the app's own person delete dropping
     another man's future award, the posting pass — shared a key with every earlier award and refused its Undo ("a
     later change … touches the same thing"). Per entry, an Undo conflicts only with a change to the same award. */
  for (const e of s.ledger) m.set(`lw.ledger/${e.id}`, { collection: 'lw.ledger', id: e.id, value: e })
  /* ONE RECORD PER OPENING BALANCE, PER POSTING WINDOW, PER LABEL ([DB-READINESS] group A, phase 3) — each is its own
     stored row (state/rows.ts; a man's window and label share his profile row), so an Undo of one man's opening,
     window or label conflicts only with a change to the same one. They were one record each for everyone. */
  for (const pid of Object.keys(s.openings)) {
    const row = s.openings[pid] as Record<string, number> | undefined
    for (const c of Object.keys(row || {})) m.set(`lw.opening/${pid}:${c}`, { collection: 'lw.opening', id: `${pid}:${c}`, value: row![c] })
  }
  for (const pid of Object.keys(s.postOuts)) m.set(`lw.postouts/${pid}`, { collection: 'lw.postouts', id: pid, value: s.postOuts[pid] })
  for (const pid of Object.keys(s.persLabels)) m.set(`lw.label/${pid}`, { collection: 'lw.label', id: pid, value: s.persLabels[pid] })
  m.set('lw.oilpolicy/all', { collection: 'lw.oilpolicy', id: 'all', value: s.oilPolicy })
  m.set('lw.current/all', { collection: 'lw.current', id: 'all', value: s.currentId })
  m.set('lw.config/all', {
    collection: 'lw.config', id: 'all', value: {
      eventDefs: s.eventDefs, figureOrder: s.figureOrder, rosterOrder: s.rosterOrder,
      manningOrder: s.manningOrder, manningHidden: s.manningHidden,
      figureHidden: s.figureHidden, groupDefs: s.groupDefs, groupPriority: s.groupPriority,
      groupPriorityCustom: s.groupPriorityCustom, groupColors: s.groupColors,
      requirements: s.requirements, eventRows: s.eventRows, showSans: s.showSans,
    },
  })
  return m
}

/* [CMDL-FINISH] §3 — apply ONE decomposed LW record onto a MUTABLE state clone
   (write() clones first, so mutating in place here never touches the captured
   baseline). Cell/bid ids are `${warId}:${pid}:${date}`; warId may itself carry
   colons, so the two trailing segments (pid, date) are split from the RIGHT. */
function applyLwRecord(s: State, e: CmdRecordEntry): void {
  const coll = e.collection
  if (coll === 'lw.war') {
    const ix = s.wars.findIndex(w => w.period.id === e.id)
    if (e.op === 'delete') { if (ix >= 0) s.wars.splice(ix, 1) }
    else if (ix >= 0) s.wars[ix].period = e.value as any
    else s.wars.push({ period: e.value as any, recs: {} } as any)
    return
  }
  if (coll === 'lw.cell') {
    const iDate = e.id.lastIndexOf(':'); const date = e.id.slice(iDate + 1)
    const rest = e.id.slice(0, iDate); const iPid = rest.lastIndexOf(':')
    const pid = rest.slice(iPid + 1); const warId = rest.slice(0, iPid)
    const war = s.wars.find(w => w.period.id === warId)
    if (!war) return
    war.recs = withList(war.recs, pid, date, e.op === 'delete' ? [] : (e.value as WarRec[]))
    return
  }
  switch (coll) {
    case 'lw.ledger': {
      /* one entry: replaced in place, appended when new, removed on a delete — the order of the rest kept */
      const cur = (s as any).ledger as Ledger
      const ix = cur.findIndex(x => x.id === e.id)
      if (e.op === 'delete') { if (ix >= 0) (s as any).ledger = cur.filter(x => x.id !== e.id) }
      else if (ix >= 0) (s as any).ledger = cur.map(x => (x.id === e.id ? e.value as LedgerEntry : x))
      else (s as any).ledger = [...cur, e.value as LedgerEntry]
      return
    }
    case 'lw.opening': {
      /* one opening balance: `<pid>:<counter>`, the counter from the RIGHT */
      const i = e.id.lastIndexOf(':'), pid = e.id.slice(0, i), c = e.id.slice(i + 1)
      const openings = { ...((s as any).openings as Openings) }
      const row: Record<string, number> = { ...(openings[pid] || {}) } as Record<string, number>
      if (e.op === 'delete') delete row[c]; else row[c] = e.value as number
      if (Object.keys(row).length) openings[pid] = row; else delete openings[pid]
      ;(s as any).openings = openings
      return
    }
    case 'lw.label': {
      const labels = { ...((s as any).persLabels as Record<string, string>) }
      if (e.op === 'delete') delete labels[e.id]; else labels[e.id] = e.value as string
      ;(s as any).persLabels = labels
      return
    }
    case 'lw.oilpolicy': (s as any).oilPolicy = e.value; return
    /* [CMDL-FINISH] CMDLF-002 — DEFERRED to [GLOBAL-UNDO]. Restoring postOuts sets
       the record, but the people posting-WINDOWS on the roster are a projection:
       reprojectRoster carries each window from the CURRENT person (ex.from/to), not
       from postOuts, so a postouts-only restore is invisible to it. Rebuilding them
       correctly means re-laying the restored postOuts over the CLEAN Raptor
       projection (setPeople(projectPeople)) — which crosses the LW↔Raptor projection
       boundary sync.ts owns and, fired at this write() boundary, re-enters the
       reconcilers. That orchestration belongs to the undo consumer (with the
       clean-projection context), not to a bare record apply. Latent: no production
       path restores postOuts at this step. */
    case 'lw.postouts': {
      /* one man's window (per person since [DB-READINESS] group A, phase 3) */
      const po = { ...((s as any).postOuts as Record<string, Person>) }
      if (e.op === 'delete') delete po[e.id]; else po[e.id] = e.value as Person
      ;(s as any).postOuts = po
      return
    }
    case 'lw.current': (s as any).currentId = e.value; return
    case 'lw.config': {
      const v = e.value as any
      Object.assign(s as any, {
        eventDefs: v.eventDefs, figureOrder: v.figureOrder, rosterOrder: v.rosterOrder,
        manningOrder: v.manningOrder, manningHidden: v.manningHidden,
        figureHidden: v.figureHidden, groupDefs: v.groupDefs, groupPriority: v.groupPriority,
        groupPriorityCustom: v.groupPriorityCustom, groupColors: v.groupColors,
        requirements: v.requirements, eventRows: v.eventRows, showSans: v.showSans,
      })
      return
    }
  }
}

/* exported for the [CMDL-FINISH] write()-seam unit tests (the two-store round-trip
   Q2); production wiring uses it only through this module. */
export const lwStore: CmdEnlistableStore = {
  key: 'leavewar',
  capture: () => LW_BASELINE,                                  // the immutable ref IS the snapshot
  restore: (snap) => { state = snap as State; LW_BASELINE = snap as State; LW_SIG++ },
  records: () => lwDecompose(LW_BASELINE),
  signature: () => String(LW_SIG),                             // [CMDL-FINISH] C9
  /* [CMDL-FINISH] §3 (F8/GU-007) — batch, delete-aware record write for the undo
     seam. Clone the current state (preserving the NON-record fields the decompose
     omits — people/role/viewer/focus), apply every entry, republish the derived
     top-level fields (withCurrent), advance the baseline, then persist + notify at
     the transaction boundary under the lock (a restore must push NO LW undo step).
     Called only from a reducer that already enlisted lwStore. */
  write(entries: CmdRecordEntry[]): void {
    const next = JSON.parse(JSON.stringify(state)) as State   // fields are all JSON-durable (rawPersist proves it)
    /* [CMDL-FINISH] Fable#8 — apply lw.war entries FIRST: a cell/bid record whose
       war does not exist yet is dropped by applyLwRecord, so a restore set that
       lists a war and its cells in any order would lose the cells. Wars first
       guarantees the war exists before its cells land. */
    const ordered = entries.slice().sort((a, b) => (a.collection === 'lw.war' ? 0 : 1) - (b.collection === 'lw.war' ? 0 : 1))
    for (const e of ordered) {
      /* [CMDL-FINISH] Fable#7 — clone-on-write: an entry's value comes from the
         record set / an undo snapshot; installing an object BY REFERENCE would let
         a later in-place live edit corrupt that snapshot. Cell/bid values are
         strings (primitives, no aliasing), so clone only object values. */
      const val = e.value
      applyLwRecord(next, (val && typeof val === 'object') ? { ...e, value: JSON.parse(JSON.stringify(val)) } : e)
    }
    state = withCurrent(next)
    LW_BASELINE = state
    cmdDeferEffect(() => { locked(() => rawPersist()); notify() })
  },
}

/* [GLOBAL-UNDO] §13 phase 2 (Codex GU-P2-009) — the AUTHORITATIVE list of the
   collections lwStore owns. ONE exported source, used for BOTH the command-
   layer record registration below AND the undo-store registration (undo-wire.ts):
   an omitted collection would fail the restore reducer with "no restore target".
   `lw.current` is in the list (harmless — nav is never restored). */
export const LW_COLLS = ['lw.cell', 'lw.war', 'lw.ledger', 'lw.opening', 'lw.oilpolicy', 'lw.postouts', 'lw.label', 'lw.current', 'lw.config'] as const

function lwRegisterCommands(): void {
  if (LW_REGISTERED) return
  LW_REGISTERED = true
  cmdDefinePermission('lw.edit', cmdAnyone)   // permissive at Step 2 (the real role gates are unchanged)
  /* [ARCH-STACK] step 4 — the war gestures. The role gates live in the writers
     (canDecide / canEditRow), exactly as lw.edit's do. */
  for (const t of ['lw.decide', 'lw.move', 'lw.ack', 'lw.approve', 'lw.decideApproved', 'lw.removeApproved', 'lw.moveApproved']) cmdDefinePermission(t, cmdAnyone)
  /* D352 (28 Sep 26): a stage move is its own command so Undo can name it ("Undid: closing bidding …"); its authority
     is perms.ts COMMAND_OPS (admin-only), as every war command's */
  cmdDefinePermission('lw.stage', cmdAnyone)
  /* [OIL-AWARD-IS-A-GRANT] (Astra's round-2 read, R2-01): an OIL award, a ledger entry and a clear that takes an award
     are their OWN commands, so the command gate asks the right row of the permissions table (perms.ts COMMAND_OPS:
     the award's, the ledger's) rather than the bid's */
  for (const t of ['lw.award', 'lw.ledger', 'lw.clear']) cmdDefinePermission(t, cmdAnyone)
  for (const c of LW_COLLS) cmdRegisterRecord({ key: `leavewar:${c}`, cls: 'record', collection: c, module: 'leavewar' })
  /* [DB-READINESS] group A, phase 3 — THE WAR'S ROWS, WRITTEN FROM THE COMMAND STREAM (state/rows.ts): every command's
     changes to the war, mapped to the rows they land in and written through the war's own door at phase 9 — inside the
     command's own saved group (the whiteboard's, in the app). A remote change applied silently is never echoed back. */
  cmdOnCommit(env => {
    if (env.emit === false) return
    const mine = env.changes.filter(c => c.collection.startsWith('lw.'))
    if (!mine.length) return
    for (const r of lwRows(mine, nowOf(LW_BASELINE))) {
      if (r.value === null) backend.remove(r.key)
      else backend.write(r.key, r.value)
    }
  })
  // [CMDL-FINISH] C9/P3-END — now that every LW write routes through the command
  // layer (the only post-boot raw path is LW_RESTORING, which runs at idle and is
  // never nested inside another command), lwStore is safe to guard. The guard
  // uses the cheap durable-version signature(), not a whole-state serialise.
  cmdRegisterGuardedStore(lwStore)
  // [CMDL-FINISH] §2.1(4)/CMDLF-002 — the LW HIST.lock is a DIFFERENT object than
  // the scheduler's 'HIST.lock'. A Raptor-driven LW reconcile enqueues an lw.sync
  // projection under LW's locked(); that lock unwinds before drainQueue runs the
  // projection's rawPersist→recordHistory, so without capturing THIS lock the
  // reconcile would record as a spurious LW undo step (and truncate redo). The
  // queued projection captures + re-installs it (commit.ts enqueue/drain).
  cmdRegisterEffectContext({
    key: 'lw.hist',
    capture: () => HIST.lock,
    install: (snap) => { const prev = HIST.lock; HIST.lock = snap as boolean; return () => { HIST.lock = prev } },
  })
}

/* [CMDL-FINISH] §2.3 (Rev 4 + F4-1) — the persist+notify ROUTER. Every durable LW
   write path (the ~48 former `persist(); notify()` sites) calls this. It replaces
   the old persist() (whose raw body is rawPersist) AND the following notify(), so
   a user edit's repaint DEFERS into the command (phase 8, causal seq live) and the
   cross-side reconciler it wakes chains to the edit instead of orphaning (C1). */
function persistNotify(): void {
  /* [DB-READINESS] group A, phase 3 — every list's order on its records, before the write is taken (placeRecords) */
  state = placeRecords(LW_BASELINE, state)
  const scope = { module: 'lw', warId: state.currentId } as CmdScope
  if (!LW_READY)    { rawPersist(); LW_BASELINE = state; rawNotify(); return }   // boot/seed
  if (LW_RESTORING) { rawPersist(); LW_BASELINE = state; rawNotify(); return }   // legacy undo — off-stream (C4)
  // defensive: at idle with no turn armed, nothing is pending (M3 + F4-1: the
  // !LW_SYNC_TURN guard keeps lwSyncTurn's armed flag from being cleared here).
  if (!cmdIsCommitting() && !LW_SYNC_TURN) LW_PROJ_PENDING = false
  if (HIST.lock || cmdIsCommitting()) {                                          // reconciler OR nested causal
    if (cmdIsCommitting() && cmdIsInReducer()) {                                 // nested causal child (Gap 2) — JOINs the parent
      /* [ARCH-STACK-4] §5.2 FB2-05 — the durable write defers to phase 8 (run on
         success, discarded if the parent command is refused after its reducer) */
      cmdCommitProjection({ type: 'lw.sync', scope, apply: (t) => { t.enlist(lwStore); cmdDeferEffect(() => locked(() => rawPersist())); LW_BASELINE = state } })
    } else if (!LW_PROJ_PENDING) {                                               // first cell of a turn — ONE projection
      LW_PROJ_PENDING = true
      const r = cmdCommitProjection({ type: 'lw.sync', scope, apply: (t) => { LW_PROJ_PENDING = false; t.enlist(lwStore); rawPersist(); LW_BASELINE = state } })
      if (isQueued(r)) r.done.then(x => { if (!isOk(x)) rawNotify() })           // a rejected drained projection → re-read the grid (Q1)
    } else {
      rawPersist()                                                               // COALESCED — raw only, do NOT advance LW_BASELINE (N1)
      if (LW_SYNC_TURN) LW_TURN_WROTE = true                                     // this idle turn actually wrote — arm the trailing projection
    }
    rawNotify()                                                                  // inline (the SYNCING loop-breaker needs it firing now)
    return
  }
  // a standalone USER edit -> the identical durable body inside a command that
  // emits the change stream; the repaint defers to phase 8 (causal seq live).
  const r = cmdCommit({
    type: 'lw.edit', scope,
    /* [ARCH-STACK-4] §21.1c (FB5-03) — the backend write defers with the repaint */
    apply: (txn) => { txn.enlist(lwStore); cmdDeferEffect(rawPersist); LW_BASELINE = state; cmdDeferEffect(rawNotify) },
  })
  if ((r as any).ok === false) rawNotify()   // a rejected edit reverted the model; re-read the grid + toast idiom
}

/* [CMDL-FINISH] F4-1/M3 — coalesce an IDLE multi-cell reconcile (week-nav
   loadWeek→runOilPass crediting K cells, a view-only setter that wakes the
   reconcilers) into ONE lw.sync projection. Arm LW_PROJ_PENDING so every cell
   inside `fn` takes the coalesced raw branch (each rawPersists but does not
   advance LW_BASELINE), then emit ONE trailing projection UNDER THE LOCK — else
   recordHistory would push an LW undo step for an idle reconcile. A no-op when
   already committing (the phase-8 lane coalesces on its own). */
export function lwSyncTurn<T>(fn: () => T): T {
  // Already committing (phase-8 lane coalesces on its own) or already inside an
  // outer turn (the outermost turn emits the ONE projection) — just run fn.
  if (cmdIsCommitting() || LW_SYNC_TURN > 0) return fn()
  LW_SYNC_TURN++
  LW_TURN_WROTE = false
  LW_PROJ_PENDING = true
  try {
    return fn()
  } finally {
    LW_SYNC_TURN--
    // ONE trailing projection for the whole turn — but ONLY if a durable LW write
    // happened (else a view-only setter that woke the reconcilers would persist
    // spuriously). Under the lock so recordHistory pushes no undo step for a
    // reconcile. Its before-image is the pre-turn baseline (the coalesced cells
    // never advanced it), so the one envelope diffs every cell.
    if (LW_TURN_WROTE) {
      locked(() => {
        cmdCommitProjection({
          type: 'lw.sync', scope: { module: 'lw', warId: state.currentId } as CmdScope,
          apply: (t) => { LW_PROJ_PENDING = false; t.enlist(lwStore); rawPersist(); LW_BASELINE = state },
        })
      })
    }
    LW_PROJ_PENDING = false
  }
}

/* =====================================================================
   UNDO / REDO (owner, 30 Aug 26 — "Add undo and redo on leave war")
   ---------------------------------------------------------------------
   A snapshot stack over the DURABLE state — precisely the fields persist()
   writes. The push lives inside persist(), because in this store a save and a
   user edit are the same event: every path that changes the war ends in
   persist()+notify(), and the pure-view notifiers (setRole / setViewer /
   focusDay / setPeople) call notify() WITHOUT persist, so they make no step.

   NOT in the snapshot, on purpose:
   - currentId / focus / role / viewer — navigation and who-is-looking, not
     edits; an undo must not switch wars or change the viewer. Switching wars
     instead RE-BASELINES the stack (selectWar), so undo is scoped to the war
     on screen — the same rule the scheduler follows per week.
   - people / qualCatalog — a live PROJECTION of Raptor's roster (sync.ts),
     owned by Raptor's Quals page; undo here must not fight it.

   Raptor-DRIVEN writes (the OIL pass's ingestDutyCredit / clearRaptorCell;
   since [ARCH-STACK] step 4 leave is never copied onto the war) run under `locked`, so
   a change Raptor pushed never becomes a Leave War undo step — undoing a cell
   Raptor still holds an input for would only be re-applied by the next
   reconcile pass, growing the stack forever. A restore (historyApply) is
   locked for the same reason AND so the sync reconcilers it wakes — which
   converge the Raptor side to the restored grid, retracting or re-minting
   inputs exactly as sync.ts's wiring note anticipates ("an Undo that removes
   an lw-tagged row") — do not themselves push a step.
   ===================================================================== */
const HIST: { stack: string[]; ix: number; lock: boolean; cap: number } =
  { stack: [], ix: -1, lock: false, cap: 60 }

/** Run `fn` with history recording suppressed, re-entrancy safe: a nested
 *  lock restores to the OUTER value, so an inner `finally` can never unlock a
 *  restore (or an outer sync pass) that is still in flight. */
function locked<T>(fn: () => T): T {
  const was = HIST.lock
  HIST.lock = true
  try {
    return fn()
  } finally {
    HIST.lock = was
  }
}

/** The durable state, serialised — the same field set persist() writes, minus
 *  `current` (which war is on screen is navigation, not an edit). */
function historySnap(): string {
  const s = state
  return JSON.stringify({
    wars: s.wars, openings: s.openings, ledger: s.ledger, oilPolicy: s.oilPolicy, eventDefs: s.eventDefs,
    figureOrder: s.figureOrder, rosterOrder: s.rosterOrder, persLabels: s.persLabels,
    manningOrder: s.manningOrder, manningHidden: s.manningHidden, figureHidden: s.figureHidden,
    groupDefs: s.groupDefs, groupPriority: s.groupPriority, groupPriorityCustom: s.groupPriorityCustom,
    requirements: s.requirements, eventRows: s.eventRows, showSans: s.showSans,
  })
}

/** Push a snapshot after a durable change: drop the redo tail, cap the stack,
 *  and treat an identical snapshot (nothing durable moved — a same-value write,
 *  or a bare war-switch whose only change was `current`) as a no-op. */
function recordHistory(): void {
  if (HIST.lock) return
  const snap = historySnap()
  if (HIST.stack[HIST.ix] === snap) return
  HIST.stack.splice(HIST.ix + 1)
  HIST.stack.push(snap)
  if (HIST.stack.length > HIST.cap) HIST.stack.shift()
  HIST.ix = HIST.stack.length - 1
}

/** Baseline the stack to the state on screen — called once at boot (main.tsx,
 *  after the demo world and the first sync pass are installed) and again
 *  whenever a different war comes on screen (selectWar). */
export function lwHistInit(): void {
  HIST.stack = [historySnap()]
  HIST.ix = 0
  HIST.lock = false
  /* [ARCH-STACK] phase 4: enable command routing now that the boot sequence
     (demo world + first sync pass) has finished its raw seed persists, and
     baseline the record source to the state on screen. Also called on selectWar
     (re-baseline), which harmlessly re-syncs the baseline to the switched war. */
  lwRegisterCommands()
  LW_BASELINE = state
  LW_READY = true
}

export function lwCanUndo(): boolean {
  return HIST.ix > 0
}
export function lwCanRedo(): boolean {
  return HIST.ix < HIST.stack.length - 1
}

/** Bumped on every restore (undo OR redo). The matrix watches it to drop any
 *  transient gesture state a restore would otherwise strand — an in-progress
 *  MOVE, an open selection, a landing preview — the way the schedule's undo
 *  calls armDrop/prunePreviews. Without it, undoing mid-move left the grid in
 *  move mode with a selection whose cells the undo had just cleared, so the
 *  next drag was read as a move-landing and no sheet opened (bug test, 30 Aug
 *  26). A plain notify is too broad to key off — a sync pass mid-move would
 *  cancel it — so this fires for a restore and nothing else. */
let historyEpoch = 0
export function lwHistEpoch(): number {
  return historyEpoch
}
/* [GLOBAL-UNDO] §13 phase 2 (Fable N5) — bump the epoch from the GLOBAL restore
   path too. The legacy historyApply bumps it inside itself so the matrix drops an
   in-flight drag/select; a globalUndo/globalRedo restores LW through the write()
   seam, which does NOT run historyApply, so the undo consumer bumps it explicitly
   (in the restore epilogue) to get the same "drop the gesture" signal. */
export function bumpLwHistEpoch(): void { historyEpoch++ }

/** Restore snapshot `i`. Locked across the whole apply so neither the restore
 *  itself nor the sync reconcilers `notify()` wakes push a new step; the
 *  `notify()` inside the lock is what lets sync converge the Raptor side to the
 *  restored grid. */
function historyApply(i: number): void {
  if (i < 0 || i >= HIST.stack.length) return
  const snap = JSON.parse(HIST.stack[i]) as Pick<State,
    'wars' | 'openings' | 'ledger' | 'oilPolicy' | 'eventDefs' | 'figureOrder' | 'rosterOrder'
    | 'persLabels' | 'manningOrder' | 'manningHidden' | 'figureHidden' | 'groupDefs'
    | 'groupPriority' | 'groupPriorityCustom' | 'requirements' | 'eventRows' | 'showSans'>
  HIST.ix = i
  historyEpoch++   // signal the matrix to drop any in-flight gesture (see above)
  locked(() => {
    // withCurrent republishes period/grid/states from the restored wars and
    // the CURRENT currentId — the war on screen does not change, only its data.
    state = withCurrent({ ...state, ...snap })
    // [CMDL-FINISH] C4 — a legacy LW undo/redo is NOT a new edit: persist it
    // OFF-STREAM (rawPersist, no projection, wakes no reconcile as a command).
    // The reconcilers still converge the Raptor side via the rawNotify inside.
    const was = LW_RESTORING; LW_RESTORING = true
    try { persistNotify() } finally { LW_RESTORING = was }
  })
}

/** Step back / forward one edit. No-ops (not errors) at the ends, so the
 *  buttons may call them freely and read lwCanUndo / lwCanRedo for disabled. */
export function lwUndo(): void {
  if (lwCanUndo()) historyApply(HIST.ix - 1)
}
export function lwRedo(): void {
  if (lwCanRedo()) historyApply(HIST.ix + 1)
}

/**
 * Set while a multi-day write is in flight, so `updateCurrent` builds the
 * state and skips the save and the notify. The caller releases it and does
 * both once.
 *
 * A module-level flag rather than a batching API, because there is exactly
 * one batching caller and JavaScript here is single-threaded: nothing can
 * interleave between setting it and clearing it. `setCellRange` clears it in
 * a `finally`, so a throw mid-range cannot leave the store permanently
 * silent — which is the one failure this shape could otherwise have.
 */
let quiet = false

/** Replace the war on screen, republish the derived fields, save and
 *  notify. Every write to a cell, a decision or a stage goes through here,
 *  so none of them can update a war without the interface following. */
function updateCurrent(fn: (war: LeaveWar) => LeaveWar): void {
  updateWar(state.currentId, fn)
}

/** As updateCurrent, but for a NAMED war — the Raptor ingest/clear pair
 *  writes into whichever war holds the input's date, which need not be the
 *  one on screen. Same save-and-notify epilogue, same `quiet` batching. */
function updateWar(id: string, fn: (war: LeaveWar) => LeaveWar): void {
  const wars = state.wars.map((w: LeaveWar) => (w.period.id === id ? fn(w) : w))
  state = withCurrent({ ...state, wars })
  if (quiet) return
  persistNotify()
}

/* (setPerson — the war's own seat / band / SXO writer behind its "Edit person"
   sheet — is GONE: D460, D461, 30 Sep 26. A man's seat, band and SXO change only
   on Quals; the war shows what the projection says.) */

/**
 * Post a person OUT from a date, or clear it (owner, 18 Aug 26 — "PO… they are
 * not counted in the manpower… grey with diagonal stripe through the boxes").
 *
 * `fromDate` is the first day they are GONE, so their last day in the squadron
 * is the day before — `to = fromDate − 1`. Everything from `fromDate` on then
 * reads as posted out: `inSquadron` is false there, which the grey `.gone`
 * hatch and the `PO` chip already key off, and which every manning count
 * (`countsFor` → `availabilityOf`) already treats as zero. `null` clears the
 * post-out (the undo). ADMIN-gated, checked here — the role switch is an
 * affordance, so the store is the only place it can mean anything.
 *
 * ANY date is legal, not just a day of the loaded war (owner, 19 Aug 26 —
 * "prior to this date to infinity… now till the future infinity… and also
 * custom dates"): a past date strikes the person's whole history from there,
 * a date beyond the war's end simply has nothing on screen to grey yet. Only
 * a malformed string is refused — same line as every guard rail: refuse
 * malformed data, never a decision.
 *
 * `archive` is the sheet's "Archive on PO date" switch (default ON): when the
 * date arrives, sync.ts's auto-archive pass moves the Raptor body into the
 * Quals archive. Stored explicitly true/false so a `to` that was NOT set
 * through this path (the demo overlay) stays untouched by that pass; clearing
 * the post-out clears the flag with it.
 *
 * Session-only like the rest of this store, and safe against the live
 * re-projection: `reprojectRoster` refreshes each person's identity from
 * Raptor's projection but preserves posting-out (`from`/`to`/`poArchive`)
 * explicitly, so this window survives every Raptor notify.
 */
export function setPostOut(id: string, fromDate: string | null, archive: boolean | PostOutcome = true): boolean {
  if (state.role !== 'admin') return false
  if (fromDate !== null && !/^\d{4}-\d{2}-\d{2}$/.test(fromDate)) return false
  const person = state.people.find(p => p.id === id)
  if (!person) return false
  /* a DELETED man's posting is final ([POST-OUT-OUTCOMES], D287 — Fable F3): no door changes it or takes it back */
  if (person.gone) return false
  if (postingLocked(id)) return false               // archived on Admin → Users — Restore there ([ONE-DOOR])
  /* WHICH posting it is (D229, D294): the four chips' outcome; the old switch reads the old way — on = overseas
     (archived), off = none. `poArchive` is kept in step for the readers that still name it. */
  const outcome: PostOutcome = typeof archive === 'string' ? archive : (archive ? 'overseas' : 'none')
  if (!POST_OUTCOMES.includes(outcome)) return false
  const to = fromDate ? addDays(fromDate, -1) : null
  /* A window that closes before it opens is not a decision, it is a typo, and
     it would hide the person on EVERY date at once (`inSquadron` answers false
     both sides). Refused here rather than clamped: silently moving the other
     end would be the app deciding a posting date for the admin. */
  if (to !== null && person.from !== null && to < person.from) return false
  /* `poDone` — the outcome has run for this date — survives only while the date AND the outcome are unchanged: a
     changed posting runs again on its own date (the plan's Round 2, Fable 5) */
  const same = !!fromDate && person.to === to && outcomeOf(person) === outcome
  const people = state.people.map(p =>
    (p.id === id ? {
      ...p, to,
      poArchive: fromDate ? outcome === 'overseas' : undefined,
      poOutcome: fromDate ? outcome : undefined,
      poDone: same ? p.poDone : undefined,
    } : p))
  state = withCurrent({ ...state, people, postOuts: windowRecord(people, id) })
  persistNotify()
  return true
}

/* does this person have an account? — the posting's one line says "account suspended" / "with his account" only then
   ([POST-OUT-OUTCOMES]). The war never reads Raptor's accounts itself: the sync (the one seam) installs the answer. */
let ACCOUNT_LOOKUP: ((id: string) => boolean) | null = null
export function setAccountLookup(fn: ((id: string) => boolean) | null): void { ACCOUNT_LOOKUP = fn }
export const hasAccount = (id: string): boolean => !!(ACCOUNT_LOOKUP && ACCOUNT_LOOKUP(id))
/* would this posting's outcome be held back on its date — the last admin who can sign in is never deleted, nor his
   account suspended, by a posting (the plan's Round 2, Fable 3: the sheet says so, not only a one-time message). The
   sentence, or null; installed by the sync, like the account lookup above. */
let BLOCK_LOOKUP: ((id: string, outcome: PostOutcome) => string | null) | null = null
export function setPostingBlockLookup(fn: ((id: string, outcome: PostOutcome) => string | null) | null): void { BLOCK_LOOKUP = fn }
export const postingBlocked = (id: string, outcome: PostOutcome): string | null => (BLOCK_LOOKUP ? BLOCK_LOOKUP(id, outcome) : null)
/* a man archived on Admin → Users: his posting dates are READ-ONLY on the war — Restore there is the one way back
   ([ONE-DOOR], round 1 Fable F1; the walk's design, Fable 4.2 / 4.3, 27 Sep 26: the Post out sheet alone was locked, and
   the Post in sheet could still move or clear his post-in under the stint Archive had closed). Both writers ask it, so
   no door can go round it. The sentence, or null; installed by the sync, like the lookups above. */
let LOCK_LOOKUP: ((id: string) => string | null) | null = null
export function setPostingLockLookup(fn: ((id: string) => string | null) | null): void { LOCK_LOOKUP = fn }
export const postingLocked = (id: string): string | null => (LOCK_LOOKUP ? LOCK_LOOKUP(id) : null)

/** THE POSTING WINDOW A STORED RECORD LAYS ON ITS PERSON — the ONE body `setPeople` and the sync's re-projection both
 *  use ([POST-OUT-OUTCOMES]; Astra's plan read A4: two overlays laying it differently would defeat the SANS rule).
 *  D283: a SANS posting with "Show SANS" ON lays NO window — from the date he is a SANS man, in the SANS group and
 *  tracked there; with it OFF the window is laid — his old place, posted out, untracked. The deleted man's `gone`
 *  rides the record. */
export function windowFor(w: Person | undefined, showSans: boolean): Partial<Person> {
  if (!w) return {}
  /* …only once the posting has RUN (`poDone` is its date): before it, a SANS posting to come shows as any posting does —
     hatched from its date, its Post out sheet the door to change or undo it (Fable's scenario 3, 27 Sep 26: with Show
     SANS on, a SANS posting to come left no trace on the grid and no door) */
  const sansShown = outcomeOf(w) === 'sans' && showSans && w.to !== null && w.poDone === addDays(w.to, 1)
  return {
    from: w.from, to: sansShown ? null : w.to, poArchive: w.poArchive, poOutcome: w.poOutcome, poDone: w.poDone,
    /* D320: his closed earlier stints ride with the current one, whatever Show SANS says (D283 acts on the current) */
    past: w.past && w.past.length ? w.past : undefined,
    ...(w.gone ? { gone: true } : {}),
  }
}

/** A posting's outcome has RUN for its date (sync.ts runPoOutcomes) — recorded once, so the pass never repeats it and
 *  never undoes a later hand change (the plan's Round 1). Quiet: inside the pass's own command. */
export function markPostingDone(id: string, poDate: string): void {
  /* the RECORD is updated in place — never rebuilt from the person: a SANS posting shown with Show SANS on lays no
     window on him (windowFor), so rebuilding it from the person threw the posting away (found 27 Sep 26 — the posting
     could then never be taken back) */
  const rec = state.postOuts[id]
  if (!rec) return
  const people = state.people.map(p => (p.id === id ? { ...p, poDone: poDate } : p))
  state = withCurrent({ ...state, people, postOuts: { ...state.postOuts, [id]: { ...rec, poDone: poDate } } })
  persistNotify()
}

/* THE WAR'S PICTURE OF A MAN IT DOES NOT SHOW RIGHT NOW (a SANS man with Show SANS off; an archived man with no row) —
   the projection's `identity` with HIS OWN stored posting record laid on, as `setPeople` lays it. The projection knows
   nothing of his dates (`from: null`), so without this an archive, a restore or a delete rebuilt his record from it and
   his post-in date was lost — his months before it then read as "here" (the walk's design, Fable 4.4, 27 Sep 26: every
   new person has a post-in date since D308). */
function withStored(identity: Person): Person {
  const w = state.postOuts[identity.id]
  return w ? { ...identity, ...windowFor(w, false) } : identity
}
/* …and a man the war DOES show: his DATES are still his stored record's, never the displayed row's — Show SANS lays no
   window on a man whose SANS posting has run (D283), a display choice that must not decide what an Archive or a delete
   stores (the final code read, Fable F1, 27 Sep 26: the same Archive stored two dates as the switch stood) */
function dated(p: Person): Person {
  const w = state.postOuts[p.id]
  return w ? { ...p, ...windowFor(w, false) } : p
}

/** A DELETED man's war half ([POST-OUT-OUTCOMES], D287, D297, D299): his records dated on or after `iso` go from every
 *  war (requests, credits, notices — "his future leave, bids" and "his Leave War row after he left"); his posting
 *  window closes the day before (kept if it already closes earlier); he is marked `gone` — kept as a posted-out man is,
 *  so the months he was here keep his leave and OIL. Runs ONLY inside the delete's command (sync.ts
 *  deletePersonOnWar enlists this store); the command's gate has decided, so no role check here. */
export function forgetPersonFrom(id: string, iso: string, frozen: Person | null = null): void {
  const wars = state.wars.map(w => {
    const pr = (w.recs as any)?.[id]
    if (!pr) return w
    const kept: any = {}
    let n = 0
    for (const d of Object.keys(pr)) { if (d < iso) kept[d] = pr[d]; else n++ }
    if (!n) return w
    return { ...w, recs: { ...(w.recs as any), [id]: kept } }
  })
  const last = addDays(iso, -1)
  const had = state.people.some(p => p.id === id)
  /* a man the war did not show (a SANS man with Show SANS off) with a past to keep: his row comes back as the war drew
     him (`frozen` — the seam passes it only when he has a record from the months he was here: a war record, or an
     input, which the war cannot see), closed the day before and `gone`, so those months keep his leave and OIL whatever
     Show SANS says after (D299; Astra 3, Fable 3) */
  const hadPast = !had && !!frozen
  /* D320: his earlier stints are cut at the cutoff too (one opening on or after it goes), and a current stint that would
     open after it is DROPPED — the last past stint becomes current again, never a stint closing before it opens
     (round 1, Fable F4 / Astra 3) */
  /* …and a man who never arrived (his only stint still to come, no earlier one) has no months to keep: his row and his
     record go — never a stint closing before it opens (the walk's design, Fable 4.5, 27 Sep 26) */
  const cut = (p: Person): Person | null => {
    const past = (p.past || []).filter(s => s.from === null || s.from < iso).map(s => ({ from: s.from, to: s.to < last ? s.to : last }))
    if (p.from !== null && p.from > last) {
      if (!past.length) return null
      const prev = past.pop()!
      return { ...p, from: prev.from, to: prev.to, past: past.length ? past : undefined, gone: true }
    }
    return { ...p, to: p.to !== null && p.to < last ? p.to : last, past: past.length ? past : undefined, gone: true }
  }
  const back = hadPast ? cut(withStored(frozen as Person)) : null
  const people = had
    ? state.people.flatMap(p => (p.id === id ? (cut(dated(p)) ?? []) : [p]))
    : back ? [...state.people, back] : state.people
  const kept = people.some(p => p.id === id)
  const { [id]: _dropped, ...rest } = state.postOuts
  const postOuts = kept ? windowRecord(people, id) : had || hadPast ? rest : state.postOuts
  /* HIS OIL AWARDS FROM THE CUTOFF GO TOO — what the delete took when they were war records ([OIL-AWARD-IS-A-GRANT],
     the award plan §2.6a); his past awards stay (D299), corrections and other pools are untouched, as before. An
     archive takes nothing (D323). */
  const ledger = state.ledger.some(e => e.personId === id && isOilAward(e) && e.date >= iso)
    ? state.ledger.filter(e => !(e.personId === id && isOilAward(e) && e.date >= iso))
    : state.ledger
  state = withCurrent({ ...state, wars, people, postOuts, ledger })
  persistNotify()
}

/**
 * Post a person IN from a date, or clear it (owner, 20 Sep 26 — "we need a
 * post in button just like post out. Because those dates are official dates").
 *
 * `date` is the first day they ARE here, stored straight onto `from`; the
 * post-out sheet's date is the first day they are GONE, so the two read the
 * same way round on screen ("PI from", "PO from") while landing on opposite
 * ends of the window. `null` clears it, which is the undo.
 *
 * Before this existed `from` was ALWAYS null — the Raptor projection has no
 * joining date to give — so every person read as having always been here.
 * That is why answer C's "a pre-joining day may be bid on" had nothing to
 * stand on: there were no pre-joining days.
 *
 * The date is OFFICIAL and nothing more: it decides manning (`inSquadron`,
 * `availabilityOf`) and the grey hatch, and it deliberately does NOT decide
 * what may be filed. A man can be on leave before he posts in and after he
 * posts out (the owner, same ruling), so records outside the window are
 * allowed, shown and charged — the row stretches to reach them (`rowInWindow`)
 * without the official dates moving an inch.
 *
 * Same guard rails as the post-out: admin-gated in the store because the role
 * switch is only an affordance, any real date accepted, only malformed strings
 * refused, and the window preserved across every Raptor re-projection.
 */
export function setPostIn(id: string, date: string | null): boolean {
  if (state.role !== 'admin') return false
  if (date !== null && !/^\d{4}-\d{2}-\d{2}$/.test(date)) return false
  const person = state.people.find(p => p.id === id)
  if (!person) return false
  if (person.gone) return false                   // a deleted man's posting is final (Fable F3)
  if (postingLocked(id)) return false             // archived on Admin → Users — Restore there ([ONE-DOOR])
  if (date !== null && person.to !== null && date > person.to) return false
  /* D320: back from a posting — his post-in may move, but never onto or before the day his last stint closed, and it is
     never cleared (that would lay "here from always" over the stint he left — past stints are read-only on the war) */
  const lastPast = person.past && person.past.length ? person.past[person.past.length - 1] : null
  if (lastPast && (date === null || date <= lastPast.to)) return false
  /* the day after his earlier stint closed JOINS the two — one stint, no boundary, no "posted out" corner on a day he
     never left (the final code read, Fable F3; the same join Restore makes, `openStint`, Fable F5) */
  const joins = !!lastPast && date === addDays(lastPast.to, 1)
  const rest = joins ? person.past!.slice(0, -1) : person.past
  const people = state.people.map(p => (p.id === id
    ? (joins ? { ...p, from: lastPast!.from, past: rest && rest.length ? rest : undefined } : { ...p, from: date })
    : p))
  state = withCurrent({ ...state, people, postOuts: windowRecord(people, id) })
  persistNotify()
  return true
}

/** WHY A POSTING DATE WOULD BE REFUSED — the sentence every posting door shows (the absence-record re-test, AB5,
 *  26 Sep 26). `setPostOut` / `setPostIn` refuse a window that closes before it opens, and every sheet swallowed that
 *  refusal: the bid sheet's confirm closed as though it had worked, the posting sheets' date box snapped back, the
 *  drag-selection's sheet reported done — and nothing was said (Fable F5, reproduced on screen). The doctrine: a
 *  refused value is put back AND the person is told. The same tests as the two writers, so the words and the refusal
 *  cannot disagree; null when the date would be taken. Dates in the sheets' own voice (they print 2026-06-15). */
export function postingProblem(id: string, kind: 'in' | 'out' | 'restore', date: string, identity?: Person): string | null {
  const person = state.people.find(p => p.id === id) || identity
  if (!person) return null
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return 'Pick a whole date first.'
  if (kind !== 'restore') { const locked = postingLocked(id); if (locked) return locked }
  /* the day-first date voice ("15 Jun 26" — ui/dates.ts shortDate's wording), never the stored 2026-06-15 (the
     absence-record re-test's re-walk: this sentence first printed the machine date; `[LW-ISO-DATES]` is the rest) */
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  const said = (iso: string) => `${Number(iso.slice(8, 10))} ${MON[Number(iso.slice(5, 7)) - 1]} ${iso.slice(2, 4)}`
  /* D320 (round 1, Fable F2 / Astra 1): a man back from a posting — his EARLIER stint's dates are read-only here */
  const lastPast = person.past && person.past.length ? person.past[person.past.length - 1] : null
  if (lastPast && person.from !== null && ((kind === 'out' && addDays(date, -1) < person.from) || (kind === 'in' && date <= lastPast.to)))
    return `${person.callsign} was posted out on ${said(addDays(lastPast.to, 1))} and came back on ${said(person.from)} — an earlier stint's dates can't be moved here.`
  if (kind === 'out' && person.from !== null && addDays(date, -1) < person.from)
    return `Posted in on ${said(person.from)} — the post-out has to be after that day.`
  if (kind === 'in' && person.to !== null && date > person.to)
    return `Posted out from ${said(addDays(person.to, 1))} — the post-in has to be before that day.`
  /* Restore's post-in date (D308, D320): after the day his stint closed (the day after reopens it — Fable F5) */
  if (kind === 'restore') {
    const closed = person.to !== null ? person.to : lastPast ? lastPast.to : null
    if (closed !== null && date <= closed) return `Posted out from ${said(addDays(closed, 1))} — the post-in has to be on or after that day.`
  }
  return null
}

/** RESTORE'S WAR HALF ([ONE-DOOR], owner D308 and D320, 27 Sep 26): he is back from `date`. His current stint, if a
 *  posting closed it, goes into `past` and a new one opens `{ from: date, to: null }` with no posting on it; a post-in
 *  on the day after it closed REOPENS that stint instead (no boundary — round 1, Fable F5); an open current stint (never
 *  posted out) simply starts on `date`. Refused on or before the day his stint closed (`postingProblem(…, 'restore')`
 *  says why). `identity` — the war's picture of a man it does not show right now (archived with no window, a SANS man
 *  with Show SANS off), laid on as the delete's `frozen` is. Runs inside Restore's command (leavewar/sync.ts). */
export function openStint(id: string, date: string, identity?: Person): boolean {
  if (state.role !== 'admin') return false
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return false
  const person = state.people.find(p => p.id === id) || (identity && withStored(identity))
  if (!person || person.gone) return false
  if (postingProblem(id, 'restore', date, person)) return false
  const clear = { poArchive: undefined, poOutcome: undefined, poDone: undefined }
  let next: Person
  if (person.to !== null) {
    next = date === addDays(person.to, 1)
      ? { ...person, to: null, ...clear }
      : { ...person, past: [...(person.past || []), { from: person.from, to: person.to }], from: date, to: null, ...clear }
  } else next = { ...person, from: date, ...clear }
  const had = state.people.some(p => p.id === id)
  const people = had ? state.people.map(p => (p.id === id ? next : p)) : [...state.people, next]
  state = withCurrent({ ...state, people, postOuts: windowRecord(people, id) })
  persistNotify()
  return true
}

/** ARCHIVE'S WAR HALF ([ONE-DOOR], owner D323, 27 Sep 26 — "posted out from today", his past kept): the current stint
 *  closes the day before `today`, as a posting that has RUN (outcome overseas, `poDone` its own posting date — Fable F9)
 *  so the posting pass never repeats it; a stint a posting already closed keeps its date; a posting still to come is
 *  replaced (its outcome returned, for the message — Fable F13); a stint not yet begun is DROPPED — the last past stint
 *  becomes current again, or, with none, no stint is closed (he was never here) — never a stint closing before it opens
 *  (round 1, Fable F4 / Astra 3). `identity` as in `openStint`. Runs inside Archive's command (leavewar/sync.ts); the
 *  command's gate has decided who may, so no role check here (as `forgetPersonFrom`). */
export function closeStintOnArchive(id: string, today: string, identity?: Person): { replaced: PostOutcome | null } {
  const shown = state.people.find(p => p.id === id)
  const person = shown ? dated(shown) : (identity && withStored(identity))
  if (!person || person.gone) return { replaced: null }
  const yesterday = addDays(today, -1)
  /* a posting that has not RUN yet (its date to come — or come, with nothing repainted since midnight, or held) is
     replaced; one that has run keeps its date (the final code read, Fable F5: the date alone called a due-today posting run) */
  const pending = person.to !== null && person.poDone !== addDays(person.to, 1) ? outcomeOf(person) ?? null : null
  let next: Person = person
  if (person.to === null || person.to > yesterday) {
    if (person.from !== null && person.from > yesterday) {
      const past = [...(person.past || [])]
      const prev = past.pop()
      next = prev ? { ...person, from: prev.from, to: prev.to, past: past.length ? past : undefined } : { ...person, to: null }
    } else next = { ...person, to: yesterday }
  }
  next = next.to !== null
    ? { ...next, poArchive: true, poOutcome: 'overseas', poDone: addDays(next.to, 1) }
    : { ...next, poArchive: undefined, poOutcome: undefined, poDone: undefined }
  const had = state.people.some(p => p.id === id)
  const people = had ? state.people.map(p => (p.id === id ? next : p)) : [...state.people, next]
  state = withCurrent({ ...state, people, postOuts: windowRecord(people, id) })
  persistNotify()
  return { replaced: pending && pending !== 'none' ? pending : null }
}

/* The persisted squadron window (State.postOuts): the person as they stand
   now, kept while EITHER end is set — or he has a closed earlier stint (D320) —
   and dropped once all are clear. One body so the ends cannot disagree about
   when the record goes. */
function windowRecord(people: Person[], id: string): Record<string, Person> {
  const next = { ...state.postOuts }
  const p = people.find(x => x.id === id)!
  if (p.from !== null || p.to !== null || (p.past && p.past.length)) next[id] = p
  else delete next[id]
  return next
}

/**
 * Install the roster. The one production caller is main.tsx's boot, which
 * hands in the projection of Raptor's PEOPLE (state/raptorRoster.ts, plus
 * the demo overlay in state/demoworld.ts).
 *
 * Deliberately NOT persisted, mirroring setRole: the projection is derived
 * from Raptor's roster on every boot, so a stored copy could only ever
 * disagree with it. Raptor's Quals page owns identity — the war has no writer
 * of its own for a seat, a band or SXO (D460, D461).
 */
export function setPeople(people: Person[]): void {
  /* Lay Leave War's own record over the projection (State.postOuts, persisted
     since 8 Sep 26): a stored posting-out window goes back onto its person, and a person
     with a window whom the projection no longer has (archived when the date
     arrived) is put back from the frozen copy — reprojectRoster's keep rule,
     which used to hold only within a session. Empty records make this the
     plain install it always was. */
  const po = state.postOuts
  const next: Person[] = people.map(p => {
    const w = po[p.id]
    return w ? { ...p, ...windowFor(w, state.showSans) } : { ...p }
  })
  const ids = new Set(next.map(p => p.id))
  /* `.to`, not merely a record (22 Sep 26). The comment above says what this is
     for and says the other half out loud: a body archived WITHOUT a posting-out
     window leaves at once, because that ✕ meant "should never have been here".
     [ONE-DOOR] (D323, 27 Sep 26 — "Ok what u recommend"): the Quals ✕ is gone; Archive
     on Admin → Users is "posted out from today" — it closes his stint (closeStintOnArchive),
     so an archived man keeps his row and his months here keep their record. What
     still leaves at once is a man archived with no stint closed (his post-in was still
     to come — he was never here).
     The test was membership of `postOuts`, which `windowRecord` fills from
     EITHER end — so a man with only a JOINING date who was then archived came
     back anyway. It lasted a session before, because the boot reader discarded
     a record with no leaving date; now that the reader keeps one (a joining date
     is an official date too), it would have lasted for good. */
  for (const id of Object.keys(po)) if (!ids.has(id) && po[id].to) next.push(po[id])
  /* AND A WINDOW THAT ARRIVES WITH THE PROJECTION IS RECORDED (the walk's F1 and
     F2, 22 Sep 26 — two reported defects, one cause).
     This body laid the stored record ON but never took one OFF, and the one
     writer that puts a window straight onto a person is the demo overlay
     (state/demoworld.ts, first boot only). So the single window the app writes
     for itself was the single window it never saved: next reload the man was
     back in the squadron, and every reader of who is available answered
     differently with nobody having touched anything.
     On an ISSUED day that is money. The men behind an ALL / ALL AVAIL puck are
     frozen at publication (D44), so the working copy gained a man the issued
     copy did not have — the day reopened as "1 pending" and cleared its four
     signatures for an amendment nobody made, and the count beside the puck read
     one higher than the Leave War would ever pay.
     It is caught HERE, not in the overlay, because this is the one body that
     owns the record: catching it at the seam makes "a window on a person with no
     record behind it" a state the store cannot be left in, rather than a rule
     the next writer has to remember. `setPostOut` already records its own, so
     this never fires for it; an admin who CLEARS a window leaves no window to
     catch, so a cleared one is never resurrected. */
  const caught: Record<string, Person> = {}
  for (const p of next) if (!po[p.id] && (p.from != null || p.to != null || (p.past && p.past.length))) caught[p.id] = p
  const got = Object.keys(caught).length > 0
  state = withCurrent({ ...state, people: next, ...(got ? { postOuts: { ...po, ...caught } } : {}) })
  /* A CAPTURE IS A PROJECTION, NEVER AN EDIT (the independent code read, F6).
     At boot the command router is not on yet — `LW_READY` is set by
     `lwHistInit`, which main.tsx calls AFTER the demo world installs — so this
     is a raw seed persist and nothing more, which is what it should be. If it
     ever fires AFTER boot, a bare `persistNotify` at idle would route as
     `lw.edit`: a change-stream envelope and an UNDO STEP for a change nobody
     made, labelled as a Leave War edit. `lwSyncTurn` files it as the
     reconciliation it is.
     Nothing reaches it today — `projectPeople` emits no window, `setPerson`
     cannot carry one, and the global undo DEFERS `lw.postouts` — so this is a
     belt. It stops being one the day `[GLOBAL-UNDO]` phase 5 lifts that
     deferral: an undo of a posting-out would then restore the RECORD without
     re-laying the person, and the next roster change would re-capture the
     window the admin had just undone, silently and persisted.
     `lwSyncTurn` ALONE IS NOT ENOUGH, and the test is what showed it: the
     router's gate is `HIST.lock || cmdIsCommitting()`, not the turn flag, so a
     bare `lwSyncTurn(persistNotify)` at idle still fell straight through to
     `lw.edit` and the turn's trailing projection never armed. `locked` is what
     puts it on the reconciler's branch — the same pairing `sync.ts` uses for
     `runOilPass`. */
  if (got) { if (LW_READY) lwSyncTurn(() => locked(persistNotify)); else persistNotify() } else notify()
}

/**
 * The roster in display order (owner, 18 Aug 26). ALWAYS grouped: every group
 * in `GROUP_ORDER`, and WITHIN each group the members ordered by the admin's
 * hand-order (or the categorised default). Grouping the output — rather than
 * returning a flat hand-order — means the groups are always contiguous, so the
 * matrix draws exactly one heading per group; a cross-group drag reorders a
 * person within their own group (they cannot leave the category their CAT puts
 * them in) instead of stranding a row under a duplicated heading.
 */
export function displayRoster(saved: string[] = state.rosterOrder): Person[] {
  /* `saved` defaults to the stored hand order; rosterFollowsDefault asks with an empty one — the default display */
  const order = saved.length ? saved : liveAutoOrder()
  const pos = new Map(order.map((id, i) => [id, i]))
  const out: Person[] = []
  /* The groups the ADMIN configured, in their display order, and the priority
     order that decides who claims a person fitting several (owner, 28 Aug 26;
     following the page by default since 3 Sep 26). With the default list this is
     byte-identical to the old GROUP_ORDER walk — `groupOf` is that same walk. */
  const defs = groupsInOrder()
  const priority = groupPriorityIds()
  const home = new Map(state.people.map(p => [p.id, assignGroup(p, defs, priority)]))
  /* Within a block: every pilot above every WSO, ALWAYS (owner, 3 Sep 26 —
     "arrange all pilots at the top always and wso at the bottom of the same
     section"), and inside each seat the hand-order (or the ranked default). A
     drag that would carry a WSO up among the pilots lands them at the top of the
     WSOs instead — the seat split is not something a drag can undo. A body
     missing from the saved order (just arrived) sinks to the end of its seat
     rather than jumping to the top. */
  const within = (a: Person, b: Person) =>
    seatRank(a) - seatRank(b) || (pos.get(a.id) ?? Infinity) - (pos.get(b.id) ?? Infinity)
  for (const d of defs) {
    const members = state.people.filter(p => home.get(p.id) === d.id)
    members.sort(within)
    out.push(...members)
  }
  /* Anyone no configured group claims still gets a row — under "Everyone else",
     always last. Without this an admin whose list is all qualifications would
     drop people off the grid entirely. */
  const rest = state.people.filter(p => !defs.some(d => home.get(p.id) === d.id))
  rest.sort(within)
  out.push(...rest)
  return out
}

/** The configured group list, pruned to the live qual catalogue and in the
 *  admin's display order. One body, so every reader agrees.
 *
 *  While `showSans` is on, the SANS group is APPENDED at the foot (owner, 3 Sep
 *  26 — SANS as their own category at the bottom). It is auto-injected here, never
 *  stored, so it can never be dragged, removed or persisted like the rest — it
 *  appears and leaves with the Show SANS switch alone. */
export function groupsInOrder(): GroupDef[] {
  const defs = pruneGroups(state.groupDefs.length ? state.groupDefs : DEFAULT_GROUPS, state.qualCatalog)
  const ids = orderedGroupIds(defs, state.groupDefs.map(d => d.id))
  const ordered = ids.map(id => defs.find(d => d.id === id)!).filter(Boolean)
  return state.showSans ? [...ordered, SANS_GROUP] : ordered
}

/**
 * The tie-break order — who claims a person matching several groups.
 *
 * By DEFAULT it FOLLOWS the display order (owner, 3 Sep 26 — "the priority order
 * should also change by default in accordance with the category order"): the group
 * higher on the page wins. Only once the admin sets a CUSTOM order
 * (`groupPriorityCustom`) does the stored `groupPriority` take over, healed against
 * the groups that exist.
 *
 * SANS is forced to the FRONT whenever shown, independent of custom/auto: it sits
 * LAST on the page but must still CLAIM its own people, or a SANS body would be
 * drawn under its CAT instead of the SANS group at the foot.
 */
export function groupPriorityIds(): string[] {
  const groups = groupsInOrder()
  const base = state.groupPriorityCustom
    ? orderedGroupIds(groups, state.groupPriority)
    : groups.map(d => d.id)
  if (!state.showSans) return base
  return [SANS_GROUP_ID, ...base.filter(id => id !== SANS_GROUP_ID)]
}

/** Whether the admin has set a custom who-wins order (the settings sheet shows a
 *  "Match the page order" reset only then). */
export function isGroupPriorityCustom(): boolean {
  return state.groupPriorityCustom
}

/** Which group a person is drawn under, for callers that need the answer
 *  without walking the whole roster (the group editor's counts, the matrix). */
export function groupIdOf(p: Person): string {
  return assignGroup(p, groupsInOrder(), groupPriorityIds())
}

/** Every group an admin can pick from — the seven built-ins plus one per
 *  qualification the squadron currently has. Grows on its own. */
export function offerableGroupList(): GroupDef[] {
  return offerableGroups(state.qualCatalog)
}

/** Replace the group list (add / remove / reorder). ADMIN-gated, like every
 *  other arrangement writer. Pruned on the way in so a stale qualification
 *  cannot be stored back. */
export function setGroupDefs(defs: GroupDef[]): void {
  if (state.role !== 'admin') return
  // SANS is auto-managed by the Show SANS switch — never let it into the stored
  // list, whatever a caller passes.
  const cleaned = defs.filter(d => d.id !== SANS_GROUP_ID)
  const groupDefs = pruneGroups(cleaned, state.qualCatalog)
  state = withCurrent({ ...state, groupDefs, groupColors: colorsFor(groupDefs, state.groupColors) })
  persistNotify()
}

/** A picked colour lives and dies with its group: keep only the entries whose
 *  group is still in the list, so a removed-then-re-added group starts fresh
 *  (its fallback colour) rather than resurrecting a pick nobody can see. */
function colorsFor(defs: readonly GroupDef[], colors: Record<string, string>): Record<string, string> {
  const keep: Record<string, string> = {}
  for (const d of defs) if (colors[d.id]) keep[d.id] = colors[d.id]
  return keep
}

/** Pick a qualification group's colour (owner, 3 Sep 26 — "allow me to pick the
 *  colour i want"). ADMIN-gated; only a group currently shown, only a `q:` group
 *  (the built-ins wear their CAT colours), only a `#rrggbb` value. */
export function setGroupColor(id: string, hex: string): void {
  if (state.role !== 'admin') return
  if (!id.startsWith('q:') || !/^#[0-9a-f]{6}$/i.test(hex)) return
  if (!groupsInOrder().some(d => d.id === id)) return
  if (state.groupColors[id] === hex) return
  state = withCurrent({ ...state, groupColors: { ...state.groupColors, [id]: hex } })
  persistNotify()
}

/**
 * Add a group to the roster, landing it just ABOVE the first category in the
 * DISPLAY order.
 *
 * Since who-wins now FOLLOWS the display order by default (owner, 3 Sep 26 —
 * "higher on the page wins"), placing a new qualification group above the
 * categories is what makes it actually CLAIM its people: a qual group below the
 * exhaustive built-ins would never draw anyone (they are all claimed first). Add
 * order is preserved — it lands above the cats but after any qual groups already
 * there — so adding SC Day then SC Night keeps SC Day higher.
 *
 * In CUSTOM who-wins mode the same "above the cats" insert is mirrored into the
 * stored priority, so a new group claims its people there too. The SANS group is
 * not addable here — it is the Show SANS switch.
 */
export function addGroup(d: GroupDef): void {
  if (state.role !== 'admin') return
  if (d.id === SANS_GROUP_ID) return
  const current = groupsInOrder().filter(x => x.id !== SANS_GROUP_ID)
  if (current.some(x => x.id === d.id)) return    // already shown
  const catAt = current.findIndex(x => x.kind === 'cat')
  const insertAt = catAt < 0 ? current.length : catAt
  const merged = pruneGroups([...current.slice(0, insertAt), d, ...current.slice(insertAt)], state.qualCatalog)
  if (!merged.some(x => x.id === d.id)) return    // a qual key the catalogue lost
  let priority = state.groupPriority
  if (state.groupPriorityCustom) {
    const byId = new Map(merged.map(x => [x.id, x]))
    const pr = groupPriorityIds().filter(id => id !== d.id && id !== SANS_GROUP_ID)
    const pAt = pr.findIndex(id => byId.get(id)?.kind === 'cat')
    priority = pAt < 0 ? [...pr, d.id] : [...pr.slice(0, pAt), d.id, ...pr.slice(pAt)]
  }
  state = withCurrent({ ...state, groupDefs: merged, groupPriority: priority })
  persistNotify()
}

/** Move one group before another in the DISPLAY order (the grid drag, in
 *  rearrange mode). Mirrors `moveRosterRow` / `moveManningRowTo`, guard included.
 *  ADMIN-gated. The auto-placed SANS group at the foot is never movable; dropping
 *  a group "before SANS" means to the end of the real groups. Because who-wins
 *  follows the page by default, this drag also reorders who-wins unless the admin
 *  has set a custom order. */
export function moveGroupTo(id: string, beforeId: string | null): void {
  if (state.role !== 'admin') return
  if (beforeId === id) return
  if (id === SANS_GROUP_ID) return
  const defs = groupsInOrder().filter(d => d.id !== SANS_GROUP_ID)
  const from = defs.findIndex(d => d.id === id)
  if (from < 0) return
  const [moved] = defs.splice(from, 1)
  const target = beforeId === SANS_GROUP_ID ? null : beforeId
  const at = target ? defs.findIndex(d => d.id === target) : defs.length
  defs.splice(at < 0 ? defs.length : at, 0, moved!)
  setGroupDefs(defs)
}

/** Move one group in the PRIORITY order — the separate who-wins list in ⚙. Doing
 *  so switches who-wins to CUSTOM (owner, 3 Sep 26 — the override), so it stops
 *  following the page order. Seeds from the effective order so the first drag
 *  starts from what the admin currently sees; SANS is never part of it (it is
 *  auto-forced first). ADMIN-gated. */
export function moveGroupPriorityTo(id: string, beforeId: string | null): void {
  if (state.role !== 'admin') return
  if (beforeId === id) return
  if (id === SANS_GROUP_ID) return
  const ids = groupPriorityIds().filter(x => x !== SANS_GROUP_ID)
  const from = ids.indexOf(id)
  if (from < 0) return
  ids.splice(from, 1)
  const target = beforeId === SANS_GROUP_ID ? null : beforeId
  const at = target ? ids.indexOf(target) : ids.length
  ids.splice(at < 0 ? ids.length : at, 0, id)
  state = withCurrent({ ...state, groupPriority: ids, groupPriorityCustom: true })
  persistNotify()
}

/** Drop a custom who-wins order and go back to following the page order (owner,
 *  3 Sep 26 — the "Match the page order" reset in ⚙). ADMIN-gated; a no-op when
 *  already following the page. */
export function clearGroupPriority(): void {
  if (state.role !== 'admin') return
  if (!state.groupPriorityCustom && state.groupPriority.length === 0) return
  state = withCurrent({ ...state, groupPriority: [], groupPriorityCustom: false })
  persistNotify()
}

/** Put the roster grouping back to the seven built-ins, following the page order.
 *  ADMIN-gated. */
export function resetGroups(): void {
  if (state.role !== 'admin') return
  state = withCurrent({ ...state, groupDefs: [...DEFAULT_GROUPS], groupPriority: [], groupPriorityCustom: false, groupColors: {} })
  persistNotify()
}

/** A ground-crew body's label: the admin's override if set, else the projected
 *  default (Raptor's `flight`). */
export function personLabel(p: Person): string {
  return state.persLabels[p.id] ?? p.label ?? ''
}

/**
 * Write the roster's row order. ADMIN-gated, the `figureOrder` rule: a member
 * does not rearrange the roster (the drag handles do not render for them). An empty array clears back to the categorised default.
 */
export function setRosterOrder(order: string[]): void {
  if (state.role !== 'admin') return
  state = withCurrent({ ...state, rosterOrder: order })
  persistNotify()
}

/** The categorised default order against the ADMIN's live grouping — each group
 *  in page order, ranked within. Same shape as the engine's `autoOrder`, but
 *  bucketed by `groupIdOf` rather than the fixed seven, so a person the page
 *  order re-homes (an SXO IP under a lifted IP block) ranks among their new
 *  block instead of carrying their old block's position (owner, 3 Sep 26). */
function liveAutoOrder(): string[] {
  return autoOrder(state.people, groupIdOf, groupsInOrder().map(d => d.id))
}

/** Re-group everyone into the categorised order. Was the Auto-sort button's
 *  action; the button went with the on-grid rearrange bar (owner, 6 Sep 26 —
 *  "Auto sort will be removed"), so nothing in the UI calls this now — kept for
 *  the tests. The UI's "back to the default order" is `resetRosterOrder` below. */
export function autoSortRoster(): void {
  setRosterOrder(liveAutoOrder())
}

/** ⚙ Settings → Reset order (owner, D160, 24 Sep 26 — "9 yes"): put a hand-arranged roster back in the default order.
 *  It CLEARS the saved order rather than saving today's default as a hand order (autoSortRoster's way), so the roster
 *  goes on FOLLOWING the default: a man who joins later, or whose CAT changes, lands in his ranked place, where under a
 *  saved order he would sink to the end of his seat (displayRoster's newcomer rule). ADMIN-gated by setRosterOrder,
 *  the one writer; a roster already following the default is no write at all, so no empty Undo step is left behind. */
export function resetRosterOrder(): void {
  if (!state.rosterOrder.length) return
  setRosterOrder([])
}

/** Does the roster, as DRAWN, stand in the default order? Judged by what the grid shows, not by whether a hand order is
 *  saved (Fable's scenario F10, 26 Sep 26): a man dragged away and back leaves a saved order that draws exactly the
 *  default, and Reset order there would be a press that changes nothing on screen yet leaves an Undo step behind. The
 *  ⚙ Settings line is greyed while this is true. (A saved order equal to today's default still differs later — a man
 *  who joins sinks to the end of his seat — and the line lights again the moment it does.) */
export function rosterFollowsDefault(): boolean {
  const now = displayRoster(), dflt = displayRoster([])
  return now.length === dflt.length && now.every((p, i) => p.id === dflt[i]!.id)
}

/**
 * Move one row to sit before `beforeId` (or to the end when null) — one
 * edit-mode drag. It materialises the CURRENT display order first (so the
 * first drag off the categorised default captures where every row actually
 * was) and writes the whole new order, keeping this the one write path the
 * admin gate covers.
 */
export function moveRosterRow(id: string, beforeId: string | null): void {
  if (state.role !== 'admin') return
  /* "before itself" is where it already is — and without this guard it was
     worse than a no-op: the splice below removes `id` first, so indexOf then
     misses and the row silently jumped to the END (review hardening, 19 Aug
     26, alongside the drag machine's insert-after rework) */
  if (beforeId === id) return
  const ids = displayRoster().map(p => p.id)
  const from = ids.indexOf(id)
  if (from < 0) return
  ids.splice(from, 1)
  const at = beforeId ? ids.indexOf(beforeId) : ids.length
  ids.splice(at < 0 ? ids.length : at, 0, id)
  setRosterOrder(ids)
}

/**
 * Set (or clear) a ground-crew body's free-text label. ADMIN-gated. An empty
 * string removes the override, so the row falls back to the projected default.
 */
export function setPersLabel(id: string, label: string): void {
  if (state.role !== 'admin') return
  const persLabels = { ...state.persLabels }
  const clean = label.trim()
  if (clean) persLabels[id] = clean
  else delete persLabels[id]
  state = withCurrent({ ...state, persLabels })
  persistNotify()
}

/**
 * Re-key every person-keyed record — each war's grid and states, the
 * openings, the ledger — through `map` (old id -> new id). Ids the map does
 * not name pass through unchanged.
 *
 * This exists for exactly one caller: the boot-time demo re-key
 * (state/demoworld.ts), which dresses the seeded demo world in Raptor's real
 * crew. It does not persist itself: installDemoWorld saves the dressed world
 * once, after both demo writers, through `persistBootWorld`.
 * (CORRECTED 30 Sep 26, [DB-READINESS] group A phase 0: this said "a fresh
 * browser simply re-keys again next boot". Not since the storage seam — the
 * boot's setPeople already saved the UNDRESSED seed, so the next boot read a
 * stored war, skipped the demo, and the demo bids sat on the seed's invented
 * callsigns, on nobody's row, until someone happened to write to the war first.)
 */
export function remapPersonKeys(map: Record<string, string>): void {
  const rekey = <T,>(rows: Record<string, T>): Record<string, T> => {
    const out: Record<string, T> = {}
    for (const [id, row] of Object.entries(rows)) out[map[id] ?? id] = row
    return out
  }
  const wars = state.wars.map(w => ({ ...w, recs: rekey(w.recs) }))
  const openings = rekey(state.openings)
  const ledger = state.ledger.map(e => ({ ...e, personId: map[e.personId] ?? e.personId, ...(e.enteredBy ? { enteredBy: map[e.enteredBy] ?? e.enteredBy } : {}) }))
  state = withCurrent({ ...state, wars, openings, ledger })
  notify()
}

/**
 * Boot only: save the Leave War's world exactly as it now stands ([DB-READINESS]
 * group A, phase 0 — plan §2.8). The demo world is dressed in memory by two
 * writers that do not persist (installDemoOil, remapPersonKeys); a first boot
 * must save the DRESSED world, inside the boot group that seals the store's
 * `initialized`, or the next boot finds a started store holding the undressed
 * seed. A raw write, never a command — a boot seed write, like setPeople's
 * (its one caller is installDemoWorld's demo half; initStore has already run
 * lwHistInit, so LW_READY cannot tell boot from a session here).
 */
export function persistBootWorld(): void {
  /* [DB-READINESS] group A, phase 3 — the whole dressed world as rows, replacing the undressed seed's rows initStore
     stored (writeWorldRows), every list's order placed first */
  state = placeRecords(null, state)
  writeWorldRows()
  rawPersist()
}

/**
 * The demo OIL story (state/demoworld.ts), laid over the seed at boot — the
 * second boot-only writer beside `remapPersonKeys` and under the same
 * contract: no persist, no undo step, deterministic, and called BEFORE the
 * re-key so its seed-id keys are re-keyed with everything else. Each cell
 * lands in the war holding its date (a date no war holds is dropped — the
 * seed's wars cover 2026 and 2027 whole); states and ledger entries merge in.
 * The tests never see it — they build the store from the pristine seed.
 */
export function installDemoOil(extra: { recs: Recs; ledger: Ledger }): void {
  const wars = state.wars.map(w => {
    let recs = w.recs
    for (const [person, row] of Object.entries(extra.recs)) {
      for (const [date, list] of Object.entries(row)) {
        if (warHolding(state.wars, date) !== w) continue
        recs = withList(recs, person, date, [...recsAt(recs, person, date), ...list])
      }
    }
    return { ...w, recs }
  })
  const have = new Set(state.ledger.map(e => e.id))
  const ledger = [...state.ledger, ...extra.ledger.filter(e => !have.has(e.id))]
  state = withCurrent({ ...state, wars, ledger })
  notify()
}

/** Set which role the interface is being used as. Since the Raptor merge the
 *  one production caller is resetSession (../../state/store.ts), which
 *  derives it from the Raptor login on every login and logout — the
 *  standalone app's on-screen toggle is gone. Still unguarded, and no longer
 *  persisted: the session is the authority, so a stored copy could only
 *  disagree with it. */
export function setRole(next: Role): void {
  if (next === state.role) return
  state = withCurrent({ ...state, role: next })
  notify()
}

/** The viewing person — Raptor's "View as" selection, mirrored on every
 *  change by `setMe` (state/auth.ts) and once at boot by main.tsx. Not
 *  persisted, same reasoning as the role above. */
export function setViewer(next: string | null): void {
  if (next === state.viewer) return
  state = withCurrent({ ...state, viewer: next })
  notify()
}

/* ---- THE WAR'S OWN RECORDS: requests and credits ([ARCH-STACK] step 4) -----
   A war stores only requests, OIL credits and replaced-bid notices (see
   engine/warrecs.ts). An APPROVED absence is a Raptor Input — the war reads it
   (merge.ts) and changes it only through the ABSENCE DOOR below, which sync.ts
   installs: approve a request, un-approve / remove / move an approved leave.
   Each writer here keeps the per-address rules (one undecided request per half,
   one credit) and never lets a new record land on a time it cannot share
   (`forbiddenPair` — leave over leave, leave over a medical, leave over worked
   time), which replaces the old "Raptor owns this cell" refusal. */

/** What the absence door does, installed by sync.ts (the one Raptor seam). Each
 *  runs INSIDE the caller's gesture (one envelope) and reports per item. */
export interface AbsenceDoor {
  /** turn requests into Inputs (design §5.2 `lw.approve`) */
  approve(items: Array<{ personId: string; date: string; recId: string }>): { done: number; skipped: number; why: string[] }
  /** un-approve approved leave back into a request of `to` (`lw.decideApproved`) */
  decideApproved(items: Array<{ personId: string; date: string; iid: string }>, to: RequestState): { done: number; skipped: number; why: string[] }
  /** delete approved leave days (`lw.removeApproved`) */
  removeApproved(items: Array<{ personId: string; date: string; iid: string }>): { done: number; skipped: number; why: string[] }
  /** slide approved leave days by `delta` (`lw.moveApproved`); null = clear, else the refusal */
  moveApproved(items: Array<{ personId: string; date: string; iid: string }>, delta: number, tracked: boolean, check: boolean, skip?: ReadonlySet<string>): { reason: 'occupied' | 'window' | 'nothing'; at?: string } | null
}
let DOOR: AbsenceDoor | null = null
export function setAbsenceDoor(d: AbsenceDoor | null): void { DOOR = d }
/** The door installed now — the tests wrap it (a refusal only the commit meets must roll the move back and be said). */
export function absenceDoor(): AbsenceDoor | null { return DOOR }

/** Run a war gesture as ONE command — every cell it touches, requests and
 *  approved leave alike, lands in one envelope and one undo step (design §5.2
 *  OA-003). Inside an already-running command it simply joins. */
function gesture<T>(type: string, fn: () => T): T {
  if (cmdIsCommitting() || !LW_READY || LW_RESTORING) return fn()
  let out!: T
  const r = cmdCommit({
    type, scope: { module: 'lw', warId: state.currentId } as CmdScope,
    apply: (t) => {
      t.enlist(lwStore)
      out = fn()
      /* the per-cell persists inside ran as joined children (locked — no
         legacy undo step each); ONE unlocked persist at the seal records the
         whole gesture as one step on the legacy Leave War stack too */
      cmdDeferEffect(() => rawPersist())
    },
  })
  if ((r as any).ok === false) { REFUSED?.(); rawNotify() }
  return out
}
/* what a refused gesture must re-derive before its repaint (the absence index,
   installed by sync.ts — Codex AS4-R2-001) */
let REFUSED: (() => void) | null = null
export function setRefusalHook(fn: (() => void) | null): void { REFUSED = fn }

/** The war's own list at one address, in the war holding the date. */
function listAt(personId: string, date: string): readonly WarRec[] {
  const war = warHolding(state.wars, date)
  return war ? recsAt(war.recs, personId, date) : []
}
/** Replace the list at one address, in the war holding the date. */
function putList(personId: string, date: string, list: readonly WarRec[]): boolean {
  const war = warHolding(state.wars, date)
  if (!war) return false
  updateWar(war.period.id, w => ({ ...w, recs: withList(w.recs, personId, date, list) }))
  return true
}

/** The absence door's edit of the war's own records (sync.ts): per address,
 *  drop records by id and add new ones, as ONE write inside the caller's
 *  gesture. Not a user entry point — the door has already checked the rules. */
export function lwEditLists(edits: Array<{ personId: string; date: string; drop: string[]; add: WarRec[] }>): void {
  if (!edits.length) return
  const wasQuiet = quiet
  quiet = true
  try {
    for (const e of edits) {
      const list = listAt(e.personId, e.date).filter(r => !e.drop.includes(r.id))
      putList(e.personId, e.date, [...list, ...e.add])
    }
  } finally { quiet = wasQuiet }
  if (!quiet) persistNotify()
}

/** Would a new contribution share this address with something it may not
 *  (a filed absence, worked time, another request on the same time)?
 *  `ignore` leaves out records the write is about to replace. */
function occupiedFor(c: Contrib, personId: string, date: string, ignore: readonly WarRec[] = []): boolean {
  const staying = listAt(personId, date).filter(r => !ignore.includes(r))
  /* WORK ALWAYS LANDS; only a REQUEST is barred here.
     A CREDIT is work, and the owner ruled on 20 Sep 26 that work lands on a
     leave day and the day is flagged — so an admin typing FO/HO onto someone's
     leave must behave exactly as the published schedule does when it earns a
     credit on that day. It used to be refused, and refused SILENTLY, so the
     same two facts were kept or lost depending on which was entered first
     (Codex review, 20 Sep 26). Incoming credits are therefore never barred.

     NOR DOES IT BAR A BID ANY MORE. Clash-check B5 said "a bid made after the
     publish that overlaps published work is refused at the bid door". That was
     quoted to the owner on 20 Sep 26 with its consequence — the same Saturday's
     leave going through on the Inputs page form and refused on the grid — and
     overruled: flag it everywhere. B5's OTHER half went the same day: publishing
     KEEPS an undecided bid and flags the day (this comment said it stood, which
     was true for a few hours). `barsWrite` carries the rule for every door so
     the four cannot drift apart. */
  return [...recContribs(staying), ...absencesAt(personId, date)].some(o => barsWrite(c, o))
}

/** WHY a cell write would be refused, in the words the person needs — or null
 *  when it would go through. The picker asks this BEFORE writing, so a refusal
 *  is always explained: `setCell` answers only true/false, and the sheet used
 *  to close on a false as though it had worked, leaving no leave and no
 *  message ([S4-BUGHUNT], 20 Sep 26). Runs the same guards `setCell` runs,
 *  never a second copy of them — the `moveProblem` idiom. */
export function cellProblem(personId: string, date: string, code: string): string | null {
  if (!canEditCell(state.period, state.role, date)) return 'That day is not open for bidding — check the war and the bidding window.'
  if (!canEditRow(state.role, state.viewer, personId)) return 'You can only bid on your own row.'
  const clean = code.trim().toUpperCase()
  if (isMedical(clean)) return 'Medical is filed on the Inputs page, not here.'
  if (!clean) return null
  const list = listAt(personId, date)
  /* AN OIL AWARD IS NOT A CELL CODE ([OIL-AWARD-IS-A-GRANT], 29 Sep 26): it is a ledger entry given from the day's
     +OIL panel or the OIL tracker (`setDayAward`, `grantTo`), and `setCell` refuses FO / HO — said here in the same
     breath, so a picker that asks first is never told "fine" and then silently refused (Fable's plan read F9) */
  if (clean === 'FO' || clean === 'HO') return OIL_DOOR_MSG
  if (!isBiddable(clean) || !parseCell(clean)) return 'That is not something you can bid here.'
  const portion = portionOfCode(clean)
  const replaced = liveRequestsOn(list, portion)
  if (replaced.length === 1 && replaced[0]!.code === clean) return null
  const c: Contrib = { id: 'new', kind: 'request', code: parseCell(clean)!.type, win: requestWin(clean), state: 'pending' }
  const staying = list.filter(r => !replaced.includes(r as RequestRec))
  const blocker = [...recContribs(staying), ...absencesAt(personId, date)].find(o => barsWrite(c, o))
  if (!blocker) return null
  if (isSickCode(blocker.code)) {
    const name = blocker.code === 'ATTC' ? 'ATT C' : blocker.code
    /* a medical recorded with HOURS says them (the absence-record re-test, W5-F4, 26 Sep 26): "That day is already
       ATT C" read as the whole day to a man looking at a morning-drawn box, when the medical ran 09:00–14:00 */
    const ws = winsOf(blocker)
    const hm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
    if (ws.length === 1 && !(ws[0]![0] === FULL[0] && ws[0]![1] === FULL[1]))
      return `${name} runs ${hm(ws[0]![0])}–${hm(ws[0]![1])} that day — leave can't go over a medical.`
    return `That day is already ${name} — leave can't go over a medical.`
  }
  return `That time is already taken by ${blocker.code} — clear it first.`
}

/** WHAT A RESTORE WOULD PUT BACK THAT THE WAR'S RULES NOW REFUSE (the absence-record re-test, W3-F8, 26 Sep 26 —
 *  found by the war walker). A bid undone, a medical then filed on its day on the Inputs page, then Redo: the bid came
 *  back and stood on the sick day, where filing the same medical over a live bid replaces it (the owner's bid rule;
 *  B7 — the same rules at every door, undo and redo included). Reads the war records a restore is about to write
 *  (`lw.cell`, id `warId:personId:date`, the day's list), and for every UNDECIDED or acknowledged request that is not
 *  there now, asks the same question the bid door asks (`barsWrite` against the absences on that day). The sentence
 *  names what now holds the day. Only a request is checked: a credit is work (it lands and flags, N2), a notice is
 *  history, and nothing else on a war day is restorable over an absence. */
export function restoreBlocker(
  changes: ReadonlyArray<{ collection: string; id: string; op: string; after?: unknown }>, dir: 'undo' | 'redo',
  /* THE DAY AS IT WILL STAND AFTER THIS RESTORE (Astra's final code read, finding 1, 26 Sep 26): the absences the same
     restore leaves on each day — the bridge (sync.ts restoreAbsencesOf) works them out from the Inputs the restore
     puts back or takes away, so undoing a filing that had replaced a bid gives the bid back in one step, and a medical
     the restore keeps is judged at the hours it will have. Defaults to the day as it stands now. */
  absOf: (personId: string, date: string) => readonly Contrib[] = absencesAt,
): string | null {
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  for (const ch of changes) {
    if (ch.collection !== 'lw.cell' || ch.op === 'delete' || !Array.isArray(ch.after)) continue
    /* the id read from the right, as applyLwRecord reads it — a war id may carry a colon */
    const iDate = ch.id.lastIndexOf(':')
    const rest = ch.id.slice(0, iDate), iPid = rest.lastIndexOf(':')
    if (iDate < 0 || iPid < 0) continue
    const date = ch.id.slice(iDate + 1), personId = rest.slice(iPid + 1), warId = rest.slice(0, iPid)
    const war = state.wars.find(w => w.period.id === warId)
    const now = new Map(((war?.recs || {})[personId]?.[date] || []).map((r: WarRec) => [r.id, r] as const))
    for (const r of ch.after as WarRec[]) {
      if (r.kind !== 'request' || (r as RequestRec).state === 'refused') continue
      /* A bid the restore makes LIVE is asked; one already standing as the same live bid is not (the restore puts
         nothing new on the day). A REFUSED bid made live again is asked too (finding 1: refused → Ack, Undo, a
         medical filed, Redo — the same bid, a different state, stood on the sick day). */
      const cur = now.get(r.id) as RequestRec | undefined
      if (cur && cur.kind === 'request' && cur.state !== 'refused' && cur.code === (r as RequestRec).code) continue
      const cell = parseCell((r as RequestRec).code)
      if (!cell) continue
      const c: Contrib = { id: r.id, kind: 'request', code: cell.type, win: requestWin((r as RequestRec).code), state: (r as RequestRec).state }
      const blocker = absOf(personId, date).find(o => barsWrite(c, o))
      if (!blocker) continue
      const who = state.people.find(p => p.id === personId)?.callsign ?? personId
      const name = blocker.code === 'ATTC' ? 'ATT C' : blocker.code
      return `Can’t ${dir} that — ${who}’s ${name} now holds ${+date.slice(8)} ${MON[+date.slice(5, 7) - 1]}, and a bid can’t go over it.`
    }
  }
  return null
}

/** What the merged view shows on top at one address. */
function mainAt(personId: string, date: string): Contrib | null {
  const war = warHolding(getState().wars as MergedWar[], date) as MergedWar | undefined
  return war?.views[personId]?.[date]?.main ?? null
}

/** Write a bid (or, for an admin, a hand-typed FO/HO credit), or clear the
 *  cell with an empty code. Returns whether anything changed. The only path
 *  that writes a request; the same guards as ever — stage, window, row, and
 *  no medical from the war (owner, 13 Sep 26) — plus the step-4 occupancy
 *  rule: a bid may not land on a time a filed absence, worked time or
 *  another undecided bid already holds. */
export function setCell(personId: string, date: string, code: string): boolean {
  if (!canEditCell(state.period, state.role, date)) return false
  if (!canEditRow(state.role, state.viewer, personId)) return false
  const clean = code.trim().toUpperCase()
  if (isMedical(clean)) return false
  const list = listAt(personId, date)

  if (!clean) {
    /* clear: the requests at the address, and — for an admin — the day's OIL awards, which are ledger entries now
       ([OIL-AWARD-IS-A-GRANT]; D260: a Clear takes the award with the rest). A generated credit belongs to the
       schedule; a notice to its "OK, seen". ONE command for both stores (Fable's plan read F2). */
    const next = list.filter(r => r.kind !== 'request')
    const awards = awardIdsAt(personId, date)
    if (next.length === list.length && !awards.length) return false
    return gesture(awards.length ? 'lw.clear' : 'lw.edit', () => {
      if (next.length !== list.length) putList(personId, date, next)
      dropLedgerIds(awards)
      return true
    })
  }

  /* FO / HO is never a cell code: an award is given from the +OIL panel or the tracker (`cellProblem` says so) */
  if (clean === 'FO' || clean === 'HO') return false

  if (!isBiddable(clean) || !parseCell(clean)) return false
  const portion = portionOfCode(clean)
  const replaced = liveRequestsOn(list, portion)
  // re-typing the same bid keeps whatever decision it carries
  if (replaced.length === 1 && replaced[0]!.code === clean) return false
  const c: Contrib = { id: 'new', kind: 'request', code: parseCell(clean)!.type, win: requestWin(clean), state: 'pending' }
  if (occupiedFor(c, personId, date, replaced)) return false
  const rec: RequestRec = { id: newRecId(), kind: 'request', code: clean, state: 'pending' }
  return putList(personId, date, [...list.filter(r => !replaced.includes(r as RequestRec)), rec])
}

/** What a range write did. `skipped` counts days it was not allowed to touch,
 *  which is a fact the person deserves rather than a silent shortfall. */
export interface RangeWrite {
  written: number
  skipped: number
}

/** Write the same code across every day from `from` to `to`, inclusive (the
 *  owner's fortnight-in-one-go ask). PARTIAL BY DESIGN: a day it may not write
 *  (posted out, outside the window, already holding something the bid cannot
 *  share) is skipped and counted, the rest written. ONE gesture — one save,
 *  one undo step. */
export function setCellRange(personId: string, from: string, to: string, code: string): RangeWrite {
  if (to < from) return { written: 0, skipped: 0 }
  const person = state.people.find(p => p.id === personId)
  const dates: string[] = []
  for (let d = from; d <= to; d = addDays(d, 1)) dates.push(d)
  return writeMany(dates.map(date => ({ personId, date })), code, person ? () => person : undefined)
}

/* the shared body of the range and selection writers */
function writeMany(cells: { personId: string; date: string }[], code: string, who?: (id: string) => Person | undefined): RangeWrite {
  let written = 0, skipped = 0
  const find = who ?? ((id: string) => state.people.find(p => p.id === id))
  const clearing = !code.trim()
  gesture('lw.edit', () => {
    const wasQuiet = quiet
    quiet = true
    try {
      for (const { personId, date } of cells) {
        /* clearing an EMPTY cell is neither a write nor a refusal — a loose
           delete-box sweeps up empties around the bids */
        if (clearing && !listAt(personId, date).some(r => r.kind === 'request' || r.kind === 'credit') && !awardIdsAt(personId, date).length) continue
        const person = find(personId)
        if (person && !leaveDateOk(person, date)) { skipped++; continue }
        if (setCell(personId, date, code)) written++
        else skipped++
      }
    } finally {
      quiet = wasQuiet
    }
    if (written > 0 && !quiet) persistNotify()
  })
  return { written, skipped }
}

/** May leave be dated on this day for this person? Before they join and after
 *  they post out are both allowed (owner, 20 Sep 26 answer C) — the day must
 *  simply be in the war. A separate question from `inSquadron`, which still
 *  keeps them out of manning. */
function leaveDateOk(_p: Person, date: string): boolean {
  return !!warHolding(state.wars, date)
}

/** Write one code across a hand-picked set of cells. `{written, skipped}` in
 *  the `setCellRange` shape. */
export function setCells(cells: { personId: string; date: string }[], code: string): RangeWrite {
  return writeMany(cells, code)
}

/** Clear a set of cells — the empty-code path of `setCells`, named so the
 *  caller (and the tests) read as delete, not "write nothing". Approved leave
 *  in the selection is REMOVED through the absence door (design §5.2
 *  `lw.removeApproved` — deliberate delete propagates and sticks), in the same
 *  gesture. */
export function clearCells(cells: { personId: string; date: string }[], awardIds?: readonly string[]): RangeWrite {
  let written = 0, skipped = 0
  /* THE AWARDS IT TAKES ARE THE AWARDS ITS CONFIRM NAMED (D260; Astra's round-2 read, R2-02): a sheet passes the ids
     `awardsIn` gave its confirm, and only those go — an award given on one of these days since the confirm stays. No
     list (a caller that named none) takes the days' awards as they stand. */
  const prevOnly = CLEAR_ONLY
  if (awardIds) CLEAR_ONLY = new Set(awardIds)
  const takesAward = cells.some(c => awardIdsAt(c.personId, c.date).length > 0)
  try {
  gesture(takesAward ? 'lw.clear' : 'lw.edit', () => {
    const approved: Array<{ personId: string; date: string; iid: string }> = []
    const rest: { personId: string; date: string }[] = []
    for (const c of cells) {
      const m = mainAt(c.personId, c.date)
      if (m && m.kind === 'absence') {
        /* THE BIDS BENEATH FILED LEAVE GO TOO (the absence-record re-test, W3-F3, 26 Sep 26): a morning filed on the
           Inputs page sits ABOVE an afternoon bid (the ladder), and this asked only the top record — so the bid was
           counted "skipped, owned by Raptor" and left where it was, while Approve / Refuse / Ack in the same box already
           reached it. Taken FIRST, whoever owns the leave on top (Fable's final code read, F3: under a leave the WAR
           approved the bid stayed while the leave went — same gesture, two answers). A leave filed on the Inputs page
           itself stays (it is the Inputs page's); a war-approved one goes by the door, which reads the Input by id. */
        /* …AND THE AWARD BESIDE IT (owner, D260, 27 Sep 26 — "removes everything in the block, awards included"): an
           award flags no leave day (N13), so a day may hold a leave and an award together, and asking only the top
           record left the award behind whichever kind of leave was on top. The awards go by the same door as a Clear
           (the admin's own records; `awardsIn` names them in the confirm first). */
        const reqs = clearRequestsAt(c.personId, c.date, true)
        if (state.role === 'admin' && canDecide(state.period.stage, state.role) && warEditable(c.personId, c.date)) approved.push({ ...c, iid: m.id })
        else {
          if (reqs) written++
          /* A LEAVE THE WAR APPROVED THAT STAYS IS SAID (Fable's D260 scenarios, S18): on a published war it is finished
             paperwork, and when the award or bid beside it went the day counted only as "deleted" — the sheet closed as
             though the leave had gone too. Leave filed on the Inputs page staying is by design and counts as nothing
             (W3-F3). */
          if (!reqs || m.lw) skipped++
        }
      } else rest.push(c)
    }
    const r = writeMany(rest, '')
    written += r.written; skipped += r.skipped
    if (approved.length) {
      const d = DOOR ? DOOR.removeApproved(approved) : { done: 0, skipped: approved.length }
      written += d.done; skipped += d.skipped
    }
  })
  } finally { CLEAR_ONLY = prevOnly }
  return { written, skipped }
}

/** Remove the undecided / decided REQUESTS at one address — the bid beneath an absence the war does not own (W3-F3) —
 *  and, with `awards`, the admin's hand-given OIL awards there too (D260; the same records a Clear takes, `setCell`).
 *  The same gates as every cell write. True when something was removed. */
function clearRequestsAt(personId: string, date: string, awards = false): boolean {
  if (!canEditCell(state.period, state.role, date) || !canEditRow(state.role, state.viewer, personId)) return false
  const list = listAt(personId, date)
  const next = list.filter(r => r.kind !== 'request')
  const ids = awards ? awardIdsAt(personId, date) : []
  if (next.length === list.length && !ids.length) return false
  if (next.length !== list.length) putList(personId, date, next)
  dropLedgerIds(ids)
  return true
}

/* THE AWARDS A CLEAR MAY TAKE ([OIL-AWARD-IS-A-GRANT], 29 Sep 26). An award is a ledger entry drawn on its day, so the
   clearing doors ask the ledger (`awardsAt`), never the war's records: the admin's (N11 — a member's clear takes none),
   narrowed while a sheet's confirmed Delete runs to the awards its confirm named (CLEAR_ONLY — R2-02). */
let CLEAR_ONLY: ReadonlySet<string> | null = null
function awardIdsAt(personId: string, date: string): string[] {
  /* a day inside a war — the grid's clears never reach any other, and a tracker award dated in no war is on no cell
     to clear (Fable's final read, F2) */
  if (!warHolding(state.wars, date)) return []
  if (state.role !== 'admin') return []
  return awardsOnDay(personId, date).filter(e => !CLEAR_ONLY || CLEAR_ONLY.has(e.id)).map(e => e.id)
}
/** Take ledger entries by id — inside the caller's command (a clear's gesture), never a command of its own, so a
 *  clear that takes a bid and an award is ONE undo step (Fable's plan read F2). */
function dropLedgerIds(ids: readonly string[]): boolean {
  if (!ids.length) return false
  const drop = new Set(ids)
  const ledger = state.ledger.filter(e => !drop.has(e.id))
  if (ledger.length === state.ledger.length) return false
  state = withCurrent({ ...state, ledger })
  if (!quiet) persistNotify()
  return true
}

/** THE OIL AWARDS A CLEAR OF THESE DAYS WOULD TAKE (owner, D260, 27 Sep 26: "the confirm names each award first").
 *  A dragged block's Delete, the bid sheet's Clear and its range Clear all remove the awards on the days they clear —
 *  and each used to do it silently (the absence-record re-test, AB1, AB2). The confirms read THIS before anything goes,
 *  so what they name is exactly what the clear takes: the same gates as `setCell` (stage / window / row, a day in a
 *  war) and the same records (an admin's hand-given credit — a member's clear takes none, and the schedule's own credit
 *  is never cleared). In the cells' order; `days` is what each is worth (`creditWorth`). */
export function awardsIn(cells: readonly { personId: string; date: string }[]): Array<{ id: string; personId: string; date: string; code: 'FO' | 'HO'; days: number }> {
  const out: Array<{ id: string; personId: string; date: string; code: 'FO' | 'HO'; days: number }> = []
  for (const { personId, date } of cells) {
    if (!warHolding(state.wars, date)) continue
    if (!canEditCell(state.period, state.role, date) || !canEditRow(state.role, state.viewer, personId)) continue
    /* the AMOUNT is what an award is worth — never worked back from its FO / HO label (Astra's plan read F05) */
    for (const e of awardIdsAt(personId, date).map(id => state.ledger.find(x => x.id === id)!)) {
      out.push({ id: e.id, personId, date, code: e.amount === 0.5 ? 'HO' : 'FO', days: e.amount })
    }
  }
  return out
}

/** THE OIL AWARDS DRAWN ON ONE DAY — ledger entries, the one kind of hand-given OIL ([OIL-AWARD-IS-A-GRANT], D402).
 *  What a screen asks; the amount is the worth. */
export function awardsOnDay(personId: string, date: string): readonly LedgerEntry[] {
  syncAwardIndex(state.ledger)     // the index follows the ledger on every read — a writer may have just changed it
  return awardsAt(personId, date)
}

/** One OIL credit on a day, as every sheet reads it back — the schedule's own (`award` false) or an award (true). The
 *  amount is the worth; `enteredName` is who entered an award, by his LIVE callsign (D200 (2)), else the approver
 *  typed at the time. */
export interface OilShown {
  id: string
  award: boolean
  code: 'FO' | 'HO'
  days: number
  note?: string
  givenBy?: string
  via?: 'schedule' | 'input'
  spans?: Array<[number, number]>
  enteredName?: string
  enteredAt?: string
}
/** Every OIL credit on one day — the schedule's first, then each award (ONE reader for the tap list, the bid sheet and
 *  the member's own award sheet, so none can see a different set — [OIL-AWARD-IS-A-GRANT]). */
export function oilOnDay(personId: string, date: string): OilShown[] {
  const out: OilShown[] = []
  for (const r of listAt(personId, date)) {
    if (r.kind !== 'credit') continue
    out.push({ id: r.id, award: false, code: r.code, days: creditWorth({ code: r.code, auto: true }), ...(r.note ? { note: r.note } : {}), ...(r.via ? { via: r.via } : {}), ...(r.spans ? { spans: r.spans } : {}) })
  }
  for (const e of awardsOnDay(personId, date)) out.push(awardShown(e))
  return out
}
export function awardShown(e: LedgerEntry): OilShown {
  const name = (e.enteredBy && state.people.find(p => p.id === e.enteredBy)?.callsign) || e.approvedBy
  return {
    id: e.id, award: true, code: e.amount === 0.5 ? 'HO' : 'FO', days: e.amount,
    ...(e.reason ? { note: e.reason } : {}), ...(e.givenBy ? { givenBy: e.givenBy } : {}),
    ...(name ? { enteredName: name } : {}), ...(e.enteredAt ? { enteredAt: e.enteredAt } : {}),
  }
}

/** An approved absence the war may change: every absence on the address was
 *  approved on the war, none is medical / course / OD, and it is not a cell
 *  holding two absences (those are changed one at a time from the list —
 *  design §23.3). */
function warEditable(personId: string, date: string): boolean {
  /* APPROVED AND PUBLISHED IS FINISHED PAPERWORK (owner, 21 Sep 26 — "if the
     input is approved and published … the member and admin can input the
     remarks there. In order to edit it again, admin has to go back to open for
     bidding or bidding closed"). ONE seat for that rule, because the war reaches
     an approved leave from five directions — the tap list, the bulk decision
     over a drag-selection, a bulk clear, a drag-move and a single move — and
     every one of them asks this question. Enforcing it only where the owner
     happened to be looking is how the rule would rot (Fable, 21 Sep 26; Astra
     found the tap-list half of it).
     It is NARROW on purpose: this predicate is only ever asked about a leave
     the WAR approved. An input nobody has approved yet stays fully editable on
     a published war, which is the other half of his ruling. */
  if (getState().period.stage === 'published') return false
  const war = warHolding(getState().wars as MergedWar[], date) as MergedWar | undefined
  const v = war?.views[personId]?.[date]
  if (!v || !v.main || v.main.kind !== 'absence') return false
  const abs = v.all.filter(c => c.kind === 'absence')
  return abs.length === 1 && !!abs[0]!.lw && isLeaveCode(abs[0]!.code)
}

/** Decide a set of cells at once — ADMIN ONLY, once bidding is no longer open
 *  (`canDecide`). Each cell acts on what it DISPLAYS (design §18 OA3-001): a
 *  shown request is decided (approving turns it into an Input through the
 *  door), a shown war-approved leave is un-approved back into a request. One
 *  gesture, one envelope; a cell with nothing decidable is skipped. */
export function setBidStates(cells: { personId: string; date: string }[], bid: BidState): { decided: number; skipped: number; already: number } {
  if (!canDecide(state.period.stage, state.role)) return { decided: 0, skipped: cells.length, already: 0 }
  /* `already` (the absence-record re-test, AB7, 26 Sep 26 — Fable F7, reproduced by W3): an Approve over a leave that
     was ALREADY approved changes nothing, and it was counted as "decided" — "3 decided" for two changes. */
  let decided = 0, skipped = 0, already = 0
  gesture('lw.decide', () => {
    const toApprove: Array<{ personId: string; date: string; recId: string }> = []
    const toUnapprove: Array<{ personId: string; date: string; iid: string }> = []
    const wasQuiet = quiet
    quiet = true
    let wrote = false
    try {
      for (const { personId, date } of cells) {
        const m = mainAt(personId, date)
        /* A DAY MAY HOLD BOTH: a filed afternoon leave shows on top of a
           morning bid nobody has decided (the ladder puts an absence above a
           request). Decide the UNDECIDED BID first — it is what a decision is
           for — instead of reading the day as "already approved" and reporting
           a decision that never happened (probe, 20 Sep 26). The tap list
           already acts per record; this is the drag / bulk path. */
        const live = liveRequestsOn(listAt(personId, date), 'full')
        if (live.length && (m?.kind !== 'request' || live.length > 1)) {
          for (const r of live) {
            if (bid === 'approved') { toApprove.push({ personId, date, recId: r.id }); continue }
            if (decideRequest(personId, date, r.id, bid)) { decided++; wrote = true } else skipped++
          }
          continue
        }
        if (m && m.kind === 'request') {
          if (bid === 'approved') { toApprove.push({ personId, date, recId: m.id }); continue }
          if (decideRequest(personId, date, m.id, bid)) { decided++; wrote = true } else skipped++
        } else if (m && m.kind === 'absence' && warEditable(personId, date)) {
          if (bid === 'approved') { already++; continue }            // already approved: nothing to do, and not a decision (AB7)
          toUnapprove.push({ personId, date, iid: m.id })
        } else skipped++
      }
    } finally {
      quiet = wasQuiet
    }
    if (wrote && !quiet) persistNotify()
    if (toApprove.length) {
      const r = DOOR ? DOOR.approve(toApprove) : { done: 0, skipped: toApprove.length }
      decided += r.done; skipped += r.skipped
    }
    if (toUnapprove.length) {
      const r = DOOR ? DOOR.decideApproved(toUnapprove, bid as RequestState) : { done: 0, skipped: toUnapprove.length }
      decided += r.done; skipped += r.skipped
    }
  })
  return { decided, skipped, already }
}

/** Record a decision on one cell — the single-cell sibling of `setBidStates`,
 *  with the same gate and the same "act on what is shown" rule. */
export function setBidState(personId: string, date: string, bid: BidState): void {
  setBidStates([{ personId, date }], bid)
}

/** Set the state of ONE request by its id (the tap list acts per record).
 *  Approving goes through the door; the rest is a plain edit. */
export function decideRequestById(personId: string, date: string, recId: string, bid: BidState): boolean {
  if (!canDecide(state.period.stage, state.role)) return false
  if (bid === 'approved') {
    return gesture('lw.decide', () => (DOOR ? DOOR.approve([{ personId, date, recId }]).done > 0 : false))
  }
  return gesture('lw.decide', () => decideRequest(personId, date, recId, bid))
}

/* ---- the tap list's per-record actions ([ARCH-STACK] step 4 — design §25
   OA10-001: a day holding several records lists EVERY one, each with its own
   permission-checked actions, so no record can hide under another) ---------- */

/** The war's own records at one address (requests, credits, notices). */
export function recordsAt(personId: string, date: string): readonly WarRec[] {
  return listAt(personId, date)
}

/** Clear ONE war record: a request (whoever may edit that cell today) or a
 *  hand-typed credit (an admin). A generated credit belongs to the schedule and
 *  a notice to its "OK, seen", so neither clears here. */
export function clearRecordById(personId: string, date: string, recId: string): boolean {
  /* an OIL AWARD on the day is a ledger entry ([OIL-AWARD-IS-A-GRANT]) — the admin's to take (N11) */
  if (awardsOnDay(personId, date).some(e => e.id === recId)) {
    if (state.role !== 'admin') return false
    return gesture('lw.award', () => dropLedgerIds([recId]))
  }
  const list = listAt(personId, date)
  const r = list.find(x => x.id === recId)
  if (!r || r.kind !== 'request') return false
  if (!canEditCell(state.period, state.role, date) || !canEditRow(state.role, state.viewer, personId)) return false
  return gesture('lw.edit', () => putList(personId, date, list.filter(x => x !== r)))
}

/** Change ONE approved-on-the-war absence by its Input id: back to a request
 *  (`pending` / `acknowledged` / `refused`) or `removed` altogether. An admin
 *  at a deciding stage; the door refuses leave filed on the Inputs page and
 *  says why when a request already sits on that time (§24). Returns null when
 *  done, else the reason in the sheet's own words. */
export function changeAbsenceById(personId: string, date: string, iid: string, to: RequestState | 'removed'): string | null {
  if (state.role !== 'admin' || !canDecide(state.period.stage, state.role)) return 'Only an admin can change approved leave now'
  if (!DOOR) return 'Not available'
  const item = [{ personId, date, iid }]
  const r = gesture(to === 'removed' ? 'lw.edit' : 'lw.decide', () => (to === 'removed' ? DOOR!.removeApproved(item) : DOOR!.decideApproved(item, to)))
  /* a refusal inside the command (a locked week) rolls the gesture back and
     leaves `r` unset — report it rather than read through it (Fable #3) */
  if (!r) return 'Couldn’t change that — the week is locked, or something else refused it'
  if (r.done > 0) return null
  return r.why[0] ?? 'That leave was filed on the Inputs page — change it there'
}

/* the plain request-state edit: pending / acknowledged / refused. A refusal
   replaces an older refusal on the same half (one refused request per half). */
function decideRequest(personId: string, date: string, recId: string, bid: BidState): boolean {
  if (bid === 'approved') return false
  const list = listAt(personId, date)
  const r = list.find((x): x is RequestRec => x.kind === 'request' && x.id === recId)
  if (!r || r.state === bid) return false
  const next: RequestRec = { ...r, state: bid }
  let rest = list.filter(x => x !== r)
  if (bid === 'refused') {
    const halves = portionOfCode(r.code)
    const older = rest.filter((x): x is RequestRec => x.kind === 'request' && x.state === 'refused' &&
      (halves === 'full' || portionOfCode(x.code) === 'full' || portionOfCode(x.code) === halves))
    rest = rest.filter(x => !older.includes(x as RequestRec))
  } else if (r.state === 'refused') {
    /* reconsidering a refusal: it becomes undecided again, so it must not share
       a half with another undecided request */
    const clash = liveRequestsOn(rest, portionOfCode(r.code))
    if (clash.length) return false
    if (occupiedFor({ id: r.id, kind: 'request', code: parseCell(r.code)!.type, win: requestWin(r.code), state: bid as RequestState }, personId, date, [r])) return false
  }
  /* the decided record keeps ITS PLACE on the day ([DB-READINESS] group A, the group-wide walk — W3 finding 2): moved to
     the end of the list, it put the day out of order and the record beside it was given a new place — its row
     rewritten by a decision about another, and a stale tab's write of it brought back a record someone had deleted */
  return putList(personId, date, list.filter(x => x === r || rest.includes(x)).map(x => (x === r ? next : x)))
}

/** "OK, seen" on a replaced-bid notice — the person or an admin. Clears every
 *  notice the same command made (one tap for a five-day replacement). */
export function ackReplacement(personId: string, noticeId: string): number {
  if (state.role !== 'admin' && state.viewer !== personId) return 0
  let seq: number | null = null
  for (const w of state.wars) for (const list of Object.values(w.recs[personId] ?? {})) {
    const n = list.find(r => r.kind === 'notice' && r.id === noticeId) as NoticeRec | undefined
    if (n) seq = n.seq
  }
  if (seq === null) return 0
  let cleared = 0
  gesture('lw.ack', () => {
    const wasQuiet = quiet
    quiet = true
    try {
      for (const w of state.wars) for (const [date, list] of Object.entries(w.recs[personId] ?? {})) {
        const keep = list.filter(r => !(r.kind === 'notice' && r.seq === seq))
        if (keep.length !== list.length) { cleared += list.length - keep.length; putList(personId, date, keep) }
      }
    } finally { quiet = wasQuiet }
    if (cleared && !quiet) persistNotify()
  })
  return cleared
}

/** Why a bidding window was refused. */
export type BidWindowResult = 'set' | 'outside' | 'backwards' | 'forbidden'

/**
 * Open bidding on a range of days inside the current war.
 *
 * This is what "the admin selects which period to open" means now that a war
 * is a whole year: the year stays on screen and the squadron may write to
 * this much of it. Admin-only, and checked here rather than trusted to a
 * hidden button, because the role switch is an affordance rather than a
 * permission — see `docs/known-gaps.md`.
 *
 * Refused rather than clamped when the range falls outside the war: an admin
 * who typed the wrong year has made a mistake worth being told about, and
 * silently sliding their dates to the period's edges would leave them
 * believing they had opened something else.
 */
export function setBidWindow(from: string, to: string): BidWindowResult {
  if (state.role !== 'admin') return 'forbidden'
  if (to < from) return 'backwards'
  if (!windowFits(state.period, from, to)) return 'outside'
  updateCurrent(w => ({ ...w, period: { ...w.period, bidFrom: from, bidTo: to } }))
  return 'set'
}

/** Open the whole war for bidding again — the state every war starts in and
 *  the one every war stored before windows existed reads as. */
export function clearBidWindow(): BidWindowResult {
  if (state.role !== 'admin') return 'forbidden'
  updateCurrent(w => ({ ...w, period: { ...w.period, bidFrom: null, bidTo: null } }))
  return 'set'
}

/**
 * Write one of a day's two event lines.
 *
 * Admin-only: these are the scheduler's facts about a day — an exercise, a
 * visit, a range closure — not something a bidder writes about themselves.
 * Checked in the store for the same reason every other write is: the role
 * switch is an affordance, so this is the only place it can bite.
 *
 * Days are stored in full rather than rebuilt from the period's range
 * precisely so these survive a reload; see `readWar`.
 */
export function setDayEvent(date: string, line: number, text: string, kind: EventKind | null = null): boolean {
  if (state.role !== 'admin') return false
  if (!state.period.days.some(d => d.date === date)) return false
  updateCurrent(w => ({
    ...w,
    period: {
      ...w.period,
      days: w.period.days.map(d => (d.date === date ? writeDayEvent(d, line, text, kind) : d)),
    },
  }))
  return true
}

/** Copy a day's event lines and write one, padding with '' so a row beyond the
 *  stored array's end (a just-added row) can be written into rather than
 *  silently dropped. The one place events are mutated. */
function writeEventLine(events: string[], line: number, text: string): string[] {
  const out = [...events]
  while (out.length <= line) out.push('')
  out[line] = text
  return out
}

/** A day with one event slot written — text AND its instance tag together
 *  (owner, 18 Aug 26: the tag rides the event, not the type library). Every
 *  write sets both: an edit that drops the tag must clear the stored one, or
 *  yesterday's tag would silently colour today's different word. */
function writeDayEvent(d: DayInfo, line: number, text: string, kind: EventKind | null): DayInfo {
  const kinds = [...(d.eventKinds ?? [])]
  while (kinds.length <= line) kinds.push(null)
  kinds[line] = text ? kind : null // a cleared event keeps no tag behind
  return { ...d, events: writeEventLine(d.events, line, text), eventKinds: kinds }
}

/**
 * Write one event line across a RANGE of days — the "repeat" mode: the same
 * word lands in each covered day's own `events[line]` (e.g. "SC" on every day
 * of a tasking week). The merged-bar mode is `addEventBand` instead.
 *
 * Admin-only, same reason as `setDayEvent`. Any day already under a band on
 * this line keeps the band — the band is the merged label and per-day text
 * beneath it is suppressed anyway — so the repeat writes only the free days.
 * A backwards range is a no-op.
 */
export function setDayEventRange(from: string, to: string, line: number, text: string, kind: EventKind | null = null): boolean {
  if (state.role !== 'admin') return false
  if (to < from) return false
  updateCurrent(w => ({
    ...w,
    period: {
      ...w.period,
      days: w.period.days.map(d => {
        if (d.date < from || d.date > to) return d
        if (bandCoversDate(w.period.bands, line, d.date)) return d
        return writeDayEvent(d, line, text, kind)
      }),
    },
  }))
  return true
}

/** Why a merged band was refused. */
export type EventBandResult = 'set' | 'overlap' | 'backwards' | 'outside' | 'forbidden'

/**
 * Add a MERGED event label spanning a range on one event line.
 *
 * Admin-only. Refused rather than clamped when it overlaps an existing band on
 * the same line (two merged labels over one day has no single right answer) or
 * falls outside the war. On success the per-day text UNDER the band on that
 * line is cleared, so a merged label never hides stray words a later delete
 * would resurrect.
 */
export function addEventBand(line: number, from: string, to: string, text: string, kind: EventKind | null = null): EventBandResult {
  if (state.role !== 'admin') return 'forbidden'
  if (to < from) return 'backwards'
  if (from < state.period.start || to > state.period.end) return 'outside'
  if (bandOverlaps(state.period.bands, line, from, to)) return 'overlap'
  updateCurrent(w => ({
    ...w,
    period: {
      ...w.period,
      bands: [...w.period.bands, { line, from, to, text, kind }],
      days: w.period.days.map(d =>
        d.date < from || d.date > to || !d.events[line] ? d : writeDayEvent(d, line, '', null)),
    },
  }))
  return 'set'
}

/** Remove the merged band on `line` that covers `date`. Admin-only. A no-op
 *  when no band is there. The days it covered keep their (empty) per-day text —
 *  the band cleared them on the way in; a fresh edit refills them. */
export function removeEventBand(line: number, date: string): boolean {
  if (state.role !== 'admin') return false
  const band = state.period.bands.find(b => b.line === line && b.from <= date && date <= b.to)
  if (!band) return false
  updateCurrent(w => ({
    ...w,
    period: { ...w.period, bands: w.period.bands.filter(b => b !== band) },
  }))
  return true
}

/** True where a band on `line` covers `date`. A module-local reader for the
 *  range writer above; the engine's `bandAt` is the exported one. */
function bandCoversDate(bands: EventBand[], line: number, date: string): boolean {
  return bands.some(b => b.line === line && b.from <= date && date <= b.to)
}

/** Why an event move was refused. Mirrors `MoveResult` for the roster. */
export type EventMoveResult = 'moved' | { reason: 'nothing' | 'outside' | 'overlap' }

/** The validation half of `moveEvent`, held apart so the grid's landing preview
 *  can ask "would this move go?" BEFORE painting it — the same split (and the
 *  same drift-seam reason) `moveProblem`/`moveCells` keep for the roster.
 *  `from`/`to` are the event's own span: `from === to` for a plain single-day
 *  event, the band's two ends for a merged bar. Returns null when the move is
 *  clear, else the reason. Admin-only, like every event mutator. */
export function moveEventProblem(line: number, from: string, to: string, dayDelta: number): Exclude<EventMoveResult, 'moved'> | null {
  if (state.role !== 'admin') return { reason: 'nothing' }
  if (!dayDelta) return { reason: 'nothing' }
  const nFrom = addDays(from, dayDelta), nTo = addDays(to, dayDelta)
  if (nFrom < state.period.start || nTo > state.period.end) return { reason: 'outside' }
  const band = state.period.bands.find(b => b.line === line && b.from === from && b.to === to)
  if (band) {
    // the shifted span must not overlap ANOTHER band on this line (itself excluded)
    if (state.period.bands.some(b => b !== band && b.line === line && nFrom <= b.to && b.from <= nTo)) return { reason: 'overlap' }
  } else {
    // a plain single-day event: there must be one to move, and its one landing
    // day must be free of a band and of another day's event on this line
    const sday = state.period.days.find(d => d.date === from)
    if (!sday || !sday.events[line]) return { reason: 'nothing' }
    if (bandCoversDate(state.period.bands, line, nFrom)) return { reason: 'overlap' }
    const tday = state.period.days.find(d => d.date === nFrom)
    if (tday && tday.events[line]) return { reason: 'overlap' }
  }
  return null
}

/** Move a whole event — a merged band OR a single-day event — by a day-delta:
 *  the event-line counterpart of `moveCells` (owner, 31 Aug 26 — "drag an
 *  existing event to move it, just like LL"). ONE atomic write, so it is one
 *  undo step and never leaves a half-moved event; validated by
 *  `moveEventProblem` first, so a refused move changes nothing. A band keeps its
 *  text and instance tag; a single-day event carries its stored `eventKinds`
 *  tag along. Admin-only. */
export function moveEvent(line: number, from: string, to: string, dayDelta: number): EventMoveResult {
  const problem = moveEventProblem(line, from, to, dayDelta)
  if (problem) return problem
  const nFrom = addDays(from, dayDelta), nTo = addDays(to, dayDelta)
  const band = state.period.bands.find(b => b.line === line && b.from === from && b.to === to)
  if (band) {
    updateCurrent(w => ({
      ...w,
      period: {
        ...w.period,
        bands: [...w.period.bands.filter(b => b !== band), { line, from: nFrom, to: nTo, text: band.text, kind: band.kind ?? null }],
        // clear any stray per-day text under the new span, the same rule addEventBand applies
        days: w.period.days.map(d => (d.date >= nFrom && d.date <= nTo && d.events[line]) ? writeDayEvent(d, line, '', null) : d),
      },
    }))
  } else {
    const src = state.period.days.find(d => d.date === from)
    const text = src?.events[line]
    if (!text) return { reason: 'nothing' }
    const kind = (src?.eventKinds?.[line] ?? null) as EventKind | null
    updateCurrent(w => ({
      ...w,
      period: {
        ...w.period,
        days: w.period.days.map(d => {
          if (d.date === from) return writeDayEvent(d, line, '', null)   // clear the source
          if (d.date === nFrom) return writeDayEvent(d, line, text, kind) // land the target
          return d
        }),
      },
    }))
  }
  return 'moved'
}

/** Add one more EVENT row (owner, 18 Aug 26 — "add more event rows if needed"),
 *  up to `MAX_EVENT_ROWS`. ADMIN-gated; returns whether it grew so a control
 *  can disable at the cap. Nothing to migrate — a day's `events` array grows
 *  the first time the new row is written into (`writeEventLine`), and a row
 *  past a day's stored length reads '' until then. */
export function addEventRow(): boolean {
  if (state.role !== 'admin') return false
  if (state.eventRows >= MAX_EVENT_ROWS) return false
  state = withCurrent({ ...state, eventRows: state.eventRows + 1 })
  persistNotify()
  return true
}

/**
 * THE SANS ENABLE FUNCTION (owner, 18 Aug 26 — "we will not show the SANS in
 * the leave war however there is a function to still enable this"). SANS
 * aircrew are excluded from the roster PROJECTION by default; flipping this on
 * asks the next projection to include them. The switch itself changes no
 * roster — sync.ts's reprojectRoster reads it and re-projects on the notify
 * this write fires, so the rows appear (or leave) at once. ADMIN-gated like
 * every squadron-wide config; surfaced in the matrix's Rearrange toolbar.
 */
export function setShowSans(on: boolean): boolean {
  if (state.role !== 'admin') return false
  if (state.showSans === !!on) return true
  state = withCurrent({ ...state, showSans: !!on })
  persistNotify()
  return true
}

/** Why removing the last event row was refused. */
export type RemoveEventRowResult = 'removed' | 'min' | 'nonempty' | 'forbidden'

/** Remove the LAST event row. ADMIN-gated, never below the default two, and
 *  refused if that row still carries any text or band on the current war
 *  (`'nonempty'`) so nothing vanishes unseen — the admin clears it first. This
 *  guard is also what keeps `columnKindFor` honest: it scans every stored event
 *  line, so a row is only ever dropped from view once it is provably empty. */
/* Does ANY war hold text or a band on this event line? `eventRows` is
   squadron-wide across every war, so the remove guard below (and the button
   state in Matrix.tsx) must look at ALL of them (review fix, 19 Aug 26) —
   checking only the open war let an admin remove a row that still carried an
   "Exercise" in another year's war, leaving that text, its column tint and
   its OIL effects invisible with nothing left to see or clear them by. */
export function eventRowUsed(line: number): boolean {
  return state.wars.some(w =>
    w.period.days.some(d => (d.events[line] ?? '') !== '') ||
    w.period.bands.some(b => b.line === line))
}

export function removeEventRow(): RemoveEventRowResult {
  if (state.role !== 'admin') return 'forbidden'
  if (state.eventRows <= DEFAULT_EVENT_ROWS) return 'min'
  if (eventRowUsed(state.eventRows - 1)) return 'nonempty'
  state = withCurrent({ ...state, eventRows: state.eventRows - 1 })
  persistNotify()
  return 'removed'
}

/* THE EVENT-TYPE LIBRARY writers. Admin-only, squadron-wide, persisted under
   the `eventdefs` key. Each wraps a pure helper from engine/eventdefs.ts and
   returns its error sentence unchanged so the sheet can show it; a successful
   edit republishes state, saves and notifies like every other write. */

function commitEventDefs(result: EventDef[] | string): string | null {
  if (typeof result === 'string') return result
  state = withCurrent({ ...state, eventDefs: result })
  persistNotify()
  return null
}

export function addEventType(name: string, kind: EventKind): string | null {
  if (state.role !== 'admin') return 'Only an admin can edit event types'
  return commitEventDefs(addEventDef(state.eventDefs, name, kind))
}

export function updateEventType(index: number, patch: { name?: string; kind?: EventKind }): string | null {
  if (state.role !== 'admin') return 'Only an admin can edit event types'
  return commitEventDefs(updateEventDef(state.eventDefs, index, patch))
}

export function removeEventType(index: number): boolean {
  if (state.role !== 'admin') return false
  const next = removeEventDef(state.eventDefs, index)
  if (next === state.eventDefs) return false
  state = withCurrent({ ...state, eventDefs: next })
  persistNotify()
  return true
}

export function resetEventTypes(): void {
  if (state.role !== 'admin') return
  state = withCurrent({ ...state, eventDefs: seedEventDefs() })
  persistNotify()
}

/* THE OIL TRACKER writers (owner, 2 Sep 26 — "admin can only edit the list,
   members can only view it"). ADMIN-GATED at the write path like every other
   management surface. The tracker itself is DERIVED (engine/oiltracker.ts);
   what an admin writes is the LEDGER (a grant, a correction, an edit or a
   deletion of one — the first interface the ledger has ever had) and the
   POLICY (expiry, default history window). Earned FO/HO days are never
   written here: they are the publish wire's cells, read straight off the
   grid, and a ledger copy would be the two-records-of-one-fact counters.ts
   refuses. */

export const MAX_REASON = 120
/** The optional "given by" on a grant (owner, 2 Sep 26) — a name or a post.
 *  ONE literal, defined with the record field it also caps (engine/warrecs.ts)
 *  and re-exported here so every existing caller keeps its import. */
export { MAX_GIVEN_BY }
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/

/** Everything a figure needs to read a person's number, from the live state
 *  — ONE builder so the column, the picker, the breakdown, the Cinch sheet,
 *  the bid-time warning and the tracker all read the same OIL policy and the
 *  same "today". Four hand-built literals used to do this; they could drift. */
export function figureCtxOf(): FigureCtx {
  // `eventDefs` and `people` feed the weekend/PH charging rule (charge.ts,
  // 3 Sep 26): which typed words are a holiday, and who is a pilot.
  // the MERGED wars (design §4.2 FB2-01): approved leave lives in the Inputs now
  return { openings: state.openings, ledger: state.ledger, sources: getState().wars, oilPolicy: state.oilPolicy, asOf: localToday(), eventDefs: state.eventDefs, people: state.people }
}

/** What a leave FILL would do to the balance it spends — the one question both leave sheets ask before taking someone
 *  below zero (the one-day sheet, a day or a picked range; the drag-selection sheet since his ruling D418, 29 Sep 26,
 *  "Drag asks too"). `before` and `after` are the SAME figure the balance column shows — `balanceOf`, or for OIL the
 *  tracker's FIFO-and-expiry ledger — read of the wars as they are and as the fill would leave them (`withFill`: each
 *  day rebuilt the way `setCell` changes it, the other half kept). Only the days the store would write count
 *  (`cellProblem` refuses the rest). null for leave that spends no balance. The sheets ask when `after` is below zero
 *  AND below `before` (`belowzero.ts goesBelow`) — a fill that spends nothing never asks, even of a man already in the
 *  red (Astra's final read, F4). */
export function balanceAfterFill(personId: string, dates: readonly string[], code: string): { counter: CounterName; before: number; after: number } | null {
  const spends = leaveCodeOf(code)?.spends
  if (!spends) return null
  const counter = spends.counter
  const ctx = figureCtxOf()
  const read = (sources: FigureCtx['sources']) => counter === 'oil'
    ? oilLedgerOf({ ...ctx, sources }, personId).balance
    : balanceOf(ctx.openings, ctx.ledger, sources, personId, counter, ctx)
  const before = read(ctx.sources)
  const writes = dates.filter(d => !cellProblem(personId, d, code))
  return { counter, before, after: writes.length ? read(withFill(ctx.sources, personId, writes, code)) : before }
}

export function setOilPolicy(patch: Partial<OilPolicy>): boolean {
  if (state.role !== 'admin') return false
  // Through the untrusted reader on purpose: it is the one place the bounds
  // live, so a sheet cannot store a policy the next boot would throw away.
  const next = readOilPolicy({ ...state.oilPolicy, ...patch })
  if (!next) return false
  state = withCurrent({ ...state, oilPolicy: next })
  persistNotify()
  return true
}

/**
 * DAYS COME IN HALVES, AND THAT IS A GUARD RAIL (owner, 21 Sep 26 — "put a
 * guard rail to make sure that only 0.5 multiples can be input just like the
 * oil tracker", after "For any type of leave, be it on the inputs or oil
 * tracker or leave war or oil credits it should always round off … This is to
 * prevent bugs and calculation of the leave balances easier").
 *
 * A half day is the smallest thing the grid ever CHARGES, so an odd quantity
 * can never be drawn down cleanly: a remainder under a half strands in the
 * balance and every figure that touches it carries a fraction nobody can
 * spend. That is the bug he is naming, and REFUSING the input is what
 * prevents it — he asked for a guard rail, not a silent correction, because
 * a number quietly changed after it was typed is the very thing this app has
 * spent two days removing.
 *
 * This RESTORES his 6 Sep 26 rule and extends it to the door that had
 * escaped it. It withdraws his own earlier ask on 21 Sep that an odd number
 * be accepted — he saw what it cost and reversed himself the same hour.
 *
 * ONE RULE AND ONE MESSAGE, EVERY POOL AND EVERY DOOR: the war's award, the
 * OIL tracker's grant, a correction, and every other leave type. (The Inputs
 * page needs nothing — leave there is whole or half days by construction,
 * with no way to type a quantity at all.) The war used to word it its own
 * way, which is the drift seam the house rules name: two sentences for one
 * rule drift apart the moment one of them is edited.
 */
const isHalfStep = (n: number) => Math.abs(n * 2 - Math.round(n * 2)) < 1e-9
export const HALF_STEP_MSG = 'Days come in halves — 1, 1.5, 2 …'

/** Which pools NEED a reason on a credit. OIL keeps the tracker's rule — a
 *  credit with no reason is the untraceable free text the ledger replaced;
 *  the other pools take a bare number from the grid (owner, 6 Sep 26 —
 *  "reason only for OIL"). ONE predicate: the writer, the edit path and the
 *  credit form all read it. */
export const reasonRequired = (counter: CounterName): boolean => counter === 'oil'

/** The sentence that stops a bad ledger write, or null. Stricter than the
 *  boot reader (which tolerates any string date and a zero amount, so an
 *  older stored ledger still loads): a NEW entry with no date or nothing in
 *  it is a mistake worth telling the admin about. ONE body for every door;
 *  `requireReason` is the door's own rule (§2.2 of the award plan — the
 *  tracker's form and the figures bar require a reason for OIL, the grid's
 *  +OIL panel never has). */
function ledgerProblem(counter: CounterName, amount: number, date: string, reason: string, givenBy = '', requireReason = reasonRequired(counter)): string | null {
  if (!Number.isFinite(amount) || amount === 0) return 'The amount must be a number other than 0'
  if (!isHalfStep(amount)) return HALF_STEP_MSG
  /* ONE CEILING FOR ONE RECORD (both final reads, Astra OA-001 / Fable F4): an OIL award is at most MAX_GRANT_DAYS
     whichever door gives or changes it — the grid's doors always said so, the tracker's form and editor did not, and
     since the grid's award opens in the tracker's editor the same record had two limits. A correction is not an award;
     the ceiling is not its rule. */
  if (counter === 'oil' && amount > MAX_GRANT_DAYS) return `That is more than ${MAX_GRANT_DAYS} days`
  if (!ISO_DAY.test(date)) return 'Pick a date'
  const clean = reason.trim()
  if (!clean && requireReason) return 'Give a reason'
  if (clean.length > MAX_REASON) return `A reason is at most ${MAX_REASON} characters`
  if (givenBy.trim().length > MAX_GIVEN_BY) return `Given by is at most ${MAX_GIVEN_BY} characters`
  return null
}

/** A NEW ledger entry's id — opaque and never re-minted (Astra's round-2 read, R2-03; Fable's, N5). Each entry is its
 *  own record in the command layer now, so an id is that record's identity: the old `ol-N` "one past the highest
 *  stored" handed an undone entry's id to the next award, which then shared its undo key. Stored ids of any shape
 *  still read. */
const ledgerId = (): string => newRecId('ol-')

/** The approver stamped on a grant: the CALLSIGN of whoever is viewing
 *  (`viewer` is a person id and would leak on screen), or "admin". */
/* the signed-in person's callsign from Raptor's whole roster, mirrored by the sync beside the
   viewer (leavewar/sync.ts): the war's own roster leaves out a SANS man (unless shown) and an
   archived callsign, and an admin who is either still grants — his stamp names him, never
   "admin" (Fable's code read, 26 Sep 26; D166 (5)). View state, not persisted. */
let VIEWER_CS: string | null = null
export function setViewerCallsign(cs: string | null): void { VIEWER_CS = cs }
function approverName(): string {
  return state.people.find(p => p.id === state.viewer)?.callsign ?? VIEWER_CS ?? 'admin'
}
/** WHO ENTERED IT AND WHEN (owner, D200 (2), 26 Sep 26): the signed-in person's ID — drawn by his LIVE callsign where
 *  shown — and the time, stamped by the store on a NEW entry and kept through every edit (who changed it is the change
 *  history's line). No person (a session tied to none) stamps only the time. */
function entered(): { enteredBy?: string; enteredAt: string } {
  return { ...(state.viewer ? { enteredBy: state.viewer } : {}), enteredAt: new Date().toISOString() }
}
/** The command a ledger write runs as (Astra's round-2 read, R2-01): an OIL AWARD is its own row of the permissions
 *  table, every other entry the ledger's. */
const ledgerType = (counter: CounterName, amount: number): string => (isOilAward({ counter, amount }) ? 'lw.award' : 'lw.ledger')

/**
 * Credit a pool to one or many people at once — the tracker's "credit N
 * people" (owner: "drag and select all WSOs to put OIL, date and reason"),
 * and since 6 Sep 26 the figures bar's "+2 for everyone I dragged" on ANY
 * balance. A NEGATIVE amount is a correction, not a second mechanism
 * (§Counters). A positive OIL credit is an OIL AWARD — the one kind of hand-given
 * OIL, drawn on the grid on its date (D400, D402). A reason is REQUIRED for OIL
 * here, as it always was (a direct blank call is refused — Astra's plan read F08).
 * Returns the error sentence for the form, or null on success.
 * One command for the whole batch → one persist, one undo step.
 */
export function grantTo(personIds: string[], counter: CounterName, amount: number, date: string, reason: string, givenBy = ''): string | null {
  if (state.role !== 'admin') return `Only an admin can credit ${counterLabel(counter)}`
  const ids = [...new Set(personIds)].filter(id => state.people.some(p => p.id === id))
  if (!ids.length) return 'Pick at least one person'
  const problem = ledgerProblem(counter, amount, date, reason, givenBy)
  if (problem) return problem
  const approvedBy = approverName()
  const by = givenBy.trim()
  const who = entered()
  const entries: Ledger = ids.map(personId => ({
    id: ledgerId(), personId, counter, amount, date, reason: reason.trim(), approvedBy,
    ...(by ? { givenBy: by } : {}), ...who,
  }))
  gesture(ledgerType(counter, amount), () => {
    state = withCurrent({ ...state, ledger: [...state.ledger, ...entries] })
    persistNotify()
  })
  return null
}

/** The OIL case of `grantTo` — kept so the tracker and its tests read as they
 *  always did. */
export function grantOil(personIds: string[], amount: number, date: string, reason: string, givenBy = ''): string | null {
  return grantTo(personIds, 'oil', amount, date, reason, givenBy)
}

/** Edit a ledger entry in place — amount, date, reason or given by. The approver and who entered it stay; the change
 *  history records who changed it. Three rules keep an OIL AWARD one fact (the award plan, §2.2 and §2.5):
 *  - ITS DATE IS FIXED (D260's reading: an award never moves — its date is the day it was earned and sets when it runs
 *    out; one on the wrong day is removed and given again). Refused only when the date CHANGES — the tracker's Save
 *    sends the date every time (Fable's round-2 read, N1). A correction and every other pool keep their date editor.
 *  - AN OIL ENTRY KEEPS ITS SIGN: an award never becomes a correction or back, or an award could be re-dated in three
 *    steps (Fable's round-2 read, N2).
 *  - ITS REASON: an award keeps one if it had one, and never has to invent one it never had (given on the grid with
 *    none); a correction always needs one; every other pool keeps its own rule (Astra's round-2 read, R2-05). */
export function updateLedgerEntry(id: string, patch: { amount?: number; date?: string; reason?: string; givenBy?: string }): string | null {
  // The ENTRY first, then the role — so the refusal can name the pool it is
  // about (review, 6 Sep 26). An id that names nothing answers "That entry is
  // gone" first, which is true for a member and an admin alike.
  const cur = state.ledger.find(e => e.id === id)
  if (!cur) return 'That entry is gone'
  if (state.role !== 'admin') return `Only an admin can edit ${counterLabel(cur.counter)}`
  const amount = patch.amount ?? cur.amount
  const date = patch.date ?? cur.date
  const reason = patch.reason ?? cur.reason
  const givenBy = (patch.givenBy ?? cur.givenBy ?? '').trim()
  const award = isOilAward(cur)
  if (award && date !== cur.date) return 'An OIL award stays on its day — delete it and give it again on the right one'
  if (cur.counter === 'oil' && Math.sign(amount) !== Math.sign(cur.amount)) return award
    ? 'An OIL award stays an award — delete it and enter a correction instead'
    : 'A correction stays a correction — delete it and give an award instead'
  const requireReason = award ? cur.reason.trim() !== '' : reasonRequired(cur.counter)
  const problem = ledgerProblem(cur.counter, amount, date, reason, givenBy, requireReason)
  if (problem) return problem
  if (amount === cur.amount && date === cur.date && reason.trim() === cur.reason && givenBy === (cur.givenBy ?? '')) return null
  gesture(ledgerType(cur.counter, cur.amount), () => {
    state = withCurrent({
      ...state,
      ledger: state.ledger.map(e => {
        if (e.id !== id) return e
        const { givenBy: _g, ...rest } = e
        return { ...rest, amount, date, reason: reason.trim(), ...(givenBy ? { givenBy } : {}) }
      }),
    })
    persistNotify()
  })
  return null
}

export function removeLedgerEntry(id: string): boolean {
  if (state.role !== 'admin') return false
  const cur = state.ledger.find(e => e.id === id)
  if (!cur) return false
  return gesture(ledgerType(cur.counter, cur.amount), () => dropLedgerIds([id]))
}

/**
 * Set a person's BALANCE of a counter to read exactly `target` now (owner,
 * 2 Sep 26 — "enable me to manually input and change LVE BAL … every time a
 * LL or OL is taken it deducts from it"). A balance is never stored
 * (counters.ts), so this moves the OPENING FIGURE by whatever makes
 * `opening + granted − drawn` equal the target; the leave already on the
 * grid stays counted and every LL/OL after this deducts as before. The
 * breakdown sheet shows the new opening, so the number is explained, not
 * hidden.
 */
export function setBalance(personId: string, counter: CounterName, target: number): boolean {
  if (state.role !== 'admin') return false
  if (!state.people.some(p => p.id === personId)) return false
  if (!Number.isFinite(target)) return false
  // Through the same ctx the column reads, or "set to 20" would land on a
  // different number than the figure shows once a holiday excuses a day.
  const opening = target - grantedTo(state.ledger, personId, counter) + drawnFrom(getState().wars, personId, counter, figureCtxOf())
  state = withCurrent({
    ...state,
    openings: { ...state.openings, [personId]: { ...state.openings[personId], [counter]: Math.round(opening * 1e6) / 1e6 || 0 } },
  })
  persistNotify()
  return true
}

/* THE COUNTER-COLUMN FIGURE ORDER AND VISIBILITY writers. ADMIN-GATED (owner,
   17 Aug 26: "normal user should not have authority to change the leave war
   column arrangement"; extended 6 Sep 26 — "admin should also be able to
   customise" which figures show at all) — the enforcement is in each writer
   below, mirroring the event-type library. (The counter SELECTION — which
   figure the column shows right now — stays ungated view state; only the
   ORDER and the HIDDEN set are management's.) Persisted under `figorder` and
   `fighidden`. The order is normalised through `orderedFigures` on every
   move, so a stored blob missing a new figure (or naming a dead one) is
   healed the first time it is touched rather than carried forward malformed;
   `visibleFigures` applies the hidden set on top of that healed order, so a
   hidden id that no longer exists just never appears in it. */

/** Move a figure one place up (`-1`) or down (`+1`) the column's order.
 *  Clamped at the ends and a no-op for an unknown id — returns whether it
 *  moved so a caller can disable a control at the boundary. */
export function moveFigure(id: string, dir: -1 | 1): boolean {
  // The column arrangement is management's (owner, 17 Aug 26: "normal user
  // should not have authority to change the leave war column arrangement").
  // Enforced here and not only in the sheet, for the same reason setCell
  // re-checks: the interface hides what a person may not do, the store is
  // what makes it true.
  if (state.role !== 'admin') return false
  const ids = orderedFigures(state.figureOrder).map(f => f.id)
  const i = ids.indexOf(id)
  if (i < 0) return false
  const j = i + dir
  if (j < 0 || j >= ids.length) return false
  ;[ids[i], ids[j]] = [ids[j], ids[i]]
  state = withCurrent({ ...state, figureOrder: ids })
  persistNotify()
  return true
}

/** Put the column's figures back in their catalogue order, and unhide every
 *  one — a reset is the admin's way back to the factory arrangement, and a
 *  figure they hid and forgot about should not survive it. */
export function resetFigureOrder(): void {
  // Same gate as moveFigure — a reset rewrites the arrangement too.
  if (state.role !== 'admin') return
  state = withCurrent({ ...state, figureOrder: [...DEFAULT_FIGURE_ORDER], figureHidden: [] })
  persistNotify()
}

/** The figures the column cycles and the drawer shows: the admin's order,
 *  less the hidden ones. Every surface that lists figures reads this, so a
 *  hidden figure disappears from all of them at once. */
export function visibleFigures(): Figure[] {
  const hidden = new Set(state.figureHidden)
  const shown = orderedFigures(state.figureOrder).filter(f => !hidden.has(f.id))
  // A stale hidden list naming every figure would leave nothing to show —
  // fall back to the whole order rather than an empty column.
  return shown.length ? shown : orderedFigures(state.figureOrder)
}

/** Hide or show one figure. ADMIN-gated, and the last visible figure cannot
 *  be hidden — returns whether anything changed. */
export function toggleFigure(id: string): boolean {
  if (state.role !== 'admin') return false
  // Mirrors moveFigure's unknown-id no-op: an id that names no real figure
  // (a typo, a stale saved order) must not be recorded as hidden forever —
  // `orderedFigures` is the same "does this name a real figure" check the
  // rest of this block already leans on.
  if (!orderedFigures(state.figureOrder).some(f => f.id === id)) return false
  const hidden = new Set(state.figureHidden)
  if (hidden.has(id)) hidden.delete(id)
  else {
    if (visibleFigures().length <= 1) return false
    hidden.add(id)
  }
  state = withCurrent({ ...state, figureHidden: [...hidden] })
  persistNotify()
  return true
}

/* THE MANNING COUNT ROWS' order and visibility (owner, 18 Aug 26: "allow me to
   rearrange or hide some rows that are not needed. Admin only."). Same shape and
   same admin gate as the figure order above; persisted under `manningorder` /
   `manninghidden`. The canonical row set is the DEFAULT requirement's rules
   (plus the set rule when there is one); a per-day override that adds a rule the
   default lacks is reconciled in the interface (CountRows), which is the only
   place that walks every day's actual results. */

/** The rule ids the manning block can draw, in their natural order — `'sets'`
 *  when a set rule exists, then each default rule's id. */
export function manningRowIds(): string[] {
  return state.requirements.default.rules.map(r => r.id)
}

/** The manning rows in DISPLAY order: the admin's hand-order first (unknown ids
 *  dropped), then any not named appended in natural order — the `orderedPeople`
 *  rule, so a rule added to the default after an order was saved still appears
 *  rather than vanishing. Hidden rows are still IN this list; hiding is applied
 *  at render, so Rearrange mode can show and un-hide them. */
export function orderedManningIds(): string[] {
  const all = manningRowIds()
  if (!state.manningOrder.length) return all
  const known = new Set(all)
  const seen = new Set<string>()
  const out: string[] = []
  for (const id of state.manningOrder) if (known.has(id) && !seen.has(id)) { out.push(id); seen.add(id) }
  for (const id of all) if (!seen.has(id)) out.push(id)
  return out
}

/** Move one manning row up (`-1`) or down (`+1`). Clamped at the ends; returns
 *  whether it moved so a control can disable at the boundary. ADMIN-gated. */
export function moveManningRow(id: string, dir: -1 | 1): boolean {
  if (state.role !== 'admin') return false
  const ids = orderedManningIds()
  const i = ids.indexOf(id)
  if (i < 0) return false
  const j = i + dir
  if (j < 0 || j >= ids.length) return false
  ;[ids[i], ids[j]] = [ids[j], ids[i]]
  state = withCurrent({ ...state, manningOrder: ids })
  persistNotify()
  return true
}

/**
 * Move one manning row to sit before `beforeId` (or to the end when null) — the
 * drag-and-drop reorder (owner, 28 Aug 26, replacing the ▲▼ arrows with the
 * same drag the roster rows already use). Same shape as `moveRosterRow`:
 * materialise the current display order, splice `id` out, reinsert before the
 * target, write the whole order. ADMIN-gated. */
export function moveManningRowTo(id: string, beforeId: string | null): void {
  if (state.role !== 'admin') return
  // "before itself" is where it already is — and the splice removes `id` first,
  // so without this guard indexOf would miss and the row would jump to the end
  // (the same trap moveRosterRow guards).
  if (beforeId === id) return
  const ids = orderedManningIds()
  const from = ids.indexOf(id)
  if (from < 0) return
  ids.splice(from, 1)
  const at = beforeId ? ids.indexOf(beforeId) : ids.length
  ids.splice(at < 0 ? ids.length : at, 0, id)
  state = withCurrent({ ...state, manningOrder: ids })
  persistNotify()
}

/** Hide or show one manning row. ADMIN-gated. */
export function toggleManningRow(id: string): void {
  if (state.role !== 'admin') return
  const hidden = new Set(state.manningHidden)
  hidden.has(id) ? hidden.delete(id) : hidden.add(id)
  state = withCurrent({ ...state, manningHidden: [...hidden] })
  persistNotify()
}

/** Put every manning row back — natural order, nothing hidden. ADMIN-gated. */
export function resetManning(): void {
  if (state.role !== 'admin') return
  state = withCurrent({ ...state, manningOrder: [], manningHidden: [] })
  persistNotify()
}

/**
 * Set one manning row's amber/red lines (owner, 19 Aug 26 — "when does the
 * amber show or red show on the box… is customisable"). ADMIN-gated like the
 * row order; the guard-rails line applies — refuse MALFORMED (not a finite
 * non-negative number, or a row that does not exist), accept any decision:
 * amber below red simply means there is no amber band, the SXO seed's own
 * idiom, and refusing it would refuse the seed. Returns whether it wrote, so
 * the sheet can keep its fields on a refusal.
 */
export function setManningThreshold(id: string, amber: number, red: number): boolean {
  if (state.role !== 'admin') return false
  if (!Number.isFinite(amber) || amber < 0 || !Number.isFinite(red) || red < 0) return false
  const rules = state.requirements.default.rules
  if (!rules.some(r => r.id === id)) return false
  const next = rules.map(r => (r.id === id ? { ...r, threshold: { amber, red } } : r))
  state = withCurrent({ ...state, requirements: { ...state.requirements, default: { rules: next } } })
  persistNotify()
  return true
}

/** Put one row's amber/red lines back to the built-in default — only a row
 *  the seed still knows has one; a counter the admin built is its own
 *  default. ADMIN-gated. */
export function resetManningThreshold(id: string): void {
  if (state.role !== 'admin') return
  const seedT = seedRequirements().default.rules.find(r => r.id === id)?.threshold
  if (!seedT) return
  setManningThreshold(id, seedT.amber, seedT.red)
}

/**
 * Create or rework one counter (owner, 19 Aug 26). The rule is pushed through
 * the SAME validator the storage read uses, so the form cannot save a shape a
 * reload would drop. An existing id is replaced in place — the row keeps its
 * position and its hidden flag; a new id is appended and `orderedManningIds`'
 * tail rule shows it at the bottom. ADMIN-gated; returns whether it wrote.
 */
export function saveManningRule(rule: ManningRule): boolean {
  if (state.role !== 'admin') return false
  const clean = readManningRule(rule)
  if (!clean) return false
  const rules = state.requirements.default.rules
  /* a NEW counter past the limit the reload keeps is refused — a longer list would read back as damage and be replaced
     by the built-in set (readManningRules); reworking one already in the list is always allowed
     ([STORE-READER-SWEEP], [DB-READINESS] phase 7) */
  if (!rules.some(r => r.id === clean.id) && rules.length >= MAX_MANNING_RULES) return false
  const next = rules.some(r => r.id === clean.id)
    ? rules.map(r => (r.id === clean.id ? clean : r))
    : [...rules, clean]
  state = withCurrent({ ...state, requirements: { ...state.requirements, default: { rules: next } } })
  persistNotify()
  return true
}

/** Delete one counter outright (owner, 19 Aug 26 — "these counters can also
 *  be deleted"). Its order and hidden entries go with it, so nothing keeps a
 *  dead id alive; a SEEDED id deleted here stays deleted (the stored list is
 *  the whole truth), and `resetManningRules` is the road back. ADMIN-gated. */
export function deleteManningRule(id: string): boolean {
  if (state.role !== 'admin') return false
  const rules = state.requirements.default.rules
  if (!rules.some(r => r.id === id)) return false
  state = withCurrent({
    ...state,
    requirements: { ...state.requirements, default: { rules: rules.filter(r => r.id !== id) } },
    manningOrder: state.manningOrder.filter(x => x !== id),
    manningHidden: state.manningHidden.filter(x => x !== id),
  })
  persistNotify()
  return true
}

/** Put the BUILT-IN counter set back — the recovery path when a seeded row
 *  was deleted or reworked beyond recognition. Counters the admin created
 *  are discarded with everything else, which is what "reset" says; the
 *  toolbar arms the button so one stray tap cannot do it. ADMIN-gated. */
export function resetManningRules(): void {
  if (state.role !== 'admin') return
  state = withCurrent({ ...state, requirements: seedRequirements(), manningOrder: [], manningHidden: [] })
  persistNotify()
}

/** Install Raptor's live qualification catalogue for the counter form's
 *  chips — the projection's rider, change-guarded by the caller like the
 *  roster itself. Not persisted and not admin-gated: it is derived squadron
 *  vocabulary, not a decision. */
export function setQualCatalog(catalog: QualDef[]): void {
  /* A group pinned to a qualification the squadron has since deleted would
     draw an empty heading nobody could remove, so the group list is re-pruned
     whenever the catalogue moves (28 Aug 26). This is not an admin write — it
     is the catalogue's own consequence — so it carries no role gate; it only
     ever REMOVES a group whose qualification no longer exists. */
  const groupDefs = pruneGroups(state.groupDefs, catalog)
  const changed = groupDefs.length !== state.groupDefs.length
  // A pruned group takes its picked colour with it, as a removed one does.
  state = withCurrent({ ...state, qualCatalog: catalog, ...(changed ? { groupDefs, groupColors: colorsFor(groupDefs, state.groupColors) } : {}) })
  // a durable group prune persists+notifies; a pure catalogue reprojection just
  // repaints (qualCatalog is a projection, not a persisted field).
  if (changed) persistNotify(); else notify()
}

/** Walk the period to its next stage. A no-op at the end of the cycle —
 *  `nextStage` owns which transitions exist. ADMIN ONLY (owner, 27 Aug 26 —
 *  "for a member, i shouldnt be able to click on bidding closed or published,
 *  thats an admin function"): moving the cycle forward is a management act,
 *  the mirror of `reopenStage`'s existing admin-only step back. Re-checked at
 *  the write, not just hidden in the strip, the same reason `reopenStage`
 *  and `setBidWindow` re-check. Members otherwise bid exactly as before —
 *  this is the ONLY member-facing change to the war. */
export function advanceStage(): void {
  if (state.role !== 'admin') return
  const next = nextStage(state.period.stage)
  if (!next) return
  /* its own command, `lw.stage` — D352: the one Undo takes it back AND SAYS SO (undo/describe.ts) */
  gesture('lw.stage', () => updateCurrent(w => ({ ...w, period: { ...w.period, stage: next } })))
}

/**
 * Step the period back one stage — how bidding is opened again after it has
 * been closed (owner, 10 Aug 26).
 *
 * Re-checks the role here rather than trusting the strip to have hidden the
 * control, for the same reason `setBidWindow` does: the role switch is an
 * affordance, not a permission, so the refusal has to live where the write
 * is. Returns whether it moved, so a caller can tell "not allowed" from
 * "already at the beginning".
 *
 * **Only the stage changes.** Bids and the decisions on them are untouched:
 * an approved bid is still approved after a reopen, and a refused one still
 * refused. Reopening changes what may happen NEXT, and rewrites nothing that
 * already happened — which is what keeps "why did this change after I bid"
 * answerable now that the cycle can run backwards.
 */
export function reopenStage(): boolean {
  if (!canReopen(state.period.stage, state.role)) return false
  const back = previousStage(state.period.stage)
  if (!back) return false
  gesture('lw.stage', () => updateCurrent(w => ({ ...w, period: { ...w.period, stage: back } })))   // D352
  return true
}

/** What an inbound Raptor input did here.
 *
 *  `clash` is the one a human has to see: Raptor is asking for a date the
 *  squadron already bid differently on, and the spec's rule is that the
 *  system never overwrites a bid — it raises it and a person decides. */
export type IngestResult = 'written' | 'confirmed' | 'clash' | 'ignored'

/**
 * Post an OIL credit earned on the schedule — sync wire 4's writer.
 *
 * Only `FO` and `HO` come through here, from published weekend/PH work or an
 * acknowledged duty claim (`engine/oil.ts`). The credit is an `auto` record the
 * pass may take away again; `spans` are the actual work times (clash check B4,
 * B8). It lands BESIDE whatever else is on the day — ALWAYS, since the owner's
 * 20 Sep 26 ruling: work overlapping leave, a medical or an undecided bid is
 * reported as a clash and the day goes amber, but the credit is still banked
 * and stays until a human resolves it by removing one side or the other. A
 * hand-typed credit already there is the squadron having recorded the same
 * fact first: taken over in place.
 */
export function ingestDutyCredit(personId: string, date: string, code: 'FO' | 'HO', why?: string, spans?: Array<[number, number]>, via: 'schedule' | 'input' = 'schedule'): IngestResult {
  // Locked — a sync-driven credit is not an undo step.
  return locked(() => ingestDutyCreditImpl(personId, date, code, why, spans, via))
}
function ingestDutyCreditImpl(personId: string, date: string, code: 'FO' | 'HO', why?: string, spans?: Array<[number, number]>, via: 'schedule' | 'input' = 'schedule'): IngestResult {
  if (code !== 'FO' && code !== 'HO') return 'ignored'
  if (!warHolding(state.wars, date)) return 'ignored'
  const list = listAt(personId, date)
  /* THE PASS OWNS ITS OWN CREDIT AND NOTHING ELSE. An award on this day is a
     different fact — days the man is OWED — and a ledger entry, not a war
     record ([OIL-AWARD-IS-A-GRANT]), so this writer cannot see one at all. */
  const had = list.find(r => isCredit(r) && r.oil === 'auto') as CreditRec | undefined
  const note = (why ?? '').trim().slice(0, MAX_REC_NOTE)
  const clean = spans?.filter(s => Array.isArray(s) && s[0] <= s[1] && s[0] >= 0 && s[1] <= 1439)
  const rec: CreditRec = { id: had?.id ?? newRecId('c'), kind: 'credit', code, oil: 'auto', via, ...(note ? { note } : {}), ...(clean && clean.length ? { spans: clean } : {}) }
  const probe = recContribs([rec]).map(c => ({ ...c, id: 'new' }))
  const staying = list.filter(r => r !== had)
  const others = [...recContribs(staying), ...absencesAt(personId, date)]
  /* THE CREDIT LANDS EVEN WHEN IT OVERLAPS AN ABSENCE (owner, 20 Sep 26 —
     "if someone is working, even tho they have leave on that day, it should
     still bank the OIL credit … until that thing is resolved — which means
     that if work is removed, then no OIL credit. If leave is removed then OIL
     still credits").
     This SETS ASIDE clash-check B4's "Overlap → no credit" half. B4's time
     test itself stands, in `forbiddenPair`, and is exactly what turns the day
     amber. Refusing to place the credit was the older reading and it cost more
     than it saved: the forward pass wrote nothing, the reverse pass skipped
     the address because the address was still wanted, and a credit already
     sitting there under evidence that had since changed went on claiming hours
     the person no longer worked. Writing unconditionally fixes that by
     overwriting, and the resolution the owner describes falls out of machinery
     that already exists — `dayView` derives the amber from the very pair we no
     longer refuse, the strip is derived from the same conflicts, and the
     reverse pass already removes an auto credit once the work is gone. */
  const clash = probe.some(p => others.some(o => forbiddenPair(p, o)))
  /* Idempotent on purpose: the pass runs on EVERY change, so an unchanged day
     must recognise its own credit and write nothing. Since N16 that comparison
     is simple again — the record on the day is the pass's own and carries
     nothing it did not put there, so it is compared against exactly what this
     run would write. */
  /* its place at the address (`ord`, [DB-READINESS] group A phase 3) is the store's, not the credit's — compared without it */
  const same = had && had.code === code && JSON.stringify({ ...had, ord: undefined }) === JSON.stringify(rec)
  if (same) return clash ? 'clash' : 'confirmed'
  /* NOTHING IS TAKEN OVER ANY MORE (N16, 21 Sep 26 — "an award and a worked
     day add up. So it's 4. The auto oil credits don't get affected by manual
     OIL inputs").

     What stood here was the take-over: the schedule's credit landing ON TOP of
     an award, with the award stashed in a snapshot so an unpublish could hand
     it back, and — after the 21 Sep defect — the award's quantity and words
     copied across so its worth would not fall. Every line of it existed for
     one reason: a person/date could hold ONE credit, so two facts had to share
     a slot. The owner's ruling gives them a slot each, and the whole apparatus
     goes with it: no snapshot, no hand-back, no keeping the larger of the two.

     That is the point, not a side effect. Both of the silent balance bugs
     found on the night of 20–21 Sep lived inside that snapshot, and so did
     the one both reviewers found in the plan for THIS change. An award the
     pass cannot see is an award the pass cannot damage. */
  /* an existing credit is updated IN ITS PLACE, with its place — never moved to the end, which would give the record
     beside it a new place and rewrite its row (the group-wide walk — W3 finding 2's twin) */
  putList(personId, date, had ? list.map(r => (r === had ? (typeof had.ord === 'number' ? { ...rec, ord: had.ord } : rec) : r)) : [...staying, rec])
  /* 'clash' still REPORTS — the day needs a human — but it no longer means
     "nothing was written". The credit is on the day either way. */
  return clash ? 'clash' : 'written'
}

/** What `setCell` / `cellProblem` say to an FO / HO typed as a cell code. */
export const OIL_DOOR_MSG = 'OIL is given from the day’s +OIL panel or the OIL tracker.'

/**
 * GIVE — OR CHANGE — THE DAY'S OIL AWARD FROM THE GRID (the bid sheet's +OIL panel; owner, 20 Sep 26 — "the admin can
 * also credit OIL on the leave sheet for convenience. We should enable that even on any day", D79).
 *
 * Since [OIL-AWARD-IS-A-GRANT] (29 Sep 26) the award is ONE kind of record whichever door gives it: a positive OIL entry
 * in the ledger, drawn on the grid on its date (D402). This is the grid's door to it. The AMOUNT is the award's worth
 * (`days`); FO / HO is only how the box is labelled (half a day HO, anything else FO).
 *
 * A day holding NO award gets a new one; a day holding exactly ONE has it rewritten (its amount, reason, given by — its
 * date never, D260); a day holding SEVERAL (two tracker credits on one date) is changed from the day's list, one award at
 * a time, never here — the panel would have to guess which. ONE command, ONE undo step. A reason is optional here, as
 * it always was on the grid (the tracker's form asks for one — §2.2 of the plan). Refused only where refusing is the
 * truth: not an admin, no war on that date, days that are not halves. Never refused for clashing with leave: an award
 * clashes with nothing (D80) and adds to a worked day (D82).
 */
export function setDayAward(personId: string, date: string, days: number, opts: { note?: string; givenBy?: string } = {}): string | null {
  if (state.role !== 'admin') return 'Only an admin can enter OIL'
  if (!warHolding(state.wars, date)) return 'That day is in no war'
  if (!Number.isFinite(days) || days <= 0) return 'Type how many days'
  if (!isHalfStep(days)) return HALF_STEP_MSG
  if (days > MAX_GRANT_DAYS) return `That is more than ${MAX_GRANT_DAYS} days`
  const note = (opts.note ?? '').trim()
  const givenBy = (opts.givenBy ?? '').trim()
  const here = awardsOnDay(personId, date)
  if (here.length > 1) return `This day holds ${here.length} OIL awards — change them from the day’s list`
  if (here.length === 1) return updateLedgerEntry(here[0]!.id, { amount: days, reason: note, givenBy })
  const problem = ledgerProblem('oil', days, date, note, givenBy, false)
  if (problem) return problem
  const entry: LedgerEntry = {
    id: ledgerId(), personId, counter: 'oil', amount: days, date, reason: note, approvedBy: approverName(),
    ...(givenBy ? { givenBy } : {}), ...entered(),
  }
  gesture('lw.award', () => {
    state = withCurrent({ ...state, ledger: [...state.ledger, entry] })
    persistNotify()
  })
  return null
}

/**
 * CHANGE AN AWARD'S REASON, ITS GIVER AND ITS DAYS — AS ONE THING (Astra, 21 Sep 26): the tap list's Edit… and the day
 * window. Addressed by the award's own id (a day may hold several). One command, one undo step; everything is checked
 * before anything is written. `null` days is refused — an award is worth what it says (the old "blank means the code's
 * own worth" went with the code). Returns null when done, else the reason in the sheet's words.
 */
export function editAward(id: string, patch: { note?: string; givenBy?: string; days?: number }): string | null {
  const cur = state.ledger.find(e => e.id === id)
  if (!cur || !isOilAward(cur)) return 'There is no OIL award there'
  if (patch.days !== undefined && patch.days > MAX_GRANT_DAYS) return `That is more than ${MAX_GRANT_DAYS} days`
  return updateLedgerEntry(id, {
    ...(patch.days !== undefined ? { amount: patch.days } : {}),
    ...(patch.note !== undefined ? { reason: patch.note } : {}),
    ...(patch.givenBy !== undefined ? { givenBy: patch.givenBy } : {}),
  })
}

/**
 * Remove a GENERATED credit the schedule no longer earns — the OIL pass's
 * clean-up, and nothing else's. A hand-typed credit is never touched (design
 * §18 OA3-003). Ignores stage, role and window: the schedule's word arrives
 * already decided.
 */
export function clearRaptorCell(personId: string, date: string): boolean {
  // Locked: a sync-driven delete is not a Leave War undo step.
  return locked(() => {
    const list = listAt(personId, date)
    const had = list.find(r => r.kind === 'credit' && r.oil === 'auto') as CreditRec | undefined
    if (!had) return false
    /* THE HAND-BACK IS GONE, AND THAT IS THE POINT (N16, 21 Sep 26).
       This used to restore an award the schedule had taken over — a whole
       snapshot-and-return apparatus whose only job was to undo damage the
       takeover had done. Since an award is now its own record, the pass never
       touched it, so there is nothing to give back: removing the schedule's
       credit simply leaves the award standing, which is what design §18
       OA3-003 asked for all along. */
    return putList(personId, date, list.filter(r => r !== had))
  })
}

/* [LW-SPARE-MOVE-DOORS] (28 Sep 26): `shiftBid` (the old single-bid mover — it read the day's TOP record) and
   `moveAbsenceById` (the day's list's old date-box move) are RETIRED. Since [LW-MOVE-STANDARD] every move goes through
   ONE door, `moveRecords` below (the records it picked); two more doors that read differently would drift. What their
   tests pinned (the dotted mark's original origin on a chain of moves, the locked-week refusal, a wrong id moving
   nothing, a retyped medical not moved, no notify on a refusal, the trail across a reload, one change line) now runs
   through `moveRecords`.
 */

/* ---- A MOVE CARRIES THE RECORDS IT PICKED (owner, D265 / D266 / D333, 27 Sep 26 — [LW-MOVE-STANDARD]) ----------------

   "For multiple records for those can be moved, u see my example 3rd and 4th picture, I couldn't see a move button for
    vector."  Every grid move used to ask the day's TOP record (the ladder: leave, medical, OIL credit, course, bid…), so
   a bid beneath an OIL award, beside leave filed on the Inputs page, or in the other half of a day holding approved leave
   could be moved by no door — and a block over such a day moved the wrong thing or nothing. A move now carries RECORDS:
   every record on the chosen days that this role may move (a block, a one-day sheet, a picked range), or exactly the one
   the day's list picked by its id (D266). What cannot move — an award (D260), leave filed on the Inputs page, a medical,
   a course, the schedule's own OIL, approved leave on a published war — stays where it is, and `stayingIn` names it
   (the banner says what stays). The landing rules are the old ones (D265 (1)): refused whole, with where, when a moving
   record cannot land. Scenarios: docs/superpowers/specs/2026-09-27-lw-move-standard-scenarios-fable.md. */


/** One record a move carries: a request (the war's own) or a leave the war approved (an Input, by its iid). */
export interface MoveRec { personId: string; date: string; id: string; kind: 'request' | 'absence' }

/** The merged view of one address (what the grid draws from). */
function viewAt(personId: string, date: string) {
  const war = warHolding(getState().wars as MergedWar[], date) as MergedWar | undefined
  return war?.views[personId]?.[date]
}

/* WHO MAY MOVE — ONE RULE, EVERY DOOR (D333: "a member gets Move on his own bid while bidding is open"). A request: on a
   row this role may write, on a day it may write (a member: his own row, inside the bidding window, while bidding is
   open — `canEditCell`; the admin: any row, any stage but draft's window rules as ever). A REFUSED request is a record
   that can move too — it lands undecided, a move being a proposal (D262 (b); the mock-up's reading, uncorrected) — but
   NOT while a live bid holds its half: it is history beside that bid, and moving the two together would land two live
   bids on one half (Fable's S32). */
function requestMovable(personId: string, date: string, r: RequestRec, list: readonly WarRec[]): boolean {
  if (!canEditRow(state.role, state.viewer, personId)) return false
  if (!isBiddable(r.code) || !canEditCell(state.period, state.role, date)) return false
  if (r.state === 'refused' && liveRequestsOn(list, portionOfCode(r.code)).length) return false
  /* …AND BENEATH AN ABSENCE ON ITS HALF (Fable's final read, finding 2, 27 Sep 26): a refused morning stays as history
     when a second morning bid is approved (the approval drops only its own record), so a day holds approved leave AND
     the refused bid on the same half. Moved together, the bid landed alive where the leave landed and the door — at the
     commit — refused the leave, silently: half a move. Asked as a LIVE bid would be (a refused one bars nothing). */
  if (r.state === 'refused') {
    const c: Contrib = { id: r.id, kind: 'request', code: parseCell(r.code)!.type, win: requestWin(r.code), state: 'pending' }
    if (absencesAt(personId, date).some(a => barsWrite(c, a))) return false
  }
  return true
}
/* A leave the WAR approved: the admin at a deciding stage, never on a published war (finished paperwork — owner,
   21 Sep 26); by its own iid, so a day holding it beside leave filed on the Inputs page still moves it (Fable's S10 —
   the day's list always could, by id; the grid refused the whole day as "owned by Raptor"). The door checks the rest
   (a locked week, the landing). */
function absenceMovable(personId: string, date: string, iid: string): boolean {
  if (!canEditRow(state.role, state.viewer, personId)) return false
  if (!canDecide(state.period.stage, state.role) || getState().period.stage === 'published') return false
  const a = viewAt(personId, date)?.all.find(c => c.kind === 'absence' && c.id === iid)
  return !!a && !!a.lw && isLeaveCode(a.code)
}

/** Every record on these days this role may move — or, with `only`, just the ones named there (the day's list picks
 *  one by its id, D266). In the cells' order; a day listed twice counts once. */
export function movableRecords(
  cells: readonly { personId: string; date: string }[],
  only?: readonly { personId: string; date: string; id: string }[],
): MoveRec[] {
  const out: MoveRec[] = []
  const seen = new Set<string>()
  for (const { personId, date } of cells) {
    const key = `${personId}|${date}`
    if (seen.has(key)) continue
    seen.add(key)
    const list = listAt(personId, date)
    for (const r of list) if (r.kind === 'request' && requestMovable(personId, date, r, list)) out.push({ personId, date, id: r.id, kind: 'request' })
    for (const a of absencesAt(personId, date)) if (absenceMovable(personId, date, a.id)) out.push({ personId, date, id: a.id, kind: 'absence' })
  }
  if (!only) return out
  return out.filter(m => only.some(o => o.personId === m.personId && o.date === m.date && o.id === m.id))
}

/** The cells of a selection that hold something this role may move (the loose-box rule, owner 27 Aug 26 — the empty
 *  cells swept up around the inputs are dropped). Since D265 "something" is ANY record on the day, not its top one. */
export function movableCells(cells: { personId: string; date: string }[]): { personId: string; date: string }[] {
  const has = new Set(movableRecords(cells).map(m => `${m.personId}|${m.date}`))
  return cells.filter(c => has.has(`${c.personId}|${c.date}`))
}

/** What a move leaves behind on its days, and says so (the mock-up's reading, uncorrected — D331: "in a block what can
 *  move goes; what can't stays, and the banner says what stays"). Only the things a person put there and might expect to
 *  travel: an OIL award, leave (filed on the Inputs page, or approved on a published war), a bid this role may not move,
 *  a refused bid kept as history.
 *  A medical, a course, the schedule's own OIL and a notice are never a move's business and go unsaid. */
export function stayingIn(
  cells: readonly { personId: string; date: string }[], movers: readonly MoveRec[],
): Array<{ personId: string; date: string; what: 'award' | 'filed' | 'approved' | 'bid' | 'refused' }> {
  const moving = new Set(movers.map(m => `${m.personId}|${m.date}|${m.id}`))
  const out: Array<{ personId: string; date: string; what: 'award' | 'filed' | 'approved' | 'bid' | 'refused' }> = []
  const seen = new Set<string>()
  for (const { personId, date } of cells) {
    const key = `${personId}|${date}`
    if (seen.has(key)) continue
    seen.add(key)
    /* an award never moves (D260, D265) — it is a ledger entry drawn on its day, and says it stays */
    for (const _a of awardsOnDay(personId, date)) out.push({ personId, date, what: 'award' })
    for (const r of listAt(personId, date)) {
      if (moving.has(`${key}|${r.id}`)) continue
      /* a refused bid staying behind is said too (Astra's final read, 3): history the move does not carry */
      if (r.kind === 'request') out.push({ personId, date, what: r.state === 'refused' ? 'refused' : 'bid' })
    }
    for (const a of absencesAt(personId, date)) {
      if (moving.has(`${key}|${a.id}`) || !isLeaveCode(a.code)) continue
      out.push({ personId, date, what: a.lw ? 'approved' : 'filed' })
    }
  }
  return out
}

export type MoveResult = 'moved' | { reason: 'nothing' | 'raptor' | 'occupied' | 'window'; at?: string }

/** The validation half of `moveRecords`, held apart so the grid's landing preview asks the SAME rule the commit
 *  applies. Null when clear. Each record is asked again here (the store's own gate, not the caller's word). */
export function moveRecordsProblem(recs: readonly MoveRec[], dayDelta: number): Exclude<MoveResult, 'moved'> | null {
  if (!dayDelta || recs.length === 0) return { reason: 'nothing' }
  const dayset = new Set(state.period.days.map((d: any) => d.date))
  const reqs: Array<{ personId: string; date: string; rec: RequestRec }> = []
  const abs: Array<{ personId: string; date: string; iid: string }> = []
  for (const m of recs) {
    if (m.kind === 'absence') {
      if (!absenceMovable(m.personId, m.date, m.id)) return { reason: 'raptor', at: m.date }
      abs.push({ personId: m.personId, date: m.date, iid: m.id })
      continue
    }
    const list = listAt(m.personId, m.date)
    const rec = list.find((r): r is RequestRec => r.kind === 'request' && r.id === m.id)
    if (!rec || !requestMovable(m.personId, m.date, rec, list)) return { reason: 'nothing', at: m.date }
    reqs.push({ personId: m.personId, date: m.date, rec })
  }
  const moving = new Set(reqs.map(r => r.rec))
  for (const r of reqs) {
    const to = addDays(r.date, dayDelta)
    if (!dayset.has(to)) return { reason: 'window', at: to }
    if (!canEditCell(state.period, state.role, to)) return { reason: 'window', at: to }
    const landing = listAt(r.personId, to).filter(x => !moving.has(x as RequestRec))
    const c: Contrib = { id: r.rec.id, kind: 'request', code: parseCell(r.rec.code)!.type, win: requestWin(r.rec.code), state: 'pending' }
    /* the selection's own approved leave sliding away frees its landing too — THAT DAY of it only (the final reads, Fable 1
       and Astra 1, both blind, 27 Sep 26): a block moves the days of a multi-day leave that sit in it, not the whole
       leave, and asking by id alone let a bid land on the leave's untouched day. Keyed by id AND date, as the door's
       own `leaving` set is. */
    const absHere = absencesAt(r.personId, to).filter(a => !abs.some(x => x.iid === a.id && x.personId === r.personId && x.date === to))
    /* (a request landing where a moving approved leave lands can only come from the same day, in the other half — the
       refused bid beneath leave on its own half is not movable, above; anything the preview cannot see, the door's answer
       at the commit rolls back, `moveRecords`) */
    if ([...recContribs(landing), ...absHere].some(o => barsWrite(c, o))) return { reason: 'occupied', at: to }
    if (liveRequestsOn(landing, portionOfCode(r.rec.code)).length) return { reason: 'occupied', at: to }
  }
  if (abs.length) {
    for (const a of abs) if (!dayset.has(addDays(a.date, dayDelta))) return { reason: 'window', at: addDays(a.date, dayDelta) }
    /* the moving requests still stand on their old days now — the door leaves them out (Fable 3, Astra 1) */
    const skip = new Set(reqs.map(r => r.rec.id))
    const p = DOOR ? DOOR.moveApproved(abs, dayDelta, biddingClosed(state.period.stage), true, skip) : { reason: 'nothing' as const }
    if (p) return p
  }
  return null
}

/** Move these records by a day-delta — ATOMIC: validated first, then ONE gesture — requests re-placed undecided (with
 *  the moved-from trail once bidding is closed), approved leave slid through the absence door — one envelope, one undo
 *  step. Every door's move ends here: the drag-select's, the one-day sheet's, the day's list's. */
export function moveRecords(recs: readonly MoveRec[], dayDelta: number): MoveResult {
  const problem = moveRecordsProblem(recs, dayDelta)
  if (problem) return problem
  const tracked = biddingClosed(state.period.stage)
  /* THE DOOR'S ANSWER AT THE COMMIT IS HONOURED (Fable's final read, finding 2 (b), 27 Sep 26): it used to be thrown
     away, so a refusal only the commit met (the requests already landed) left half a move and the banner said nothing.
     A refusal now throws inside the gesture — the command rolls the whole move back — and is returned, said like any
     other. */
  let refused: Exclude<MoveResult, 'moved'> | null = null
  try {
    gesture('lw.move', () => {
    const reqs: Array<{ personId: string; from: string; to: string; rec: RequestRec }> = []
    const abs: Array<{ personId: string; date: string; iid: string }> = []
    for (const m of recs) {
      if (m.kind === 'absence') { abs.push({ personId: m.personId, date: m.date, iid: m.id }); continue }
      const rec = listAt(m.personId, m.date).find((r): r is RequestRec => r.kind === 'request' && r.id === m.id)
      if (rec) reqs.push({ personId: m.personId, from: m.date, to: addDays(m.date, dayDelta), rec })
    }
    const wasQuiet = quiet
    quiet = true
    try {
      // every source out before any landing, so a block sliding over itself
      // never deletes a day it has just filled
      for (const r of reqs) putList(r.personId, r.from, listAt(r.personId, r.from).filter(x => x !== r.rec))
      for (const r of reqs) {
        const landed: RequestRec = {
          id: r.rec.id, kind: 'request', code: r.rec.code, state: 'pending',
          ...(tracked ? { shiftedFrom: r.rec.shiftedFrom ?? r.from } : {}),
          ...(r.rec.carried ? { carried: r.rec.carried } : {}),
        }
        putList(r.personId, r.to, [...listAt(r.personId, r.to), landed])
      }
    } finally { quiet = wasQuiet }
    if (reqs.length && !quiet) persistNotify()
    if (abs.length && DOOR) {
      const d = DOOR.moveApproved(abs, dayDelta, tracked, false)
      if (d) { refused = d; throw new MoveRefusedAtCommit(d.reason) }
    }
    })
  } catch (e) { if (!(e instanceof MoveRefusedAtCommit)) throw e }
  return refused ?? 'moved'
}

/** The throw that rolls a move back when the absence door refuses at the commit (inside a command the command catches it
 *  and rolls back; outside one — before the war is ready — `moveRecords` catches it). */
class MoveRefusedAtCommit extends Error {
  constructor(reason: string) { super(`lw.move: the absence door refused at the commit — ${reason}`) }
}

/* THE CELL-SHAPED DOORS, KEPT (every caller and test that moves "these days"): a day with nothing this role may move is
   still refused with its reason — a leave the war does not own reads "owned by Raptor", anything else "nothing" — and
   every other day contributes ALL its movable records (D265), where it used to contribute only its top one. */
function cellsToRecords(cells: readonly { personId: string; date: string }[]): MoveRec[] | Exclude<MoveResult, 'moved'> {
  const recs = movableRecords(cells)
  for (const c of cells) {
    if (recs.some(m => m.personId === c.personId && m.date === c.date)) continue
    if (!canEditRow(state.role, state.viewer, c.personId)) return { reason: 'nothing', at: c.date }
    const top = mainAt(c.personId, c.date)
    return { reason: top?.kind === 'absence' ? 'raptor' : 'nothing', at: c.date }
  }
  return recs
}

/** The validation half of `moveCells` — the records on these days, asked as `moveRecordsProblem` asks them. */
export function moveProblem(cells: { personId: string; date: string }[], dayDelta: number): Exclude<MoveResult, 'moved'> | null {
  if (!dayDelta || cells.length === 0) return { reason: 'nothing' }
  const recs = cellsToRecords(cells)
  return Array.isArray(recs) ? moveRecordsProblem(recs, dayDelta) : recs
}

/** Move a whole SELECTION by a day-delta — the drag-select "Move" (owner, 27 Aug 26): every record on its days this role
 *  may move (D265), atomic, one undo step. */
export function moveCells(cells: { personId: string; date: string }[], dayDelta: number): MoveResult {
  if (!dayDelta || cells.length === 0) return { reason: 'nothing' }
  const recs = cellsToRecords(cells)
  return Array.isArray(recs) ? moveRecords(recs, dayDelta) : recs
}

/** WHAT A DECIDE OF THESE DAYS WOULD ANSWER — the number of days on which `setBidStates` would find something to
 *  decide, asked without writing (the final reads, Fable 4 / Astra 2, both blind, 27 Sep 26: with a range picked from a
 *  day holding no bid, the one-day sheet drew no Decide, though D335 widens Decide to the range). The same eligibility
 *  `setBidStates` applies: the admin at a deciding stage; a bid (live, or the day's shown one), or a leave the war approved
 *  that may be sent back. */
export function decidableIn(cells: readonly { personId: string; date: string }[]): number {
  if (!canDecide(state.period.stage, state.role)) return 0
  let n = 0
  for (const { personId, date } of cells) {
    if (!warHolding(state.wars, date)) continue
    const m = mainAt(personId, date)
    if (liveRequestsOn(listAt(personId, date), 'full').length || m?.kind === 'request' || (m?.kind === 'absence' && warEditable(personId, date))) n++
  }
  return n
}

/** WHAT A DELETE OF THESE DAYS WOULD CHANGE — the number of days on which `clearCells` would take something, asked
 *  without writing (D332 with the house rule "offer only what can be taken": the sheets draw Delete only where it would
 *  do something). The same gates `clearCells` runs: a request or — for the admin — an award on a day this role may
 *  write; a leave the war approved that the admin may remove (never on a published war). */
export function deletableIn(cells: readonly { personId: string; date: string }[]): number {
  let n = 0
  for (const { personId, date } of cells) {
    if (!warHolding(state.wars, date)) continue
    const writable = canEditCell(state.period, state.role, date) && canEditRow(state.role, state.viewer, personId)
    /* an award only-day offers Delete to the admin (D260 (c)) — the award is a ledger entry, asked of the ledger */
    const own = writable && (listAt(personId, date).some(r => r.kind === 'request') || awardIdsAt(personId, date).length > 0)
    const approved = state.role === 'admin' && canDecide(state.period.stage, state.role) && warEditable(personId, date)
    if (own || approved) n++
  }
  return n
}

/**
 * Ask the matrix to bring one day into view.
 *
 * View state in the domain store, deliberately: the stage strip and the
 * matrix render independently of each other on purpose — neither takes props
 * from the other, so both stay renderable standalone in their own tests — and
 * the store is already the channel they share. It is not persisted; where
 * someone was last looking is not a fact about the leave war.
 */
export function focusDay(date: string): void {
  state = { ...state, focusDate: date, focusSeq: state.focusSeq + 1 }
  notify()
}

/** Put a different leave war on screen. Unknown ids are ignored rather than
 *  blanking the grid — a stale link is not worth an empty page. */
export function selectWar(id: string): void {
  if (id === state.currentId) return
  const picked = state.wars.find(w => w.period.id === id)
  if (!picked) return
  // Land on the START of the new war's bidding window (owner, 7 Sep 26 — the
  // same rule as opening the tab). The old focus pointed into the war just
  // left, and since wars do not overlap that date names no column in the new
  // grid — so it had to go; but rather than drop it to nothing, we point it at
  // the new war's own bid-start, a real column here and where the reader wants
  // to be. `focusSeq` bumps so the matrix re-runs its jump even when the two
  // wars happen to share a start date.
  state = withCurrent({
    ...state,
    currentId: id,
    focusDate: defaultFocusDate(picked.period),
    focusSeq: state.focusSeq + 1,
  })
  persistNotify()
  // Undo is scoped to the war on screen: switching wars starts a fresh stack,
  // so an undo can never reach back and silently rewrite the war just left
  // (the same per-context re-baseline the scheduler does on loadWeek). The
  // persist() above made no step of its own — only `current` changed.
  lwHistInit()
}

/**
 * Install a full set of wars into the live store, replacing whatever is there,
 * and select `currentId` (falling back to the first war if that id is absent).
 *
 * The raw blob is validated through the SAME `readWars` path a stored blob
 * would have taken at boot, so its states reconcile against their grid exactly
 * as a persisted war did — returns false and changes nothing if it does not
 * pass. It does not persist: this is a live injection, not a save.
 *
 * Its one caller is the e2e probe bridge. The under-manned fixtures — which used
 * to inject a red-day war by writing `leavewar:wars` into localStorage before
 * boot — cannot reach the store that way, so they boot the app and then push the
 * same war object in through here. Not a production path.
 * CORRECTED 17 Sep 26: the old reason given was "Leave War is session-only now (a
 * memory backend)". It is not — Leave War persists on a built site; the memory
 * backend is the dev/test path, which is what the e2e run uses. The bridge is
 * still the right seam because it does not depend on which backend is mounted.
 */
export function loadWars(raw: unknown, currentId: string): boolean {
  const wars = readWars(raw)
  if (!wars) return false
  const id = wars.some(w => w.period.id === currentId) ? currentId : (wars[0] ? wars[0].period.id : '')
  state = withCurrent({ ...state, wars, currentId: id })
  notify()
  // A wholesale world swap re-baselines undo — an undo must not reach back to
  // the world that was here before the injection (same rule as selectWar).
  lwHistInit()
  return true
}

/**
 * Which existing war already covers part of this span, if any.
 *
 * `createWar` returns a bare `'overlap'`, and "those dates overlap a leave
 * war that already exists" sends an admin hunting through the picker for
 * which one. The owner hit exactly that: they typed Apr–Aug 27, were told
 * "overlap", and reasonably concluded it was a bug because the dates plainly
 * did not touch 2026 — the war they clashed with was JAN - DEC 27, and
 * nothing on screen said so.
 *
 * A selector rather than a wider `CreateWarResult`, because the refusal
 * itself is a tested contract and this is a question about the sentence, not
 * about the rule.
 */
export function clashingWar(start: string, end: string): Period | null {
  return state.wars.find(w => overlapping(w.period, { start, end }))?.period ?? null
}

/** Why a war was not created. */
export type CreateWarResult = 'created' | 'overlap' | 'backwards' | 'unnamed' | 'forbidden'

/**
 * Create a leave war over any span the admin asks for, down to a single
 * month. A quarter is the common case, not a rule.
 *
 * It lands in DRAFT and does not take the screen: opening it is a separate
 * act taken when the schedule firms up, and switching to it would yank the
 * admin out of the war they were working in to look at an empty one.
 *
 * The overlap refusal is the load-bearing one. A date must belong to at most
 * one war, or a person could hold leave on it twice over — the manning
 * counts would count him away twice and his balance would be drawn twice,
 * with nothing downstream able to say which war was the real one.
 */
export function createWar(name: string, start: string, end: string): CreateWarResult {
  // Checked here rather than trusted to the hidden button: the role switch
  // is unguarded, so the store is the only place this can actually mean
  // anything. See `docs/known-gaps.md`.
  if (state.role !== 'admin') return 'forbidden'

  const clean = name.trim()
  if (!clean) return 'unnamed'
  if (end < start) return 'backwards'

  const war = makeWar(`war-${start}-${end}`, clean, start, end)
  if (state.wars.some(w => overlapping(w.period, war.period))) return 'overlap'

  state = withCurrent({ ...state, wars: [...state.wars, war] })
  persistNotify()
  return 'created'
}
