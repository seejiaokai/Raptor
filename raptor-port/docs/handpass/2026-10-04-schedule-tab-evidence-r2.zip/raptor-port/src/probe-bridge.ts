/* The probe bridge — the reference is a single script, so its Playwright
   probes call app globals straight off window (openScheduler(0),
   slotVal('d:0.0.0'), DAYS[2]…). The port's modules are ESM, so nothing
   lands on window by itself. This shim republishes the same names the
   probes use, backed by the real modules, so the reference probe sweep can
   drive the React build unchanged. It changes no behaviour — it only makes
   the existing API reachable — and it weighs a few hundred bytes. */
import { DAYS } from './engine/data'
import { PEOPLE, isScheduler, isLead, isInstr, isInstrPilot, isOcu, isPersonnel, sanStatus, nameToId, aarNeed, aarOK, scShiftKind } from './engine/people'
import { INPUTS, INPUT_TYPES, INPUT_META, TYPE_GROUPS, DATES, inpMeta, inpType, canSpare, canWork, awayAllDay, inpWin, typeGroup, isLeave, isLocalLeave, isDownchit, isOffType, isPersonal, isUnavail, isFly, isAway, isSansAvail, isUpchit, sansAvailOn, sansWindow, sansLetters, sansBadge, inputFlags, inputDormant, inputCoversDate, inpLabel, isOther, restsInput, dateOrd, dateIx, baseYear, isLateInput, lateNote, inputDueISO, inputOwnDueISO, inputWeekStartISO, weekStartISO, inputStampISO } from './engine/inputs'
import { medDownAsOf, pendingUpchits, upchitsWithin, medEpisode, upchitTrimPlan, newMedTrimPlan, ordShift, ordLabel } from './engine/medical'
import { VCONF, SHIFT_HARD, RULE_STD, RULE_SPEC, ruleParse, rulesOffCount, rulesReset, rulesLoad, rulesSave, ruleFmt, ruleOff, kindOff, KIND_LABEL } from './engine/rules'
import { ELOG, elogRows, elogFor, elogWhen, elogClear, elogRemap, keyLabel } from './engine/editlog'
import { STORE_CFG, STORE_STD, storeKey, addStore, delStore, renameStore, moveStore, storesSave, storesLoad, storesReset, storesAreStandard, storesText } from './engine/stores'
import { CXR_CFG, CXR_STD, addCxReason, delCxReason, renameCxReason, moveCxReason, cxReasonsSave, cxReasonsLoad, cxReasonsReset, cxrAreStandard } from './engine/cxreasons'
import { DAYTPL_CFG, DAYTPL_STD, tplFromDay, addDayTpl, delDayTpl, renameDayTpl, moveDayTpl, applyDayTpl, dayTplSave, dayTplLoad, dayTplReset, dayTplAreStandard } from './engine/daytpl'
import { dayOilCredits, dayOilSpans, envMin, uniformOil, inputOilAmt } from './engine/oil'
import { oilDayFigures, oilFigureFor, oilItemOfKey } from './ui/oilmode'
import { oilEvidenceOf, oilEarnedWork } from './engine/oilev'
import { refreshHistDots, HIST_CELLS } from './ui/histbubble'
import { SCHED, SIGN_ROLES, markEdit, publishALDay, setDayApproved, signOf, dayApproved, alColor, alCount, alDays, signMissing, nextSeq, pendDays, pendCount, approvedDays, daysLabel, daySnapOf, dayVersions, verLabel, dayCurVer } from './engine/publish'
import { dayKeys } from './engine/restore'
import { dayDrafts, curDraftId, draftDup, draftSelect, draftRename, draftDelete, draftVerLabel, isDraftVer, rebaseDayPending, loadVersionToWorkingCopy, reconcileIssuedMarks } from './engine/drafts'
import * as V from './engine/validate'
import { validate, WCODE, wlbl, chipOf, sevOf, CHIP_LABEL, RANK, restClear, dayEvents, traceOf, traceLeads, traceIx } from './engine/validate'
import { collectEvents, scSeatHit, avSeatHit } from './engine/events'
import { slotVal, setSlotVal, fillSlot, txtGet, txtSet, rowCrew, acRef, rollCx, whoArr, rowRef, acceptInput, unacceptInput, inpKey, acceptedDay, renameCallsign } from './engine/slots'
import { slotBar, dayEngaged, slotRules, dayOff, dayAway, sansGate, SANS_LABEL } from './engine/avail'
import { isStandalone, makeStandalone, waveDutyBlock, saDutyIx, DUTY_PICK, SAWAVE, dayCount, saExempt } from './engine/waves'
import * as waves from './engine/waves'
import { keyDay, shiftKeys, shiftAircraft, shiftFormation, shiftWave, uniqDays, permuteKeys, moveKeys } from './engine/keys'
import { applyMove, moveWave, waveInsertSlot, waveDefault, waveDefaultView, setWaveDefault, moveWaveDefault } from './engine/reorder'
import { hhmm, parseHM, hmOK, minus, overlap, hm24 } from './engine/time'
import { HIST, histSnap } from './state/history'
import { commandStream } from './command'
import { resyncSchedBaseline, schedBaselineClean } from './state/sched-commit'
import { HOOKS } from './engine/hooks'
import * as view from './state/view'
import { setLgEdit, setEffectiveRole, setMe } from './state/auth'
import { notify, loadWeek, moveSection, moveSectionTo, writeInputs } from './state/store'
import { globalUndo, globalRedo } from './undo'
import { secOrder, SECTIONS, secDefault, setSecDefault, moveSecDefault } from './engine/order'
import { setRole as lwSetRole, loadWars as lwLoadWars, setCell as lwSetCell, setPostOut as lwSetPostOut } from './leavewar/state/store'
import { pinViewer } from './leavewar/sync'

/* the hosts the bridge is installed on ([ACCOUNTS], 26 Sep 26): this PC only — the
   e2e suite, the probes, the Tracker smoke and the hand-pass drivers all serve the
   build here; a deployed host never gets a bridge (main.tsx) */
export function isLocalHost(): boolean {
  if (typeof location === 'undefined') return false
  const h = location.hostname
  return h === 'localhost' || h === '127.0.0.1' || h === '[::1]' || h === '::1'
}
export function installProbeBridge() {
  /* the whole bridge, and every global it hangs on window, exists on the developer's PC only —
     asked here as well as by its one caller (main.tsx), so no future caller can install it on a
     deployed host (Fable's code read, 26 Sep 26) */
  if (!isLocalHost()) return
  const w = window as any
  /* the engine singletons the probes read */
  w.DAYS = DAYS; w.PEOPLE = PEOPLE; w.INPUTS = INPUTS; w.VCONF = VCONF
  w.SCHED = SCHED
  /* WARN/REST/EVD are REASSIGNED by every validate() — getters, or a probe
     reads the pre-validate snapshot */
  Object.defineProperty(w, 'WARN', { get: () => V.WARN, configurable: true })
  Object.defineProperty(w, 'REST', { get: () => V.REST, configurable: true })
  Object.defineProperty(w, 'EVD', { get: () => V.EVD, configurable: true })
  Object.defineProperty(w, 'SIMW', { get: () => V.SIMW, configurable: true })   // the day's sim brief / debrief windows ([CROWD-SIM-BRIEF])
  /* live lets, published as getters so a probe always reads the current value */
  Object.defineProperty(w, 'ARM', { get: () => view.ARM, configurable: true })
  Object.defineProperty(w, 'SBDAY', { get: () => view.SBDAY, configurable: true })
  Object.defineProperty(w, 'CURPAGE', { get: () => view.CURPAGE, configurable: true })
  /* the loaded week's Monday (dd/mm/yyyy), a `let` reassigned by setCurWeek —
     a getter so a probe reads the current week after a continuous-nav crossing */
  Object.defineProperty(w, 'CURWEEK', { get: () => waves.CURWEEK, configurable: true })
  /* STORE_CFG is a `let`, reassigned whole by storesLoad/storesReset — same
     reason as ARM/SBDAY/CURPAGE above, a getter so a probe never reads a
     stale array after a load/reset */
  Object.defineProperty(w, 'STORE_CFG', { get: () => STORE_CFG, configurable: true })
  /* CXR_CFG is a `let` reassigned whole by cxReasonsLoad/cxReasonsReset — a
     getter for the same reason STORE_CFG is */
  Object.defineProperty(w, 'CXR_CFG', { get: () => CXR_CFG, configurable: true })
  /* the mutation funnel + validation */
  w.slotVal = slotVal; w.setSlotVal = setSlotVal; w.fillSlot = fillSlot
  w.txtGet = txtGet; w.txtSet = txtSet
  w.validate = validate; w.collectEvents = collectEvents; w.slotBar = slotBar
  w.markEdit = markEdit; w.publishALDay = publishALDay; w.setDayApproved = setDayApproved; w.signOf = signOf
  w.afterSchedMutate = () => { view.afterSchedMutate(); notify() }
  /* [ARCH-STACK] follow-up #1 (R2-09): the command layer is wired at module-eval,
     long before this bridge installs, so w.afterSchedMutate() now OPENS a command.
     For e2e FIXTURE setup that must not pollute the stream, expose the RAW epilogue
     (no command) plus a baseline re-sync so the next real command isn't dirtied by
     the fixture. And expose a read-only stream reader for the P5 live proof: the
     length, a copy of the last envelope, and the baseline-clean guardrail. */
  w.afterSchedMutateRaw = () => { view.rawSchedEpilogue(); resyncSchedBaseline(); notify() }
  w.resyncSchedBaseline = () => resyncSchedBaseline()
  w.commandStreamLen = () => commandStream().length
  w.lastEnvelope = () => { const s = commandStream(); return s.length ? JSON.parse(JSON.stringify(s[s.length - 1])) : null }
  w.schedBaselineClean = () => schedBaselineClean()
  /* week navigation — the per-week stash work (23 Aug 26) made cross-week
     round trips part of the engine's observable behaviour, so probes/demos
     can now drive them the same way the week chips do */
  w.loadWeek = loadWeek
  /* selection / arm */
  w.armSlot = (k: any, el: any) => { view.armSlot(k, el); notify() }
  w.disarmSlot = () => { view.disarmSlot(); notify() }
  w.selectPerson = (id: any, inWeek?: any) => { view.selectPerson(id, inWeek); notify() }
  /* [GLOBAL-UNDO] §13 phase 2 (§9 / E3, Codex GU-P2-001) — the Undo/Redo entry points
     drive the ONE timeline. The legacy scheduler RESTORE (histApply) and its
     record/push (histPush) are NOT exposed: they mutate scheduler state with no
     command envelope or revision bump, so a console call could desync the timeline
     and let a later globalUndo apply a stale inverse. The read-only histSnap stays
     (state inspection only). The adapted probe drives undo through w.undo now. */
  w.undo = () => { globalUndo(); notify() }; w.redo = () => { globalRedo(); notify() }
  w.toast = (...a: any[]) => HOOKS.toast(...a)
  /* the renderers all collapse to the store's notify in React */
  w.renderSchedule = () => notify()
  w.renderEditWeek = () => notify()
  w.renderScheduler = () => notify()
  w.refreshHighlights = () => notify()
  /* page navigation: click the same nav link a user would */
  w.go = (p: string) => {
    const a = document.querySelector(`.nav a[data-page="${p}"]`) as HTMLElement | null
    if (a) a.click(); else { const d = document.querySelector(`#drawerNav a[data-page="${p}"]`) as HTMLElement | null; d && d.click() }
  }
  /* the bare state setter behind w.go — needed by e2e tests that force the
     scheduler board open on a role/page combination no click path can ever
     reach (a squadron member's Edit Schedule link doesn't exist to click),
     the same way w.openScheduler already forces SBDAY open with no click. */
  w.setPage = (p: string) => { view.setPage(p); notify() }
  /* Shell.tsx and ui-contracts already claim this mirror exists — make it true */
  w.openWarns = (sev: any) => { view.openWarns(sev); notify() }
  /* the Leave War role, same precedent as w.setPage (this PC only, like the whole
     bridge): production writes it only from resetSession (the Raptor login), but the vendored e2e suite
     needs mid-test member↔admin switches that no click path reaches since
     the standalone app's on-screen toggle was removed at the merge. */
  w.lwSetRole = (r: 'admin' | 'member') => lwSetRole(r)
  /* [GLOBAL-UNDO] the RAPTOR effective role — what deriveActor()/mayReverse read to
     gate a global undo. The e2e sets its LOGIN actor to admin this way (the reliable
     path: no mid-test re-login — the grid is already up). GATED TO LOCALHOST (dev +
     the e2e's vite-preview) so it is NOT present on the deployed public site: unlike
     w.lwSetRole (LW role only), raptorRole('admin') would also open scheduler editing
     via canEditSched, so keep that reach off any real surface (Codex GU-P2-002). */
  // NO notify: a Raptor notify wakes the Raptor->Leave War roster re-sync, which
  // re-renders the grid and races a drag-select fired right after (fails on CI's
  // slower runners). mayReverse reads the role at undo-CLICK time, and the buttons
  // refresh off the timeline, so the flip needs no re-render.
  if (isLocalHost()) {
    w.raptorRole = (r: 'admin' | 'member') => { setEffectiveRole(r) }
    /* [ACCOUNTS] — the signed-in PERSON in place, the partner of raptorRole: the e2e
       and the walk switch who is signed in without a re-sign-in (which would reload a
       fresh demo world — bug-check order §7.7). It replaces the one e2e step that
       drove the retired "View as" picker. */
    w.raptorMe = (pid: string | null) => { setMe(pid); notify() }
  }
  /* the Leave War VIEWER — the person the war scopes a member to (canEditRow).
     Production mirrors the SIGNED-IN person onto it through the sync (D166 (4)); the
     e2e pins the member's identity to the row it edits. Same precedent as
     w.lwSetRole — and, like the whole bridge since [ACCOUNTS], this PC only. */
  w.lwSetViewer = (id: string | null) => pinViewer(id)   // held for this sign-in (leavewar/sync.ts pinViewer)
  /* Inject a full war set into the live store. Same reason as w.lwSetRole: the
     under-manned e2e fixtures cannot seed a red-day war through localStorage
     before boot — they boot, then push it in through here. CORRECTED 17 Sep 26:
     the old reason given was "Leave War is session-only now (a memory backend)".
     It is not — Leave War persists on a built site; the memory backend is the
     dev/test path, which is what the e2e run actually uses. The bridge is still
     the right seam, for a different reason: it does not depend on the backend. */
  w.lwLoadWars = (raw: unknown, currentId: string) => lwLoadWars(raw, currentId)
  /* [ARCH-STACK] step 4 — file an absence through the REAL inputs door (the one
     the Inputs page uses: writeInputs → the absence rules → the war re-reads
     it), and read the Inputs back. Localhost only, like w.raptorRole: e2e and
     screenshot scenarios plant a filed leave / medical without driving the
     whole Inputs form each time. */
  if (isLocalHost()) {
    w.fileInput = (row: any) => writeInputs(() => { INPUTS.unshift({ remarks: '', mod: '2026-01-01', ...row }) })
    w.INPUTS = INPUTS
    w.lwSetCell = (p: string, d: string, code: string) => lwSetCell(p, d, code)
    w.lwSetPostOut = (p: string, from: string | null) => lwSetPostOut(p, from)
  }
  /* the board — loaded lazily to keep module order simple */
  /* the id-getter every probe leans on, and the wider engine surface */
  w.$ = (id: string) => document.getElementById(id)
  w.editMode = () => HOOKS.editMode()
  w.INPUT_TYPES = INPUT_TYPES; w.SHIFT_HARD = SHIFT_HARD; w.RULE_STD = RULE_STD; w.RULE_SPEC = RULE_SPEC
  w.ruleParse = ruleParse; w.rulesOffCount = rulesOffCount
  w.HIST = HIST; w.SAWAVE = SAWAVE
  w.overlap = overlap; w.rowCrew = rowCrew; w.acRef = acRef; w.rollCx = rollCx
  w.isStandalone = isStandalone; w.makeStandalone = makeStandalone; w.dayCount = dayCount
  w.waveDutyBlock = waveDutyBlock; w.saDutyIx = saDutyIx; w.DUTY_PICK = DUTY_PICK
  w.keyDay = keyDay; w.shiftKeys = shiftKeys; w.shiftAircraft = shiftAircraft
  w.shiftFormation = shiftFormation; w.shiftWave = shiftWave; w.uniqDays = uniqDays
  w.permuteKeys = permuteKeys; w.moveKeys = moveKeys; w.applyMove = applyMove
  w.secOrder = secOrder; w.SECTIONS = SECTIONS; w.moveSection = moveSection; w.moveSectionTo = moveSectionTo
  w.moveWave = moveWave
  /* the admin-set DEFAULT arrangement (owner, 29 Aug 26 pt.2): the global section
     fallback secOrder uses, and the global wave order a new wave is placed by. */
  w.secDefault = secDefault; w.setSecDefault = setSecDefault; w.moveSecDefault = moveSecDefault
  w.waveDefault = waveDefault; w.waveDefaultView = waveDefaultView; w.setWaveDefault = setWaveDefault
  w.moveWaveDefault = moveWaveDefault; w.waveInsertSlot = waveInsertSlot
  w.hhmm = hhmm; w.parseHM = parseHM; w.hmOK = hmOK; w.minus = minus
  w.dayApproved = dayApproved; w.alColor = alColor; w.signMissing = signMissing; w.nextSeq = nextSeq
  w.isScheduler = isScheduler; w.isLead = isLead; w.isInstr = isInstr; w.isInstrPilot = isInstrPilot; w.isOcu = isOcu; w.isPersonnel = isPersonnel
  w.sanStatus = sanStatus; w.nameToId = nameToId
  w.aarNeed = aarNeed; w.aarOK = aarOK; w.WCODE = WCODE; w.wlbl = wlbl
  /* the reference's `sa` probe reads RANK by regexing the page source — the
     whole app is one inline script there, so its consts are literally in the
     HTML. ESM has no source to scrape, so publish the object itself. */
  w.RANK = RANK
  w.chipOf = chipOf; w.sevOf = sevOf; w.isLeave = isLeave; w.SIGN_ROLES = SIGN_ROLES
  w.traceOf = traceOf; w.traceLeads = traceLeads; w.traceIx = traceIx
  w.CHIP_LABEL = CHIP_LABEL; w.restClear = restClear; w.dayEvents = dayEvents
  w.isLocalLeave = isLocalLeave; w.slotRules = slotRules; w.saExempt = saExempt
  w.isDownchit = isDownchit; w.isOffType = isOffType; w.dayOff = dayOff; w.rulesReset = rulesReset
  w.isFly = isFly; w.isAway = isAway; w.inputFlags = inputFlags; w.inputDormant = inputDormant
  w.inputCoversDate = inputCoversDate; w.inpLabel = inpLabel; w.isOther = isOther; w.restsInput = restsInput; w.dateOrd = dateOrd; w.dateIx = dateIx; w.baseYear = baseYear
  w.isLateInput = isLateInput; w.lateNote = lateNote; w.inputDueISO = inputDueISO; w.inputOwnDueISO = inputOwnDueISO; w.inputWeekStartISO = inputWeekStartISO
  w.weekStartISO = weekStartISO; w.inputStampISO = inputStampISO
  w.isPersonal = isPersonal; w.isUnavail = isUnavail
  /* SANS AVAILABILITY (owner, 14 Aug 26) — the one gate every consumer calls */
  w.isSansAvail = isSansAvail; w.sansAvailOn = sansAvailOn; w.sansBadge = sansBadge
  w.isUpchit = isUpchit
  w.medDownAsOf = medDownAsOf; w.pendingUpchits = pendingUpchits; w.upchitsWithin = upchitsWithin; w.medEpisode = medEpisode
  w.upchitTrimPlan = upchitTrimPlan; w.newMedTrimPlan = newMedTrimPlan; w.ordShift = ordShift; w.ordLabel = ordLabel
  w.sansGate = sansGate; w.SANS_LABEL = SANS_LABEL
  w.sansWindow = sansWindow; w.sansLetters = sansLetters
  /* the 10 Aug 26 type table and everything derived from it */
  w.INPUT_META = INPUT_META; w.TYPE_GROUPS = TYPE_GROUPS; w.inpMeta = inpMeta; w.inpType = inpType
  w.canSpare = canSpare; w.canWork = canWork; w.awayAllDay = awayAllDay; w.inpWin = inpWin
  w.typeGroup = typeGroup; w.dayAway = dayAway
  w.acceptInput = acceptInput; w.unacceptInput = unacceptInput; w.inpKey = inpKey
  w.acceptedDay = acceptedDay; w.renameCallsign = renameCallsign
  w.rulesLoad = rulesLoad; w.rulesSave = rulesSave; w.DATES = DATES
  w.STORE_STD = STORE_STD; w.storeKey = storeKey; w.storesAreStandard = storesAreStandard; w.storesText = storesText
  w.addStore = addStore; w.delStore = delStore; w.renameStore = renameStore; w.moveStore = moveStore
  w.storesSave = storesSave; w.storesLoad = storesLoad; w.storesReset = storesReset
  w.CXR_STD = CXR_STD; w.cxrAreStandard = cxrAreStandard
  w.addCxReason = addCxReason; w.delCxReason = delCxReason; w.renameCxReason = renameCxReason; w.moveCxReason = moveCxReason
  w.cxReasonsSave = cxReasonsSave; w.cxReasonsLoad = cxReasonsLoad; w.cxReasonsReset = cxReasonsReset
  /* whole-day schedule templates (owner, 15 Aug 26). DAYTPL_CFG is a `let`
     reassigned whole by dayTplLoad/dayTplReset — same reason STORE_CFG above
     is a getter, not a plain reference: a probe reading a bare snapshot could
     hold a stale array after either call swaps it out. */
  Object.defineProperty(w, 'DAYTPL_CFG', { get: () => DAYTPL_CFG, configurable: true })
  w.DAYTPL_STD = DAYTPL_STD; w.tplFromDay = tplFromDay
  w.addDayTpl = addDayTpl; w.delDayTpl = delDayTpl; w.renameDayTpl = renameDayTpl; w.moveDayTpl = moveDayTpl
  w.applyDayTpl = applyDayTpl; w.dayTplSave = dayTplSave; w.dayTplLoad = dayTplLoad; w.dayTplReset = dayTplReset
  w.dayTplAreStandard = dayTplAreStandard
  /* weekend/PH work OIL credit (Leave War wire 4 — the uniform ≤6h/>6h rule
     since 28 Aug 26; scShiftCredit is deleted with the SC-window rule) */
  w.dayOilCredits = dayOilCredits; w.dayOilSpans = dayOilSpans
  /* THE OIL READERS THE SCREEN ACTUALLY USES (21 Sep 26). dayOilSpans above is
     the raw day walk; what a puck draws goes through the evidence block and the
     day's decisions, so a probe that reads only the walk cannot tell a rule from
     a display fault. These are the bodies the green edge is drawn from. */
  w.oilDayFigures = oilDayFigures; w.oilFigureFor = oilFigureFor
  w.oilItemOfKey = oilItemOfKey; w.oilEvidenceOf = oilEvidenceOf
  w.oilEarnedWork = oilEarnedWork
  w.envMin = envMin; w.uniformOil = uniformOil; w.inputOilAmt = inputOilAmt
  /* the edit log. ELOG is a const object mutated in place (rows.push /
     splice), never reassigned, so a plain reference is enough — unlike
     STORE_CFG above, which needs a getter because storesLoad swaps it whole. */
  w.ELOG = ELOG; w.elogRows = elogRows; w.elogFor = elogFor; w.elogWhen = elogWhen
  w.elogClear = elogClear; w.elogRemap = elogRemap; w.keyLabel = keyLabel
  w.alCount = alCount; w.alDays = alDays; w.pendDays = pendDays; w.pendCount = pendCount; w.approvedDays = approvedDays
  w.daySnapOf = daySnapOf; w.dayVersions = dayVersions; w.verLabel = verLabel; w.dayCurVer = dayCurVer
  w.dayKeys = dayKeys
  /* per-day alternate drafts (owner, 15 Aug 26) — engine/drafts.ts */
  w.dayDrafts = dayDrafts; w.curDraftId = curDraftId; w.draftDup = draftDup
  w.draftSelect = draftSelect; w.draftRename = draftRename; w.draftDelete = draftDelete
  w.draftVerLabel = draftVerLabel; w.isDraftVer = isDraftVer; w.rebaseDayPending = rebaseDayPending
  w.loadVersionToWorkingCopy = loadVersionToWorkingCopy; w.reconcileIssuedMarks = reconcileIssuedMarks
  w.setDayPreview = (di: any, v: any) => { view.setDayPreview(di, v); notify() }
  /* History's gold dots — the pass that runs after every repaint, timed by the walk ([HIST-PHONE-HIDE], Fable's final read F6) */
  w.refreshHistDots = refreshHistDots; w.HIST_CELLS = HIST_CELLS
  w.renderInputs = () => notify()
  w.renderStatus = () => notify()
  w.ruleFmt = ruleFmt; w.ruleOff = ruleOff; w.kindOff = kindOff; w.KIND_LABEL = KIND_LABEL
  w.lgSetEdit = (on: any) => { setLgEdit(on); notify() }
  w.daysLabel = daysLabel
  w.findGo = (key: any) => { const [di, gi] = String(key).split('|'); return DAYS[+di!] && DAYS[+di!].waves[+gi!] }
  w.histSnap = histSnap   // read-only state snapshot for inspection; histApply/histPush NOT exposed (E3, above)
  w.dayEngaged = dayEngaged; w.scShiftKind = scShiftKind; w.hm24 = hm24; w.rowRef = rowRef
  w.scSeatHit = scSeatHit; w.avSeatHit = avSeatHit
  w.armedKey = () => view.armedKey()
  w.placeArmed = (id: any) => { view.placeArmed(id); notify() }
  w.reflow = () => HOOKS.reflow()
  /* mechanism shims: the reference exposes its render internals; in React the
     equivalent of "poke the cache, re-render" is a plain store tick */
  w.renderLogic = () => notify()
  w.weekDirty = () => notify()
  w.ruleApply = () => { rulesSave(); validate(); notify() }
  import('./ui/board').then(b => {
    w.openScheduler = b.openScheduler
    w.closeScheduler = b.closeScheduler
    w.addWave = b.addWave
    w.waveMenu = b.waveMenu
    w.addWaveFromTpl = b.addWaveFromTpl
    Object.defineProperty(w, 'CXT', { get: () => b.CXT, configurable: true })
  })
  import('./engine/wavetpl').then(m => {
    Object.defineProperty(w, 'WAVETPL_CFG', { get: () => m.WAVETPL_CFG, configurable: true })
    w.waveFromTpl = m.waveFromTpl; w.isWaveHidden = m.isWaveHidden; w.setWaveHidden = m.setWaveHidden
  })
  w.whoArr = whoArr
  import('./ui/html').then(m => { w.cxText = m.cxText; w.dayHTML = m.dayHTML; w.puck = m.puck })
  import('./ui/pan').then(m => { w.hsSync = m.hsSync; w.panDays = m.panDays })
  import('./ui/drag').then(m => { w.applyDrop = m.applyDrop; w.dragFrom = m.dragFrom; w.nearSeat = m.nearSeat; w.barDrop = m.barDrop; Object.defineProperty(w, 'DRAG', { get: () => m.DRAG, set: v => m.setDrag(v), configurable: true }) })
  import('./ui/palette-html').then(m => { w.paletteDay = m.paletteDay; w.paletteHTML = m.paletteHTML; w.offReason = (m as any).offReason })
  import('./ui/board-html').then(m => { w.inTypeCls = (m as any).inTypeCls; w.sbInputsHTML = m.sbInputsHTML })
}
