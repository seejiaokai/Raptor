import { describe, it, expect } from 'vitest'
import { MemoryBackend } from './memory'
import { resetPreSchema, SCHEMA_VERSION } from './reset'
import { readSchema } from './schema'

/* the stamp is one object since [DB-READINESS] group A phase 0 — its format is what these pin */
const stampFormat = (be: MemoryBackend) => readSchema(be.peek('settings', 'schema'))?.dataFormatVersion

/* a store carrying pre-1A demo data: a bare-string note and a content-key
   ground.src on a saved week, plus people/settings that must be KEPT. */
const withPreV1AData = () => {
  const be = new MemoryBackend()
  be.seed({
    inputs: { all: JSON.stringify([{ iid: 'i1', person: 'x', type: 'LL' }]) },
    weeks: { '2026-07-13': JSON.stringify({ d: [{ notes: ['OLD STRING NOTE'], ground: [{ src: 'x|Jul 13|Meeting|600|2026' }] }] }) },
    people: { all: JSON.stringify({ dj: { cs: 'DJ' } }) },
    settings: { rules: '{"x":1}' },
  })
  return be
}

describe('resetPreSchema — ARCH-STACK 1A storage reset (Astra SID-05/07)', () => {
  it('clears pre-1A inputs+weeks, keeps people/settings, and stamps last', async () => {
    const be = withPreV1AData()
    const snap = await be.loadAll()
    await resetPreSchema(be, snap)
    // the in-memory snapshot is cleared for the incompatible collections, kept for the rest
    expect(snap.inputs).toEqual({})
    expect(snap.weeks).toEqual({})
    expect(JSON.parse(snap.people.all).dj.cs).toBe('DJ')
    expect(snap.settings.rules).toBe('{"x":1}')
    // durably gone in the backend, and the version stamped
    expect(be.peek('inputs', 'all')).toBeNull()
    expect(be.peek('weeks', '2026-07-13')).toBeNull()
    expect(be.peek('people', 'all')).not.toBeNull()
    expect(stampFormat(be)).toBe(SCHEMA_VERSION)
  })

  it('1C: a v1-stamped (1A) store is still reset — the bump to 2 clears cs-form who weeks', async () => {
    expect(SCHEMA_VERSION).toBeGreaterThanOrEqual(2)          // 1C bumped it
    const be = withPreV1AData()
    be.seed({ settings: { schema: JSON.stringify(1) } })      // an existing 1A store
    const snap = await be.loadAll()
    await resetPreSchema(be, snap)
    expect(snap.inputs).toEqual({})
    expect(snap.weeks).toEqual({})
    expect(be.peek('weeks', '2026-07-13')).toBeNull()
    expect(stampFormat(be)).toBe(SCHEMA_VERSION)
  })

  it('is a no-op on an already-stamped store — no deletes, no re-stamp', async () => {
    const be = withPreV1AData()
    be.seed({ settings: { schema: JSON.stringify(SCHEMA_VERSION) } })
    const snap = await be.loadAll()
    const writes = be.journal.filter(e => e.op !== 'loadAll').length
    await resetPreSchema(be, snap)
    expect(snap.inputs.all).toBeTruthy()                    // untouched
    expect(be.peek('inputs', 'all')).not.toBeNull()
    expect(be.journal.filter(e => e.op !== 'loadAll').length).toBe(writes)   // no backend writes at all
  })

  it('v3: a returning browser\'s Leave War world is cleared so the medical-free demo re-seeds', async () => {
    // Owner, 13 Sep 26 — medical is member-filed only, so the demo's old
    // war-CREATED medical must not persist. Clearing the leavewar collection
    // before hydration makes main.tsx read hadStoredWars=false → the demo
    // re-seeds clean, with no back-compat code (dev-phase reset).
    const be = new MemoryBackend()
    be.seed({
      leavewar: { wars: JSON.stringify([{ period: { id: 'y2026' }, grid: { splice: { '2026-01-05': 'ATTC' } } }]) },
      people: { all: JSON.stringify({ dj: { cs: 'DJ' } }) },
      settings: { schema: JSON.stringify(2) },     // a pre-v3 (1C-era) store
    })
    const snap = await be.loadAll()
    await resetPreSchema(be, snap)
    expect(snap.leavewar).toEqual({})
    expect(be.peek('leavewar', 'wars')).toBeNull()     // durably gone → hadStoredWars=false at boot
    expect(be.peek('people', 'all')).not.toBeNull()    // people kept (projected onto the fresh demo)
    expect(stampFormat(be)).toBe(SCHEMA_VERSION)
  })

  it('stamps a fresh empty store (nothing to reset)', async () => {
    const be = new MemoryBackend()
    const snap = await be.loadAll()
    await resetPreSchema(be, snap)
    expect(stampFormat(be)).toBe(SCHEMA_VERSION)
  })

  it('SID-07/IR-02: a failed delete THROWS (boot rejects to Retry) and leaves the stamp unset — the next boot completes', async () => {
    const be = withPreV1AData()
    const snap = await be.loadAll()
    be.failNext(1)                                          // the first backend.remove throws
    // the failure propagates so bootStorage rejects → main.tsx Retry; the app never
    // proceeds to a write-enabled state on an unstamped store (IR-02).
    await expect(resetPreSchema(be, snap)).rejects.toThrow()
    // the stamp is NOT written, and the pre-1A record is still there for the retry
    expect(be.peek('settings', 'schema')).toBeNull()
    expect(be.peek('weeks', '2026-07-13')).not.toBeNull()
    // next boot (no injected failure) re-reads the still-present data and completes
    const snap2 = await be.loadAll()
    await resetPreSchema(be, snap2)
    expect(be.peek('inputs', 'all')).toBeNull()
    expect(be.peek('weeks', '2026-07-13')).toBeNull()
    expect(stampFormat(be)).toBe(SCHEMA_VERSION)
  })
})
