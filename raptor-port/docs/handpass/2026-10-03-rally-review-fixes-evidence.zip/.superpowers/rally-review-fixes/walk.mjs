import {mkdirSync,writeFileSync,readFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const out='C:/Users/User/projects/Raptor/raptor-port/docs/img/handpass/2026-10-03-rally-review-fixes'+(process.env.WALK_RUN?'/'+process.env.WALK_RUN:'');mkdirSync(out,{recursive:true})
process.env.HP_URL='http://127.0.0.1:4242';process.env.HP_SHOTS=out
const {open,go,board,publish,login}=await import('../../raptor-port/scripts/handpass/lib.mjs')
const results=[],observations=[],pictures=[];let failure=null
const save=()=>writeFileSync(out+'/walk-results.json',JSON.stringify({results,observations,pictures,failure},null,2))
for(const [name,width,height] of [['desktop',1440,900],['phone',390,844]]){
 const resume=name==='desktop'&&process.env.RESUME_DESKTOP;const {browser,page,errors}=await open({width,height,state:resume||null});const di=1,gi=0
 const check=async(label,fn)=>{await fn();results.push({width:name,label,status:'PASS'});save()}
 const shot=async(label)=>{const path=out+'/'+name+'-'+label+'.png';await page.screenshot({path});pictures.push(path);save()}
 const settle=()=>page.waitForTimeout(180)
 const click=async(sel)=>{const e=page.locator(sel+':visible').first();await e.scrollIntoViewIfNeeded();await e.click();await settle()}
 const setting=async(key,value)=>{const e=page.locator(`[data-lgset="${key}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Tab');await settle()}
 const editLogic=async()=>{if(await page.locator('#lgEdit:visible').count())await click('#lgEdit')}
 const close=async()=>{await click('#sbDone');await page.locator('#schedBoard').waitFor({state:'hidden'})}
 const openBoard=async(day)=>{if(await page.locator('#schedBoard:visible').count())await close();await board(page,day)}
 const field=async(key,value)=>{const e=page.locator(`#schedBoard [data-bfld="${key}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Tab');await settle()}
 const line=async(ix,value)=>{const e=page.locator(`#schedBoard [data-itline="${di}|${gi}|${ix}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Enter');await settle()}
 const read=()=>page.evaluate(([d,g])=>({lines:window.DAYS[d].waves[g].intimes,v:{...window.VCONF},book:JSON.parse(JSON.stringify(window.SCHED)),warnings:window.WARN.all.filter(w=>w.di===d),header:[...document.querySelectorAll('#schedBoard .sb-go .asd')].filter(e=>e.offsetParent!==null).map(e=>e.textContent),events:window.collectEvents()[d].events}),[di,gi])
 const clear=async()=>{while(await page.locator(`#schedBoard [data-itdel^="${di}|${gi}|"]:visible`).count())await click(`#schedBoard [data-itdel^="${di}|${gi}|"]`)}
 const undo=async()=>{await click(await page.locator('#sbUndo:visible').count()?'#sbUndo':'#undoBtn')},redo=async()=>{await click(await page.locator('#sbRedo:visible').count()?'#sbRedo':'#redoBtn')}
 const reportRow=()=>page.locator('#schedBoard .sb-warn [data-wix]:visible').filter({hasText:'later than'}).first()
 let wrongVer,correctedVer
 try{
  if(!resume){
  if(name==='desktop'&&!process.env.SKIP_DEMO){
   await check('P1 fresh demo Mon–Thu publishes in both seed weeks with zero reporting-order warning',async()=>{
    for(const week of ['13/07/2026','20/07/2026']){
     await go(page,'editsched');await click(`#weekSegE [data-wk="${week}"]`)
     assert.equal(await page.evaluate(()=>window.WARN.all.filter(w=>w.code==='REPORT_ORDER').length),0)
     for(const day of [0,1,2,3]){await openBoard(day);assert.equal((await publish(page,day)).published,true);await close()}
    }
    await click('#weekSegE [data-wk="13/07/2026"]')
   });await shot('fresh-demo-published')
  }
  await go(page,'logic');await editLogic()
  await check('L1/L3 numeric then text, Undo/Redo/reset keep both live values',async()=>{
   await setting('reportLead','2h');await setting('reportText','RALLY');assert.equal((await read()).v.reportText,'RALLY')
   await undo();assert.equal((await read()).v.reportText,'IN TIME + WX/NOTAMS');assert.equal((await read()).v.reportLead,120)
   await redo();assert.equal((await read()).v.reportText,'RALLY')
   await click('#lgReset');assert.equal((await read()).v.reportLead,180);assert.equal((await read()).v.reportText,'IN TIME + WX/NOTAMS')
   await undo();assert.equal((await read()).v.reportLead,120);assert.equal((await read()).v.reportText,'RALLY');await redo()
  })
  await check('L4 literal markup/quotes, blank and 60-character words',async()=>{
   await setting('reportText','<b>RALLY</b> "&');assert.equal(await page.locator('[data-lgset="reportText"]:visible').inputValue(),'<b>RALLY</b> "&')
   assert.equal(await page.locator('[data-lgset="reportText"]:visible').evaluate(e=>e.closest('.lgmatrix').querySelectorAll('b').length),0)
   await setting('reportText',' ');assert.equal((await read()).v.reportText,'IN TIME + WX/NOTAMS')
   await setting('reportText','x'.repeat(60));assert.equal((await read()).v.reportText.length,60);await click('#lgReset')
  })
  await shot('logic-defaults')
  await go(page,'editsched');await openBoard(di)
  for(const li of [0,1]){await field(`ff:${di}.${gi}.${li}.to`,'12:00');await field(`ff:${di}.${gi}.${li}.ld`,'13:00');await field(`ff:${di}.${gi}.${li}.br`,'')}
  await clear();await close()
  await page.locator(`#eWeek [data-itadd="${di}|${gi}"]`).first().scrollIntoViewIfNeeded()
  await check('M1 week add uses09:00 default atTO12:00 and the control is reachable',async()=>{
   await click(`#eWeek [data-itadd="${di}|${gi}"]`);assert.deepEqual((await read()).lines,['09:00H: IN TIME + WX/NOTAMS'])
   assert.equal((await read()).warnings.filter(w=>w.code==='REPORT_ORDER').length,0)
  })
  await go(page,'logic');await editLogic();await setting('reportLead','2h');await setting('reportText','RALLY 13:00')
  await go(page,'editsched');await openBoard(di);await clear()
  await check('M1/L1 Board add uses10:00 and configured words; first clock wins; suggested brief09:40',async()=>{
   await click(`#schedBoard [data-itadd="${di}|${gi}"]`);const r=await read();assert.deepEqual(r.lines,['10:00H: RALLY 13:00'])
   assert.ok(r.events.filter(e=>e.kind==='fly'&&e.slot.startsWith(`${di}.${gi}.`)).every(e=>e.report===600))
   assert.ok(r.warnings.some(w=>w.code==='REPORT_ORDER'&&w.msg.includes('rally 10:00 is later than suggested brief 09:40')))
  })
  await shot('suggested-brief-mint');await close();await go(page,'logic');await setting('reportText','<b>RALLY</b> "&')
  await go(page,'editsched');await openBoard(di);await clear();await click(`#schedBoard [data-itadd="${di}|${gi}"]`)
  await check('L4 literal words minted without markup nodes',async()=>{
   const e=page.locator(`#schedBoard [data-itline="${di}|${gi}|0"]:visible`);assert.equal(await e.innerText(),'10:00H: <b>RALLY</b> "&')
   assert.deepEqual(await e.locator('b').allTextContents(),['10:00H'])
  })
  await page.waitForTimeout(700);await page.reload();await login(page);await go(page,'logic')
  await check('L1/L4 both overrides survive an ordinary reload and fresh sign-in',async()=>{const r=await read();assert.equal(r.v.reportLead,120);assert.equal(r.v.reportText,'<b>RALLY</b> "&');assert.ok((await page.locator('#lgBody').innerText()).includes('<b>RALLY</b> "&'))})
  await editLogic();await click('#lgReset');await go(page,'editsched');await openBoard(di);await clear()
  await click(`#schedBoard [data-itadd="${di}|${gi}"]`);await line(0,'09:00 IN TIME');await click(`#schedBoard [data-itadd="${di}|${gi}"]`);await line(1,'10:15 RALLY')
  for(const li of [0,1])await field(`ff:${di}.${gi}.${li}.br`,'10:00')
  await check('P1 first publication succeeds with wrong pair and freezes the red warning',async()=>{
   assert.equal((await publish(page,di)).published,true);const r=await read();assert.equal(r.book.dayOK[di],1)
   const issued=r.book.als.filter(a=>a.di===di).at(-1)?.snap??r.book.orig[di];wrongVer=r.book.cur[di];assert.ok(issued.w.byDay.warns.some(w=>w.code==='REPORT_ORDER'));assert.ok(r.warnings.some(w=>w.code==='REPORT_ORDER'))
   assert.ok(!(await page.locator('body').innerText()).includes('Cannot publish'))
  })
  await shot('published-warning')
  await check('P3 hide working warning, issue its AL, and read issued hidden state',async()=>{
   if(width<500&&await page.locator('#schedBoard [data-sbwtog]:visible').count())await click('#schedBoard [data-sbwtog]')
   const row=reportRow();await row.locator('button[data-woff]').click();await settle();assert.ok(await reportRow().evaluate(e=>e.classList.contains('hid')))
   const before=(await read()).book.orig[di].w.wo||[];assert.equal(before.length,0)
   await publish(page,di);const r=await read();assert.ok(r.book.als.at(-1).snap.w.wo.length>0)
  })
  await shot('hidden-warning-AL');await close();await go(page,'viewsched')
  await check('P3 view-only copy has literal reporting text and no add or hide authority from its new text',async()=>{
   const day=page.locator(`#vWeek .day[data-day="${di}"]`);assert.ok((await day.innerText()).includes('10:15 RALLY'));assert.equal(await day.locator('[data-itadd]').count(),0)
   await day.locator(`[data-daywarn="${di}"]`).click();await settle();const hidden=day.locator('.witem.hid').filter({hasText:'later than'});assert.ok(await hidden.count());assert.equal(await hidden.locator('[data-woff]').count(),0)
  })
  await go(page,'editsched');await openBoard(di)
  await check('P3 restore and reissue keep raw timing problem but restore its visible warning',async()=>{
   if(!await reportRow().count()&&await page.locator('#schedBoard [data-sbwtog]:visible').count())await click('#schedBoard [data-sbwtog]')
   await reportRow().locator('button[data-woff]').click();await settle();assert.ok(!await reportRow().evaluate(e=>e.classList.contains('hid')));assert.equal((await publish(page,di)).published,true)
   assert.deepEqual((await read()).book.als.at(-1).snap.w.wo??[],[])
  })
  await line(1,'10:00 RALLY');await publish(page,di)
  await check('P2 correcting timing issues new version and drops reporting-order warning',async()=>{const r=await read();correctedVer=r.book.cur[di];assert.ok(!r.book.als.at(-1).snap.w.byDay.warns.some(w=>w.code==='REPORT_ORDER'))})
  if(name==='desktop')await check('P2 publication Undo/Redo restores exact AL identity and warning bundle',async()=>{
   const before=await read(),count=before.book.als.length;await undo();assert.equal((await read()).book.als.length,count-1);await redo();const after=await read();assert.equal(after.book.cur[di],correctedVer);assert.deepEqual(after.book.als,before.book.als)
  })
  await check('P4 Board and week can look at the older wrong pair without editing it',async()=>{
   await click(`#schedBoard [data-planmenu="${di}"]`);await click(`[data-planpv="${wrongVer}"]`)
   assert.ok((await page.locator('#schedBoard').innerText()).includes('10:15 RALLY'));assert.equal(await page.locator(`#schedBoard [data-itadd="${di}|${gi}"]:visible`).count(),0)
   await shot('issued-wrong-pair-preview');await close();assert.ok((await page.locator(`#eWeek .day[data-day="${di}"]`).innerText()).includes('10:15 RALLY'))
   await click(`#eWeek [data-planmenu="${di}"]`);await click(`[data-plangolive="${di}"]`);await openBoard(di)
   assert.deepEqual((await read()).lines,['09:00 IN TIME','10:00 RALLY'])
  })
  }else{await go(page,'editsched');await openBoard(di)}
  await openBoard(0);await field('ff:0.1.1.ld','21:00');assert.equal((await publish(page,0)).published,true);await openBoard(di)
  await line(0,'22:00 IN TIME');await line(1,'22:00 RALLY')
  for(const li of [0,1]){await field(`ff:${di}.${gi}.${li}.to`,'01:00');await field(`ff:${di}.${gi}.${li}.ld`,'11:00');await field(`ff:${di}.${gi}.${li}.br`,'22:40')}
  await check('T3 previous-day header and15h long-day text appear on Board',async()=>{
   const r=await read();assert.ok(r.header.some(t=>t.includes('22:00 (prev day)')))
   assert.ok(r.warnings.some(w=>w.code==='LONGDAY'&&w.msg.includes('15h00, 22:00 (previous day) → 13:00')))
   assert.ok(r.warnings.some(w=>w.code==='CREW_REST'&&w.who.includes('casper')&&w.msg.includes('told to report 22:00 (previous day) — 1h00 before his Monday duty ends.')))
  })
  await publish(page,di)
  const marked=page.locator(`#schedBoard .puck[data-person="casper"]:visible`).first()
  if(await marked.count()){await marked.scrollIntoViewIfNeeded();await marked.click();await settle()}
  await shot('previous-day-board');await close()
  await check('T3 previous-day week header is visible and buttons keep their hit areas',async()=>{
   const h=page.locator(`#eWeek .day[data-day="${di}"] .go-tab`).first();await h.scrollIntoViewIfNeeded();assert.ok((await h.innerText()).includes('22:00 (prev day)'))
   const b=page.locator(`#eWeek [data-itadd="${di}|${gi}"]`).first();assert.ok(await b.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return hit===e||e.contains(hit)}))
  });await shot('previous-day-week')
  if(name==='desktop')await check('X1/X2 actual print and CSV keep issued flying rows when working take-off differs',async()=>{
   await openBoard(di);await field(`ff:${di}.${gi}.0.to`,'02:00');await close()
   const download=page.waitForEvent('download');await click('#exportSched');const d=await download;await d.saveAs(out+'/issued-schedule.csv')
   const csv=readFileSync(out+'/issued-schedule.csv','utf8');assert.ok(csv.includes('01:00'));assert.ok(!csv.includes('02:00'));assert.ok(csv.startsWith('\uFEFF"Day","Date","Wave","CS","Mission","Brief","TO","Land"'))
   await click('#exportPdf');await page.waitForTimeout(500);const html=await page.locator('iframe').last().evaluate(e=>e.srcdoc);assert.ok(html.includes('01:00'));assert.ok(!html.includes('02:00'))
   writeFileSync(out+'/issued-print.html',html);const printed=await page.context().newPage();await printed.setViewportSize({width:794,height:1123});await printed.setContent(html);await printed.emulateMedia({media:'print'});const pic=out+'/desktop-issued-print.png';await printed.screenshot({path:pic,fullPage:true});pictures.push(pic);await printed.pdf({path:out+'/issued-schedule.pdf',format:'A4',printBackground:true});await printed.close()
  })
  await page.waitForTimeout(700);await page.reload();await login(page);await go(page,'viewsched')
  await check('P2/T3 issued previous-day clock survives reload',async()=>{assert.ok((await page.locator(`#vWeek .day[data-day="${di}"]`).innerText()).includes('22:00 (prev day)'));assert.equal((await read()).v.reportText,'IN TIME + WX/NOTAMS')})
  if(name==='desktop'){
   await go(page,'editsched');await openBoard(0);await field('ff:0.1.1.to','08:00');await field('ff:0.1.1.ld','09:30');await publish(page,0);await openBoard(di);await field('fr:1.0.0.1','2A: LATE SHOW')
   await check('T4 sanctioned late show remains dashed when rest clears before step',async()=>{const r=await read();assert.ok(r.warnings.some(w=>w.code==='CREW_REST'&&w.who.includes('casper')&&w.dashed));assert.ok((await page.locator('#schedBoard .puck[data-person="casper"]:visible').first().getAttribute('class')).includes('boxdash'))});await shot('late-show-dashed')
   await openBoard(0);await field('ff:0.1.1.ld','12:00');await publish(page,0);await openBoard(di)
   await check('T4 sanctioned late show remains solid when rest clears after step',async()=>{const r=await read();assert.ok(r.warnings.some(w=>w.code==='CREW_REST'&&w.who.includes('casper')&&!w.dashed&&w.msg.includes('Late show cannot save it')));assert.ok((await page.locator('#schedBoard .puck[data-person="casper"]:visible').first().getAttribute('class')).includes('boxred'))});await shot('late-show-solid');await close()
  }
  await go(page,'editsched');await openBoard(di)
  for(const [screen,w,h] of [['short-laptop',1440,600],['landscape-phone',844,390]]){
   await page.setViewportSize({width:w,height:h});await settle();await check('T3 '+screen+' header and add control have a usable hit target',async()=>{const b=page.locator(`#schedBoard [data-itadd="${di}|${gi}"]:visible`).first();await b.scrollIntoViewIfNeeded();assert.ok(await b.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return hit===e||e.contains(hit)}))})
  }
  await page.setViewportSize({width,height});await close()
  await page.reload();await login(page,'user');await go(page,'logic')
  await check('L2 member keeps read-only Logic and no text editing door',async()=>{assert.equal(await page.locator('[data-lgset="reportText"]').count(),0);assert.equal(await page.locator('#lgEdit:visible').count(),0)})
  assert.deepEqual(errors,[]);results.push({width:name,label:'console/page/HTTP errors',status:'PASS'});await page.context().storageState({path:out+'/'+name+'-state.json'})
 }catch(e){failure={width:name,message:e.message,stack:e.stack};await shot('failure');await page.context().storageState({path:out+'/'+name+'-failure-state.json'});console.error(e);break}
 finally{await browser.close();save()}
}
console.log(JSON.stringify({checks:results.length,failure},null,2));if(failure)process.exitCode=1
