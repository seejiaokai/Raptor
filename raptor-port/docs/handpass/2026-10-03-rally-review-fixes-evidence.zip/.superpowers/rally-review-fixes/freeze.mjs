import {readFileSync,writeFileSync,mkdirSync,copyFileSync,readdirSync,statSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {spawnSync} from 'node:child_process'
import {dirname} from 'node:path'
const root='C:/Users/User/projects/Raptor',out=root+'/raptor-port/docs/img/handpass/2026-10-03-rally-review-fixes',snap=root+'/.superpowers/rally-review-fixes/snapshot';mkdirSync(out,{recursive:true});mkdirSync(snap,{recursive:true})
const git=args=>{const r=spawnSync('git',args,{cwd:root,encoding:'utf8'});if(r.status!==0)throw Error(r.stderr);return r.stdout.trim()}
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex')
const source=git(['ls-files','raptor-port/src','raptor-port/e2e']).split('\n').filter(Boolean).map(path=>({path,sha256:hash(root+'/'+path)}))
const group=a=>createHash('sha256').update(JSON.stringify(a)).digest('hex')
const walk=path=>readdirSync(path).flatMap(name=>{const p=path+'/'+name;return statSync(p).isDirectory()?walk(p):[p]})
const bundle=walk(root+'/raptor-port/dist').map(p=>({path:p.slice(root.length+1),sha256:hash(p)}))
const changed=git(['diff','--name-only','HEAD','--','raptor-port/src','raptor-port/e2e']).split('\n').filter(Boolean)
for(const rel of changed){mkdirSync(dirname(snap+'/'+rel),{recursive:true});copyFileSync(root+'/'+rel,snap+'/'+rel)}
writeFileSync(snap+'/source.patch',git(['diff','--binary','HEAD','--','raptor-port/src','raptor-port/e2e'])+'\n')
writeFileSync(out+'/fingerprints.json',JSON.stringify({base:git(['rev-parse','HEAD']),branch:git(['branch','--show-current']),sourceHash:group(source),bundleHash:group(bundle),source,bundle,changed},null,2))
console.log(JSON.stringify({sourceHash:group(source),bundleHash:group(bundle),changed:changed.length}))
