import {mkdirSync,writeFileSync} from 'node:fs'
const root='C:/Users/User/projects/Raptor/raptor-port/docs/img/handpass/2026-10-03-rally-review-fixes',out=root+'/'+(process.env.WIDTH_RUN||'logic-width-red');mkdirSync(out,{recursive:true});process.env.HP_URL='http://127.0.0.1:4242';process.env.HP_SHOTS=out
const {open,go}=await import('../../raptor-port/scripts/handpass/lib.mjs'),results=[]
for(const [name,width,height] of [['desktop',1440,900],['phone',390,844]]){
 const {browser,page,errors}=await open({width,height});try{
  await go(page,'logic');await page.locator('#lgEdit:visible').click();const input=page.locator('[data-lgset="reportText"]:visible');await input.scrollIntoViewIfNeeded()
  const metrics=await input.evaluate(e=>{const s=getComputedStyle(e),c=document.createElement('canvas').getContext('2d');c.font=s.font;const r=e.getBoundingClientRect();return {value:e.value,needed:c.measureText(e.value).width,available:e.clientWidth-parseFloat(s.paddingLeft)-parseFloat(s.paddingRight),right:r.right,viewport:innerWidth}})
  const numeric=await page.locator('[data-lgset="reportLead"]:visible').first().evaluate(e=>e.getBoundingClientRect().width)
  const pass=metrics.needed<=metrics.available&&metrics.right<=width&&numeric===(width>820?66:58)&&errors.length===0;results.push({name,pass,...metrics,numeric,errors});await page.screenshot({path:out+'/'+name+'.png'})
  if(process.env.WIDTH_RUN){
   await input.fill('RALLY');await input.press('Tab');await page.locator('[data-lgset="reportText"]:visible').scrollIntoViewIfNeeded();await page.screenshot({path:out+'/'+name+'-custom.png'})
   await page.locator('[data-lgset="reportText"]:visible').fill('x'.repeat(60));await page.locator('[data-lgset="reportText"]:visible').press('Tab');await page.locator('#lgDone:visible').click()
   const cell=page.locator('.lgcell-text').first();await cell.scrollIntoViewIfNeeded();const long=await cell.evaluate(e=>({text:e.querySelector('.val').textContent,cap:window.VCONF.reportText.length,right:e.getBoundingClientRect().right,pageOverflow:document.documentElement.scrollWidth-innerWidth}));results.push({name,long,pass:long.cap===60&&long.text==='x'.repeat(60)&&long.right<=width&&long.pageOverflow<=1});await page.screenshot({path:out+'/'+name+'-long-readonly.png'})
  }
 }finally{await browser.close()}
}
writeFileSync(out+'/results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));if(results.some(r=>!r.pass))process.exitCode=1
