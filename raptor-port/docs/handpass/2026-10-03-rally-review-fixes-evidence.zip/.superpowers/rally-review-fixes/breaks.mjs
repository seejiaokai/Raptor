import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {spawnSync} from 'node:child_process'
import {createHash} from 'node:crypto'
const root='C:/Users/User/projects/Raptor/raptor-port',out='C:/Users/User/projects/Raptor/.superpowers/rally-review-fixes/breaks';mkdirSync(out,{recursive:true})
const cases=[
 ['first-issue','src/engine/publish.ts',/export function setDayApproved\(([^]*?)\)\{/,m=>m+'return;', 'src/state/rally-publish.test.ts'],
 ['AL-issue','src/engine/publish.ts','export function publishALDay(di:any){',s=>s+'return;', 'src/state/rally-publish.test.ts'],
 ['final-issue','src/engine/publish.ts','export function alIssue(di:any){di=+di;',s=>s+"return {seq:0,id:'',sign:{},count:0};", 'src/state/rally-publish.test.ts'],
 ['suggested-B','src/engine/reporting.ts',"name:parseHM(f.br)==null?'suggested brief':'brief'",()=>"name:'brief'", 'src/engine/rally-workspan.test.ts'],
 ['mint-lead','src/ui/interactions.ts','- VCONF.reportLead : null',()=>'- 0 : null','src/ui/intimesadd.test.tsx'],
 ['mint-words','src/ui/interactions.ts','+ VCONF.reportText',()=>"+ 'IN TIME + WX/NOTAMS'",'src/ui/intimesadd.test.tsx'],
 ['stored-words','src/engine/rules.ts',"if(sp.kind==='text'){const txt=ruleParse(k,n);if(txt!=null)VCONF[k]=txt;}",()=>"if(sp.kind==='text'){}",'src/state/command-write-seam.test.ts'],
 ['Logic-field','src/ui/LogicPage.tsx','(r.set || []).filter((k: any) => RULE_SPEC[k])',()=>"(r.set || []).filter((k: any) => RULE_SPEC[k] && k!=='reportText')",'src/ui/logic.test.tsx'],
 ['rest-report','src/engine/validate.ts','told to report ${stated(instructed)}',()=> 'told to report ${hm24(instructed)}','src/engine/rally-dated-rest.test.ts'],
 ['long-day','src/engine/validate.ts','${dur(span)}, ${stated(s)} →',()=> '${dur(span)}, ${hm24(s)} →','src/engine/rally-dated-rest.test.ts'],
 ['leave-by','src/engine/validate.ts','const leaveBy=stated(first+(targetIndex-sourceIndex)*1440-VCONF.crewRest);',()=> 'const leaveBy=hm24(first+(targetIndex-sourceIndex)*1440-VCONF.crewRest);','src/engine/rally-dated-rest.test.ts'],
 ['older-source-date','src/engine/validate.ts','first+(targetIndex-sourceIndex)*1440-VCONF.crewRest',()=> 'first+1440-VCONF.crewRest','src/engine/rally-dated-rest.test.ts'],
 ['pre-drop','src/engine/validate.ts','not clear until ${stated(c.earliest)}',()=> 'not clear until ${hm24(c.earliest)}','src/engine/rally-dated-rest.test.ts'],
 ['Board-header','src/ui/board.ts','stated(inT,true)',()=> 'hm24(inT)','src/ui/rally-feedback.test.tsx'],
 ['week-header','src/ui/html.ts','${report!=null&&report<0?',()=> '${report!=null&&report<-1440?','src/ui/rally-feedback.test.tsx'],
]
const hash=b=>createHash('sha256').update(b).digest('hex'),results=[]
for(const [name,rel,needle,replacement,test] of cases){
 const path=root+'/'+rel,original=readFileSync(path),text=original.toString(),changed=text.replace(needle,replacement)
 if(changed===text)throw Error('break missing '+name)
 try{
  writeFileSync(path,changed);let r=spawnSync(process.execPath,[root+'/node_modules/vitest/vitest.mjs','run',test],{cwd:root,encoding:'utf8',timeout:180000});writeFileSync(out+'/'+name+'-red.log',(r.stdout||'')+(r.stderr||''));if(r.status===0||r.error)throw Error('break did not produce test RED '+name)
  writeFileSync(path,original);r=spawnSync(process.execPath,[root+'/node_modules/vitest/vitest.mjs','run',test],{cwd:root,encoding:'utf8',timeout:180000});writeFileSync(out+'/'+name+'-restored.log',(r.stdout||'')+(r.stderr||''));if(r.status!==0||r.error)throw Error('restored test not green '+name)
  results.push({name,test,red:true,restored:true,sourceHash:hash(original)});console.log('PASS '+name)
 }finally{writeFileSync(path,original);if(hash(readFileSync(path))!==hash(original))throw Error('restoration failed '+name);writeFileSync(out+'/results.json',JSON.stringify(results,null,2))}
}
