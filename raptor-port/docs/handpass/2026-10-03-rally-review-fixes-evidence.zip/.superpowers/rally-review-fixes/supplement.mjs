import {mkdirSync,readFileSync,writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const root='C:/Users/User/projects/Raptor/raptor-port/docs/img/handpass/2026-10-03-rally-review-fixes'
const out=root+'/supplement';mkdirSync(out,{recursive:true})
process.env.HP_URL='http://127.0.0.1:4242';process.env.HP_SHOTS=out
const {open,go,board,publish}=await import('../../raptor-port/scripts/handpass/lib.mjs')
const results=[],pictures=[];let failure=null
const save=()=>writeFileSync(out+'/results.json',JSON.stringify({results,pictures,failure},null,2))
for(const [name,width,height] of [['desktop',1440,600],['phone',844,390]]){
 const {browser,page,errors}=await open({width,height,state:root+'/walk-04/'+name+'-state.json'})
 const click=async(sel)=>{const e=page.locator(sel+':visible').first();await e.scrollIntoViewIfNeeded();await e.click();await page.waitForTimeout(250)}
 const check=async(label,fn)=>{await fn();results.push({width:name,label,status:'PASS'});save()}
 const shot=async(label)=>{const path=out+'/'+name+'-'+label+'.png';await page.screenshot({path});pictures.push(path);save()}
 try{
  await go(page,'editsched');await board(page,1)
  const add=page.locator('#schedBoard [data-itadd="1|0"]:visible').first();await add.scrollIntoViewIfNeeded()
  await check('short-screen header and Add are readable with an uncovered hit target',async()=>{
   assert.ok((await page.locator('#schedBoard .sb-go .asd:visible').first().innerText()).includes('22:00 (prev day)'))
   assert.ok(await add.evaluate(e=>{const r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.x>=0&&r.y>=0&&r.right<=innerWidth&&r.bottom<=innerHeight&&(hit===e||e.contains(hit))}))
  });await shot('previous-day-short-screen')
  if(name==='desktop'){
   await click('#schedBoard [data-planmenu="1"]')
   const ver=await page.locator('[data-planpv]').filter({hasText:'Original'}).first().getAttribute('data-planpv')
   await click(`[data-planpv="${ver}"]`)
   assert.ok((await page.locator('#schedBoard').innerText()).includes('10:15 RALLY'))
   const before=await page.evaluate(()=>JSON.stringify({orig:window.SCHED.orig,als:window.SCHED.als}))
   await click('#schedBoard [data-restore="1"]')
   if(await page.locator('#schedBoard [data-restcancel="1"]:visible').count())await click('#schedBoard [data-restore="1"]')
   await check('P4 loading Original restores its wrong pair and leaves every issued snapshot frozen',async()=>{
    assert.deepEqual(await page.evaluate(()=>window.DAYS[1].waves[0].intimes),['09:00 IN TIME','10:15 RALLY'])
    assert.equal(await page.evaluate(()=>JSON.stringify({orig:window.SCHED.orig,als:window.SCHED.als})),before)
   })
   await check('P4 remaining wrong pair can be reissued after loading the old version',async()=>{
    assert.equal((await publish(page,1)).published,true)
    assert.ok(await page.evaluate(()=>window.SCHED.als.filter(a=>a.di===1).at(-1).snap.w.byDay.warns.some(w=>w.code==='REPORT_ORDER')))
   });await shot('old-version-reissued')
   const printed=await page.context().newPage()
   await printed.setContent(readFileSync(root+'/walk-04/issued-print.html','utf8'))
   await printed.emulateMedia({media:'print'})
   await printed.pdf({path:out+'/issued-schedule-css-page.pdf',preferCSSPageSize:true,printBackground:true})
   await printed.close();results.push({width:name,label:'actual saved agency print rendered with its CSS page size',status:'PASS'});save()
  }
  assert.deepEqual(errors,[]);results.push({width:name,label:'console/page/HTTP errors',status:'PASS'});save()
 }catch(e){failure={width:name,message:e.message,stack:e.stack};await shot('failure');console.error(e);break}
 finally{await browser.close();save()}
}
console.log(JSON.stringify({checks:results.length,failure},null,2));if(failure)process.exitCode=1
