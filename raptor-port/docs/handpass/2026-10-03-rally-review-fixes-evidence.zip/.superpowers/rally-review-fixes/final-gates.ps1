Set-Location -LiteralPath 'C:\Users\User\projects\Raptor\raptor-port'
$env:E2E_PORT='4241'
$env:CI='1'
$taskLogs='C:\Users\User\projects\Raptor\.superpowers\rally-review-fixes\final-gates'
New-Item -ItemType Directory -Path $taskLogs -Force | Out-Null
node scripts/gatelock.mjs take 'codex/rally-workspan — final unit repairs and affected browser checks'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$taskFailures=0
try {
 npx vitest run *> "$taskLogs\unit.log"
 if ($LASTEXITCODE -ne 0) { $taskFailures++ }
 Get-Content "$taskLogs\unit.log" -Tail 7
 npm run build *> "$taskLogs\build.log"
 if ($LASTEXITCODE -ne 0) { $taskFailures++ }
 Get-Content "$taskLogs\build.log" -Tail 4
 node reference/tfin.js *> "$taskLogs\tfin.log"
 if ($LASTEXITCODE -ne 0) { $taskFailures++ }
 Get-Content "$taskLogs\tfin.log" -Tail 4
 npx playwright test e2e/geometry.spec.ts e2e/warnhide.spec.ts --reporter=line *> "$taskLogs\browser.log"
 if ($LASTEXITCODE -ne 0) { $taskFailures++ }
 Get-Content "$taskLogs\browser.log" -Tail 6
 node scripts/rulecheck.mjs *> "$taskLogs\rulecheck.log"
 if ($LASTEXITCODE -ne 0) { $taskFailures++ }
 Get-Content "$taskLogs\rulecheck.log" -Tail 3
 node scripts/docsize.mjs *> "$taskLogs\docsize.log"
 if ($LASTEXITCODE -ne 0) { $taskFailures++ }
 Get-Content "$taskLogs\docsize.log" -Tail 3
} finally { node scripts/gatelock.mjs release }
exit $taskFailures
