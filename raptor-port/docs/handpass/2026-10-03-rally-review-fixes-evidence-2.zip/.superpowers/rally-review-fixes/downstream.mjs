import {mkdirSync,writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const root='C:/Users/User/projects/Raptor/raptor-port/docs/img/handpass/2026-10-03-rally-review-fixes'
const out=root+'/'+(process.env.DOWNSTREAM_RUN||'downstream-01');mkdirSync(out,{recursive:true})
process.env.HP_URL='http://127.0.0.1:4242';process.env.HP_SHOTS=out
const {open,go,board,publish}=await import('../../raptor-port/scripts/handpass/lib.mjs')
const results=[],pictures=[];let failure=null
const save=()=>writeFileSync(out+'/results.json',JSON.stringify({results,pictures,failure},null,2))
for(const scenario of (process.env.DOWNSTREAM_CASES||'I1,I2,I3').split(',')){
 const {browser,page,errors}=await open({state:root+'/walk-04/phone-state.json'})
 const click=async(sel)=>{const e=page.locator(sel+':visible').first();await e.scrollIntoViewIfNeeded();await e.click();await page.waitForTimeout(250)}
 const close=async()=>{if(await page.locator('#schedBoard:visible').count())await click('#sbDone')}
 const on=async(di)=>{await close();await board(page,di)}
 const field=async(key,value)=>{const e=page.locator(`#schedBoard [data-bfld="${key}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Tab');await page.waitForTimeout(200)}
 const line=async(di,ix,value)=>{const e=page.locator(`#schedBoard [data-itline="${di}|0|${ix}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Enter');await page.waitForTimeout(200)}
 const setting=async(key,value)=>{await close();await go(page,'logic');if(await page.locator('#lgEdit:visible').count())await click('#lgEdit');const e=page.locator(`[data-lgset="${key}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Tab');await page.waitForTimeout(250)}
 const shot=async(label)=>{const p=out+'/'+scenario+'-'+label+'.png';await page.screenshot({path:p});pictures.push(p);save()}
 const check=async(label,fn)=>{const observed=await fn();results.push({scenario,label,status:'PASS',observed});save()}
 const place=async(key,id)=>{await click(`#schedBoard [data-slot="${key}"]`);assert.equal(await page.evaluate(()=>window.ARM.key),key);await click(`#sbRoster .rpuck[data-person="${id}"]`);assert.equal(await page.evaluate(k=>window.slotVal(k),key),id);await page.keyboard.press('Escape')}
 try{
  if(scenario==='I1'){
   const hours=async()=>{await close();await go(page,'editsched');await click('#insightBtn');const text=await page.evaluate(()=>[...document.querySelectorAll('#insightBody .ibar')].find(e=>e.querySelector('.nm')?.textContent==='Outlaw'&&e.querySelector('.v[title$="on the programme"]'))?.querySelector('.v').textContent);assert.ok(text);const m=text.match(/(\d+)h(?:(\d+)m?)?/);assert.ok(m);return {text,minutes:+m[1]*60+(+m[2]||0)}}
   await on(1);await check('issued Tuesday is fifteen nonnegative work hours',async()=>{const w=await page.evaluate(()=>window.WARN.all.find(w=>w.di===1&&w.code==='LONGDAY'&&w.who.includes('casper')));assert.ok(w.msg.includes('15h00, 22:00 (previous day) → 13:00'));return w.msg})
   const initial=await hours();await shot('issued-work-hours');await click('#insightClose')
   await on(1);await line(1,0,'21:00 IN TIME');await line(1,1,'21:00 RALLY')
   await check('draft sixteen-hour report leaves latest-issued Insights unchanged',async()=>{assert.ok(await page.evaluate(()=>window.WARN.all.some(w=>w.di===1&&w.code==='LONGDAY'&&w.who.includes('casper')&&w.msg.includes('16h00, 21:00 (previous day) → 13:00'))));const now=await hours();assert.deepEqual(now,initial);await click('#insightClose');return {initial,now}})
   await on(1);assert.equal((await publish(page,1)).published,true)
   let amended;await check('publishing moves actual weekly hours by exactly sixty minutes',async()=>{amended=await hours();assert.equal(amended.minutes,initial.minutes+60);return {initial,amended}});await shot('amended-work-hours');await click('#insightClose')
   const before=await page.evaluate(()=>JSON.stringify(window.DAYS[1].waves[0].intimes));await setting('reportText','RALLY TEST')
   await check('changing only future default words leaves existing reporting and hours unchanged',async()=>{assert.equal(await page.evaluate(()=>JSON.stringify(window.DAYS[1].waves[0].intimes)),before);const now=await hours();assert.deepEqual(now,amended);await click('#insightClose');return now})
  }
  if(scenario==='I2'){
   await on(1);await click('#schedBoard [data-lac="1.0.0"]');assert.equal(await page.evaluate(()=>window.DAYS[1].waves[0].formations[0].aircraft.length),3)
   const offer=async(iso,half)=>{await close();await go(page,'inputs');await page.locator('#inPerson').selectOption('krait');await page.locator('#inType').selectOption('SANS Availability');await click(`#inCal [data-cal="${iso}"]`);await click(`#inSpan [data-span="${half}"]`);await page.locator('#inSans').getByRole('checkbox',{name:'Fly',exact:true}).check();await click('#inAdd');const observed=await page.evaluate(()=>window.INPUTS.filter(i=>i.person==='krait'));writeFileSync(out+'/I2-offer-'+iso+'.json',JSON.stringify(observed,null,2));assert.ok(await page.evaluate(([d,h])=>window.INPUTS.some(i=>i.person==='krait'&&window.isSansAvail(i.type)&&window.inputCoversDate(i,'Jul '+Number(d.slice(8,10)))&&i.half===h),[iso,half]),JSON.stringify(observed))}
   const picker=async()=>{await on(1);await click('#schedBoard [data-slot="1.0.0.2.p"]');const p=page.locator('#sbRoster .rpuck[data-person="krait"]:visible').first();await p.scrollIntoViewIfNeeded();const read=await page.evaluate(()=>{const key='1.0.0.2.p',r=window.slotRules(key);return {rules:r,bar:window.slotBar('krait',key),gate:window.sansGate('krait',window.DAYS[1].dt,'fly',r.sansStart,r.slotEnd),why:document.querySelector('#sbRoster .rpuck[data-person="krait"]')?.textContent}});return read}
   await offer('2026-07-13','pm');let prior
   await check('prior-date-only offer is not treated as target-date availability in the actual picker',async()=>{prior=await picker();assert.equal(prior.gate.status,'none');assert.equal(prior.rules.sansStart,-120);return prior});await shot('prior-date-picker')
   await click('#sbRoster .rpuck[data-person="krait"]');await page.keyboard.press('Escape');await check('accepted prior-date-only placement has no persistent SANS_AVAIL warning under the current rule',async()=>{assert.equal(await page.evaluate(()=>window.slotVal('1.0.0.2.p')),'krait');const ws=await page.evaluate(()=>window.WARN.all.filter(w=>w.di===1&&w.code==='SANS_AVAIL'&&w.who.includes('krait')));assert.equal(ws.length,0);return ws})
   await click('#sbUndo');await offer('2026-07-14','am');let target
   await check('target-AM offer cannot cover a previous-evening report in the picker',async()=>{target=await picker();assert.equal(target.gate.status,'window');return target});await shot('target-AM-picker')
   await click('#sbRoster .rpuck[data-person="krait"]');await page.keyboard.press('Escape');await check('accepted target-AM placement shows the same out-of-window advisory',async()=>{assert.equal(await page.evaluate(()=>window.slotVal('1.0.0.2.p')),'krait');const ws=await page.evaluate(()=>window.WARN.all.filter(w=>w.di===1&&w.code==='SANS_AVAIL'&&w.who.includes('krait')));assert.ok(ws.length);return ws.map(w=>w.msg)});await shot('target-AM-placed')
  }
  if(scenario==='I3'){
   await setting('reportLead','3h');await setting('debrief','2h');await on(5);await click('#schedBoard [data-wvadd="5"]');await page.getByRole('button',{name:'Flying wave',exact:true}).click();await page.waitForTimeout(300)
   await field('ff:5.0.0.to','12:00');await field('ff:5.0.0.ld','13:00');await field('ff:5.0.0.br','09:40');await place('5.0.0.0.p','bane');await click('#schedBoard [data-itadd="5|0"]');await line(5,0,'09:00 IN TIME')
   const nominal=()=>page.evaluate(()=>{const spans=window.dayOilSpans(window.DAYS[5]).bane;return {spans,minutes:window.envMin(spans),award:window.uniformOil(window.envMin(spans))}})
   const earned=async(label)=>{await close();await go(page,'leavewar');await click('[data-testid="month-JUL"]');const cell=await page.locator('[data-testid="cell-bane-2026-07-18"]').innerText();assert.ok(cell.includes('HO*'));await click('[data-testid="oil-tracker"]');const row=page.locator('[data-testid="oil-row-bane"] .oil-e').filter({has:page.locator('.by.auto')}).filter({hasText:'18 Jul'}).first();assert.ok(await row.count());const text=await row.innerText();assert.ok(text.includes('+0.5'));await shot(label);const closer=page.locator('[data-testid="oil-close"]:visible');if(await closer.count())await closer.click();else await page.keyboard.press('Escape');return {cell,tracker:text}}
   await check('360 nominal minutes remains below the existing full-day threshold',async()=>{const n=await nominal();assert.deepEqual(n.spans,[[540,900]]);assert.equal(n.minutes,360);return n});assert.equal((await publish(page,5)).published,true)
   await check('published360min appears as actual half-day earned Leave War credit',async()=>{const e=await earned('earned-360');assert.ok(e.tracker.includes('09:00–15:00'));return e})
   await on(5);await line(5,0,'08:00 RALLY');assert.equal((await publish(page,5)).published,true)
   await check('actual earlier report does not replace the nominal360min earned basis',async()=>{const n=await nominal();assert.equal(n.minutes,360);const e=await earned('actual-report-credit-unchanged');assert.ok(e.tracker.includes('09:00–15:00'));return {n,e}})
   await setting('reportLead','2h');await on(5);await line(5,0,'07:00 RALLY');assert.equal((await publish(page,5)).published,true)
   await check('changing Logic lead gives300 nominal minutes and actual10:00–15:00 earned record',async()=>{const n=await nominal();assert.deepEqual(n.spans,[[600,900]]);assert.equal(n.minutes,300);const e=await earned('earned-300');assert.ok(e.tracker.includes('10:00–15:00'));return {n,e}})
  }
  assert.deepEqual(errors,[]);results.push({scenario,label:'console/page/HTTP errors',status:'PASS'});save()
 }catch(e){failure={scenario,message:e.message,stack:e.stack};await shot('failure');console.error(e);break}
 finally{await browser.close();save()}
}
console.log(JSON.stringify({checks:results.length,failure},null,2));if(failure)process.exitCode=1
