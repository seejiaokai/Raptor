import {mkdirSync,writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const root='C:/Users/User/projects/Raptor/raptor-port/docs/img/handpass/2026-10-03-rally-review-fixes'
const out=root+'/'+(process.env.HEADER_RUN||'header-width-red');mkdirSync(out,{recursive:true})
process.env.HP_URL='http://127.0.0.1:4242';process.env.HP_SHOTS=out
const {open,go,board}=await import('../../raptor-port/scripts/handpass/lib.mjs')
const results=[],pictures=[];let failures=0
for(const [name,width,height] of [['desktop',1440,900],['phone',390,844],['landscape',844,390],['tablet',1024,600]]){
 const {browser,page,errors}=await open({width,height,state:root+'/walk-04/phone-state.json'})
 try{
  await go(page,'editsched');await board(page,1)
  const head=page.locator('#schedBoard .sb-go-h:visible').first();await head.scrollIntoViewIfNeeded()
  const measured=await head.evaluate(e=>{
   const summary=e.querySelector('.asd'),r=summary.getBoundingClientRect(),hr=e.getBoundingClientRect(),cs=getComputedStyle(summary)
   const line=parseFloat(cs.lineHeight)||parseFloat(cs.fontSize)*1.2
   const buttons=[...e.querySelectorAll('button')].map(b=>{const q=b.getBoundingClientRect(),hit=document.elementFromPoint(q.x+q.width/2,q.y+q.height/2);return {text:b.textContent,width:q.width,height:q.height,inside:q.x>=hr.x&&q.right<=hr.right+1&&q.y>=hr.y&&q.bottom<=hr.bottom+1&&q.x>=0&&q.right<=innerWidth&&q.y>=0&&q.bottom<=innerHeight,hit:hit===b||b.contains(hit)}})
   return {text:summary.textContent,width:r.width,height:r.height,line,buttons,headerWidth:hr.width,scrollWidth:e.scrollWidth,clientWidth:e.clientWidth}
  })
  const path=out+'/'+name+'-previous-day-header.png';await page.screenshot({path});pictures.push(path)
  try{
   assert.ok(measured.text.includes('22:00 (prev day)'))
   assert.ok(measured.width>=120&&measured.height<=measured.line*2.2,'the complete date cue must fit within two readable lines, not a narrow vertical column')
   assert.ok(measured.buttons.every(b=>b.inside&&b.hit&&b.width>=27&&b.height>=14),'every header button retains its full bounds and actual hit target')
   assert.ok(measured.scrollWidth<=measured.clientWidth+1,'the wave header must not overflow horizontally')
   assert.deepEqual(errors,[]);results.push({name,status:'PASS',measured})
  }catch(e){failures++;results.push({name,status:'FAIL',message:e.message,measured})}
 }finally{await browser.close()}
}
writeFileSync(out+'/results.json',JSON.stringify({results,pictures,failures},null,2))
console.log(JSON.stringify({results:results.map(r=>({name:r.name,status:r.status,width:r.measured.width,height:r.measured.height})),failures},null,2));if(failures)process.exitCode=1
