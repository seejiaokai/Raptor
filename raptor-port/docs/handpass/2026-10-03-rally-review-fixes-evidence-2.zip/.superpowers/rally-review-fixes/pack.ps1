param([string]$TaskArchiveName='2026-10-03-rally-review-fixes-evidence.zip')
$ErrorActionPreference='Stop'
$taskRepo='C:\Users\User\projects\Raptor'
$taskProofRoot=Join-Path $taskRepo '.superpowers\rally-review-fixes'
$taskImageRoot=Join-Path $taskRepo 'raptor-port\docs\img\handpass\2026-10-03-rally-review-fixes'
$taskZip=Join-Path $taskRepo ('raptor-port\docs\handpass\'+$TaskArchiveName)
$taskFileList=[System.Collections.Generic.List[string]]::new()
Get-ChildItem -LiteralPath $taskProofRoot -File | Where-Object { $_.Extension -in '.log','.mjs','.ps1' } | ForEach-Object { $taskFileList.Add($_.FullName) }
foreach($taskDirName in @('red-green','gates','final-gates','breaks')) {
 Get-ChildItem -LiteralPath (Join-Path $taskProofRoot $taskDirName) -File -Recurse | ForEach-Object { $taskFileList.Add($_.FullName) }
}
Get-ChildItem -LiteralPath $taskImageRoot -File -Recurse | ForEach-Object { $taskFileList.Add($_.FullName) }
Get-ChildItem -LiteralPath (Join-Path $taskRepo 'raptor-port\dist') -File -Recurse | ForEach-Object { $taskFileList.Add($_.FullName) }
Add-Type -AssemblyName System.IO.Compression
$taskZipStream=[System.IO.File]::Open($taskZip,[System.IO.FileMode]::Create)
$taskArchive=[System.IO.Compression.ZipArchive]::new($taskZipStream,[System.IO.Compression.ZipArchiveMode]::Create)
try {
 foreach($taskFile in ($taskFileList | Sort-Object -Unique)) {
  $taskRelative=$taskFile.Substring($taskRepo.Length+1).Replace('\','/')
  $taskEntry=$taskArchive.CreateEntry($taskRelative,[System.IO.Compression.CompressionLevel]::Optimal)
  $taskEntryStream=$taskEntry.Open();$taskInputStream=[System.IO.File]::OpenRead($taskFile)
  try { $taskInputStream.CopyTo($taskEntryStream) } finally { $taskInputStream.Dispose();$taskEntryStream.Dispose() }
 }
} finally { $taskArchive.Dispose();$taskZipStream.Dispose() }
Get-Item -LiteralPath $taskZip | Select-Object Name,Length
Get-FileHash -LiteralPath $taskZip -Algorithm SHA256
