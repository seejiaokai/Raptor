import {mkdirSync,writeFileSync} from 'node:fs'
import assert from 'node:assert/strict'
const root='C:/Users/User/projects/Raptor/raptor-port/docs/img/handpass/2026-10-03-rally-review-fixes',out=root+'/header-actions';mkdirSync(out,{recursive:true})
process.env.HP_URL='http://127.0.0.1:4242';process.env.HP_SHOTS=out
const {open,board}=await import('../../raptor-port/scripts/handpass/lib.mjs')
const {browser,page,errors}=await open({width:844,height:390,state:root+'/walk-04/phone-state.json'})
const results=[],pictures=[];let failure=null
const click=async(s)=>{const e=page.locator(s+':visible').first();await e.scrollIntoViewIfNeeded();await e.click();await page.waitForTimeout(250)}
const check=async(label,fn)=>{await fn();results.push({label,status:'PASS'})}
const shot=async(label)=>{const p=out+'/'+label+'.png';await page.screenshot({path:p});pictures.push(p)}
try{
 await board(page,1);const before=await page.evaluate(()=>JSON.stringify(window.DAYS[1].waves)),num=await page.evaluate(()=>window.DAYS[1].waves[0].intimes.length)
 await check('Add is operated in the formerly clipped header and Undo restores its exact data',async()=>{await click('#schedBoard [data-itadd="1|0"]');assert.equal(await page.evaluate(()=>window.DAYS[1].waves[0].intimes.length),num+1);await click('#sbUndo');assert.equal(await page.evaluate(()=>JSON.stringify(window.DAYS[1].waves)),before)})
 await check('Line is operated and Undo restores the exact formations',async()=>{await click('#schedBoard [data-gline="1.0"]');assert.equal(await page.evaluate(()=>window.DAYS[1].waves[0].formations.length),3);await click('#sbUndo');assert.equal(await page.evaluate(()=>JSON.stringify(window.DAYS[1].waves)),before)})
 await check('Wave is operated and Undo restores the entire isolated fixture wave',async()=>{const n=await page.evaluate(()=>window.DAYS[1].waves.length);await click('#schedBoard [data-gdel="1.0"]');assert.equal(await page.evaluate(()=>window.DAYS[1].waves.length),n-1);await click('#sbUndo');assert.equal(await page.evaluate(()=>JSON.stringify(window.DAYS[1].waves)),before)})
 for(const [key,value] of [['ff:1.0.0.to','12:00'],['ff:1.0.1.to','12:00']]){const e=page.locator(`#schedBoard [data-bfld="${key}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Tab')}
 for(const [i,value] of [[0,'09:00 IN TIME'],[1,'09:00 RALLY']]){const e=page.locator(`#schedBoard [data-itline="1|0|${i}"]:visible`).first();await e.scrollIntoViewIfNeeded();await e.fill(value);await e.press('Enter')}
 await check('ordinary same-day header keeps its clock without a previous-day cue',async()=>{const h=page.locator('#schedBoard .sb-go-h:visible').first();await h.scrollIntoViewIfNeeded();const text=await h.innerText();assert.ok(text.includes('09:00'));assert.ok(!text.includes('prev day'))});await shot('same-day-header')
 const ver=await page.evaluate(()=>window.dayCurVer(1));await click('#schedBoard [data-planmenu="1"]');await click(`[data-planpv="${ver}"]`)
 await check('issued readonly header keeps the previous-day cue and no edit controls',async()=>{const h=page.locator('#schedBoard .sb-go-h:visible').first();await h.scrollIntoViewIfNeeded();assert.ok((await h.innerText()).includes('22:00 (prev day)'));assert.equal(await h.locator('.gctl button').count(),0)});await shot('issued-previous-day-header')
 assert.deepEqual(errors,[]);results.push({label:'console/page/HTTP errors',status:'PASS'})
}catch(e){failure={message:e.message,stack:e.stack};await shot('failure');console.error(e)}
finally{await browser.close();writeFileSync(out+'/results.json',JSON.stringify({results,pictures,failure},null,2))}
console.log(JSON.stringify({checks:results.length,failure},null,2));if(failure)process.exitCode=1
