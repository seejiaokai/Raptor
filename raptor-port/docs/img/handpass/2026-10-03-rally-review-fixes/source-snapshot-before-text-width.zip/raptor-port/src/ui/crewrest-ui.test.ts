/* The two crew-rest visuals (owner, 6 Aug 26): a sanctioned late show rings
   DASHED rather than solid, and clicking a crew-rest warning traces it back to
   the previous day — dashed ring there too, labelled CR, with the leave-by
   time the warning already worked out.

   Markup-level, because that is where both live: jsdom cannot measure a ring,
   but it can prove which class the builder emitted. The stroke itself is a
   measured contract in scheduler.css and is covered by the geometry gate. */
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { DAYS } from '../engine/data'
import { validate, WARN, traceOf, traceLeads, traceIx } from '../engine/validate'
import { VCONF } from '../engine/rules'
import { parseHM } from '../engine/time'
import { isStandalone, CURWEEK, setCurWeek } from '../engine/waves'
import { weekBundle } from '../engine/weeks-data'
import { snapshotStash, restoreStash, stashPut } from '../engine/weekstash'
import { dayHTML, dayWarnHTML } from './html'
import { personWarns } from '../engine/avail'
import { focusWarn, clearWarnFocus, setWarnFocus, toggleDayWarn, selectPerson, selDrop } from '../state/view'
import * as view from '../state/view'

const CREW = 'waldo'
const DSNAP = JSON.stringify(DAYS)
beforeEach(() => {
  DAYS.length = 0; JSON.parse(DSNAP).forEach((d: any) => DAYS.push(d))
  /* selDrop, not clearWarnFocus alone: these tests now OPEN day boxes and
     click pucks, and an open box leaking into the next test would make the
     on-demand strip look standing again — i.e. hide the very regression the
     block below exists to catch. */
  selDrop()
})

const firstForm = (di: number) => {
  const w = (DAYS[di].waves || []).find((x: any) => !isStandalone(x) && (x.formations || []).length)
  return w ? w.formations[0] : null
}
/* another flying formation on the same day, so a man can be given two legs and
   the trace asked which one it names */
const otherForm = (di: number, not: any) => {
  for (const w of (DAYS[di].waves || [])) {
    if (isStandalone(w)) continue
    for (const f of (w.formations || [])) if (f !== not) return f
  }
  return null
}
/* the slot-key the engine will mint for a seat — the raw indices of waves,
   formations and aircraft, which is the grammar collectEvents builds from */
const keyOf = (di: number, f: any, ai: number, seat: 'p' | 'w') => {
  const waves = DAYS[di].waves || []
  for (let gi = 0; gi < waves.length; gi++) {
    const li = (waves[gi].formations || []).indexOf(f)
    if (li >= 0) return `${di}.${gi}.${li}.${ai}.${seat}`
  }
  return ''
}
const hhmmOf = (m: number) => {
  const x = ((m % 1440) + 1440) % 1440
  return String(Math.floor(x / 60)).padStart(2, '0') + ':' + String(x % 60).padStart(2, '0')
}
/* the owner's numbers: in-time 12:00, brief 13:00, T/O 15:20 → rest must be
   clear by 12:00 and the latest show is 14:20 */
const build = (leftAt: string, rmks: string) => {
  const prev: any = firstForm(0)!
  /* waldo is a WSO: seat him in the RCP or the puck earns a QUAL flag, which
     outranks CR and would hide the very label these tests are about */
  prev.aircraft.push({ p: '', w: CREW, area: '', rmks: '', opts: {} })
  prev.to = '20:00'; prev.ld = hhmmOf(parseHM(leftAt)! - VCONF.debrief)
  const today: any = firstForm(1)!
  today.aircraft.push({ p: '', w: CREW, area: '', rmks, opts: {} })
  today.br = '13:00'; today.to = '15:20'; today.ld = '16:45'
  const wave = DAYS[1].waves.find((w: any) => (w.formations || []).includes(today))
  wave.intimes = ['%CS% IN TIME 1200H'.replace('%CS%', today.cs)]
  validate()
  return WARN.byDay[1].warns.findIndex((w: any) => w.code === 'CREW_REST' && (w.who || []).includes(CREW))
}
/* the crew's own puck on a day: [0] the class list, [1] the whole element,
   because the flag chip is a CHILD (class l-cr / l-c), not part of the class */
const puckOf = (di: number) => {
  const m = dayHTML(di, false).match(new RegExp(`<span class="([^"]*puck[^"]*)"[^>]*data-person="${CREW}"[^>]*>(.{0,200})`))
  return m ? m[1] : ''
}
const puckHtml = (di: number) => {
  const m = dayHTML(di, false).match(new RegExp(`<span class="[^"]*puck[^"]*"[^>]*data-person="${CREW}"[^>]*>(.{0,200})`))
  return m ? m[1] : ''
}

describe('the crew-rest ring', () => {
  it('an unsanctioned breach rings SOLID', () => {
    expect(build('01:30', '2A: BFM-5'), 'the case flags').toBeGreaterThanOrEqual(0)
    expect(puckOf(1)).toContain('boxred')
    expect(puckOf(1)).not.toContain('boxdash')
  })

  it('a sanctioned late show that still makes the show rings DASHED', () => {
    expect(build('01:30', '2A: LATE SHOW')).toBeGreaterThanOrEqual(0)
    expect(puckOf(1)).toContain('boxdash')
    expect(puckOf(1), 'the dashed class REPLACES the solid one').not.toContain('boxred')
  })

  it('past the latest show it rings solid again, remark or not', () => {
    /* left 02:21 → rest clears 14:21, after the 14:20 latest show */
    expect(build('02:21', '2A: LATE SHOW')).toBeGreaterThanOrEqual(0)
    expect(puckOf(1)).toContain('boxred')
    expect(puckOf(1)).not.toContain('boxdash')
  })
})

/* THE MESSAGE STATES ITS DEBRIEF ASSUMPTION (owner, 15 Aug 26 — "state why it
   would flag… the assumption that the crew will debrief 2 hours after landing…
   because actually they can leave quickly after landing"). A sortie's rest
   clock does not start at the landing; it starts VCONF.debrief later. That pad
   is a default, so the breach spells it out — landing, pad, derived end — and a
   scheduler who knows this crew walks off fast can discount it themselves. */
describe('the breach message spells out the debrief assumption', () => {
  it('a sortie breach names the real landing, the +2h pad, and the derived end', () => {
    const ix = build('01:30', '2A: BFM-5')          // lands 23:30, +2h → ends 01:30
    const msg = WARN.byDay[1].warns[ix].msg
    expect(msg, 'the real landing, not just the derived end').toContain('landed 23:30')
    expect(msg, 'the pad named as an assumption the reader can override').toContain('+2h debrief assumed')
    expect(msg, 'and the derived end the 12h clock actually runs from').toContain('ended 01:30')
  })
})

/* THE TRACE IS A STANDING MARK (owner, 6 Aug 26). It used to appear only while
   the warning was focused, which meant the reader had to already know about
   the breach to be shown its cause. It is model state now — validate() files
   every breach against the day that caused it — so it is on the page before
   anything is clicked, and clicking is only ever navigation. */
describe('the previous-day trace', () => {
  it('is painted with nothing clicked, and does not clear with the focus', () => {
    const ix = build('01:30', '2A: BFM-5')
    expect(puckOf(0), 'the cause is marked before any click').toContain('boxdot')
    expect(puckHtml(0), 'and labelled CR').toContain('l-cr"')
    focusWarn(1, ix)
    expect(puckOf(0), 'focusing the warning does not change it').toContain('boxdot')
    clearWarnFocus()
    expect(puckOf(0), 'and clearing the focus does not take it away').toContain('boxdot')
  })

  it('rings DOTTED, never solid — he flew a legal day here', () => {
    build('01:30', '2A: BFM-5')
    expect(puckOf(0)).toContain('boxdot')
    expect(puckOf(0), 'the breach is tomorrow, so no red box today').not.toContain('boxred')
    expect(puckOf(0), 'and it is not the sanctioned-late-show dash either').not.toContain('boxdash')
  })

  it('the chip and the title name the day it breaks and the leave-by time', () => {
    build('01:30', '2A: BFM-5')
    const h = puckHtml(0)
    expect(h, 'the caption is the reader\'s question, not the threshold').toContain('is broken by this day')
    expect(h).toContain('had to leave by 00:00')
  })

  it('the warning carries the time he had to leave — as data, not message text', () => {
    const ix = build('01:30', '2A: BFM-5')
    const w = WARN.byDay[1].warns[ix]
    expect(w.leaveBy, 'anchor 12:00 less 12h crew rest').toBe('00:00 (next day)')
    /* owner, 22 Aug 26: the trace row's bold lead prints the leave-by, so the
       message restating it read twice — it is a data field only now */
    expect(w.msg).not.toContain('leave by')
    expect(w.prevDi, 'and which day to look back at').toBe(0)
  })

  it('publishes the same facts on WARN.trace, keyed by the day that caused it', () => {
    const ix = build('01:30', '2A: BFM-5')
    const t = traceOf(0, CREW)
    expect(t, 'filed against day 0, the day a scheduler can still fix').toBeTruthy()
    expect(t.di, 'and pointing at the day of the breach').toBe(1)
    expect(t.leaveBy).toBe('00:00 (next day)')
    expect(traceIx(t, CREW), 'resolving to the warning\'s own index').toBe(ix)
    expect(traceOf(1, CREW), 'nothing is filed against the day of the breach').toBeNull()
  })

  /* THE TRACE NAMES THE LEG, NOT JUST THE DAY (owner, from the deployed site,
     7 Aug 26). The row on the causing day is the only affordance a scheduler can
     act on, so it has to be able to point at the sortie to move — and the engine
     is the only place that knows which one it was. */
  it('names the leg on the causing day that ran late', () => {
    build('01:30', '2A: BFM-5')
    const prev: any = firstForm(0)!
    const t = traceOf(0, CREW)
    expect(t.fromKey, 'his own RCP seat in the line that landed after midnight')
      .toBe(keyOf(0, prev, prev.aircraft.length - 1, 'w'))
  })

  it('names the LATER-ending leg where he flew twice that day', () => {
    /* the whole reason a key beats a heuristic: "his first puck in document
       order" would land on the morning line, which broke nothing */
    build('01:30', '2A: BFM-5')
    const prev: any = firstForm(0)!
    const am: any = otherForm(0, prev)!
    expect(am, 'the seed day has a second flying formation').toBeTruthy()
    am.aircraft.push({ p: '', w: CREW, area: '', rmks: '', opts: {} })
    am.to = '08:00'; am.ld = '09:00'
    validate()
    const t = traceOf(0, CREW)
    expect(t, 'the breach still stands').toBeTruthy()
    expect(t.fromKey, 'the late line, not the morning one it renders before')
      .toBe(keyOf(0, prev, prev.aircraft.length - 1, 'w'))
  })

  it('traces only the crew the warning names, and only its own previous day', () => {
    build('01:30', '2A: BFM-5')
    expect(puckOf(2), 'day 2 caused nothing').not.toContain('boxdot')
    expect(traceOf(0, 'bane'), 'and nobody else flew him into it').toBeNull()
  })
})

/* The strip under the previous day's issue box — the same breach, read from
   the day that caused it, addressed by the NEXT day's (di, ix) so the ordinary
   .witem handler navigates it with no click path of its own.

   It is ON DEMAND (owner, 7 Aug 26): several lines of tomorrow's prose used to
   sit on a day whose own issue list was still collapsed, so the day read as
   though it had a problem of its own. Two asks reveal it — open this day's
   warning list, or click the man's puck — and the puck's own dotted ring and R
   tag stay standing either way, so the day still shows WHERE to click. */
describe('the cross-day row on the warning list', () => {
  it('stays hidden until asked for', () => {
    build('01:30', '2A: BFM-5')
    expect(dayHTML(0, false), 'nothing clicked, nothing opened').not.toContain('dwtrace')
  })

  it('opening this day\'s warning list reveals it', () => {
    const ix = build('01:30', '2A: BFM-5')
    toggleDayWarn(0)
    const h = dayHTML(0, false)
    expect(h, 'the strip is there').toContain('dwtrace')
    expect(h, 'addressed to the day of the breach, not this one')
      .toContain(`data-wdi="1" data-wix="${ix}"`)
    expect(h).toContain('had to leave by')
  })

  /* THE WARNING IS TOMORROW'S, THE VIEW STAYS HERE (owner, from the deployed
     site, 7 Aug 26). Clicking used to throw the week over to the breach day and
     land on the flagged leg — which the row's own prose had already described.
     What the reader came for is the sortie on THIS day that ran late, because
     that is the only one still movable. */
  it('carries the pan address of the line on this day that caused it', () => {
    build('01:30', '2A: BFM-5')
    toggleDayWarn(0)
    const h = dayHTML(0, false)
    const prev: any = firstForm(0)!
    expect(h, 'the day it is drawn on, so the view does not leave it')
      .toContain('data-wpd="0"')
    expect(h, 'and the late leg inside it')
      .toContain(`data-wpk="${keyOf(0, prev, prev.aircraft.length - 1, 'w')}"`)
  })

  it('clicking the man\'s puck reveals it too', () => {
    /* the other half of the owner's sentence. Landing at 01:30 gives him a
       long-day note on day 0 as well, so his narrowed box opens there and the
       strip rides INSIDE it — the row sits with his own issues, in the same
       list, which is the whole point of the 7 Aug 26 restyle. */
    build('01:30', '2A: BFM-5')
    selectPerson(CREW, true)
    const h = dayHTML(0, false)
    expect(h, 'his own puck is the way in').toContain('dwtrace')
    expect(h, 'and the strip is part of his list, not a private box').toContain('dwlist')
  })

  it('a day where he has nothing of his own wears the solo list box', () => {
    /* Ending day 0 at 22:45 keeps his day short (no long-day note) while the
       06:00 report still breaches — the seed's own Casper numbers. With no
       row of his on the causing day there is no box to ride in, so the strip
       stands alone — wrapped as a `solo` list so its box and width are the
       SAME as an ordinary issue list's, not a private container (owner,
       7 Aug 26). */
    build('22:45', '2A: BFM-5')
    const source:any=firstForm(0)!
    DAYS[0].waves.find((w:any)=>(w.formations||[]).includes(source)).intimes=[`${source.cs} IN TIME 1700H`]
    const today: any = firstForm(1)!
    const wave = DAYS[1].waves.find((w: any) => (w.formations || []).includes(today))
    wave.intimes = [`${today.cs} IN TIME 0600H`]
    validate()
    expect(personWarns(0, CREW).length, 'the case depends on him carrying nothing on day 0').toBe(0)
    selectPerson(CREW, true)
    const h = dayHTML(0, false)
    expect(h, 'the strip still reveals').toContain('dwtrace')
    expect(h, 'wrapped as a solo list').toContain('dwlist solo')
  })

  it('sits below the warnings and above the advisories (owner, 7 Aug 26)', () => {
    /* items are severity-sorted at validate(); the cross-day row is red
       business but tomorrow's, so it ranks after this day's own hard rows and
       before its ambers. Read the rendered order straight off the list. */
    build('01:30', '2A: BFM-5')
    toggleDayWarn(0)
    const h = dayHTML(0, false)
    const kinds = [...h.matchAll(/<div class="witem (hard wtr|hard|adv|note)[" ]/g)].map(m => m[1])
    expect(kinds, 'the seed day gives the row neighbours on both sides')
      .toEqual(expect.arrayContaining(['hard', 'hard wtr', 'adv']))
    const tr = kinds.indexOf('hard wtr')
    expect(kinds.slice(0, tr).every(k => k === 'hard'), 'nothing but warnings above it').toBe(true)
    expect(kinds.slice(tr + 1).every(k => k !== 'hard'), 'every warning sits above it').toBe(true)
    expect(kinds.slice(tr + 1).some(k => k === 'adv' || k === 'note'), 'and the advisories follow below').toBe(true)
  })

  it('the puck keeps its standing mark, so there is something to click', () => {
    build('01:30', '2A: BFM-5')
    expect(puckOf(0), 'the dotted ring stays with nothing clicked').toContain('boxdot')
    expect(dayHTML(0, false), 'even though the prose does not').not.toContain('dwtrace')
  })

  it('the day of the breach carries no such row — it is not that day\'s doing', () => {
    build('01:30', '2A: BFM-5')
    toggleDayWarn(1)
    expect(dayHTML(1, false)).not.toContain('dwtrace')
  })

  it('the ⚠ count stays the day\'s OWN issues', () => {
    build('01:30', '2A: BFM-5')
    const own = ((WARN.byDay[0] && WARN.byDay[0].warns) || []).length
    toggleDayWarn(0)
    const m = dayHTML(0, false).match(/⚠ (\d+) issue/)
    /* a day with no issues of its own shows no count at all, and the strip
       still renders once asked for — that is the case the mark exists for */
    if (own) expect(+m![1], 'tomorrow\'s breach is not counted here').toBe(own)
    else expect(m, 'no issue box, but the strip stands alone').toBeNull()
    expect(dayHTML(0, false)).toContain('dwtrace')
  })
})

/* A man can carry a sanctioned late show AND an unrelated warning that
   outranks it. The ring belongs to the flag the puck PRINTS, so a conflict
   must not inherit the dash and read as a sanctioned conflict. */
describe('the dash belongs to the crew-rest flag, not to the person', () => {
  it('a louder unrelated flag rings solid even when the CR is sanctioned', () => {
    build('01:30', '2A: LATE SHOW')
    /* give him a conflict on the same day: C (rank 12) outranks CR (rank 9) */
    const today: any = firstForm(1)!
    DAYS[1].ground = DAYS[1].ground || []
    DAYS[1].ground.push({ prog: 'CLASHING MTG', str: today.to, end: '17:30', who: 'Scribe' })
    validate()
    const cls = puckOf(1)
    expect(puckHtml(1), 'the conflict wins the chip').toContain('l-c"')
    expect(cls, 'so the ring is solid, not a sanctioned-looking dash').toContain('boxred')
    expect(cls).not.toContain('boxdash')
  })
})

/* The trace used to be rebuilt from whatever the click had put on WFOCUS, so
   each surface that opened a warning had to remember to carry prevDi and
   leaveBy across — and the chip path once didn't. Reading it off the model
   instead makes that whole class of bug unreachable: no surface can forget a
   field it never passes. Pinned, because it is the reason for the rework. */
describe('the trace does not depend on which surface opened the warning', () => {
  it('a focus built by jumpToWarn carries no trace fields, and none are needed', () => {
    const ix = build('01:30', '2A: BFM-5')
    const w = WARN.byDay[1].warns[ix]
    setWarnFocus({ di: 1, ix, ids: (w.who || []).slice(), sev: w.sev, key: w.key, code: w.code })
    expect(puckOf(0), 'the previous day is marked regardless').toContain('boxdot')
    expect(puckHtml(0)).toContain('l-cr"')
  })
})

/* A louder flag of his own wins the CAPTION — a conflict is not a crew-rest
   problem and must not be labelled as one — but the dotted ring is additive
   and stays, because he still wrecks tomorrow either way. .boxdot is an
   outline and .boxred a box-shadow, which is what lets both be worn at once. */
describe('a louder flag on the causing day', () => {
  it('takes the chip but leaves the dotted ring', () => {
    build('01:30', '2A: BFM-5')
    const prev: any = firstForm(0)!
    DAYS[0].ground = DAYS[0].ground || []
    DAYS[0].ground.push({ prog: 'CLASHING MTG', str: prev.to, end: '23:30', who: 'Scribe' })
    validate()
    expect(traceOf(0, CREW), 'the trace itself is untouched').toBeTruthy()
    expect(traceLeads(0, CREW), 'but it no longer owns the flag').toBeNull()
    expect(puckHtml(0), 'the conflict wins the chip').toContain('l-c"')
    expect(puckOf(0), 'and both rings are worn at once').toContain('boxdot')
    expect(puckOf(0)).toContain('boxred')
  })
})

/* THE FORWARD TRACE ACROSS THE WEEK EDGE (owner, 23 Aug 26 — "If I plan
   someone who bust crew rest the day prior it should also flag out just like
   what u see for outlaw"). validate.ts's crewRestDay is run a second time
   after the day loop, with next Monday standing in as a phantom "today"
   (weekctx.ts's nextMondaySeed) and the LOADED week's real Sunday (ev[6]) as
   the phantom's yesterday — di:null throughout, since the phantom day
   belongs to a week this WARN cannot address by index. Only the trace write
   survives the phantom guard (markTrace's own di!=null-free write onto
   ev[6]'s real index), so the write above is the only side effect. */
describe('the forward trace across the week edge', () => {
  /* CURWEEK stays module state across tests — this file never otherwise
     touches it (it always validates the loaded seed week directly), so any
     test below that moves it restores it afterward. */
  afterEach(() => { setCurWeek('13/07/2026') })

  it('the default seed week (week 1) draws no forward trace', () => {
    validate()
    expect(WARN.trace[6]).toBeFalsy()
  })

  it("the default second seed week (week 2) draws no forward trace either", () => {
    const savedDays = JSON.stringify(DAYS)
    try {
      const wk2 = weekBundle('20/07/2026').days
      DAYS.length = 0; wk2.forEach((d: any) => DAYS.push(d))
      setCurWeek('20/07/2026')
      validate()
      expect(WARN.trace[6]).toBeFalsy()
    } finally {
      DAYS.length = 0; JSON.parse(savedDays).forEach((d: any) => DAYS.push(d))
    }
  })

  /* the case the owner proved by hand: bane flies week 2's Monday (WAVE 1
     VL, T/O 08:40, in-time 0700H — instructed report 06:20) and week 1's
     Sunday hands him a duty that runs him till 23:00. Week 1 stays the
     loaded week throughout — the trace lands on ITS Sunday (di 6), pointing
     forward at a Monday this WARN cannot address by index. */
  it('a week-2 Monday flyer given a week-1 Sunday duty till 23:00 draws a forward trace on trace[6]', () => {
    ;(DAYS[6] as any).dutywaves[0].rows.push({ role: 'Duty', id: 'bane', str: '1300', end: '2300' })
    validate()
    const t = traceOf(6, 'bane')
    expect(t, 'a forward trace crosses the week edge').toBeTruthy()
    expect(t.di, "the breach belongs to a day this week's WARN cannot address").toBeNull()
    expect(t.dow).toBe('Monday')
    expect(t.msg).toMatch(/Crew rest breach/)

    /* removing the duty and re-validating clears it — the trace is model
       state, re-derived on every validate(), never a sticky flag */
    ;(DAYS[6] as any).dutywaves[0].rows.pop()
    validate()
    expect(traceOf(6, 'bane')).toBeNull()
  })

  it('renders as "Breaks Monday" with no data-wdi — there is no warning on THIS week to focus', () => {
    ;(DAYS[6] as any).dutywaves[0].rows.push({ role: 'Duty', id: 'bane', str: '1300', end: '2300' })
    validate()
    toggleDayWarn(6)
    const h = dayWarnHTML(6)
    expect(h).toContain('Breaks Monday')
    const row = h.match(/<div class="witem hard wtr[^]*?<\/div>/)
    expect(row, 'the trace row itself').toBeTruthy()
    expect(row![0]).not.toContain('data-wdi')
    ;(DAYS[6] as any).dutywaves[0].rows.pop()
  })

  /* regression: the ordinary WITHIN-week trace (this file's own `build`
     helper, day 0 → day 1) still carries data-wdi — only the cross-week
     trace is addressless. Already pinned above ("carries the pan address of
     the line on this day that caused it"); restated here for locality next
     to the new forward-trace pins. */
  it('a real within-week trace row still carries data-wdi (regression)', () => {
    const ix = build('01:30', '2A: BFM-5')
    toggleDayWarn(0)
    expect(dayHTML(0, false)).toContain(`data-wdi="1" data-wix="${ix}"`)
  })

  /* a CREW_TIGHT-only case never traces — matching the within-week rule
     (crewRestDay's tight branch never calls markTrace, only the hard-breach
     branch does). Sunday 09:00–18:00: clears at 06:00, inside bane's
     05:40–06:20 nominal/instructed window, so it chips TT but never breaks. */
  it('a CREW_TIGHT-only forward case writes no trace', () => {
    const saved=snapshotStash()
    try {
      const next=weekBundle('20/07/2026').days
      next[0].waves[0].intimes=['06:20 VL IN TIME'];next[0].waves[0].formations[0].br='06:20'
      stashPut('20/07/2026',JSON.stringify({d:next}))
      ;(DAYS[6] as any).dutywaves[0].rows.push({ role: 'Duty', id: 'bane', str: '0900', end: '1800' })
      validate();expect(traceOf(6, 'bane')).toBeNull()
    } finally { restoreStash(saved);(DAYS[6] as any).dutywaves[0].rows.pop() }
  })
  /* THE RING MUST BE EXPLAINABLE BY A TAP (23 Aug 26, found driving the
     built bundle): selectPerson used to open only days where the person has
     a WARNING in the loaded week — a man whose only mark is the forward
     trace (his breach lives on next week's Monday) had a ringed puck that a
     click could not explain. Trace days now join PFOCUS's day list, so the
     tap opens Sunday's "Breaks Monday" row like any other. */
  it('clicking the puck of a man with only a forward trace opens Sunday and shows the box', () => {
    ;(DAYS[6] as any).dutywaves[0].rows.push({ role: 'Duty', id: 'bane', str: '1300', end: '2300' })
    validate()
    expect(((WARN.byDay[6] || {}).warns || []).some((w: any) => (w.who || []).includes('bane')),
      'precondition: Sunday itself carries no warning for him — only the trace').toBe(false)
    view.selectPerson('bane', true)
    expect(view.PFOCUS && view.PFOCUS.id, 'the tap focused him').toBe('bane')
    expect(view.PFOCUS.days).toContain(6)
    expect(view.DWOPEN.has(6), "Sunday's box is open").toBe(true)
    expect(dayWarnHTML(6)).toContain('Breaks Monday')
    view.selectPerson('bane', true)   // second tap clears, leaving no focus behind
    ;(DAYS[6] as any).dutywaves[0].rows.pop()
    validate()
  })
})
