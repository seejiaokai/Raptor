/* The Logic tab's rule book — lgRules verbatim. Every value is read out
   of the live engine objects at render time, so the page cannot drift. */
import { VCONF, SHIFT_HARD, kindOff, ruleFmt } from '../engine/rules'
import { RANK, CHIP_LABEL, WCODE, chipText, wlbl } from '../engine/validate'
import { INPUT_TYPES, inpMeta, canSpare, isLeave, isDownchit, shiftHardInput, inputRuleText } from '../engine/inputs'
import { lgT, hm24, hhmm } from '../engine/time'
import { WAVE_BUILTIN, kindNote } from '../engine/wavetpl'
import { esc } from '../state/view'
import { lgCanEdit } from '../state/auth'

export const LG_TIER:any={hard:'Warning',adv:'Advisory',note:'Note',set:'Setting'};
export const lgV=(v:any)=>`<span class="val">${esc(String(v))}</span>`;
export function lgRules(){
  const SH=Object.keys(SHIFT_HARD).filter((k:any)=>SHIFT_HARD[k]);
  /* every event kind the engine actually produces — 'other' is the push() default
     and no call site uses it, so it is deliberately not listed */
  const KIND:any={fly:'a flight',sim:'a sim',duty:'a duty post',shift:'another shift',
    ground:'a ground event',prog:'a programme item'};
  const chipRow=()=>`<span class="lgchips">`+Object.keys(RANK).sort((a:any,b:any)=>RANK[b]-RANK[a])
    .map((c:any)=>`<span class="lgc"><i style="background:${
      /* red = the rule is HARD. This list used to carry NB/SB (advisories) and
         to omit RUN (a warning), so it disagreed with the week's own legend
         about the 7 — owner, 10 Aug 26. Keep it in step with html.ts. */
      c==='C'||c==='CR'||c==='Q'||c==='RUN'||c==='CPH'?'#F0555F;color:#fff':
      c==='LD'?'#8A96A3;color:#0B0D10':'#E5A83B'}">${esc(chipText(c))}</i>${esc(wlbl(CHIP_LABEL[c]||c))}</span>`).join('')+`</span>`;
  const matrix=()=>`<span class="lgmatrix">`+Object.keys(KIND).map((k:any)=>{
    const hard=!!SHIFT_HARD[k], off=kindOff(k);
    const body=lgCanEdit()
      ? `<label class="lgtog"><input type="checkbox" data-lgkind="${k}"${hard?' checked':''}>`
        +`${hard?'Warning':'Advisory'}</label>`
      : `<span>${hard?'Warning — he cannot be in two places':'Advisory — you can still give him academics'}</span>`;
    return `<span class="lgcell ${hard?'hard':'adv'}"><span class="k">${esc(KIND[k])}</span>`
      +body+(off?`<span class="lgmod">changed</span>`:'')+`</span>`;}).join('')+`</span>`;
  /* Every absence type the squadron books, and what each one costs. Built off
     INPUT_META (10 Aug 26) rather than the old three-entry LEAVE_TYPES, and
     the cell's severity follows canSpare — so this matrix cannot describe a
     rule the engine does not apply, and a new type appears here the day it is
     added to the table. The cost sentence itself is inputRuleText — the SAME
     source the Inputs "?" legend reads, so the two can no longer drift; a guard
     test pins both. (The two used to hand-write their own copies: this matrix
     had no SANS / Upchit line, the Inputs gloss no SC-MAIN Warning nuance.) */
  const rule=(t:any)=>inputRuleText(t);
  /* a code only earns a spelt-out name when it IS an abbreviation — "Training
     — training" says nothing twice. Same test offWord and the Inputs page's
     type legend make. */
  const tname=(t:any)=>{const n=((inpMeta(t)||{}).name)||'';
    return n.toLowerCase()===String(t).toLowerCase()?'':n+' — ';};
  const leaves=()=>`<span class="lgmatrix">`+INPUT_TYPES.map((k:any)=>
    `<span class="lgcell ${canSpare(k)?'adv':'hard'}"><span class="k">${esc(k)}</span>`
    +`<span>${esc(tname(k))}${esc(rule(k))}</span></span>`).join('')+`</span>`;

  return [
  {g:'How a day is measured',
   sub:'Before any rule can fire, the engine has to decide how much of the day each commitment actually occupies.',
   rows:[
    {sev:'set',set:['step','dekit'],src:()=>`VCONF.step ${VCONF.step} · VCONF.dekit ${VCONF.dekit}`,
     t:()=>`A sortie occupies the schedule from <b>step</b>, ${lgV(lgT(VCONF.step))} before take-off, to <b>dekit</b>, ${lgV(lgT(VCONF.dekit))} after landing — not just take-off to landing.`},
    {sev:'set',set:['briefLead'],src:()=>`VCONF.briefLead ${VCONF.briefLead}`,
     t:()=>`The <b>flight brief</b> is the time in the line's <b>B</b> box. Where a line has none, this setting suggests one — ${lgV(lgT(VCONF.briefLead))} before take-off — and the scheduler accepts it or types their own.<span class="why">This number is a convenience, not a rule: it only works out the suggestion so nobody has to do the arithmetic. What every brief warning actually follows is the B on the line. A line left blank is still checked, against that same suggested time, so an unconfirmed line never goes silently unchecked. A published in-time moves the man's <b>report</b> time, and so his working day and his crew rest; it does not move the brief.</span>`},
    {sev:'set',set:['reportLead','reportText'],src:()=>`VCONF.reportLead ${VCONF.reportLead} · VCONF.reportText ${VCONF.reportText}`,
     t:()=>`The <b>nominal report</b> to the squadron is ${lgV(lgT(VCONF.reportLead))} before take-off. The <b>+ In-time / Rally</b> button uses this lead when the wave has no resolved report, followed by the words below.<span class="why">Words are one line, up to 60 characters; blank restores IN TIME + WX/NOTAMS. The normal reporting parser reads them. If you include another clock in the words, the first clock — the time the button fills in — wins.</span>`},
    /* the SAME step key as the busy-window row above — one knob, quoted and
       editable on both rows it governs (owner, 21 Aug 26: editing the step
       timing must move this line too; the separate showLead key it replaced
       is gone) */
    {sev:'set',set:['step'],src:()=>`VCONF.step ${VCONF.step}`,
     t:()=>`<b>Step</b>, ${lgV(lgT(VCONF.step))} before take-off, is also the line that decides how a crew-rest breach is DRAWN — it is the same step setting as above, so changing it moves both.<span class="why">A remark such as "2A: LATE SHOW" or "SHOW AT BRIEF" does not excuse crew rest and does not remove the warning: the breach is still red and still counted, because the reader has to see that rest was broken. What the remark changes is the ring. While the man still clears rest by step, his puck rings <b>dashed</b> — a scheduler sanctioned this and he does make the jet. Once rest runs past step the ring goes <b>solid</b> again: there is nothing to sanction, because he cannot walk, kit up and start engines in less than this. He is not late to the brief, he is unable to make the flight.</span>`},
    {sev:'set',set:['debrief'],src:()=>`VCONF.debrief ${VCONF.debrief}`,
     t:()=>`The <b>flight debrief</b> runs for ${lgV(lgT(VCONF.debrief))} after landing.`},
    {sev:'set',set:['minTurn','dur'],src:()=>`VCONF.minTurn ${VCONF.minTurn} · VCONF.dur ${VCONF.dur}`,
     t:()=>`<b>Not currently used:</b> <span class="val">minTurn</span> and <span class="val">dur</span> are carried in the settings but no rule reads them.<span class="why">Listed so the page accounts for every setting in the engine, used or not.</span>`},
    {sev:'set',set:['openEnd'],src:()=>`VCONF.openEnd ${VCONF.openEnd}`,
     t:()=>`A row with a start time and <b>no end time</b> is assumed to run ${lgV(lgT(VCONF.openEnd))}.<span class="why">Without this an open-ended meeting sitting on top of a take-off went completely unflagged.</span>`},
    {sev:'set',src:()=>`collectEvents · shiftLine`,
     t:()=>`A <b>standby shift</b> (SC, AVALON, BB) occupies <b>exactly the hours written on the line</b> — no step, no dekit, no brief, no debrief tail.<span class="why">It is a shift, not a sortie. Padding it like a jet used to make SC AM 07–13 and SC PM 13–19 overlap by fifty minutes and report two clean shifts as one fifteen-hour day.</span>`},
    {sev:'set',src:()=>`win() · e<st → e+=1440`,
     t:()=>`Anything whose end reads <b>earlier than its start</b> has crossed midnight, and is rolled into the next day.<span class="why">Left as written, the interval is inverted and can never overlap anything — which silently switches every check off for that row.</span>`},
   ]},

  {g:'In-time / Rally',
   sub:'Reporting instructions apply to the named formations in their wave, or the whole wave when none is named.',
   rows:[
    {sev:'set',t:()=>`Each line uses its <b>first recognised clock</b>, such as 09:00H or 0900. Write <b>IN TIME</b>, <b>RALLY</b>, or both; an older clock-only instruction still means in-time. Remarks can stay on the line. Only this wave's formation names select crews; individual names do not. A formation-specific instruction replaces the wave-wide instruction for that activity. Duplicates use the earliest actual time, regardless of row order.`},
    {sev:'set',t:()=>`For a flight, a reporting clock later than take-off means <b>the immediately previous day</b>. The earliest applicable in-time or rally starts the crew's reporting day; an earlier qualifying commitment can still start work or rest checks. <b>RALLY AFTER IN TIME</b>, without a clock, means rally at that formation's applicable in-time.`},
    {sev:'hard',code:'REPORT_ORDER',t:()=>`Present stages must run <b>in-time → rally → brief → take-off → landing</b>. Equal adjacent times are allowed. A reversed pair names the formation and both times while editing; a blank B is named as the suggested brief. It remains a <b>red warning</b> in the draft and issued copy. Timing warnings never refuse publication or amendments. Missing reporting instructions do not create a compulsory field.`},
    {sev:'adv',code:'REPORT_UNRESOLVED',t:()=>`An unrecognised reporting clock, or <b>RALLY AFTER IN TIME</b> with no applicable in-time, asks you to check the instruction. This advisory alone does not block publication; it does not pretend that an unresolved clock was understood.`},
   ]},

  {g:'Two things at once',
   sub:'The commonest question the board answers: is this person already busy?',
   rows:[
    {sev:'set',src:()=>`const overlap=(a1:any,a2:any,b1:any,b2:any)=>a1<b2&&b1<a2`,
     t:()=>`Two windows overlap only if one <b>starts before the other ends</b>. Touching end-to-end is <b>not</b> an overlap.<span class="why">This is deliberate, and it is what makes SC AM 07:00–13:00 and SC PM 13:00–19:00 read as two clean shifts rather than a clash.</span>`},
    {sev:'hard',code:'DOUBLE_BOOK',
     t:()=>`Two commitments at the same time for one person is a <b>Warning</b> — he cannot be in two places.<span class="why">Sortie against sortie is excluded here: that is the tight-turn rule's business, not this one.</span>`},
    {sev:'adv',code:'SHIFT_SOFT',extra:matrix,kinds:true,
     t:()=>`A man on an <b>SC MAIN</b> shift is graded by what he runs into — ${SH.length} kinds are hard, the rest are advisory:<span class="why">With one overlay (26 Aug 26): a personal-input commitment across the shift is graded by its TYPE — ${INPUT_TYPES.filter(shiftHardInput).join(', ')} are a <b>Warning</b>, because the shift may launch him; a Meeting stays an <b>Advisory</b>. A type the engine does not recognise — a typo, or a record from an older store — reads as the <b>Warning</b> too, never the advisory: when in doubt the engine assumes the serious case. A ground row carrying one of those words — lifted from an input or typed by hand — grades as the commitment it is, not as academics. A programme item always stays advisory.</span>`},
    {sev:'set',src:()=>`isPersonal / isUnavail`,
     t:()=>`Every personal input is a <b>real commitment</b>, <b>“Fly”</b> included — it clashes with a sortie and eats brief/debrief time exactly like an appointment.<span class="why">There used to be an “offer” exemption for “Available fly”, “Available duty” and “Fly”. Those first two types are gone, and a man who says he is flying elsewhere is not available for this sortie.</span>`},
    /* no `code`: ⓘ is a per-item switch, not a validator code — the engine
       emits nothing for an info item, which is the whole point */
    {sev:'note',src:()=>`row.info · events.ts / avail.ts / oil.ts`,
     t:()=>`A Ground or Common Programme item marked <b>ⓘ info only</b> is shown on the programme but <b>never checked</b>: it raises no clash, occupies nobody's time, keeps nobody busy in the crew palette and earns no OIL.<span class="why">For the mass brief or all-call that overlaps everything on purpose: the squadron still wants it printed, but an engine ringing over it would teach everyone to ignore the bell. The crew picker stands down too — arming an info item bars no one, so the picker and the warning list stay in step. Flip the ⓘ on the item's row on the scheduler board; flip it again and the checks return.</span>`},
   ]},

  {g:'Crew rest',
   sub:'The rule the squadron cares about most, and the one with the most edge cases.',
   rows:[
    {sev:'hard',code:'CREW_REST',set:['crewRest'],src:()=>`VCONF.crewRest ${VCONF.crewRest}`,
     t:()=>`Aircrew flying today must have ${lgV(lgT(VCONF.crewRest))} clear before <b>the first thing on their programme</b> — the report, or anything scheduled earlier: a meeting, a sim, a duty post, or a duty-and-commitments input with typed times.<span class="why">The owner's rule (21 Aug 26): this person needs ${lgT(VCONF.crewRest)} of rest in order to fly. An 08:00 meeting ahead of a 10:00 in-time is what starts his day, so it is what the warning measures to and names — whether it sits on the Ground Programme or came in as an input. Monday checks against the previous week's Sunday, not against nothing — a late Sunday finish can still bust a Monday report. Planning that late Sunday draws the same “Breaks Monday” box on Sunday itself the moment you make it (23 Aug 26) — the breach warning itself still only appears on Monday once next week is opened. A day with no flying asks for no rest. Exactly ${lgT(VCONF.crewRest)} is legal — the bar is strictly greater-than.</span>`},
    /* set:['reportLead'] — the owner circled this exact row asking "is this
       editable as well? The number?" (21 Aug 26). The 3h IS reportLead,
       already editable further up under "The clock a day runs on"; the box
       now also sits where the number is quoted, so he never has to know
       which row owns it. Editing either box moves the same setting. */
    {sev:'adv',code:'CREW_TIGHT',set:['reportLead'],
     t:()=>`If the <b>nominal</b> ${lgT(VCONF.reportLead)} report falls inside the rest window but the instructed report does not, that is an <b>Advisory</b>, not a breach.`},
    {sev:'set',src:()=>`prevFlyEnd → REST[di]`,
     t:()=>`Rest is measured off the last commitment of <b>any kind</b> the day before — a sortie, a shift, a duty post, a sim, a ground event, a programme item, or a <b>duty-and-commitments input</b> all count.<span class="why">A sortie ends for rest purposes at landing + the debrief; everything else ends at its written end, with no tail added. This is the owner's 21 Aug 26 ruling: anything that ends the day prior and eats into the ${lgT(VCONF.crewRest)} is a warning, whatever kind of row it was. For inputs the same ruling names its own limits: only the Duty &amp; other commitments types except <b>Personal</b> and <b>SANS Availability</b> — leave and medical never count — and only when the input carries <b>typed times</b>; an all-day record has no timing to measure to.</span>`},
    {sev:'set',src:()=>`nomOf · insOf`,
     t:()=>`A shift's <b>own start time is its report time</b>: no ${lgT(VCONF.reportLead)} lead and no brief lead come off it.`},
    {sev:'set',src:()=>`saExempt · scSpare`,
     t:()=>`An <b>SC SPARE</b> carries no crew rest in either direction — standing spare buys none for the next day, and it never closes a spare slot to anyone.`},
   ]},

  {g:'Turning and the length of the day',
   rows:[
    {sev:'adv',code:'TURN',set:['tightTurn'],src:()=>`VCONF.tightTurn ${VCONF.tightTurn}`,
     t:()=>`Landing to the next take-off needs the <b>tight turn threshold</b>, ${lgV(lgT(VCONF.tightTurn))}, or the time the ground actually takes — ${lgV(lgT(VCONF.dekit))} dekit plus ${lgV(lgT(VCONF.step))} step — whichever is longer. Right now that is ${lgV(lgT(Math.max(VCONF.tightTurn,VCONF.dekit+VCONF.step)))}. Less is a tight turn.`},
    {sev:'adv',code:'DT_SUM',
     t:()=>`<b>Double turning</b> — <b>two or more sorties in one day, flown one after the other</b> — raises one Advisory line at the head of the day naming everyone who is on it, matching the amber DT pucks. Double turning is routine and planned, not an error.<span class="why">There is no span test: a man on two sorties is double turning whether they are back to back or a whole day apart. How tight the gap is belongs to the tight-turn rule. And two seats on the same air time are not a double turn at all — that man is double-booked, the red conflict Warning speaks for him, and this line leaves him out.</span>`},
    {sev:'note',code:'LONGDAY',set:['longDay'],src:()=>`VCONF.longDay ${VCONF.longDay}`,
     t:()=>`More than ${lgV(lgT(VCONF.longDay))} on the books, first commitment to last, is a <b>long work day</b> — a grey note, not a warning.`},
    {sev:'hard',code:'DAYS_RUN',set:['maxRun'],src:()=>`VCONF.maxRun ${VCONF.maxRun}`,
     t:()=>`Nobody may be on the programme more than <span class="val">${VCONF.maxRun}</span> days in a row — a <b>break day</b> is due. It is counted across the week boundary — last week's tail carries in, reading what the app remembers of last week (including your own edits), not just what was originally planned — so a run that started before Monday still catches. The Warning lands on the day that breaks the limit, which is the day to clear.<span class="why">Every kind of tasking counts: a flight, a duty post, a sim, a ground item, a programme row. Leave and downchits are not tasking, so a day off resets the count.</span>`},
   ]},

  {g:'Briefs and debriefs',
   sub:'A man can be free at take-off and still have no time to prepare.',
   rows:[
    {sev:'adv',code:'NO_BRIEF',
     t:()=>`Anything sitting between the <b>brief time and take-off</b> means there is no time for the flight brief — an Advisory: the clash itself already carries the Warning; the eaten brief window is the advice on top of it.<span class="why">An event that finishes at or before the brief time is fine — a stand-down 08:30–09:00 against a 10:20 brief is no issue.</span>`},
    {sev:'adv',code:'DEBRIEF',
     t:()=>`Anything inside <b>landing + ${lgT(VCONF.debrief)}</b> costs the flight debrief. Bad, but not unflyable — an Advisory.`},
    {sev:'adv',code:'SIM_BRIEF',set:['epBrief'],src:()=>`VCONF.epBrief ${VCONF.epBrief}`,
     t:()=>`An EP profile on the OFT briefs ${lgV(lgT(VCONF.epBrief))} before the box — unless its remarks name a lead (<b>BRIEF 30 PRIOR</b>, <b>30 mins prior</b>), which wins for that line; the AMT carries its <b>own BRIEF row</b>, and that row's time is the hard line.`},
    {sev:'adv',code:'SIM_DEBRIEF',set:['simDebrief','amtDebrief'],src:()=>`VCONF.simDebrief ${VCONF.simDebrief} · VCONF.amtDebrief ${VCONF.amtDebrief}`,
     t:()=>`A sim debriefs for ${lgV(lgT(VCONF.simDebrief))} after the box. The AMT's debrief is its <b>DEBRIEF row's own start-to-end</b> when that row carries an end; left blank, it falls back to ${lgV(lgT(VCONF.amtDebrief))} after the debrief start.`},
    {sev:'set',set:['simLen'],src:()=>`VCONF.simLen ${VCONF.simLen}`,
     t:()=>`A sim row with a start and <b>no end time</b> is assumed to run ${lgV(lgT(VCONF.simLen))} — its own number, not the general ${lgT(VCONF.openEnd)} other open-ended rows get.<span class="why">A box slot is a fixed block, not a meeting: assuming the meeting length under-booked every unfinished sim row by half an hour. The validator and the crew picker read this same setting, so what one flags and what the other offers cannot drift. It was a hard-coded 90 until 21 Aug 26.</span>`},
   ]},

  {g:'Qualification and currency',
   rows:[
    {sev:'hard',code:'QUAL',
     t:()=>`<b>Seat rules.</b> A WSO cannot fly the front seat; <b>IW</b> is a WSO-only category and sits RCP only. The <b>rear seat is open to any pilot</b> — jet or sim, no instructor rating needed. A pilot <b>FI</b> follows the IP rules, a WSO FI the IW rules. The sim's front seat follows the same rule as the jet's.`},
    {sev:'hard',code:'ILLEGAL_CREW',
     t:()=>`<b>The combination matrix</b> (F-15 Table 1.5-2). An <b>OCU pilot</b> may not fly with a <b>CAT A–D WSO</b>, and an <b>OCU WSO</b> may not fly with a <b>CAT A–D pilot</b> — not authorised combinations, a Warning.<span class="why">An instructor in either seat clears the matrix: an instructor pilot (IP / IR / FI) flies with anyone, an instructor WSO with any front seat.</span>`},
    {sev:'adv',code:'CREW_SOLO',
     t:()=>`<b>OCU pilot with OCU WSO</b> is a <b>crew solo</b> — only allowed for sorties designated under the F-15 Basic Course Syllabus. An Advisory.`},
    {sev:'adv',code:'CO_APPROVAL',
     t:()=>`<b>D+C, C+D and D+D</b> (pilot + WSO) require <b>CO approval</b>. An Advisory.`},
    {sev:'adv',code:'OCU_NO_IP',
     t:()=>`An <b>OCU formation with no instructor</b> (IW / IP / IR / FI) in it raises an Advisory.`},
    {sev:'adv',code:'PAX_CREW',
     t:()=>`A <b>personnel (ground crew)</b> body in the <b>rear seat</b> — an incentive passenger — raises a <b>crew-pairing</b> Advisory: the ride is a non-standard pairing that needs approval. It reuses the <b>CP</b> flag.<span class="why">Ground crew hold no flying qualification and may ride a rear seat only. They carry just three checks — a conflict, a long working day and the seven-day run — plus this pairing advisory; every other flying rule (crew rest, the seat and combination rules, refuelling, SC currency) is off for them.</span>`},
    {sev:'hard',code:'NO_IR',
     t:()=>`An <b>IRT</b> — an instrument rating test — needs an <b>IR</b> (instrument rating examiner) in the crew. IRT in a formation's <b>mission</b> wants an IR anywhere in that formation; IRT in one aircraft's <b>remarks</b> wants the IR in that aircraft.`},
    {sev:'hard',code:'AAR_QUAL',
     t:()=>`Air-to-air refuelling currency is read <b>straight off the remarks</b>. A bare <b>AAR</b> is <b>night on a night wave</b>, day otherwise — writing <b>NAAR</b> or <b>DAAR</b> says it outright, whatever the wave.<span class="why">An <b>A:</b> tag means the front seat; a <b>B:</b> tag is ignored entirely — a WSO holds no AAR currency. <b>NO AAR / NO DAAR / NO NAAR</b> ask for nothing. Only the front seat is checked. The clock is out of this rule by the owner's call (21 Aug 26): a landing time used to tip a bare AAR to night after 19:00, and doesn't any more — the wave's own day/night setting is the whole answer.</span>`},
    {sev:'hard',code:'AAR_INSTR',
     t:()=>`A pilot who is <b>not</b> current may still fly a refuelling sortie as <b>training</b> — but only with someone cleared to <b>instruct</b> that AAR in the back seat. If the man behind him is an instructor pilot without the mark, the line is flagged on <b>him</b>.<span class="why">Being IP / IR / FI is not enough on its own: instructing AAR from the rear cockpit is a separate sign-off, recorded on the Quals page as an <b>I</b> in place of the tick on DAAR or NAAR. When the back seat holds the right mark for what the remarks ask, the front seat's own currency warning is <b>cleared</b> — a supervised training sortie is legal and should not read as a fault. With the back seat empty, holding a WSO, or holding a pilot who is not an instructor, nobody aboard can supervise and the front-seat warning stands instead.</span>`},
    {sev:'hard',code:'SC_QUAL',set:['scDayFrom','scDayTo'],
     src:()=>`VCONF.scDayFrom ${hhmm(VCONF.scDayFrom)} · VCONF.scDayTo ${hhmm(VCONF.scDayTo)}`,
     t:()=>`<b>SC DAY</b> covers a shift sitting wholly inside ${lgV(hhmm(VCONF.scDayFrom))}–${lgV(hhmm(VCONF.scDayTo))}. Anything reaching outside it needs <b>SC NIGHT</b>. A spare is checked for currency exactly like a main.`},
    {sev:'set',src:()=>`q.naar&&!q.daar · q.naar==='I'&&q.daar!=='I' · q.scNight&&!q.scDay`,
     t:()=>`Night currency is signed off <b>after</b> day currency, never before: <b>NAAR</b> cannot be held without DAAR, and <b>SC NIGHT</b> cannot be held without SC DAY. Removing the day one removes the night one with it. The <b>instructor mark</b> follows the same order one rung up — the NAAR <b>I</b> needs the DAAR <b>I</b> — but withdrawing the day mark only <b>demotes</b> the night one back to a plain tick: he is still night current, he is simply no longer cleared to teach it.`},
   ]},

  {g:'Leave, downchit and personal inputs',
   rows:[
    {sev:'set',extra:leaves,src:()=>`INPUT_META`,
     t:()=>`An absence is booked as one of ${lgV(INPUT_TYPES.length)} things. Every one of them closes the man for the hours it covers — flying, sims, duties and ground slots alike — from the moment it is typed. The one exception: an input a scheduler has <b>removed</b> from the Ground Programme sits in Personal Inputs and flags <b>nothing</b> until it is accepted back.<span class="why">Removing it is the scheduler saying it does not stand — a rejected request must not keep ringing warnings (owner, 26 Aug 26). Deleting the input entirely says the same thing louder.</span>`},
    {sev:'hard',code:'LEAVE_FLY',
     t:()=>`On leave but planned to fly, sit a sim, stand a duty or take a ground slot — a Warning, and the <b>reason</b> is printed with it.`},
    {sev:'hard',code:'DNIF_FLY',
     t:()=>`Medically down and planned anyway — a Warning. <b>HL</b>, <b>OML</b> and <b>ATT C</b> close everything, an SC spare included. <b>ATT B</b> is the exception: he may not fly, but a duty post, a sim seat or a ground slot is proper work for him and raises nothing.<span class="why">It is the only place the app separates “cannot fly” from “cannot come to work”. A man on ATT B is grounded, not absent.</span>`},
    {sev:'hard',code:'INPUT_FLY',
     t:()=>`Any other input clashing with a sortie, a sim, a duty or a ground slot — a course, a meeting, an appointment, overseas duty. Since 10 Aug 26 these count the moment they are typed; a scheduler no longer has to accept one first.`},
    {sev:'adv',code:'SANS_AVAIL',
     t:()=>`<b>SANS Availability</b> is the opposite of every type above — it says which events a SANS body <b>is</b> offering, Fly / AMT / OFT, and when. A SANS body planted into a flying seat, an OFT box or an AMT box <b>outside what a filed SANS Availability input offers</b> — the wrong event, or outside the stated time — raises an Advisory. It wears the amber <b>A</b> flag — the planned-against-what-was-filed chip (owner, 26 Aug 26; it launched on CP, but CP says a crew <i>pairing</i> needs approval, which is not this man's problem). A flying seat is judged from the crew's <b>in-time to landing + dekit</b> (owner, 26 Aug 26): the wave's published in-time — or a typed SC B — opens the window when it shows the crew earlier than the step; with no in-time published the window stays step to dekit, and a later in-time never narrows it. A sim box is judged at its own written hours.<span class="why">Filing <b>nothing</b> raises no Advisory here — only the palette's grey-out, printed the moment a slot is armed, and the same toast on planting anyway. This is deliberate: the demo week's SANS aircrew fly with no SANS Availability record filed at all, and turning a blank record into a persistent warning would flag every one of them for something nobody has asked them to file yet.</span>`},
    /* no `code`: this is a MARK, not a validator code — giving it one would
       put it in the fired-rules lookup and imply the engine emits it. */
    {sev:'note',set:['inputLead'],src:()=>`VCONF.inputLead ${VCONF.inputLead}`,
     t:()=>`A member's input is due <b>${lgV(ruleFmt('inputLead',VCONF.inputLead))}</b> before <b>its own week</b> starts. One last changed after that deadline is marked <b>LATE</b> wherever it appears — the week, the board, the Inputs page, and the view-only programme.<span class="why">The deadline runs with the input: it is the Monday of the week the input's own first day falls in, minus this setting, whatever week is on screen — so a leave for December filed in August is judged against December's deadline, not the week being viewed. The deadline day itself is still on time: at ${esc(ruleFmt('inputLead',VCONF.inputLead))} an input for the week of Mon 17 Aug is due by Mon 3 Aug, and one touched on the 4th is late. What is measured is the <b>last change</b>, not the first submission, so an input raised early and then amended after the deadline still reads late — the deadline exists so the week can be planned against something that has stopped moving. This is a <b>mark only</b>: it raises no warning, closes no slot and changes nothing the validator sees. <b>Downchits are exempt</b> — going DNIF is not a decision a man makes in advance, and marking the one input type that is always last-minute would only teach everyone to ignore the mark. Leave and detachments are <b>not</b> exempt: those are applied for, and applying late is the thing this is about.</span>`},
    /* wire 4 — a mark on Leave War, not a validator code (no `code` for the
       same reason inputLead above carries none) */
    {sev:'note',set:['oilFullMin'],src:()=>`VCONF.oilFullMin ${VCONF.oilFullMin} · engine/oil.ts`,
     t:()=>`<b>Work on a weekend or public holiday earns OIL</b>, credited automatically into Leave War when the day is <b>published</b>. ONE rule for everything: a person's worked hours for the day run START TO FINISH — from the first thing they do to the end of the last, gaps between events included, because they are still in squadron — over flying (report to landing plus debrief), sims, duty rows, the Ground and Common Programme and SC MAIN shifts. <b>${lgV(ruleFmt('oilFullMin',VCONF.oilFullMin))}</b> or more is a FULL day (FO, 1.0), under it a HALF (HO, 0.5), regardless of the time of day or the shift's shape.<span class="why">A public holiday is whatever Leave War says it is — the PH flag on the day, or an event word tagged <b>PH</b> (the seeded <b>PH</b> type). An <b>Off day</b> declared by management (the <b>Off day</b> event tag, grey down the column) earns nothing — it is given, not worked. An SC <b>spare</b> earns nothing (standing by at home), and <b>AVALON / BB</b> earn nothing at all, desks included. A row with no times written earns nothing either — the credit follows the timings as scheduled, and a guess would mint OIL from nothing. One start-to-finish measure per day means an hour can never earn twice and a day can never earn more than 1.0. An <b>ALL</b> or <b>ALL AVAIL</b> puck on a Common-Programme or Ground row credits everyone available for that event (aircrew, SANS excluded). A <b>Duty & commitments input</b> is never credited silently: the app asks its owner first, and the confirmed days count into the same start-to-finish day. The credit lands in Leave War as an FO (full) or HO (half) cell and moves the OIL balance there; if the schedule changes and the day is re-issued, the credit follows. It never overwrites a leave bid — that disagreement is raised on Leave War's clash strip for a human to resolve. Every credit — an earned day or one an admin gives — shows in Leave War's <b>OIL tracker</b> with its date and reason; a day of OIL taken spends the <b>oldest</b> credit first, and a credit lasts as long as the admin's OIL policy says (a number of days or months from its own date, or forever) before what is left of it expires.</span>`},
    /* the blind-desk warning (owner, 20 Sep 26) — the rule above says a row
       with no times earns nothing; this is the app finally SAYING so. */
    {sev:'hard',code:'OIL_NO_TIMES',
     t:()=>`On a <b>weekend or public holiday</b>, a duty desk with somebody on it and <b>no start and end times</b> earns him nothing — and the day says so, on the day itself and again at the moment it is published. The warning names the desk.<span class="why">OIL is minted strictly from the times written, so a blank desk measures nothing and mints nothing. That is correct — a guess would invent leave out of thin air — but it used to happen in silence: the day was published, no OIL appeared, and nothing said why. A man's leave balance was short and no screen admitted it. The warning sits on the day while it is being built because that is where the fix is free; after the publish, correcting it costs an amendment. A blank desk with nobody on it says nothing — an empty desk owes no one. On an ordinary weekday it says nothing either, since no weekday work earns OIL at all.</span>`},
    /* A DAY ISSUED BEFORE THESE SEATS COUNTED (owner, 22 Sep 26 — "ok fix this
       first"). Its sibling above is a row with no usable times; this one is a
       day whose ISSUED copy predates the app counting the people behind an
       ALL AVAIL puck on a duty desk, a sim or an extras line. It used to read
       "1 pending" with no cell marked and nothing in History, while the chip
       beside the puck said "?" — so the day asked for an amendment it could not
       explain. Caught by the guard that every code the engine can raise is
       documented here, which is exactly what that guard is for. */
    {sev:'adv',code:'OIL_OLD_BLOCK',
     t:()=>`A <b>weekend or public holiday you already published</b> can say it has <b>something pending</b> the first time this app counts a seat it did not count before — an <b>ALL AVAIL</b> puck on a <b>duty desk</b>, a <b>sim</b>, or an <b>extra people</b> line. Publish the day again and the men behind that puck get their OIL. An Advisory, and only on a day that has already gone out.<span class="why">The issued copy of a day is the squadron's word about what was worked, and it keeps crediting exactly what it credited — nothing moves on its own. But the men behind that puck earned nothing from that seat, because the app was not counting it when the day went out, and they should have. So the day raises the ordinary pending mark and waits for the scheduler to acknowledge it, which is what publishing again does. It says this in words rather than leaving a bare "1 pending" behind, because the copy that went out never wrote down who was behind the puck — so there is no cell to mark and nothing to show in History, and a scheduler would otherwise be republishing blind. One amendment per affected day, once.</span>`},
    /* the four OIL reminders on a weekend or holiday. They printed their internal code as their
       heading until the amendment re-test gave them plain ones ([HUMAN-RETEST] walk W4-F5,
       24 Sep 26) — which is what put them in front of the guard that every check is written up
       here. Each says what the day is waiting for; none changes what anyone earns. */
    {sev:'adv',code:'OIL_NO_PERIOD',
     t:()=>`A <b>weekend or public holiday</b> with work on it that <b>no Leave War period covers</b> can earn nobody any OIL — the credit has nowhere to land. The day names the missing year and offers to create the period, before and after it is published.<span class="why">Publishing does not fix it, so the day keeps saying so after it goes out; a day that read clean here would be the lie (owner, 22 Sep 26).</span>`},
    {sev:'adv',code:'OIL_UNPUBLISHED',
     t:()=>`A <b>weekend or public holiday</b> with somebody down to earn OIL that is <b>not published yet</b> earns nobody anything until it is — the day reminds the scheduler to publish it before the day is out. Silent on an ordinary weekday, on an empty weekend, and the moment the day goes out.`},
    {sev:'adv',code:'OIL_STALE_DAY',
     t:()=>`A day published as an ordinary working day that the Leave War <b>later calls a public holiday</b> keeps earning what it went out with — nothing — until it is <b>published again</b>. The day says so, and its pending count shows the difference.<span class="why">Only the issued schedule earns OIL, in both directions (owner, 21 Sep 26): the published record is what happened, so today's calendar never moves it on its own — but it must never do that silently.</span>`},
    {sev:'adv',code:'OIL_STALE_HOLIDAY',
     t:()=>`The mirror of the one above: a day published as a <b>holiday</b> that the Leave War <b>no longer calls one</b> keeps its OIL until it is <b>published again</b>, which withdraws it. The day says so.`},
    /* the nought-minute sortie (owner's ruling D49, 22 Sep 26). The rule above
       says the credit follows the timings as scheduled; this is the one place
       where a line's timings cannot be right and the man is paid anyway. */
    {sev:'adv',code:'FLT_NO_LEN',
     t:()=>`An ordinary <b>flying line</b> typed with the <b>same take-off and landing time</b> still earns the crew their OIL; a <b>standby shift</b> (SC, AVALON, BB) typed the same way earns nobody anything at all. Either way one of the two times is wrong and the day says so, on the line, on <b>any</b> day.<span class="why">The sortie itself measures nothing, so on the face of it nobody should earn from it. They do, and deliberately: a flying day runs from the report three hours before take-off to the debrief two hours after landing, and the crew did both. They were in squadron whatever the times say, which is the squadron's own fact rather than anything the times can show. So the line is never refused and no credit is taken away — the warning exists because a nought-minute sortie is always a slip of the keyboard, and it is cheaper to fix while the day is being built than after it has gone out. It names the line, not the crew: the times are the scheduler's to correct. A line that has no readable times at all is a different problem and carries the other warning — that one really does earn nobody anything. <b>A standby SHIFT is the other way round</b>: SC, AVALON and BB have no report and no debrief, so their window is the written window and one typed to the same minute earns nobody anything at all. The warning says so in those words on a shift, and the day names it — as a shift, not as a desk — in the same list as a desk with no usable times.</span>`},
    {sev:'set',src:()=>`canSpare · sparePost`,
     t:()=>`<b>Local keeps the man reachable</b>, so he may still be raised as an <b>SC SPARE</b> — standby is not a task, and it raises no flag. <b>Overseas cannot</b> (OL, OD), and <b>neither can any of the four medical codes</b>, HL, OML, ATT C and ATT B. Putting one of them on a spare line is a Warning.<span class="why">Standing spare means being reachable and fit to walk. Overseas he is not reachable; medically down he is not fit — which is why the medical codes are barred even though the man is on the island. Besides currency, the pilots-only front seat and not holding another SC seat in the same hours (see The standby lines), this is what IS checked on a spare line.</span>`},
    /* the half-days (owner, 10 Aug 26) */
    {sev:'note',src:()=>`inp.s · inp.e · slotStart · slotEnd`,
     t:()=>`Leave and medical absences can be booked <b>AM</b> (00:00–12:00), <b>PM</b> (12:01 onwards) or all day, and a half-day only closes its own half — a man on AM leave can still be planned for an afternoon wave.<span class="why">Each slot is judged against its own hours, and a sortie's hours run from the <b>step</b>, not the take-off. So a morning absence does not free a wave that starts walking before noon: Monday's first VL takes off 12:40 and steps at 11:40, which is still the morning. A row with no times on it at all is treated as covering the whole day rather than none of it — an unknown never clears an absence.</span>`},
   ]},

  /* WAVE TYPES — the one-line summary of each "+ Wave" kind, rendered from the
     SAME engine/wavetpl.ts kindNote the template editor prints under its kind
     picker, so the picker and this page can never show different words (owner,
     30 Aug 26 — "make sure these word summaries are updated when I change the
     rules concerning them … and the logic page should be updated as well").
     kindNote is the ONE source of the one-liner; the per-kind DETAIL is "The
     standby lines" group just below (and the flying-wave rules above). When a
     kind's CHECKING rule changes in validate.ts / events.ts, update all three in
     step: the rule, kindNote (both the picker and the row here follow it), and
     the matching detail row below. logic.test.tsx pins that every kind's kindNote
     shows on this page, so a dropped wire fails a gate rather than drifting. */
  {g:'Wave types at a glance',
   sub:'The same one-line summary shown under each type in the “+ Wave” template editor. The detailed rules for each follow below.',
   rows:WAVE_BUILTIN.map((b:any)=>({sev:'note',src:()=>`kindNote('${b.key}')`,
     t:()=>`<b>${esc(b.label)}</b> — ${esc(kindNote(b.key))}`})),
  },

  {g:'The standby lines',
   /* the DETAILED per-kind rules; the one-line summaries are the "Wave types at a
      glance" group above, sourced from engine/wavetpl.ts kindNote. Keep both, plus
      the rule in validate.ts / events.ts, in step when a kind's checking changes. */
   sub:'SC, AVALON and BB sit outside the day’s flying count — and mostly outside the engine.',
   rows:[
    {sev:'set',src:()=>`saExempt · isStandalone`,
     t:()=>`An <b>SC MAIN</b> line is fully cross-checked, at the hours written on it.`},
    {sev:'adv',code:'SC_INTIME',
     t:()=>`A typed <b>B</b> on an SC line is that crew's <b>in-time</b>, not a brief. On a <b>MAIN</b> it starts the crew-rest clock and the duty-hours day, and anything that cuts into — or ends inside — the window between the B and the shift start draws this advisory. A <b>SPARE</b> reports nowhere, so his B does nothing.<span class="why">The hard rules stay on the shift's own hours: a commitment before the shift start has not double-booked the shift yet, which is why the window reads amber rather than red — and something crossing the start itself is the conflict rule's business, said once, not twice.</span>`},
    {sev:'set',src:()=>`scSpare`,
     t:()=>`An <b>SC SPARE</b> is standing by, not tasked: he is checked for <b>currency</b>, for being <b>able to stand it at all</b>, for the <b>front seat</b> — a WSO may not hold a spare front seat — and for <b>not holding another SC seat, or the SC desk, in the same hours</b>. Nothing else: he may fly, sit a sim or stand an ordinary duty in the same hours and none of it raises anything; but an overseas leave or a downchit across the shift does, and so does another SC seat — MAIN or SPARE — or an SC duty desk whose hours overlap his.<span class="why">Overlap means genuinely shared minutes: SC AM 07:00–13:00 into SC PM 13:00–19:00 touch only at 13:00 and stay two clean shifts a man may hold back to back (owner, 31 Aug 26). The SC desk is the duty block whose template is marked <b>SC</b> (owner, 7 Sep 26); a MAIN on that desk is the ordinary conflict. The crew picker refuses the second seat with the same rule the warning uses, so the two never disagree. The rear spare seat carries no seat rule — offered and declined the same day.</span>`},
    {sev:'set',src:()=>`w.noconf`,
     t:()=>`<b>AVALON</b> and <b>BB</b> are exempt from every cross-check against the day's tasks, rest and briefs, and carry four rules of their own — the two are twins (owner, 7 Sep 26), BB's only difference being that its hours are typed rather than fixed, and a BB line left with blank hours is checked for nothing. Every man on it, jet seat or desk, must be <b>on the island</b> and <b>not medically down</b> — overseas leave, overseas duty, hospitalisation, medical leave or ATT C anywhere on the line, and ATT B on a jet seat too, though he may still man the desk. Every seat, MAIN or SPARE, needs <b>SC currency</b> for its hours — SC NIGHT on AVALON's 19:00–07:00, SC DAY on a BB shift typed inside the day. The <b>front seat is pilots-only</b>, MAIN or SPARE — a WSO there is an illegal seat. And <b>nobody holds a seat and another place in the same hours</b> — MAIN and SPARE, a seat and the desk, an AVALON seat and a BB seat; two desk roles on one man are allowed. The AVALON or BB desk is the duty block whose template is marked <b>AVALON</b> or <b>BB</b>; it earns no OIL on a weekend or holiday, and neither does a seat.<span class="why">Local leave, an off in lieu, a course or an appointment plants him with nothing raised — the point of the rule is that standing AVALON is not the same as being cross-checked against the day's tasks (owner, 11 Aug 26; the three seat rules 7 Sep 26). And the shift runs 19:00–07:00, so its morning half is judged against <b>tomorrow's</b> inputs, the same way a night sortie landing after midnight is. A man on AVALON tonight and a sortie tomorrow morning is not a rule — nothing on AVALON is an event.</span>`},
    {sev:'set',src:()=>`slotBar · dayEvents`,
     t:()=>`When an SC slot is armed, the crew picker judges each name against <b>that shift's own window</b>, not the whole day — so a man on SC AM is offered normally for SC PM.`},
   ]},

  {g:'What the puck shows',
   sub:'One puck can carry several problems at once. It prints the most serious.',
   rows:[
    {sev:'set',extra:chipRow,src:()=>`RANK`,
     t:()=>`Flag priority, most serious first:`},
    {sev:'set',src:()=>`cls.push('boxred')`,
     t:()=>`A <b>red box</b> round the whole puck marks a conflict, a crew-rest breach, a qualification problem or a missed brief. The amber flags do not draw one.`},
    {sev:'set',src:()=>`markRing · SEVR`,
     t:()=>`The ring round a puck takes the <b>most serious</b> tier that person carries that day: red beats amber beats grey.`},
   ]},

  {g:'Publishing and amendments',
   rows:[
    {sev:'set',src:()=>`daySigned · signMissing`,
     t:()=>`A day needs all four sign-offs — <b>CUR CK, SKED CK, PLANNED BY, APPROVED BY</b> — before it can be published. Only crew holding the <b>Scheduler</b> qualification appear in the last three.`},
    {sev:'set',src:()=>`signClear(di)`,
     t:()=>`Publishing a day <b>spends its signatures</b>. The next amendment on that day is signed for on its own merits.`},
    {sev:'set',src:()=>`publishALDay · alIssue`,
     t:()=>`An <b>AL</b> is published from the day it belongs to, and takes <b>only that day's</b> unpublished edits. Other days keep theirs.`},
    {sev:'set',src:()=>`publishableKeys`,
     t:()=>`Only edits on a <b>published</b> day can go out as an amendment — an AL never claims to amend something that was never issued.`},
   ]},
  ];
}
