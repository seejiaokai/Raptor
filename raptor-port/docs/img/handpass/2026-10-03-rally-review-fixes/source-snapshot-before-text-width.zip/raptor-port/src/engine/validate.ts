import { PEOPLE, isSpecial, realP, whoId, isOcu, isInstr, isInstrPilot, aarOK, aarInstrOK, scShiftKind, scQualOK } from './people'
import { isDownchit, isLeave, isUnavail, canSpare, canWork, shiftHardInput, restsInput, inpLabel, inpMeta, withFrozenInputs } from './inputs'
import { VCONF, SHIFT_HARD } from './rules'
import { overlap, hm24, lgT, parseHM } from './time'
import { collectEvents, shiftEvHard, scSeatHits, avSeatHits } from './events'
import { reportingIssuesForDay,stated } from './reporting'
import { HOOKS } from './hooks'
import { sansGate, SANS_LABEL } from './avail'
import { seedRunIn, datedRestSeed, dayHidesIn, nextMondayWorked, nextMondayHides, windowDiverges, windowFiling, windowInputs, filingDivergesAt } from './weekctx'
import { setWorld, setFiling, clearFiling } from './world'
import { CURWEEK, isStandalone } from './waves'
import { DAYS } from './data'
import { dayOilBlind, blindDesks } from './oil'
import { oilWouldEarn, oilOldBlockCrowd, oilEvidenceOf } from './oilev'
import { keyDay, seatRow } from './keys'
import { rowPlaces } from './slots'
import { SCHED, approvedDays, dayApproved, dayDelta, dayDeltaCore, dayCurVer, daySnapOf } from './publish'
import { hideKey, shownWarns } from './warnhide'
import { rosterIds } from './faceattrs'

/* the reference guards its header counters with $() lookups; the engine takes
   $ from the hooks (null outside a browser) so the guarded lines stay verbatim */
const $=(id:any)=>HOOKS.$(id);
export const WCODE:any={DOUBLE_BOOK:'Conflict — two events at once',DNIF_FLY:'Downchit + flying',LEAVE_FLY:'On leave + flying',INPUT_FLY:'Personal input clash',
  TURN:'Tight turn',ILLEGAL_CREW:'Illegal aircrew combination',CREW_SOLO:'Crew solo — only allowed under syllabus',CO_APPROVAL:'Crew combination — CO approval required',OCU_NO_IP:'OCU without IP',CREW_REST:'Crew rest (<{crewRest})',QUAL:'Qualification — illegal seat',
  NO_BRIEF:'No time for the flight brief',DEBRIEF:'No time for the flight debrief',SIM_BRIEF:'No time for the sim brief',SIM_DEBRIEF:'No time for the sim debrief',
  CREW_TIGHT:'Tight turning — crew rest',LONGDAY:'Long work day',DT_SUM:'Double turning',
  DAYS_RUN:'No break day — too many days in a row',
  SC_QUAL:'SC currency — wrong shift',AAR_QUAL:'AAR currency — not qualified',AAR_INSTR:'AAR — back seat not cleared to instruct',NO_IR:'IRT without an IR examiner',
  PAX_CREW:'Incentive passenger — crew pairing needs approval',
  SHIFT_SOFT:'On shift — also down for a ground event',
  SC_INTIME:'In-time window cut — busy between report and shift start',
  SANS_AVAIL:'SANS availability — planned outside the availability filed',
  OIL_NO_TIMES:'No OIL earned — a row has no usable times',
  FLT_NO_LEN:'Flight times — take-off and landing are the same',
  REPORT_ORDER:'In-time / Rally — timings out of order',
  REPORT_UNRESOLVED:'In-time / Rally — check the reporting instruction',
  OIL_OLD_BLOCK:'Published before these seats counted — republish to credit them',
  /* the four OIL advisories printed their CODE as the heading ("OIL_UNPUBLISHED — …") —
     [HUMAN-RETEST] amendment re-test, walk W4-F5, 24 Sep 26; pinned in ui/amendretest.test.tsx */
  OIL_NO_PERIOD:'No OIL — no Leave War period covers this date',
  OIL_UNPUBLISHED:'OIL waiting — this day is not published',
  OIL_STALE_DAY:'Became a holiday after publishing — republish for its OIL',
  OIL_STALE_HOLIDAY:'No longer a holiday — republish to withdraw its OIL'};
/* what a flag PRINTS on the puck. The internal codes stay as they are — they
   key the colours, the ranking and the tooltips — but the squadron reads these
   at 9px on a phone, so the glyphs are short: R for crew rest, B for either
   brief, D for either debrief, L for a long day. */
export const CHIP_TEXT:any={DT:'DT',TT:'TT',C:'C',A:'A',Q:'Q',CR:'R',RUN:'7',NB:'B',SB:'B',DB:'D',SD:'D',LD:'L',CP:'CP',CPH:'CP'};
export const chipText=(c:any)=>CHIP_TEXT[c]||c;
/* Which flag a puck shows when a person has more than one on the day. Highest
   wins. Order set by the squadron: qual → conflict → crew rest → no flight brief
   → no flight debrief → no sim brief → no sim debrief → advisory → tight turn →
   double turn → long work day. Module scope, not inside validate(), so the Logic
   tab can print the real ordering rather than a second copy of it.

   CP / CPH are crew pairing (renamed from CC, owner ask 5 Aug 26) — the
   pairing rules, which used to ring the puck and caption nothing. They are TWO
   codes rather than one because a chip carries no severity of its own: CP is
   the advisory colour and CPH the hard one, and both PRINT `CP`, so the
   squadron reads one flag while the engine keeps the two apart. Both are
   INSERTED into the squadron's order rather than reshuffling it: CP leads the
   advisories, CPH sits below the conflict flag, because a man booked into two
   places at once is a harder stop than a pairing that wants a signature.
   Everything that outranked everything else before still does. Adding a code
   here without adding it to RANK would half-work: markChip's first write
   lands (there is nothing to beat) and every later one loses to `undefined`,
   silently freezing the flag. */
export const RANK:any={LD:0,DT:1,TT:2,A:3,SD:4,SB:5,DB:6,NB:7,CP:8,CR:9,RUN:10,CPH:11,C:12,Q:13};
export const CHIP_LABEL:any={DT:'Double turn',TT:'Tight turn',C:'Conflict (two events at once)',
  A:'Advisory — on shift and also down for a ground event or programme item, or planned outside SANS availability',CR:'Crew rest breach (<{crewRest})',Q:'Qualification — illegal seat',
  NB:'No time for the flight brief',DB:'No time for the flight debrief',SB:'No time for the sim brief',SD:'No time for the sim debrief',LD:'Long work day (>{longDay})',
  RUN:'No break day — too many days on the programme in a row',
  CP:'Crew pairing — this pairing needs approval',CPH:'Crew pairing — not an authorised pairing'};
export const SEVWORD:any={hard:'Warning',adv:'Advisory',note:'Note'};
/* ring precedence: red beats orange beats grey, so a person carrying both a
   long day and a conflict still shows the conflict ring. (Module-level since 26 Sep 26 so the published face — faceWarn —
   combines a frozen ring with a live one by the same order the day loop does.) */
const SEVR:any={note:1,adv:2,hard:3};
export const restTraceEntries=(t:any)=>t?.crs||(t?.leaveBy!=null?[t]:[]);
/* The earliest target remains the compatible puck address; additional
   targets survive independently, including after hide replay. */
function mergeRestTrace(prior:any,addition:any){
  if(addition.leaveBy==null)return {...prior,...addition};
  const entries=restTraceEntries(prior).map((t:any)=>{const {run,crs,...entry}=t;return entry;});
  const key=(t:any)=>`${t.targetWeek||''}|${t.targetDi??t.di}|${t.msg}`;
  if(!entries.some((t:any)=>key(t)===key(addition)))entries.push({...addition});
  if(entries.length===1)return {...prior,...entries[0]};
  return {...prior,...entries[0],crs:entries};
}
/* THE WARNINGS A PUBLISHED FACE KEEPS LIVE ([LEAVE-LATE-PUBLISHED] — every other warning shows as issued, D179):
   · the Leave War's "no period covers this date" (Fable F5 — D179 leaves the war's reminders live, D19), and every other
     OIL warning — they speak from what the day earns under TODAY's calendar ("started earning", "stopped being a
     holiday", "published before the app counted", "a row has no usable times — nobody on it earns"), and on a published
     day that moves only when the war declares or lifts a holiday, which the OIL line already reads pending (Fable's code
     read F3, 26 Sep 26; owner D2, "the day says so"): compared too, one holiday read two changes;
   · a crew-rest breach and the 7-day run on the day itself (owner, D184 and D185, 26 Sep 26 — "The 7 day warning as
     well"; "2 & 3 make it live": with D183's dotted mark, "to see the break of crew rest") — and the same check's other
     answer, "Tight turning — crew rest" (CREW_TIGHT): one crew-rest judgement answers a breach OR a tight turn, so a
     neighbour's change that turns one into the other must not leave a frozen tight turn beside a live breach, nor read
     pending for one answer and not the other (the agent's reading, on the look card);
   · a lapsed qualification (D185) — read as the warnings the app marks with its Qualification flag (Q): an illegal seat,
     SC currency, AAR currency and an AAR instructor not cleared. The crew-pairing warnings (CP / CPH — an OCU without an
     IP, no IR examiner, an unauthorised pairing) stay frozen — CONFIRMED by him, D188 ("Q6yes", 26 Sep 26), with the
     tight-turn note live beside the breach.
   Not stored with the published version and not compared, so they alone never make the day pending; each is drawn
   from the official pass — today's judgement of the issued day — with its rings and flags (the day loop files each
   mark under the class of the warning that raised it: `fz` / `lv` below). A medical downchit stays FROZEN (D185, "1
   frozen still"). */
export const LIVE_ON_FACE=new Set<string>(['OIL_NO_PERIOD','OIL_STALE_DAY','OIL_STALE_HOLIDAY','OIL_OLD_BLOCK','OIL_NO_TIMES','OIL_UNPUBLISHED',
  'CREW_REST','CREW_TIGHT','DAYS_RUN','QUAL','SC_QUAL','AAR_QUAL','AAR_INSTR']);
/* A label may quote a live threshold: {crewRest} prints whatever crew rest is
   set to right now. Without this an edited rule leaves stale numbers behind in
   tooltips and warning lists — the engine says 10h, the chip still says 12h. */
export const wlbl=(s:any)=>String(s==null?'':s).replace(/\{(\w+)\}/g,(m:any,k:any)=>k in VCONF?lgT(VCONF[k]):m);
export let WARN:any={all:[],byDay:[],sev:{},chip:{},dash:{},trace:{},fz:{sev:{},chip:{},dash:{}},lv:{sev:{},chip:{},dash:{}}};
/* THE RUN TABLES, published like REST/EVD for the pre-drop query (5 Sep 26):
   RUNLEN[di][id] = consecutive days on the programme through day di (only
   ids ON that day), RUNSEED[id] = the count walked in from before Monday,
   NEXTON = who is on next week's Monday, EVDAYS = the per-day accumulators
   the day loop ran over (fly/events/input/dow/di), PREVSUN/NEXTMON = the two
   phantom seeds. Reassigned by every validate() — re-read, never cache. */
export let RUNLEN:any[]=[], RUNSEED:any={}, NEXTON:Set<any>=new Set(), EVDAYS:any[]=[], PREVSUN:any=null, NEXTMON:any=null;
/* when crew rest expires today, per day index, per person — minutes into the
   day. Filled by validate(); read by the crew picker so an SC slot can be
   closed to anyone who is not yet clear of the previous day. */
export let REST:any={};
export function restClear(di:any,id:any){const m=REST[di]; const v=m&&m[id]; return v==null?null:v;}
/* every cross-checked commitment on a day, bucketed by person — published the
   same way REST is, so the crew picker can ask "is he busy at THIS hour" without
   running collectEvents() again for every name in the palette. SC SPARE lines
   are absent here exactly as they are absent from the engine. */
export let EVD:any={};
/* …and the day's SIM brief / debrief windows, published the same way ([CROWD-SIM-BRIEF], phase 7): events.ts builds
   them (`simwin` — one per OFT EP line, one for the AMT block, each naming the men on it) and until now only the
   warning pass below could read them, so the ALL AVAIL window could not ask whether an event sits inside a crowd
   man's own sim brief (crowdClashes). Reassigned by every validate(), like EVD — re-read, never cache. */
export let SIMW:any={};
/* ONE PERSON'S WORKING DAY, out of the events they are on that day — the ONE
   definition of it (extracted 20 Aug 26 for the Insights work-hours section;
   the long-work-day note below is its other reader).

   Report (the published in-time when the wave has one, else T/O − reportLead)
   through last landing + the debrief pad, or plain start→end for everything
   that is not flying. `ef` is the FLY event that set the END, null when a
   non-flying commitment did, so a caller can name the debrief pad baked into
   it. Null when the person has nothing with both a start and an end.

   It is a function rather than two copies for the reason
   docs/feature-impact.md §drift-seams exists: a week's total hours and the
   note that says a day is long have to mean the same thing, or one of them is
   lying. The body is the long-day block's own, moved unchanged. */
export function workSpan(evs:any){
  let s:any=null,e:any=null,ef:any=null;
  (evs||[]).forEach((o:any)=>{
    /* the published in-time IS the report time when there is one; only fall
       back to T/O − 3h when the wave published none. Taking the min() of the
       two discarded any in-time later than T/O − 3h and inflated the day —
       three of the four long-day notes on the seed Monday were wrong. */
    /* A SHIFT with a typed in-time is on duty FROM that in-time (owner, 24 Aug
       26 — "if B is filled earlier than TO for main only, include the long day
       duty hours span calculation"). An SC MAIN's report rides the event
       (events.ts), so the day starts at the earlier of it and the shift start —
       min() so a late B cannot shrink the day. Blank B leaves report equal to
       the shift start and this line byte-identical to the old `o.s`; spares
       never reach the event stream at all. */
    const os=o.kind==='fly'?(o.report!=null?o.report:o.to-VCONF.reportLead)
            :o.kind==='shift'&&o.report!=null?Math.min(o.report,o.s):o.s;
    const oe=o.kind==='fly'?o.ld+VCONF.debrief:o.e;
    if(os!=null&&(s==null||os<s))s=os;
    if(oe!=null&&(e==null||oe>e)){e=oe;ef=o.kind==='fly'?o:null;}
  });
  if(s==null||e==null)return null;
  return {s,e,span:e-s,ef};
}
export function dayEvents(di:any,id:any){const m=EVD[di]; return (m&&m[id])||[];}
/* THE TWO WINDOWS A FLYING LEG CLAIMS BEYOND ITS AIRBORNE TIME, and the words
   for each — ONE BODY, two readers. The warning list below reads them for a
   man's own commitments; [ALL-AVAIL-WINDOW] reads them for an event he stands
   behind a placeholder on (crowdClashes, next). Extracted 23 Sep 26 so the two
   can never disagree about what a debrief IS: if the pad or the wording ever
   changes, both change together. The numbers and the sentences are exactly the
   ones the loop used to build inline, so the warning list is byte-identical.

   Brief is the line's own brief time (the hard line, never T/O − 3h) to T/O;
   debrief is land to land + the debrief pad. Both amber (owner, 4 Aug 26). */
export const legBriefWin=(lg:any):[number,number]=>[lg.brief,lg.to]
export const legDebriefWin=(lg:any):[number,number]=>[lg.ld,lg.ld+VCONF.debrief]
export const noBriefSays=(lg:any,what:string)=>{const [bs,bt]=legBriefWin(lg)
  return `No time for the ${lg.label} flight brief — ${what} sits inside ${hm24(bs)}–${hm24(bt)} (brief ${hm24(bs)})`}
export const debriefSays=(lg:any,what:string)=>{const [ls,de]=legDebriefWin(lg)
  return `Not enough time to attend the ${lg.label} debrief — ${what} sits inside ${hm24(ls)}–${hm24(de)} (land + ${lgT(VCONF.debrief)})`}

/* THE SAME FOR A SIM ([CROWD-SIM-BRIEF], phase 7): the two sentences the pass below used to build inline, lifted so the
   ALL AVAIL window says them in the list's own words. `sw` is one of the day's sim windows (events.ts simwin). The
   warning list is byte-identical — the reference comparison (tfin.js 728/0) is the proof. */
export const simBriefSays=(sw:any,what:string)=>`No time for the ${sw.label} brief — ${what} sits inside ${hm24(sw.bs)}–${hm24(sw.be)}`
export const simDebriefSays=(sw:any,what:string)=>`No time for the ${sw.label} debrief — ${what} sits inside ${hm24(sw.ds)}–${hm24(sw.de)}`
/* does this sim window carry a brief / a debrief that measures anything — the pass's own two tests, one body */
export const simHasBrief=(sw:any)=>sw.bs!=null&&sw.be!=null&&sw.be>sw.bs
export const simHasDebrief=(sw:any)=>sw.ds!=null&&sw.de!=null&&sw.de>sw.ds

/** [ALL-AVAIL-WINDOW] — DOES AN EVENT HE STANDS BEHIND A PLACEHOLDER ON SIT
 *  INSIDE ONE OF HIS OWN FLYING LEGS' BRIEF OR DEBRIEF? (owner, D36 + D38.)
 *
 *  THE OWNER'S OWN EXAMPLE, and the reason the window exists: "click on his
 *  puck and know that the ops brief he's scheduled for as all avail is in
 *  between the standard debrief time". A man who lands at 15:00 is AVAILABLE
 *  from dekit (D36 keeps the availability window narrow, on purpose), so he is
 *  rightly in the crowd behind a 15:20 ops brief — and the app's job is to FLAG
 *  that the brief sits inside his 15:00–17:00 debrief, not to remove him.
 *
 *  WHY THE WARNING LIST CANNOT SAY IT ALREADY: the pass above deliberately
 *  skips placeholders (`!isSpecial`), because a placeholder is not a body on a
 *  seat and ringing it would be wrong. So a man who is only BEHIND one is never
 *  treated as being on that event, and this clash is raised nowhere. This asks
 *  the same rule about that one event, for that one man, without adding
 *  anything to the warning list — which stays byte-identical to the reference.
 *
 *  AND HIS SIM BRIEF AND DEBRIEF ([CROWD-SIM-BRIEF], phase 7): a man on the OFT at 10:00 is busy for the box and
 *  free for the quarter-hour before it, so he stands behind a 09:50 event — flagged with the sim brief, in the
 *  warning list's own words (simBriefSays / simDebriefSays). The day's sim windows are SIMW, published beside EVD.
 *
 *  WHICH WORLD'S EVENTS. By default the LIVE day's (EVD) — the working copy.
 *  A caller reading an ISSUED face hands in that version's own events (`evs`,
 *  rebuilt with collectEvents while the snapshot is installed), so the issued
 *  face flags what the RECORD says and never paints today onto it (Fable S3):
 *  a man booked since publication is surfaced by the pending mark and the
 *  working copy's live crowd, which drops him (D44/D45). That is also why there
 *  is no red "booked elsewhere" half here any more. It was written for exactly
 *  that issued case; on the working copy it could never fire, because the crowd
 *  is resolved with this same day's `personBusy` and already leaves every busy
 *  man out. A check that cannot fire is a comment that vouches.
 *
 *  `simw` is the sim half of the same choice: the day's sim windows of the world being read — the live day's (SIMW)
 *  by default, the RECORD's own when an issued face hands them in with `evs` (an empty list is an answer). */
export function crowdClashes(di:any,id:any,s:number|null,e:number|null,label:string,evs?:any[],simw?:any[]):{sev:string,msg:string}[]{
  const p=PEOPLE[id]
  /* ground crew carry no flight brief of their own to lose — the same
     exemption the pass above makes */
  if(!p||isSpecial(id)||p.pers||s==null||e==null)return [];
  const out:{sev:string,msg:string}[]=[];
  (evs||dayEvents(di,id)).filter((x:any)=>x&&x.kind==='fly').forEach((lg:any)=>{
    const [bs,bt]=legBriefWin(lg), [ls,de]=legDebriefWin(lg);
    if(bs!=null&&bt!=null&&overlap(s,e,bs,bt))out.push({sev:'adv',msg:noBriefSays(lg,label)});
    if(ls!=null&&overlap(s,e,ls,de))out.push({sev:'adv',msg:debriefSays(lg,label)});
  });
  (simw||SIMW[di]||[]).forEach((sw:any)=>{ if(!sw||(sw.ids||[]).indexOf(id)<0)return;
    if(simHasBrief(sw)&&overlap(s,e,sw.bs,sw.be))out.push({sev:'adv',msg:simBriefSays(sw,label)});
    if(simHasDebrief(sw)&&overlap(s,e,sw.ds,sw.de))out.push({sev:'adv',msg:simDebriefSays(sw,label)});
  });
  return out;
}
/* A NOUGHT-MINUTE SORTIE — ONE BODY, THREE READERS (D49, owner 22 Sep 26).
   The warning below asks it, and so do both surfaces that DRAW the line: the
   week (ui/html.ts) and the board (ui/board.ts), because the ruling is that the
   day says the times are wrong ON THE LINE, not only in the list on the right.
   Written once here rather than re-derived beside each renderer — a rule read in
   two places is a drift seam (CLAUDE.md §the robustness doctrine), and this one
   would drift into a line wearing a mark no warning explains, or a warning about
   a line wearing no mark.
   The CREW test is part of the rule, not an extra: a line nobody is on raises no
   warning, so it must carry no mark either. */
export function fltNoLen(f:any):boolean{
  if(!f||f.cx)return false;
  const st=parseHM(f.to),en=parseHM(f.ld);
  if(st==null||en==null||st!==en)return false;
  const crew:any[]=[];
  (f.aircraft||[]).forEach((ac:any)=>{if(!ac.cx){crew.push(ac.p);crew.push(ac.w);}});
  return crew.some((v:any)=>{const id=whoId(v);return !!id&&(realP(id)||isSpecial(id));});
}
/* the sentence, shared by the warning and by every marked box's own words, so a
   scheduler reading the box is told the same thing as the list.
   TWO SENTENCES, BECAUSE THEY ARE TWO DIFFERENT FACTS (22 Sep 26, the
   independent code read). D49 is a ruling about a SORTIE: the man reported three
   hours before and debriefed for two after, so the half day is real work
   whatever the written times say. A STANDALONE wave — SC MAIN, SC SPARE,
   AVALON, BB — has no such padding; its window IS the written window, so typed
   08:00–08:00 it measures nothing and pays nobody. Telling a scheduler that
   shift "still earns from the report and debrief" was false, on the wave the
   squadron works most weekends, about money. */
export const FLT_NO_LEN_SAYS=(st:any,sa?:any)=>`takes off and lands at the same time (${hm24(st)}) — one of the two is wrong; ${sa?'a shift with no length earns nobody any OIL until it is fixed':'the day still earns from the report and debrief'}`;
/* the 7-day run's sentence — one body for the warning and for the dotted mark that points at it from the days before
   (the mark carries the words its warning will have, so a hide of that warning is found — [WARN-HIDE-KEPT]) */
const runSays=(id:any,n:any)=>`${PEOPLE[id]?PEOPLE[id].cs:id} is on the programme ${n} days in a row — ${VCONF.maxRun} is the limit, so a break day is due`;
/* a nought-minute line's sentence — one body for the warning and for the next-week preview, which draws the line's red
   time box without a warning list and asks whether THAT warning is hidden (ui/peek.ts) */
export const fltNoLenMsg=(f:any,wv:any)=>`${f.cs||wv.label||'A flying line'} ${FLT_NO_LEN_SAYS(parseHM(f.to),isStandalone(wv))}`;
/* a ring is the worst of a man's warnings, a chip the highest — the two merges every mark goes through (the day loop and
   shownOf's replay share them) */
const markWorse=(m:any,di:any,id:any,s:any)=>{m[di]=m[di]||{}; const c=m[di][id]; if(!c||SEVR[s]>SEVR[c])m[di][id]=s;};
const markHigher=(m:any,di:any,id:any,c:any)=>{m[di]=m[di]||{}; if(!m[di][id]||RANK[c]>RANK[m[di][id]])m[di][id]=c;};
function validateCore(){
  const ev=collectEvents(), all:any[]=[], byDay:any[]=[], sev:any={}, chip:any={}, dash:any={}, trace:any={};
  REST={}; EVD={}; SIMW={};
  /* EACH MARK ALSO FILED BY ITS CLASS ([LEAVE-LATE-PUBLISHED], D184/D185, 26 Sep 26): a published face shows the rings
     and flags it went out with, except those raised by a LIVE_ON_FACE warning, which it takes from today. A ring is the
     worst of a man's warnings, so it cannot be split afterwards — every mark is written to the day's whole map (what
     every surface reads, unchanged) AND to `fz` (raised by a warning that freezes) or `lv` (by one that stays live).
     A mark site of a live warning names its code; one that names none is frozen-class. */
  const fz:any={sev:{},chip:{},dash:{}}, lv:any={sev:{},chip:{},dash:{}};
  const cls=(code:any)=>code&&LIVE_ON_FACE.has(code)?lv:fz;
  const ring=markWorse, flag=markHigher;
  /* EACH MARK IS ALSO WRITTEN DOWN WITH ITS WARNING ([WARN-HIDE-KEPT], owner D469, 1 Oct 26 — "if it's hidden, the pucks
     shouldn't have flagging for that specific item"). A ring is the worst of a man's warnings and a chip the highest, so
     the maps cannot be un-merged afterwards: every mark site names the CODE of the warning it stands beside, and the mark
     is kept in `marks` (and each next-day mark in `traces`, with the warning it points at). shownOf() below replays them
     without the marks of a hidden warning — a mark goes when no SHOWN warning of that day and code names that man.
     Nothing is hidden → the maps written here are the ones every surface reads, exactly as before. */
  const marks:any[]=[], traces:any[]=[];
  const markRing=(di:any,id:any,s:any,code?:any)=>{ring(sev,di,id,s); ring(cls(code).sev,di,id,s); marks.push({k:'sev',di,id,v:s,code});};
  const markChip=(di:any,id:any,c:any,code?:any)=>{flag(chip,di,id,c); flag(cls(code).chip,di,id,c); marks.push({k:'chip',di,id,v:c,code});};
  /* the ring STYLE, which a chip cannot carry: a sanctioned late show rings
     dashed while still counting as the hard warning it is (owner, 6 Aug 26).
     Separate from sev because it is orthogonal — same red, different stroke. */
  const markDash=(di:any,id:any,code?:any)=>{dash[di]=dash[di]||{}; dash[di][id]=true; const m=cls(code).dash; m[di]=m[di]||{}; m[di][id]=true; marks.push({k:'dash',di,id,v:true,code});};
  /* THE CAUSE, published on the day that CAUSED it (owner, 6 Aug 26). A crew-rest
     breach is raised on the day the man is told to report, but the day a
     scheduler can actually fix is the one BEFORE — so that day carries a
     standing mark of its own: which day it breaks (`di`), the time he had to
     be gone by (`leaveBy`), and the message, so the previous day can print the
     warning without re-deriving a word of it. Keyed by the PREVIOUS day, which
     is what makes it readable straight off the puck. */
  /* MERGED, not replaced (5 Sep 26): the same puck can carry the crew-rest
     trace (its fields at the top level, unchanged) AND the run trace (nested
     under `run`) — day six of a run whose late landing also wrecks tomorrow. */
  /* `w` — the warning this mark points at: its day (null = next week's Monday), code, man and words (shownOf) */
  const markTrace=(pdi:any,id:any,t:any,w?:any)=>{if(pdi==null)return; trace[pdi]=trace[pdi]||{}; trace[pdi][id]=mergeRestTrace(trace[pdi][id],t); traces.push({pdi,id,t,w});};
  const dur=(m:any)=>`${m<0?'-':''}${Math.floor(Math.abs(m)/60)}h${String(Math.round(Math.abs(m)%60)).padStart(2,'0')}`;
  /* CONSECUTIVE WORKING DAYS (owner, Aug 26) — nobody may be on the programme
     more than VCONF.maxRun days without a break day. Counted in day order off
     day.events, which is every kind of tasking there is: a flight, a duty
     post, a sim, a ground item, a programme row. Leave and downchits are not
     tasking, so a day off breaks the run exactly as it should. Computed in one
     pass up front because a run is a property of the WEEK, not of a day, and
     the per-day loop below can then just read the number off.
     SEEDED FROM THE PREVIOUS WEEK since the cross-week work (owner: the
     engine reads continuously, "it doesn't just stay within a week") — a man
     who worked straight through last week walks into this Monday already
     carrying his count, so the limit breaks on the true seventh day, not on
     this week's seventh. seedRunIn (weekctx.ts) walks back from last Sunday
     through weekBundle data, at most maxRun days; an unauthored previous
     week seeds nothing, which is byte-identical to the old fresh start. */
  RUNLEN=[]; EVDAYS=ev; {
    const run:any=seedRunIn(CURWEEK,VCONF.maxRun);
    RUNSEED={...run};
    ev.forEach((day:any,i:any)=>{
      const on=new Set<any>();
      (day.events||[]).forEach((e:any)=>{ if(e.id&&PEOPLE[e.id]&&!isSpecial(e.id))on.add(e.id); });
      Object.keys(run).forEach((id:any)=>{ if(!on.has(id))run[id]=0; });   // a clear day resets it
      const m:any={}; on.forEach((id:any)=>{ m[id]=run[id]=(run[id]||0)+1; });
      RUNLEN[i]=m;
    });
  }
  const restWeek=CURWEEK, restSeeds=new Map<number,any>();
  const restDayAt=(index:number)=>{
    if(index>=0&&index<7)return ev[index];
    if(!restSeeds.has(index))restSeeds.set(index,datedRestSeed(restWeek,index));
    return restSeeds.get(index);
  };
  /* THE RUN TRACE (owner, 5 Sep 26 — "make the warning like what the crew
     rest does… dotted pucks, to warn that the 7 day breach is on which day
     actually"). The breach lands on the day the count crosses the limit;
     EVERY earlier day of that run is a day the scheduler can still clear (take
     him off any one of them and the count resets), so each of them carries a
     dotted trace pointing at the day it breaks: `run:{di,dow,n}` merged onto
     WARN.trace beside the crew-rest fields. Only the crossing day is traced
     to — the days after it wear their own solid flag. Walked back while
     RUNLEN still knows him (consecutive by construction, so it is one run).
     THE FORWARD PASS, mirroring crew rest's phantom Monday: a run that stands
     AT the limit on Sunday and continues into next Monday (nextMondayWorked —
     the seed-side on-set, the stash read first) breaks on a day this WARN
     cannot address, so it traces with di:null and dow 'Monday' and writes no
     warning — the breach itself lands when next week is loaded. Bounded to
     Monday, one lookahead day, like the crew-rest trace. Trace only — never a
     warning — so parity.test.ts (which compares WARN.byDay) is untouched. */
  {
    const traceRun=(from:any,id:any,t:any)=>{ for(let k=from;k>=0;k--){ if(!RUNLEN[k]||RUNLEN[k][id]==null)break; markTrace(k,id,{run:t},{di:t.di,code:'DAYS_RUN',who:[id],msg:runSays(id,t.n)}); } };
    ev.forEach((day:any,i:any)=>{
      Object.keys(RUNLEN[i]||{}).forEach((id:any)=>{
        const n=RUNLEN[i][id];
        if(n>VCONF.maxRun&&!(i>0&&RUNLEN[i-1][id]>VCONF.maxRun))traceRun(i-1,id,{di:day.di,dow:day.dow,n});
      });
    });
    NEXTON=nextMondayWorked(CURWEEK);
    Object.keys(RUNLEN[6]||{}).forEach((id:any)=>{
      const n=RUNLEN[6][id];
      if(n===VCONF.maxRun&&NEXTON.has(id))traceRun(6,id,{di:null,dow:'Monday',n:n+1});
    });
  }
  /* ONE DAY'S CREW-REST COMPUTATION, extracted verbatim from the day loop
     below (the buildDay-extraction precedent) so the phantom next-Monday
     pass after the loop cannot drift from the real rule — one body, two
     callers, never a second copy of the arithmetic. `phantom` guards every
     write addressed to the CURRENT day (its warning, chips, rings, dash,
     REST) — a phantom day is next week's Monday, which this WARN cannot
     address by day index — leaving exactly one side effect: markTrace onto
     prevSeed.di, the "Breaks Monday" box on the live Sunday that caused
     it (owner, 23 Aug 26 — "If I plan someone who bust crew rest the day
     prior it should also flag out just like what u see for outlaw").
     `add` rides in as a parameter because it is the day loop's own
     closure over that day's `ws` list; the phantom caller passes null —
     every add here is phantom-guarded, so it is never dereferenced. */
  /* PROBE MODE (5 Sep 26, the pre-drop query): `probe` = {id, hit} makes
     the pass a QUESTION about one man — every write is suppressed (phantom
     covers the current day; the trace write below is guarded too, since a
     probe's prevSeed may be a live day) and the breach, if any, is handed to
     `probe.hit(...)` instead of filed. Same body, same arithmetic, so what
     the picker says before the drop and what the validator flags after it
     cannot drift. Everyone but probe.id is skipped — the answer is his. */
  const crewRestDay=(prevSeed:any,day:any,di:any,phantom:any,add:any,probe?:any)=>{
      /* prevFlyEnd/prevEnd were once distinct — the rest-bearing set against
         the last end of ANY kind — and a late non-resting row could mask the
         sortie underneath it. With every kind rest-bearing they track the
         same number; both stay because the reference computes both and the
         fallback below costs nothing. */
      /* WHICH leg ran late, not just how late. The end time alone answers the
         rule but not the reader: the cross-day row on this day is the one
         affordance a scheduler can act on, and it has to be able to point at
         the sortie to move. So the winning event's own slot-key is kept beside
         its minute count (`slot` on a flying/shift event, `key` on the others)
         and travels on the trace — see markTrace below. */
      /* prevFlyLd carries the raw LANDING of the winning rest-end so the tail
         can spell out its own arithmetic (owner, 15 Aug 26 — "at least they
         know the assumption"): a sortie ends at land + debrief, and a
         scheduler who knows this crew walks off the jet fast can read that the
         2h is an assumption, not a fact. Null when the winning end is a SHIFT,
         which ends at its written time with no debrief tail to assume. */
      const prevEnd:any={}, prevFlyEnd:any={}, prevFlyKey:any={}, prevFlyLd:any={}, prevSource:any={};
      const targetIndex=day.restIndex??day.di??di;
      for(let distance=1;distance<=4;distance++){
      const origin=targetIndex-distance;
      const source=probe?.dayAt?probe.dayAt(origin):distance===1?prevSeed:restDayAt(origin);
      if(!source)continue;
      // Preserve the existing previous-day arithmetic, moving each older
      // authored end onto that same axis exactly once.
      const offset=(1-distance)*1440;
      source.events.forEach((e:any)=>{
        /* EVERYTHING THAT ENDS THE DAY BEARS CREW REST (owner, 21 Aug 26 —
           "anything that ends the day prior and affects the 12 hour crew
           rest will be a warning"; this widened twice the same day: first
           duties joined sortie-and-shift, then sims, ground events and
           programme items joined them all). A sortie still ends at land +
           debrief; every other kind ends at its WRITTEN end with no tail —
           a sim's brief/debrief windows live in simwin, not on the event,
           so its box end is what counts here. The tight-turning advisory
           below is now only the nominal-vs-instructed gap, never a
           severity downgrade by event kind; and the REST[] map the picker
           reads is built from the same set, so they cannot disagree. */
        const rests=true;
        const rawEnd=e.kind==='fly'?e.ld+VCONF.debrief:e.e;   // a shift/duty ends when it ends
        if(rawEnd==null)return;
        const end=rawEnd+offset;
        if(prevEnd[e.id]==null||end>prevEnd[e.id])prevEnd[e.id]=end;
        if(rests&&(prevFlyEnd[e.id]==null||end>prevFlyEnd[e.id])){prevFlyEnd[e.id]=end; prevFlyKey[e.id]=e.slot||e.key; prevFlyLd[e.id]=e.kind==='fly'?e.ld+offset:null; prevSource[e.id]=source;}
      });
      /* DUTY & COMMITMENT INPUTS BEAR CREW REST TOO (owner, 21 Aug 26 —
         "everything in duty and commitments affects crew rest… do not
         include personal, sans availability", and it counts on both sides).
         Only the restsInput types, and only entries with TYPED times — an
         all-day record spans the full 1439 minutes and has no "timing you
         see" (his words), so it stays with the ordinary clash rules. The
         nx/pv copies are the midnight tails: other days' records shifted
         into this frame — counting an nx entry would file TODAY's own
         meeting as yesterday's end, so both are skipped. The end is the
         written end, no debrief tail; prevFlyLd stays null so the message
         keeps the plain "ended" wording, and prevFlyKey is cleared — an
         input has no board slot for the previous-day trace to jump to.
         REST[di] below is built from these same maps, so the SC picker's
         crew-rest refusal follows this rule with no second copy. */
      source.input.forEach((i:any)=>{
        if(i.nx||i.pv||!restsInput(i.type))return;
        if(i.s==null||i.e==null||!isFinite(i.e)||i.e-i.s>=1439)return;
        const end=i.e+offset;
        if(prevEnd[i.id]==null||end>prevEnd[i.id])prevEnd[i.id]=end;
        if(prevFlyEnd[i.id]==null||end>prevFlyEnd[i.id]){prevFlyEnd[i.id]=end; prevFlyKey[i.id]=null; prevFlyLd[i.id]=null; prevSource[i.id]=source;}
      });
      }
      /* when rest expires today, for everyone who had ANY commitment
         yesterday — the palette reads this to keep an SC slot closed to
         anyone who is not yet clear */
      const restMap:any={};
      Object.keys(prevFlyEnd).forEach((id:any)=>{
        const cl=prevFlyEnd[id]+VCONF.crewRest-1440;
        // A prior-day report can still precede clearance at/before midnight.
        // Keep the old positive-day map, adding signed clearance only where
        // today's actual flight/SC report or brief reaches yesterday.
        if(cl>0||day.fly.some((e:any)=>e.id===id&&((e.intime!=null&&e.intime<0)||(!e.shift&&e.brief!=null&&e.brief<0))))restMap[id]=cl;
      });
      if(!phantom)REST[di]=restMap;
      /* today's rest-bearing commitments: sorties AND shifts */
      const byR:any={}; day.fly.forEach((e:any)=>{(byR[e.id]=byR[e.id]||[]).push(e);});
      /* a shift reports when it starts; a sortie reports 3h before T/O */
      const nomOf=(e:any)=>e.shift?e.to:e.to-VCONF.reportLead;
      /* Read the leg's OWN brief (events.ts sets it from the indicated B, or
         from VCONF.briefLead when the line has none) — recomputing
         `e.to-VCONF.briefLead` here would ignore a typed B and quietly
         disagree with the brief window the same engine flags against.

         A `late show` / `show at brief` remark does NOT move this anchor
         (owner, 6 Aug 26): the breach is reported either way, in red, counted
         like any other. What the remark changes is the RING — see makesIt
         below — because a scheduler writing it has sanctioned the late join,
         and the reader still needs to see that crew rest was broken. */
      const briefOf=(e:any)=>e.brief!=null?e.brief:e.to-VCONF.briefLead;
      /* A shift reports at its start UNLESS an in-time was typed for it — an SC
         line's B box is that crew's report time (owner, 24 Aug 26). When set it
         is honoured (the earlier of it and the shift start, so a later value
         cannot push the report past when the watch actually begins); when blank
         e.intime is null and this is byte-identical to the old `e.to`. */
      const insOf=(e:any)=>e.shift?(e.intime!=null?Math.min(e.intime,e.to):e.to):Math.min(e.intime!=null?e.intime:Infinity,briefOf(e));
      Object.keys(byR).forEach((id:any)=>{
        if(probe&&id!==probe.id)return;
        /* Personnel (ground crew) hold no crew-rest rule — an incentive ride
           does not put a ground-crewman on a 12-hour flying clock. */
        if(PEOPLE[id]&&PEOPLE[id].pers)return;
        /* Crew rest runs off the last commitment of ANY kind (owner,
           21 Aug 26 — see the collection above). The prevEnd fallback is
           vestigial now that everything rests, and pfly can only read true
           when a previous end exists at all. */
        const pe=prevFlyEnd[id]!=null?prevFlyEnd[id]:prevEnd[id];
        if(pe==null||!isFinite(pe))return;
        const pfly={[id]:prevFlyEnd[id]!=null};
        const earliest=pe+VCONF.crewRest-1440;         // minutes into TODAY that crew rest expires
        // Do not assume clearance by midnight means a prior-day report is clear.
        // The actual first commitment below is compared on the same signed axis.
        const legs=byR[id];
        const nominal=Math.min.apply(null,legs.map(nomOf));
        const instructed=Math.min.apply(null,legs.map(insOf));
        /* THE DAY STARTS AT ITS FIRST COMMITMENT (owner, 21 Aug 26 — "if
           they have anything earlier like a meeting that busts crew rest
           and they fly later, it's also a violation… think it as, this
           person needs 12 hours of rest in order to fly"). His 21:30 →
           09:00 example had the in-time at 10:00 and the brief at 11:00 —
           both legal — and an 08:00 meeting that is not. So the anchor is
           the EARLIEST of the instructed flying report and any other
           scheduled commitment that day: a sim, a duty post, a ground
           event, a programme item. The flying legs themselves stay on
           insOf (their step/dekit pads are derived, not instructions).
           PERSONAL INPUTS joined the candidate set the same day (the second
           reduce): the restsInput types with typed times count — an 08:00
           Meeting input before a 10:00 report binds the breach exactly as a
           ground row would — while 'Personal', 'SANS Availability', leave,
           medical and all-day records stay out. An input-bound breach names
           the input in the message (inpLabel, so an Other reads by its
           remarks) but anchors on the LEG's key — an unaccepted input has
           no schedule row for the warning jump to pan to. When nothing else
           starts earlier, first === instructed and every message below is
           byte-identical to before. */
        const fe0=day.events.reduce((m:any,e:any)=>e.id===id&&e.kind!=='fly'&&e.kind!=='shift'&&e.s!=null&&isFinite(e.s)&&(m==null||e.s<m.s)?e:m,null);
        const fi=day.input.reduce((m:any,i:any)=>i.id===id&&!i.nx&&!i.pv&&restsInput(i.type)&&i.s!=null&&isFinite(i.s)&&i.e!=null&&i.e-i.s<1439&&(m==null||i.s<m.s)?i:m,null);
        const fe=fi!=null&&(fe0==null||fi.s<fe0.s)?{s:fi.s,label:inpLabel(fi)}:fe0;
        const first=Math.min(instructed,fe!=null?fe.s:Infinity);
        const evBound=first<instructed;
        const onShift=legs.some((e:any)=>e.shift);
        /* SPELL OUT THE ASSUMPTION when a sortie set the rest-end: show the
           real landing, name the debrief pad as an assumption, then the
           derived end and the 12h clearance — so the reader can override it in
           their head for a crew that leaves quickly. A shift (prevFlyLd null)
           has no debrief to assume, so it keeps the plain "ended". */
        const landed=prevFlyEnd[id]!=null?prevFlyLd[id]:null;
        const source=prevSource[id]||prevSeed;
        const tail=landed!=null
          ? `${source.dow} landed ${hm24(landed)}, +${lgT(VCONF.debrief)} debrief assumed → ended ${hm24(pe)} → crew rest clear at ${stated(earliest)}`
          : `${source.dow} ended ${hm24(pe)} → crew rest clear at ${stated(earliest)}`;
        if(pfly[id]&&first<earliest){
          const bl=legs.reduce((m:any,e:any)=>insOf(e)<insOf(m)?e:m);   // the leg told to report earliest is the breach
          /* The LEAVE-BY: the latest the previous day could have ended for this
             man to be clear. It is what the scheduler actually needs — "he is
             short" is a complaint, "he had to be gone by 00:00" is an
             instruction — and the previous day's puck prints it when the
             warning is clicked. It rides the warning/trace as DATA only since
             22 Aug 26 (owner: the trace row's bold lead already says it, and
             the message's old ", so he had to leave by" tail said it again —
             "that's like repeating what u said"). first===instructed when no
             earlier event binds, so the unbound arithmetic is unchanged. */
          const sourceIndex=source.restIndex??source.di;
          const leaveBy=stated(first+(targetIndex-sourceIndex)*1440-VCONF.crewRest);
          /* A sanctioned late show still makes the jet if rest clears by
             STEP, VCONF.step before T/O — the same knob that pads the busy
             window, so editing the step timing moves this line with it
             (owner, 21 Aug 26; a separate showLead key was removed for
             exactly that drift). Then the ring is DASHED:
             same red warning, same count, but the reader can see a scheduler
             meant it. Past that line there is no sanctioning it — he cannot
             walk, kit up and start engines — so it rings solid like any other
             breach. A shift has no take-off to measure against — and neither
             does a MEETING: when an earlier event binds the breach, a late
             show on the jet cannot excuse the 08:00 he reports to first. */
          const makesIt=!bl.shift&&earliest<=bl.to-VCONF.step;
          const dashed=!evBound&&!!bl.lateShow&&makesIt;
          if(!phantom){markChip(di,id,'CR','CREW_REST');markRing(di,id,'hard','CREW_REST'); if(dashed)markDash(di,id,'CREW_REST');}
          const prevDi=source.di;
          /* CAUSE-FIRST, SAID ONCE (owner, 22 Aug 26 — "refine the way u
             reason the crew rest warning. Clear and concise"): one forward
             chain — yesterday's end → when rest clears → the commitment that
             breaks it — with the shortfall in the same breath. The old shape
             stated the report first, re-derived it through the tail, then
             re-stated the leave-by the trace row's own lead already carries. */
          const rest=first+1440-pe, endDow=DAYS[((targetIndex+Math.floor(pe/1440)-1)%7+7)%7].dow;
          const restWords=rest<0?`${dur(-rest)} before his ${endDow} duty ends`:`only ${dur(rest)} rest`;
          const crMsg=`Crew rest breach — ${tail}, but `
            +(evBound?`his day starts ${stated(first)} (${fe.label}) before the ${stated(instructed)} report — ${restWords}.`
             :onShift?`${legs.filter((e:any)=>e.shift).map((e:any)=>e.label)[0]} starts ${stated(instructed)} — ${restWords}.`
             :`told to report ${stated(instructed)} — ${restWords}.`)
            +(dashed?` Late show — he still makes the ${hm24(bl.to-VCONF.step)} step.`
                    :(!evBound&&bl.lateShow?` Late show cannot save it — the ${hm24(bl.to-VCONF.step)} step is still before rest clears.`:''));
          /* the warning anchors on what binds it: the early event's own slot
             key when a meeting caused the breach, the leg otherwise — the
             jump then pans to the row the scheduler has to move */
          if(probe){probe.hit({di,dow:day.dow,leaveBy,earliest,first,msg:crMsg});return;}
          if(!phantom)add('hard','CREW_REST',[id],crMsg,evBound?(fe.slot||fe.key||bl.key):bl.key,{prevDi,leaveBy,dashed});
          /* The same breach, filed against the day that caused it — with
             `fromKey`, the leg on THAT day that ran late. It rides on the trace
             and NOT on the warning: parity.test.ts compares every field of
             WARN.byDay against the reference, while WARN.trace is port-only, so
             this stays clear of the reference entirely. */
          const external=di==null?{targetDi:day.targetDi,targetWeek:day.targetWeek}:{};
          markTrace(prevDi,id,{di,dow:day.dow,leaveBy,dashed,msg:crMsg,fromKey:prevFlyKey[id],...external},{di,code:'CREW_REST',who:[id],msg:crMsg,...external});
        } else if(nominal<earliest||instructed<earliest){
          /* Chip, no ring (owner, 7 Aug 26). A tight turn is a note, not a
             problem to fix — and this was the ONLY TT that rang: the same-day
             tight turn above chips bare, and so does DT. One glyph meaning
             "ringed problem" here and "unringed note" there is unreadable, so
             the ring goes rather than the chip. The warning itself is
             unchanged — still filed, still counted, still clickable. */
          if(!phantom)markChip(di,id,'TT','CREW_TIGHT');
          /* the sim/ground suffix is UNREACHABLE since every kind became
             rest-bearing (pfly is true whenever pe exists) — the ternary
             stays because the patched reference carries the identical line
             and neither side can emit it */
          if(!phantom)add('adv','CREW_TIGHT',[id],`Tight turning — T/O ${hm24(Math.min.apply(null,legs.map((e:any)=>e.to)))} puts the ${lgT(VCONF.reportLead)} report at ${hm24(nominal)}, inside ${lgT(VCONF.crewRest)}. ${tail}`
            +(pfly[id]?'':' (prior day ended on a sim or ground event, so crew rest itself does not apply)'),
            legs.reduce((m:any,e:any)=>nomOf(e)<nomOf(m)?e:m).key);
        }
      });
  };
  ev.forEach((day:any,idx:any)=>{
    const di=day.di, ws:any[]=[], seen=new Set();
    /* publish this day's events for the crew picker (see dayEvents) */
    const evd:any=EVD[di]={}; day.events.forEach((e:any)=>{(evd[e.id]=evd[e.id]||[]).push(e);});
    SIMW[di]=day.simwin||[];
    /* the same rule can fire off two legs of the same sortie pair, so identical
       rows are collapsed rather than printed twice. */
    /* key = the slot-key of the FIRST item the message names, so a click on the
       warning pans to the line that caused it (di.gi.li.ai[.p|w] flying,
       s:/d:/g:/a: rows). Optional — day-spanning warnings carry none. The dedup
       string k stays key-free: first add wins and keeps the first item's key. */
    const add=(s:any,code:any,who:any,msg:any,key?:any,extra?:any)=>{who=who.filter(Boolean);
      const k=code+'|'+who.join(',')+'|'+msg; if(seen.has(k))return; seen.add(k);
      const w={sev:s,code,who,day:day.dow,di,msg,key,...(extra||{})};ws.push(w);all.push(w);};
    const kOf=(e:any)=>e&&(e.slot||e.key)||null;   // byE events carry slot (fly/shift) or key (the rest)
    /* D502: include uncrewed formations; no invented puck penalty.
       These ordinary issued warnings freeze normally. */
    reportingIssuesForDay(DAYS[di]).forEach(issue=>add(issue.blocking?'hard':'adv',issue.code,[],issue.msg,
      issue.lines.length?`it:${di}.${issue.gi}`:`${di}.${issue.gi}.${issue.li}.0.p`));
    /* An SC / AVALON / BB line is a SHIFT, not a sortie. Its crew still count
       as tasked and are still checked for clashes and qualification, but a
       handover is not a turn, a 12-hour watch is not a long flying day, and a
       shift start does not imply a brief at T/O − 2h20. */
    const byP:any={}; day.fly.filter((e:any)=>!e.shift).forEach((e:any)=>{(byP[e.id]=byP[e.id]||[]).push(e);});
    /* A genuine double turn is two legs flown one AFTER the other. Legs whose
       AIRBORNE windows overlap are the same air time booked twice — the hard
       DOUBLE_BOOK clash below speaks for that man, and counting him "double
       turning" beside it read as two problems where there is one (owner,
       21 Aug 26 — the conflict is enough, no double-turn advisory on top).
       The airborne window (to..ld) is the line because it is the line the
       clash rule itself draws; a leg with no times stays counted, matching
       the clash's own null guard, which cannot fire without them. Shared by
       the DT chip and the DT_SUM summary so the two can never disagree. */
    const dturns=(ls:any)=>{for(let i=0;i<ls.length;i++)for(let j=i+1;j<ls.length;j++)if(!(ls[i].to!=null&&ls[j].to!=null&&overlap(ls[i].to,ls[i].ld,ls[j].to,ls[j].ld)))return true;return false;};
    // DT (2+ sorties) + TT (tight turn = next in-time within 20-min of previous land)
    Object.keys(byP).forEach((id:any)=>{
      /* Personnel (ground crew) carry only the conflict, long-day and 7-day
         checks — turning an aircraft is not their concern, so a passenger who
         rides two rear seats in a day raises no DT/TT. A genuine overlap is
         still caught below as a hard conflict. */
      if(PEOPLE[id]&&PEOPLE[id].pers)return;
      const es=byP[id].slice().sort((a:any,b:any)=>a.to-b.to);
      if(es.length>=2&&dturns(es))markChip(di,id,'DT','DT_SUM');
      for(let i=0;i<es.length-1;i++){ const turn=es[i+1].to-es[i].ld;   // land → next T/O; need 30m dekit + 60m step = 90m
        /* The threshold and the mechanics are edited independently, so either
           can be the binding one: a 60 min threshold with 30 dekit + 60 step
           would let a physically impossible turn through. Take the larger. */
        const need=Math.max(VCONF.tightTurn,VCONF.dekit+VCONF.step);
        /* turn<0 means the two legs OVERLAP — he is airborne twice at once,
           which is not a turn at all. It was reported as one, carrying a
           negative minute count ("Tight turn VL→VL: -85 min"), and the hard
           clash below now speaks for that case instead (owner, 11 Aug 26). */
        if(turn>=0&&turn<need){markChip(di,id,'TT','TURN');add('adv','TURN',[id],`Tight turn ${es[i].label}→${es[i+1].label}: ${turn} min land→next T/O (needs ${need} min — threshold ${VCONF.tightTurn}, dekit+step ${VCONF.dekit}+${VCONF.step})`,es[i].key);} }
    });
    /* C — two commitments at the same time for one person.
       Sortie-vs-sortie is the tight-turn rule's business, not this one.
       A SHIFT (SC MAIN) is graded by what it runs into:
         another cockpit — flight, sim, another shift — or a duty POST he has to
         man → Warning, he cannot be in two places;
         a ground event or a programme item → Advisory, because you can still
         give academics to the man who is on SC — with ONE overlay (owner,
         26 Aug 26): a ground row that IS a red-list commitment, by its source
         input or by its own words, is the commitment, not academics → Warning.
         shiftEvHard (events.ts) carries the overlay; Meeting stays the advisory.
       SC SPARE never reaches here at all: a spare is standing by, so he stays
       free for anything else on the day. */
    /* SHIFT_HARD is declared once at the top of the engine — the crew picker
       shares it (and the same shiftEvHard overlay), so the two can never
       disagree about what bars a shift. */
    const byE=evd;
    Object.keys(byE).forEach((id:any)=>{ const es=byE[id].slice().sort((a:any,b:any)=>a.s-b.s);
      for(let i=0;i<es.length;i++)for(let j=i+1;j<es.length;j++){
        const A=es[i],B=es[j];
        /* Sortie-vs-sortie is the tight-turn rule's business — but only where
           the legs are SEQUENTIAL. This used to skip every flying pair, because
           two back-to-back legs overlap the moment the step and dekit pads are
           added and would have rung on every legitimate tight turn. That also
           swallowed the case where the man is genuinely airborne twice at once:
           plan him into two aircraft on the same times and the only thing said
           was an amber tight turn with a negative minute count (owner, 11 Aug
           26). The line between the two is the AIRBORNE window (to..ld), never
           the padded one — so compare those, and let a real overlap fall
           through to the hard clash below. */
        if(A.kind==='fly'&&B.kind==='fly'
           &&!(A.to!=null&&B.to!=null&&overlap(A.to,A.ld,B.to,B.ld)))continue;
        if(!overlap(A.s,A.e,B.s,B.e))continue;
        /* every clash, not just the first: a man double-booked in the morning
           AND in the evening used to be told about the morning only. The red
           ring goes on too — a hard warning with a grey puck was a bug. */
        if(A.kind==='shift'||B.kind==='shift'){
          const sh=A.kind==='shift'?A:B, other=A.kind==='shift'?B:A;
          if(shiftEvHard(other)){
            markChip(di,id,'C','DOUBLE_BOOK'); markRing(di,id,'hard','DOUBLE_BOOK');
            add('hard','DOUBLE_BOOK',[id],`${sh.label} & ${other.label} clash`,kOf(sh)||kOf(other));
          } else {
            /* amber A, not the red conflict C — the puck has to say advisory at a
               glance, the way the note under it already does */
            markChip(di,id,'A','SHIFT_SOFT'); markRing(di,id,'adv','SHIFT_SOFT');
            add('adv','SHIFT_SOFT',[id],
              `${PEOPLE[id]?PEOPLE[id].cs:id} is on ${sh.label} (${hm24(sh.s)}–${hm24(sh.e)}) and also down for ${other.label}`,kOf(sh)||kOf(other));
          }
          continue;
        }
        markChip(di,id,'C','DOUBLE_BOOK'); markRing(di,id,'hard','DOUBLE_BOOK');
        /* two seats on the SAME line print the same label, so the general
           wording came out as "VL BFM & VL BFM clash" — which reads like a
           fault in the app rather than a fault in the plan. Name what actually
           happened instead; the two-different-lines wording is unchanged. */
        add('hard','DOUBLE_BOOK',[id],A.label===B.label
          ?`${PEOPLE[id]?PEOPLE[id].cs:id} is in two seats on ${A.label} at once`
          :`${A.label} & ${B.label} clash`,kOf(A)||kOf(B));} });
    /* THE IN-TIME WINDOW (owner, 24 Aug 26 — "have a no brief advisory as well
       if anything cuts or ends between B and TO time for SC main"). An SC MAIN
       with a typed B earlier than the shift start is on duty from that B, so a
       commitment that cuts into or ends inside B→start gets an amber advisory —
       amber, not red, because the shift itself has not been double-booked yet.
       Only a shift event can carry report<s (events.ts sets it from the SC B
       alone; a spare has no event at all), so the guard needs no wave lookup.
       An event that also overlaps the shift window is the clash loop's business
       above and is not re-reported here; a timed personal input is included the
       way crew rest includes it (restsInput, typed times only) — and since
       26 Aug 26 inputs DO speak against the shift window itself (the per-type
       red/amber below), so an input reaching into the shift gets the same
       already-reported exclusion the events have, or one Meeting would read
       both as SHIFT_SOFT and as an in-time cut. */
    Object.keys(byE).forEach((id:any)=>byE[id].forEach((sh:any)=>{
      if(sh.kind!=='shift'||sh.report==null||sh.report>=sh.s)return;
      const cs=PEOPLE[id]?PEOPLE[id].cs:id;
      const cut=(s:any,e:any,label:any)=>{
        markChip(di,id,'A','SC_INTIME'); markRing(di,id,'adv','SC_INTIME');
        add('adv','SC_INTIME',[id],
          `${cs} reports ${hm24(sh.report)} for ${sh.label} — ${label} (${hm24(s)}–${hm24(e)}) cuts into the in-time window before the ${hm24(sh.s)} start`,kOf(sh));};
      byE[id].forEach((o:any)=>{ if(o===sh)return;
        if(!overlap(sh.report,sh.s,o.s,o.e))return;
        if(overlap(sh.s,sh.e,o.s,o.e))return;
        cut(o.s,o.e,o.label);});
      day.input.forEach((inp:any)=>{ if(inp.id!==id||inp.nx||inp.pv)return;
        if(!restsInput(inp.type)||inp.s==null||inp.e==null||inp.e-inp.s>=1439)return;
        if(!overlap(sh.report,sh.s,inp.s,inp.e))return;
        if(overlap(sh.s,sh.e,inp.s,inp.e))return;
        cut(inp.s,inp.e,inpLabel(inp));});
    }));
    // C via input clash (DNIF / leave / appointment vs a sortie)
    /* SHIFT lines ride day.fly too, and this loop used to speak over them —
       "Meeting clashes with SC AM" beside the shift's own graded voice, and a
       leave read twice in two wordings. Since the per-type grading (owner,
       26 Aug 26) the events loop below is a shift's ONE voice — red-list and
       ATT B hard, Meeting amber, leave/med/OD hard — so a shift line is
       excluded here outright. Real sorties are untouched. */
    day.fly.forEach((e:any)=>day.input.forEach((inp:any)=>{ if(inp.id!==e.id)return;
      if(e.shift)return;
      if(overlap(e.step,e.dekit,inp.s,inp.e)){
        /* the offer exemption is gone with the "Available *" types (owner
           decision, Aug 26). "Fly with" is now an ordinary commitment: a man who
           says he is flying elsewhere is not available for this sortie, so it
           clashes exactly like a Meeting or an Appointment does. */
        const dn=isDownchit(inp.type),lv=isLeave(inp.type), wc=dn?'DNIF_FLY':lv?'LEAVE_FLY':'INPUT_FLY';
        markChip(di,e.id,'C',wc); markRing(di,e.id,'hard',wc);
        /* the REASON is the whole point of the flag — a downchit body planned to
           fly has to say what grounded them, not merely that something clashes. */
        const why=inp.remarks?` — reason: ${inp.remarks}`:'';
        add('hard',dn?'DNIF_FLY':lv?'LEAVE_FLY':'INPUT_FLY',[e.id],
          dn?`Downchit but planned to fly ${e.label}${why}`
            :lv?`On leave but planned to fly ${e.label}${why}`
              :`${inp.type} clashes with ${e.label}${why}`,e.key);} }));
    /* being unavailable does not only bar flying — a duty, a sim seat or a
       ground slot on the same day is just as wrong, and used to pass. This
       covered leave and downchits only (owner, 4 Aug 26): a Detachment, or a
       personal input a scheduler has actioned to Unavailable, warned against a
       sortie but let a sim seat, a duty post or a ground row through silently
       — so "unavailable" guarded the jets and nothing else. Now every input
       the validator can see clashes with every kind of tasking. Shifts grade
       the ordinary personal types BY TYPE now (owner, 26 Aug 26 — SC MAIN may
       launch the man): the red-list commitments (shiftHardInput — Training,
       CSE, Fly with, Personal, Appointment, Duty, Other) hard-flag a shift
       exactly like OD always did; a Meeting reads as the amber SHIFT_SOFT
       advisory, the same voice its accepted ground row speaks in, so the raw
       and landed representations of one input can never disagree. An
       UNRECOGNISED type (a typo, or a record from an older store) fails
       closed and hard-flags the shift like the red list (owner, 26 Aug 26 —
       it was already hard against a sortie; softer-only-on-shifts was the
       seam). The timed
       accepted copy is still deferred to its row (inpShow), so nothing here
       double-reports. Leave, medical and overseas duty still hard-flag a
       shift — those close the man's day outright.
       ATT B (owner, 10 Aug 26; narrowed 26 Aug 26): grounded, not absent —
       unfit to fly but at his desk — so a duty post, a sim seat, a ground row
       or a programme item is proper and must not flag. An SC MAIN SHIFT is the
       exception now: the shift may require him to FLY, so it hard-flags like
       the jet does (and the crew picker already refused him the seat — this
       closes that drift). canWork() still separates "cannot fly" from "cannot
       work" everywhere else. */
    day.events.forEach((e:any)=>{ if(e.kind==='fly')return;
      day.input.forEach((inp:any)=>{ if(inp.id!==e.id)return;
        if(canWork(inp.type)&&e.kind!=='shift')return;
        const dn=isDownchit(inp.type), lv=isLeave(inp.type);
        if(!isUnavail(inp.type)&&e.kind==='shift'&&!shiftHardInput(inp.type)&&inpMeta(inp.type)){
          /* Meeting — the one KNOWN soft type — is the shift's amber voice,
             worded byte-for-byte like the ground-row SHIFT_SOFT above. An
             UNRECOGNISED type fails closed to the hard branch below (owner,
             26 Aug 26 — it already read hard against a sortie, and unknown
             belongs on the serious side): the inpMeta gate is what keeps a
             typo'd or stale-store type out of this advisory. Mirrored in
             refwin.ts reinput as the explicit MEETING literal. */
          if(!overlap(e.s,e.e,inp.s,inp.e))return;
          markChip(di,e.id,'A','SHIFT_SOFT'); markRing(di,e.id,'adv','SHIFT_SOFT');
          add('adv','SHIFT_SOFT',[e.id],
            `${PEOPLE[e.id]?PEOPLE[e.id].cs:e.id} is on ${e.label} (${hm24(e.s)}–${hm24(e.e)}) and also down for ${inpLabel(inp)}`,kOf(e));
          return;
        }
        if(!overlap(e.s,e.e,inp.s,inp.e))return;
        { const wc=dn?'DNIF_FLY':lv?'LEAVE_FLY':'INPUT_FLY'; markChip(di,e.id,'C',wc); markRing(di,e.id,'hard',wc); }
        const why=inp.remarks?` — reason: ${inp.remarks}`:'';
        add('hard',dn?'DNIF_FLY':lv?'LEAVE_FLY':'INPUT_FLY',[e.id],
          (dn?'Downchit but tasked':lv?'On leave but tasked':`${inp.type} but tasked`)+` — ${e.label}${why}`,kOf(e)); }); });
    /* AVALON'S ONE CHECK (owner, 11 Aug 26; three more joined it on 7 Sep 26,
       right below, and BB became AVALON's twin the same day). The wave and its desk keep their
       noconf exemption — nothing on them is cross-checked against tasks, rest or
       qualifications — but the owner commissioned exactly one look, the same shape
       as the SC SPARE rule below: a man standing AVALON must be on the island and
       fit. Jet seats (MAIN and SPARE alike) bar what cannot spare — overseas (OL,
       OD) and the whole medical group, ATT B included, because these are jet
       seats and ATT B means no flying. A duty role mans a desk, so ATT B is the
       carve-out (work:true rows test canWork). It warns, never blocks. The shift
       runs 19:00–07:00: day.input's midnight tail (events.ts) is what lets the
       morning half see tomorrow's inputs, so a man fine tonight but overseas from
       tomorrow is caught here with no extra code. */
    (day.sacrew||[]).forEach((sa:any)=>{
      day.input.forEach((inp:any)=>{ if(inp.id!==sa.id)return;
        if(canSpare(inp.type))return;
        if(sa.work&&canWork(inp.type))return;
        if(!overlap(sa.s,sa.e,inp.s,inp.e))return;
        const dn=isDownchit(inp.type), wc=dn?'DNIF_FLY':'LEAVE_FLY';
        markChip(di,sa.id,'C',wc); markRing(di,sa.id,'hard',wc);
        const why=inp.remarks?` — reason: ${inp.remarks}`:'';
        add('hard',dn?'DNIF_FLY':'LEAVE_FLY',[sa.id],
          `${inp.type} but on ${sa.label} — ${dn?'medically down':'overseas'}${why}`,sa.key);
      });
    });
    /* THE THREE AVALON CHECKS OF 7 SEP 26 (owner — "Avalon main will also be
       checked for SC NIGHT qual", "u still cannot put a wso in the front seat",
       "they should also not be planned as a main and a spare the same timing …
       or be planned on a duty for Avalon and planned as Avalon main or spare").
       Each is the SC-spare rule below re-cut for AVALON, and each is anchored on
       the seat (or desk row) it is about, which is what lets the exempt line's
       puck ring for its OWN rule and nothing else (html.ts). The wave stays
       noconf: none of this reads day.events or crew rest, so a man on AVALON
       tonight and a sortie tomorrow morning still raises nothing — the owner
       has not asked for that. BB is AVALON's twin (owner, 7 Sep 26 — "bb main
       and spare rules are exactly the same. And the duties") — events.ts
       collects every noconf wave and both desks into day.sacrew, so this loop
       and the availability look above cover BB with no BB-specific code; a BB
       shift left with blank times has no window and is simply not collected. */
    const avPairSeen:any=new Set();
    (day.sacrew||[]).forEach((sa:any)=>{
      const p=realP(sa.id); if(!p)return;
      /* SC CURRENCY ON EVERY JET SEAT — MAIN and SPARE (owner, 7 Sep 26: "Avalon
         main will also be checked for SC NIGHT qual", then the same day "AVALON
         SPARE also requires SC NIGHT" — the SC-spare precedent, where currency
         is the man's own qualification and the spare exemption never covered
         it). Never the desk. The kind is read off the shift as scheduled
         (scShiftKind, the same body SC uses): AVALON's 19:00–07:00 is a night
         shift; a BB shift typed inside the day asks for SC DAY instead of
         quietly asking nothing. Reads the seat, not the pilot: a WSO in a rear
         seat is checked too. */
      if(sa.seat){
        const kind=scShiftKind(sa.s,sa.e);
        if(kind&&!scQualOK(sa.id,kind)){
          markChip(di,sa.id,'Q','SC_QUAL');markRing(di,sa.id,'hard','SC_QUAL');
          add('hard','SC_QUAL',[sa.id],
            `${kind==='day'?'SC DAY':'SC NIGHT'} currency needed for ${sa.label} ${sa.role} (${hm24(sa.s)}–${hm24(sa.e)}) — ${p.cs} is not current`,sa.key);
        }
      }
      /* THE FRONT SEAT IS PILOTS-ONLY, MAIN AND SPARE ALIKE — the three
         predicates of the SC-spare seat rule, verbatim, so the crew picker
         (whose seat rules carry no exemption) and the warning list agree on a
         drag-drop. The rear seat stays unruled, as it is on the SC spare. */
      if(sa.seat==='p'){
        const tag=`(${sa.label} ${sa.role})`;
        if(p.pers){markChip(di,sa.id,'Q','QUAL');markRing(di,sa.id,'hard','QUAL');add('hard','QUAL',[sa.id],`${p.cs} is ground crew — cannot fly a front seat ${tag}`,sa.key);}
        else if(p.seat==='RCP'){markChip(di,sa.id,'Q','QUAL');markRing(di,sa.id,'hard','QUAL');add('hard','QUAL',[sa.id],`${p.cs} is a WSO — cannot fly FCP ${tag}`,sa.key);}
        else if(p.q==='IW'&&p.seat==='FCP'){markChip(di,sa.id,'Q','QUAL');markRing(di,sa.id,'hard','QUAL');add('hard','QUAL',[sa.id],`${p.cs} is CAT IW — a WSO category, cannot fly FCP ${tag}`,sa.key);}
      }
      /* ONE MAN IN TWO AVALON / BB PLACES IN THE SAME HOURS — MAIN + SPARE, a
         seat + the desk. NOT two desk roles (owner, 7 Sep 26 — "two avalon desk
         roles is ok"): a desk row asks only about SEATS. Nothing on these waves
         is an event, so the ordinary clash loop is blind here; avSeatHit walks
         the model, the same body the picker reads before a plant. Said once per
         pair (the seen-set, the SC precedent), anchored on the first place in
         the day's order — seats before desks — so that copy rings; both are
         named in the words. */
      avSeatHits(di,sa.id,sa.s,sa.e,sa.key,sa.role==='DUTY').forEach((hit:any)=>{
        const pk=[sa.key,hit.key].sort().join('|')+'·'+sa.id;
        if(avPairSeen.has(pk))return; avPairSeen.add(pk);
        markChip(di,sa.id,'C','DOUBLE_BOOK'); markRing(di,sa.id,'hard','DOUBLE_BOOK');
        const mine=sa.role==='DUTY'?sa.label:`${sa.label} ${sa.role}`;
        /* `also` names the OTHER place, so that copy's puck can ring for the
           pair it is in (an exempt desk reads only its own rule — html.ts) */
        add('hard','DOUBLE_BOOK',[sa.id],
          `${p.cs} is on ${mine} (${hm24(sa.s)}–${hm24(sa.e)}) and also on ${hit.what} (${hm24(hit.s)}–${hm24(hit.e)})`,sa.key,{also:hit.key});
      });
    });
    /* ---- BRIEF / DEBRIEF windows round each sortie -----------------------
       The published BRIEF time (the B column, T/O − 2h20) is the hardline: the
       brief starts then, so only an event reaching PAST it steals brief time.
       An event that finishes at or before the brief time is fine — e.g. a stand
       -down 0830–0900 against a 1020 brief is no issue. Anything sitting inside
       brief → T/O means there is no time for the flight brief. Losing the brief
       or the debrief window is amber, not red (owner, 4 Aug 26): the clash
       itself already carries the red — the eaten window is advice on top of it,
       and a red here painted the whole puck red for what is a squeeze, not an
       impossibility. Land + 2h is the debrief. Both are
       tested against the person's non-flying commitments and their timed personal
       inputs — a second sortie in the window is the tight-turn rule's business,
       and all-day inputs are already caught above.                            */
    const timedInput=day.input.filter((i:any)=>i.e-i.s<1439);
    Object.keys(byE).forEach((id:any)=>{
      /* personnel (ground crew) carry only conflict, long-day and the 7-day run
         — an incentive passenger has no flight brief of his own to lose */
      if(PEOPLE[id]&&PEOPLE[id].pers)return;
      const legs=byE[id].filter((e:any)=>e.kind==='fly'), others=byE[id].filter((e:any)=>e.kind!=='fly');
      legs.forEach((lg:any)=>{
        const [bs,bt]=legBriefWin(lg), [ls,de]=legDebriefWin(lg);   // brief time is the hardline, not T/O − 3h
        const hits=(s:any,e:any)=>others.filter((o:any)=>overlap(s,e,o.s,o.e)).map((o:any)=>o.label)
          .concat(timedInput.filter((i:any)=>i.id===id&&overlap(s,e,i.s,i.e)).map((i:any)=>i.type));
        const hb=hits(bs,bt);
        if(hb.length){markChip(di,id,'NB','NO_BRIEF');markRing(di,id,'adv','NO_BRIEF');
          add('adv','NO_BRIEF',[id],noBriefSays(lg,hb.join(', ')),lg.slot);}
        const hd=hits(ls,de);
        if(hd.length){markChip(di,id,'DB','DEBRIEF');markRing(di,id,'adv','DEBRIEF');
          add('adv','DEBRIEF',[id],debriefSays(lg,hd.join(', ')),lg.slot);}
      });
    });
    /* ---- sim brief / debrief windows -------------------------------------
       EP profiles brief 15 min prior and debrief 30 min after. The AMT carries
       its own BRIEF row, so that row's time IS the hard line — nothing is added
       in front of it.                                                          */
    (day.simwin||[]).forEach((sw:any)=>sw.ids.forEach((id:any)=>{
      if(PEOPLE[id]&&PEOPLE[id].pers)return;       // ground crew — no sim brief of their own to lose
      const mine=(byE[id]||[]);
      const hits=(s:any,e:any)=>mine.filter((o:any)=>overlap(s,e,o.s,o.e)).map((o:any)=>o.label)
        .concat(timedInput.filter((i:any)=>i.id===id&&overlap(s,e,i.s,i.e)).map((i:any)=>i.type));
      if(simHasBrief(sw)){ const h=hits(sw.bs,sw.be);
        /* amber like NO_BRIEF (owner, 4 Aug 26) — same rule, sim flavour */
        if(h.length){markChip(di,id,'SB','SIM_BRIEF');markRing(di,id,'adv','SIM_BRIEF');
          add('adv','SIM_BRIEF',[id],simBriefSays(sw,h.join(', ')),sw.key);} }
      if(simHasDebrief(sw)){ const h=hits(sw.ds,sw.de);
        if(h.length){markChip(di,id,'SD','SIM_DEBRIEF');markRing(di,id,'adv','SIM_DEBRIEF');
          add('adv','SIM_DEBRIEF',[id],simDebriefSays(sw,h.join(', ')),sw.key);} }
    }));
    /* ---- double-turn summary --------------------------------------------
       One line at the head of the day telling the next scheduler how many
       bodies are flying twice. Amber, not red (owner, 4 Aug 26): double
       turning is routine and planned, so the summary now matches the amber DT
       chips instead of shouting over them. dturns (above) keeps a man whose
       only "second sortie" overlaps his first out of this count — he is
       double-booked, not double turning, and the hard clash already says so. */
    const dts=Object.keys(byP).filter((id:any)=>byP[id].length>=2&&!(PEOPLE[id]&&PEOPLE[id].pers)&&dturns(byP[id]));
    if(dts.length)add('adv','DT_SUM',dts,`${dts.length} ${dts.length===1?'person is':'people are'} double turning: ${dts.map((id:any)=>PEOPLE[id]?PEOPLE[id].cs:id).join(', ')}`);
    /* ---- long work day --------------------------------------------------
       Report (T/O − 3h, or the published in-time) through land + 2h, or plain
       start→end for everything that is not flying. Over 12h and the day gets a
       grey note stating the actual hours. Personal inputs are left out — an
       all-day input would read as a 24-hour work day.                          */
    Object.keys(byE).forEach((id:any)=>{
      const w=workSpan(byE[id]); if(!w)return;
      /* ef keeps the FLY event that set the day's END (null when a non-flying
         commitment did), so the note can name the debrief pad baked into it. */
      const s=w.s,e=w.e,ef=w.ef,span=w.span;
      if(span>VCONF.longDay){markChip(di,id,'LD','LONGDAY');markRing(di,id,'note','LONGDAY');
        /* NAME THE DEBRIEF ASSUMPTION (owner, 15 Aug 26 — the same "state the
           assumption" as crew rest). When a sortie closes the day, its end is
           the landing plus the assumed 2h debrief pad, so the note prints the
           real landing and flags the pad — a scheduler who knows this crew
           leaves fast can discount it. A non-flying finish is a fixed clock
           time with nothing to assume, so it stays bare. */
        const back=ef?`${hm24(e)} (last landing ${hm24(ef.ld)} + ${lgT(VCONF.debrief)} debrief assumed)`:`${hm24(e)}`;
        add('note','LONGDAY',[id],`${PEOPLE[id]?PEOPLE[id].cs:id} has a long work day: ${dur(span)}, ${stated(s)} → ${back}`);}
    });
    /* the run breaks its limit ON this day, which is the day the scheduler has
       to clear — so that is where the flag lands */
    Object.keys(RUNLEN[idx]||{}).forEach((id:any)=>{
      const n=RUNLEN[idx][id];
      if(n>VCONF.maxRun){
        markChip(di,id,'RUN','DAYS_RUN'); markRing(di,id,'hard','DAYS_RUN');
        add('hard','DAYS_RUN',[id],runSays(id,n));}
    });
    /* ---- crew rest across the day boundary -------------------------------
       12h clear from the previous day's last commitment — ANY commitment
       (owner, 21 Aug 26: "anything that ends the day prior and affects the
       12 hour crew rest will be a warning"). A sortie's day ends at land +
       2h (the debrief); a shift, a duty desk row, a sim, a ground event or
       a programme item ends when it ends. The
       squadron's nominal report is T/O − 3h; if the aircrew has actually been
       TOLD to come in earlier than legal — through the published in-time or the
       brief time, whichever is earlier — that is a hard breach, not a caution.

       AN SC SHIFT COUNTS THE SAME AS A SORTIE, at the hours written on the line
       and no others. It ends the previous day for rest purposes at its LD (no
       debrief tail is added), and it must itself start 12h clear — the shift's
       own start time IS the report time, so no 3h lead and no brief lead are
       taken off it either.

       MONDAY IS NO LONGER EXEMPT (the cross-week work — owner: a late Sunday
       must bust the next Monday's rest). The old `if(idx>0)` guard meant the
       first loaded day had no yesterday and the whole block was skipped;
       prevSundaySeed (weekctx.ts) now stands in as Monday's yesterday, built
       from the previous week's bundle by the very same buildDay the loaded
       days use, shaped exactly like ev[idx-1]. Its di is null, so the
       markTrace below no-ops (its own guard) and the breach carries
       prevDi:null — the trace belongs to a day this WARN cannot address, and
       the warning's own message already names Sunday and its end time. An
       unauthored previous week seeds empty maps and the guards below skip
       every man, byte-identical to the old REST[di]={} branch. */
    const prevSeed:any=idx>0?ev[idx-1]:(PREVSUN=restDayAt(-1));
    crewRestDay(prevSeed,day,di,false,add);
    // crew combination matrix + OCU without IP — shown as puck rings
    /* a SPARE+SPARE overlap is seen from both formations' loops below, so the
       pair is remembered and printed once — day-scoped, like the day loop */
    const scPairSeen:any=new Set();
    day.forms.forEach((f:any)=>{
      f.acs.forEach((ac:any)=>{ const p=realP(ac.p),w=realP(ac.w);
        /* ---- combination matrix (F-15 Table 1.5-2, owner Aug 5 '26) ----
           Graded only when the front seat is a CAT A–D or OCU pilot and the
           back seat is a CAT A–D or OCU WSO: an instructor in either seat
           clears the matrix outright — an instructor pilot (IP/IR/FI) flies
           with anyone, and an instructor WSO with any front seat (the
           table's IR footnote on the OCU-pilot column is disregarded —
           owner). A mis-seated body is the seat rules' (QUAL) business, not
           this one's. The gradings:
             OCU pilot + CAT A–D WSO  → Warning, not an authorised combination
             CAT A–D pilot + OCU WSO  → Warning, not an authorised combination
             OCU pilot + OCU WSO      → Advisory — a crew solo, only allowed
                                        under the Basic Course Syllabus
             D+C, C+D, D+D (fmr+WSO)  → Advisory — CO approval required
           This SUPERSEDES the old two-OCU hard rule: the matrix reads that
           pairing as the crew-solo advisory. Ring only, no chip — the
           ILLEGAL_CREW shape. */
        if(p&&w&&p.seat==='FCP'&&w.seat==='RCP'&&!isInstrPilot(p.q)&&!isInstr(w.q)){
          if(isOcu(p.q)&&isOcu(w.q)){markRing(di,ac.p,'adv','CREW_SOLO');markRing(di,ac.w,'adv','CREW_SOLO');markChip(di,ac.p,'CP','CREW_SOLO');markChip(di,ac.w,'CP','CREW_SOLO');add('adv','CREW_SOLO',[ac.p,ac.w],`${p.cs} (OCU pilot) with ${w.cs} (OCU WSO) in ${f.label} — a crew solo, only allowed under the Basic Course Syllabus`,ac.key);}
          else if(isOcu(p.q)||isOcu(w.q)){markRing(di,ac.p,'hard','ILLEGAL_CREW');markRing(di,ac.w,'hard','ILLEGAL_CREW');markChip(di,ac.p,'CPH','ILLEGAL_CREW');markChip(di,ac.w,'CPH','ILLEGAL_CREW');add('hard','ILLEGAL_CREW',[ac.p,ac.w],isOcu(p.q)?`OCU pilot ${p.cs} with CAT ${w.q} WSO ${w.cs} — not an authorised combination (${f.label})`:`OCU WSO ${w.cs} with CAT ${p.q} pilot ${p.cs} — not an authorised combination (${f.label})`,ac.key);}
          else if((p.q==='D'&&(w.q==='C'||w.q==='D'))||(p.q==='C'&&w.q==='D')){markRing(di,ac.p,'adv','CO_APPROVAL');markRing(di,ac.w,'adv','CO_APPROVAL');markChip(di,ac.p,'CP','CO_APPROVAL');markChip(di,ac.w,'CP','CO_APPROVAL');add('adv','CO_APPROVAL',[ac.p,ac.w],`CAT ${p.q} pilot ${p.cs} with CAT ${w.q} WSO ${w.cs} in ${f.label} — CO approval required`,ac.key);}
        }
        /* Personnel (ground crew) in a FRONT seat is illegal — they hold no
           flying qualification and may ride a rear seat only. In the REAR seat
           they raise the crew-pairing CP advisory instead: an incentive ride is
           a non-standard pairing that needs approval (owner, Aug 26). The seat
           and combination checks below key on FCP/RCP and never catch a 'GND'
           seat, so these two lines are the whole story for personnel. */
        if(p&&p.pers){markChip(di,ac.p,'Q','QUAL');markRing(di,ac.p,'hard','QUAL');add('hard','QUAL',[ac.p],`${p.cs} is ground crew — cannot fly a front seat (${f.label})`,ac.key+'.p');}
        if(w&&w.pers){markChip(di,ac.w,'CP','PAX_CREW');markRing(di,ac.w,'adv','PAX_CREW');add('adv','PAX_CREW',[ac.w],`${w.cs} is riding the rear seat of ${f.label} as an incentive passenger — this crew pairing needs approval`,ac.key+'.w');}
        // Q — seat qualification: a WSO can't fly FCP. The rear seat carries no
        // instructor rule: any pilot may ride the back (owner, 7 Sep 26 — "don't
        // flag out that they are in an illegal seat"; the AAR supervision rule
        // below, currency and the combination matrix are separate and still apply)
        if(p&&p.seat==='RCP'){markChip(di,ac.p,'Q','QUAL');markRing(di,ac.p,'hard','QUAL');add('hard','QUAL',[ac.p],`${p.cs} is a WSO — cannot fly FCP (${f.label})`,ac.key+'.p');}
        /* belt and braces: CAT IW is a WSO-only category, so an IW record whose
           seat says FCP is inconsistent data — the Quals-page dropdowns never
           offer IW to a pilot, but a hand-edit could. Flag it, don't hide it. */
        if(p&&p.q==='IW'&&p.seat==='FCP'){markChip(di,ac.p,'Q','QUAL');markRing(di,ac.p,'hard','QUAL');add('hard','QUAL',[ac.p],`${p.cs} is CAT IW — a WSO category, cannot fly FCP (${f.label})`,ac.key+'.p');}
        /* AAR — the remarks call for it and the FRONT seat is not current.
           A man who is not current may still fly it as TRAINING, but only with
           someone cleared to teach that AAR sitting behind him (owner,
           10 Aug 26). So the three outcomes below, in order of what the
           scheduler has to do about them:
             back seat is an instructor pilot holding the mark → nothing. This
               is the legal training sortie, and flagging it was the bug.
             back seat is an instructor pilot WITHOUT it → AAR_INSTR, and the
               warning names the BACK-SEATER and anchors on his seat, because
               he is the man who has to change.
             back seat empty, a WSO, or a pilot who is not an instructor →
               AAR_QUAL, unchanged: nobody aboard could supervise him.
           Night versus day is already decided — ac.aar is 'DAAR' or 'NAAR'
           straight out of aarNeed, so the same call answers both. */
        if(ac.aar&&p&&!isSpecial(ac.p)&&!aarOK(ac.p,ac.aar)){
          const teacher=!!(w&&w.seat==='FCP'&&isInstrPilot(w.q)&&!isSpecial(ac.w));
          const day=ac.aar==='NAAR'?'night':'day';
          if(teacher&&aarInstrOK(ac.w,ac.aar)){/* supervised — no warning */}
          else if(teacher){
            /* BOTH men wear it, as the combination matrix above does. The
               message names the back-seater and the key anchors on his seat
               because he is the one to change — but the jet is illegal, not
               just his seat, and ringing him alone would leave the pilot who
               is actually flying an AAR he is not current for reading clean.
               Back-seater first in `who`: the message opens with his name. */
            markChip(di,ac.w,'Q','AAR_INSTR');markRing(di,ac.w,'hard','AAR_INSTR');
            markChip(di,ac.p,'Q','AAR_INSTR');markRing(di,ac.p,'hard','AAR_INSTR');
            add('hard','AAR_INSTR',[ac.w,ac.p],
              `${w.cs} is not cleared to instruct ${ac.aar} — ${p.cs} is not ${ac.aar} current and ${f.label} remarks call for ${day} AAR`,ac.key+'.w');}
          else{
            markChip(di,ac.p,'Q','AAR_QUAL');markRing(di,ac.p,'hard','AAR_QUAL');
            add('hard','AAR_QUAL',[ac.p],
              `${p.cs} is not ${ac.aar} current — ${f.label} remarks call for ${day} AAR`,ac.key+'.p');}} });
      const ocus=f.fcps.filter((id:any)=>PEOPLE[id]&&isOcu(PEOPLE[id].q));
      const hasIP=f.fcps.some((id:any)=>PEOPLE[id]&&isInstr(PEOPLE[id].q));
      /* an IP in the BACK seat supervises just as well as one in the front —
         the seat rules explicitly allow it, so looking only at FCPs both
         flagged the standard OCU sortie and missed an OCU in the rear */
      /* crewAll used to be `.filter(Boolean)` — truthy-only, so the ALL AVAIL
         sentinel (a special PEOPLE record, never a real body) flowed straight
         through into OCU_NO_IP's ocuAll/anyIP and NO_IR's who/ring/chip below,
         landing a red ring + CPH chip on a sentinel that fills a seat with no
         one really in it. events.ts:37 builds the same crew list and already
         excludes specials this way; validate.test.ts pins "ALL AVAIL sentinels
         never raise warnings" and this line was the hole in that invariant.
         The warning itself still fires for the real crew that remains —
         only the sentinel stops being named/ringed/chipped. */
      const crewAll=[...new Set(f.acs.reduce((a:any,x:any)=>a.concat([x.p,x.w]),[]).filter((id:any)=>id&&PEOPLE[id]&&!isSpecial(id)))];
      const ocuAll=crewAll.filter((id:any)=>PEOPLE[id]&&isOcu(PEOPLE[id].q));
      const anyIP=crewAll.some((id:any)=>PEOPLE[id]&&isInstr(PEOPLE[id].q));
      if(ocuAll.length&&!anyIP){ocuAll.forEach((id:any)=>{markRing(di,id,'adv','OCU_NO_IP');markChip(di,id,'CP','OCU_NO_IP');});add('adv','OCU_NO_IP',ocuAll,`OCU in ${f.label} with no IP`,f.key);}
      /* NO_IR — an instrument rating test needs an IR examiner aboard (owner,
         Aug 5 '26). The mission lives in f.shift (collectEvents folds f.msn
         into it); a per-aircraft IRT lives in that aircraft's remarks. IRT in
         the formation's msn wants an IR anywhere in the formation; IRT in one
         aircraft's remarks wants the IR in THAT aircraft. Ring only, no chip —
         same shape as OCU_NO_IP, and red: the sortie cannot be examined. */
      const isIR=(id:any)=>{const q=realP(id);return !!(q&&q.q==='IR');};
      if(/\bIRT\b/i.test(String(f.shift||''))&&crewAll.length&&!crewAll.some(isIR)){
        crewAll.forEach((id:any)=>{markRing(di,id,'hard','NO_IR');markChip(di,id,'CPH','NO_IR');});
        add('hard','NO_IR',crewAll,`IRT in ${f.label} with no IR examiner`,f.key);}
      f.acs.forEach((ac:any)=>{ if(!/\bIRT\b/i.test(String(ac.rmks||'')))return;
        const crew=[ac.p,ac.w].filter((id:any)=>id&&realP(id));
        if(crew.length&&!crew.some(isIR)){crew.forEach((id:any)=>{markRing(di,id,'hard','NO_IR');markChip(di,id,'CPH','NO_IR');});
          add('hard','NO_IR',crew,`IRT remarks on ${f.label} with no IR examiner`,ac.key);}});
      /* SC currency — read off the shift as scheduled, both MAIN and SPARE.
         This is about the person's own qualification, not a clash with another
         commitment, so the spare exemption does not cover it. */
      if(f.sc){
        const kind=scShiftKind(f.s,f.e);
        if(kind){
          const wrong=(f.allCrew||[]).filter((id:any)=>PEOPLE[id]&&!isSpecial(id)&&!scQualOK(id,kind));
          if(wrong.length){
            const win=`${hm24(f.s)}–${hm24(f.e)}`;
            wrong.forEach((id:any)=>{markChip(di,id,'Q','SC_QUAL');markRing(di,id,'hard','SC_QUAL');});
            add('hard','SC_QUAL',wrong,
              `${kind==='day'?'SC DAY':'SC NIGHT'} currency needed for ${f.label} (${win})`
              +` — ${wrong.map((id:any)=>PEOPLE[id].cs).join(', ')} ${wrong.length===1?'is':'are'} not current`,f.key);
          }
        }
        /* WHO MAY NOT STAND AN SC SPARE. Standing by means being on the island
           and fit to walk, so the bar is canSpare() — the owner's rule, local
           yes and overseas no, with the medical group carved out because those
           four keep the man here but not fit (owner, 10 Aug 26). A local
           commitment does NOT bar a spare: he is standing by, not tasked, so
           leave at home, a meeting or a course all still leave him reachable.
           The spare exemption keeps this crew out of every other clash rule,
           so this is the only place any of it can be caught at all.
           Deliberately written against "a standalone spare" rather than SC
           alone — and the AVALON/BB version of it (every seat and the desk,
           with the ATT B desk carve-out) is the day.sacrew loop above. */
        (f.spareCrew||[]).forEach((id:any)=>{
          day.input.forEach((inp:any)=>{ if(inp.id!==id)return;
            if(canSpare(inp.type))return;
            if(!overlap(f.s,f.e,inp.s,inp.e))return;
            const dn=isDownchit(inp.type), wc=dn?'DNIF_FLY':'LEAVE_FLY';
            markChip(di,id,'C',wc); markRing(di,id,'hard',wc);
            const why=inp.remarks?` — reason: ${inp.remarks}`:'';
            /* say WHICH of the two disqualifies him — "overseas" and "medically
               down" are different problems and the scheduler fixes them
               differently */
            add('hard',dn?'DNIF_FLY':'LEAVE_FLY',[id],
              `${inp.type} but standing SC SPARE — ${dn?'medically down':'overseas'}`
              +`, ${f.label}${why}`,f.key); }); });
        /* TWO SC SEATS IN THE SAME HOURS (owner, 31 Aug 26 — "give a warning
           conflict if u are planned for MAIN and SPARE in the same time
           framing … the 1300 is not a conflict"; SPARE+SPARE ruled the same
           red). A spare is deliberately absent from EVD, so the ordinary
           DOUBLE_BOOK loop cannot see him — this asks the model instead,
           through the same standaloneHits body (scSeatHits — every hit) the crew picker's slotBar reads,
           so what bars a plant and what reds after a drag-drop cannot drift.
           MAIN+MAIN needs nothing here: main shifts are events and the clash
           loop already reds them. Abutting shifts never fire — overlap() is
           half-open, AM into PM at 13:00 stays two clean halves. Reuses the
           DOUBLE_BOOK code (the DNIF/LEAVE precedent above): the label "two
           events at once" is exactly the fault, and the message carries the
           spare-specific wording. Anchored on the SPARE seat so the week's
           exempt-line ring (html.ts) finds it; the MAIN copy rings off the
           ordinary per-person chip. */
        (f.spareAcs||[]).forEach((sa:any)=>{
          [['p',sa.p],['w',sa.w]].forEach(([seat,id]:any)=>{ if(!id||!PEOPLE[id]||isSpecial(id))return;
            const own=`${sa.key}.${seat}`;
            /* every place, not the first (audit, 8 Sep 26 — the avSeatHits
               precedent): two spares + the desk is three pairs at the walk
               level; add()'s message-dedupe folds the two identical spare↔desk
               lines to one, so the user sees the desk clash the old first-hit
               walk dropped entirely (a distinct-worded case like MAIN+SPARE+desk
               still shows all three) */
            scSeatHits(di,id,f.s,f.e,own).forEach((hit:any)=>{
              const pk=[own,hit.key].sort().join('|')+'·'+id;
              if(scPairSeen.has(pk))return; scPairSeen.add(pk);
              markChip(di,id,'C','DOUBLE_BOOK'); markRing(di,id,'hard','DOUBLE_BOOK');
              add('hard','DOUBLE_BOOK',[id],
                `${PEOPLE[id].cs} is standing SC SPARE (${f.label} ${hm24(f.s)}–${hm24(f.e)})`
                +` and also on ${hit.what} (${hm24(hit.s)}–${hm24(hit.e)})`,own); }); }); });
        /* THE SPARE FRONT SEAT IS PILOTS-ONLY (owner, 31 Aug 26 — "a wso
           can't be planned for FCP"; the pilot-in-rear-seat mirror was
           offered and DECLINED, so the rear spare seat stays unruled here).
           Spare rows never reach f.acs, so the flying seat rules above cannot
           see them; the front-seat predicates are mirrored from there so the
           crew PICKER and the warning list agree — slotBar's seat rules carry
           no spare gate (avail.ts), so the picker already refuses a WSO AND a
           ground-crew body from a spare front seat; the validator must red the
           same drag-drop or it re-opens the very picker/validator drift this
           whole rule closes (ground crew hold no flying qualification at all,
           the stricter case of "not a pilot"). */
        (f.spareAcs||[]).forEach((sa:any)=>{ const sp=realP(sa.p); if(!sp)return;
          if(sp.pers){markChip(di,sa.p,'Q','QUAL');markRing(di,sa.p,'hard','QUAL');add('hard','QUAL',[sa.p],`${sp.cs} is ground crew — cannot fly a front seat (${f.label} SPARE)`,sa.key+'.p');}
          else if(sp.seat==='RCP'){markChip(di,sa.p,'Q','QUAL');markRing(di,sa.p,'hard','QUAL');add('hard','QUAL',[sa.p],`${sp.cs} is a WSO — cannot fly FCP (${f.label} SPARE)`,sa.key+'.p');}
          else if(sp.q==='IW'&&sp.seat==='FCP'){markChip(di,sa.p,'Q','QUAL');markRing(di,sa.p,'hard','QUAL');add('hard','QUAL',[sa.p],`${sp.cs} is CAT IW — a WSO category, cannot fly FCP (${f.label} SPARE)`,sa.key+'.p');}});
      }
    });
    /* SANS AVAILABILITY (owner, 14 Aug 26) — a SANS body planted into a
       flying / OFT / AMT slot outside what he actually filed raises a
       persistent amber Advisory, wearing the amber A chip (owner, 26 Aug 26 —
       "shouldn't sans planned outside availability be A, instead of CP?";
       it launched on CP, the PAX_CREW precedent, but CP's hover says a crew
       PAIRING needs approval, which is not this man's problem — A is the
       planned-against-what-was-filed chip, the same family as SHIFT_SOFT and
       SC_INTIME, and its label now names this case too).
       Checks are built from day.fly (domain
       'fly', window IN-TIME → dekit since 26 Aug 26 — owner: "SANS should
       consider IN TIME till land plus 30 minutes for availability".
       min(e.report,e.step) opens the front at the published in-time (or a
       typed SC B) when one shows the crew earlier than the step / shift
       start, and stays the plain step→dekit pad when no in-time is
       published or the clock is later — a late in-time can never SHRINK
       the occupied window, the same guard insOf/workSpan put on crew rest.
       This is the same front edge slotBar judges a flying seat against:
       slotRules' sansStart reads the identical seatIntime body (events.ts).
       AVALON excluded because saExempt
       formations never reach day.fly at all) plus day.events' sim entries
       whose key names the device (`s:di.amt.ri` / `s:di.oft.ri` — domain is
       the captured word, window is the event's own s→e). A duty, ground or
       programme event carries no matching key, so it never reaches
       sansGate — "any ground event can also be planned" is the owner's rule
       for slotBar too, and the two must not drift apart.
       ONLY 'not-offered' and 'window' raise. 'none' — nothing filed at all —
       is DELIBERATELY silent here: the owner's own example only ever
       describes planting AGAINST a filed record ("indicates A and O…
       planned for F"), and firing on a bare no-record would put this
       Advisory on every seeded SANS flyer the demo week already carries
       (romeo, vinci and krait fly; waldo rides OFT as pax) — seed INPUTS
       carry zero SANS records, so that would break reference parity for a
       rule nobody asked to cover. No-record still reads to the scheduler —
       the palette greys the puck and prints the reason, and the toast on
       planting says the same — it simply never becomes a persistent
       Advisory. 'ok' and 'na' are not a problem and need no comment. */
    const sansChecks:any[]=[];
    day.fly.forEach((e:any)=>sansChecks.push({id:e.id,domain:'fly',s:Math.min(e.report,e.step),en:e.dekit,label:e.label,key:e.key}));
    day.events.forEach((e:any)=>{ const m=/^s:\d+\.(amt|oft)\./.exec(String(e.key||'')); if(!m)return;
      sansChecks.push({id:e.id,domain:m[1],s:e.s,en:e.e,label:e.label,key:e.key}); });
    sansChecks.forEach((c:any)=>{ const p=PEOPLE[c.id]; if(!p||!p.san)return;
      const g=sansGate(c.id,day.dt,c.domain,c.s,c.en);
      if(g.status!=='not-offered'&&g.status!=='window')return;
      markRing(di,c.id,'adv','SANS_AVAIL');markChip(di,c.id,'A','SANS_AVAIL');
      const reason=g.status==='not-offered'?`not offering ${SANS_LABEL[c.domain]} today`
        :`available ${hm24(g.off.s)}–${hm24(g.off.e)} only`;
      add('adv','SANS_AVAIL',[c.id],`${p.cs} planned for ${c.label} — ${reason}`,c.key);
    });
    /* Q (sims) — the sim box guards its FRONT seat like the jet (ground crew,
       a WSO, an IW-in-FCP record — none may occupy it). The REAR seat has no
       seat rule at all: an OFT or AMT session does not need an instructor in
       the back (owner, 14 Aug 26 — the jet's IP/IR/FI rear-seat rule used to
       be copied here, and only the jet keeps it). */
    (day.simcrew||[]).forEach((s:any)=>{ const p=realP(s.p);
      if(p&&p.pers){markChip(di,s.p,'Q','QUAL');markRing(di,s.p,'hard','QUAL');add('hard','QUAL',[s.p],`${p.cs} is ground crew — cannot take the front seat (${s.label})`,`s:${di}.${s.kind}.${s.ri}.p`);}
      if(p&&p.seat==='RCP'){markChip(di,s.p,'Q','QUAL');markRing(di,s.p,'hard','QUAL');add('hard','QUAL',[s.p],`${p.cs} is a WSO — cannot take the front seat (${s.label})`,`s:${di}.${s.kind}.${s.ri}.p`);}
      if(p&&p.q==='IW'&&p.seat==='FCP'){markChip(di,s.p,'Q','QUAL');markRing(di,s.p,'hard','QUAL');add('hard','QUAL',[s.p],`${p.cs} is CAT IW — a WSO category, cannot take the front seat (${s.label})`,`s:${di}.${s.kind}.${s.ri}.p`);}
    });
    /* A DESK WITH A MAN ON IT AND NO TIMES EARNS HIM NOTHING, AND SAYS SO
       (owner, 20 Sep 26 — "I would also like u to give the warning On the day
       itself, while you're building it").
       His own case: a man on the SDO desk for a Sunday, the day published, no
       OIL, and no screen admitting why. OIL is minted strictly from written
       times, so a blank desk mints nothing — correct, and silent. THIS is the
       valuable half of the warning: here the fix is free, because after the
       publish it costs an amendment.
       Weekends and public holidays only — they are the only days that earn OIL
       at all, so a blank desk on a Tuesday is ordinary and must say nothing.
       The weekend comes from the day's own name; the holiday from the hook,
       because only Leave War holds that answer. */
    /* A NOUGHT-MINUTE SORTIE ([OIL-SEATS-CAN-EARN] step 8; D49, owner 22 Sep 26
       — "It should still earn — leave it as it is"). A line typed with the same
       take-off and landing STILL PAYS the man: he reported and debriefed, so he
       was at work whatever the times say. Both reviewers read that half day as
       the app paying off its own padding and asked for the line to be refused;
       the only reason it is not is a fact about how the squadron runs, which the
       code cannot hold. The ruling stands and nothing about the money changes.
       What was missing is that one of the two times is plainly wrong and no
       screen said so. This says it — on ANY day, because a nought-minute sortie
       is wrong on a Tuesday as well, and as an ADVISORY, because the line is not
       being refused. It names the line, not the crew: the times are the
       scheduler's to fix and no pilot's fault. */
    ((DAYS[di]||{}).waves||[]).forEach((wv:any,gi:any)=>{
      (wv.formations||[]).forEach((f:any,li:any)=>{
        if(!fltNoLen(f))return;
        add('adv','FLT_NO_LEN',[],fltNoLenMsg(f,wv),`ff:${di}.${gi}.${li}.ld`);
      });
    });
    const earnsOil=day.dow==='Saturday'||day.dow==='Sunday'||HOOKS.oilEarningDay(di);
    if(earnsOil){
      const blind=dayOilBlind(DAYS[di]||{});
      if(blind.length){
        const {list,verb}=blindDesks(blind);
        /* "no USABLE times" (the follow-up code read, G1). "No times" was true
           of every row this named until a nought-minute standalone shift joined
           the list: that shift HAS two times typed on it, and being told it has
           none is a sentence a scheduler can see is false while he is looking at
           them. Unusable covers both — a blank pair and an equal one. */
        add('hard','OIL_NO_TIMES',[],`${list} ${verb} no usable times — nobody on ${blind.length>1?'them':'it'} earns OIL for this day`);
      }
      /* NOBODY EARNS UNTIL THE DAY IS PUBLISHED ([OIL-AUTO-REMOVE] §2.3, owner
         21 Sep 26). All OIL now lands on publication — the schedule's and a
         duty-and-commitments claim's alike — which is what lets the board's OIL
         mode be the single door. The risk he accepted is a weekend nobody
         bothers to publish paying nobody, and the mitigation he chose is a
         standing practice of publishing every day PLUS a reminder to every
         scheduler: "ok u can set it as a reminder to all schedulers."
         This is that reminder. It speaks only on a day that CAN earn, that has
         somebody down to earn something, and that has not gone out yet — so it
         is silent on an ordinary weekday, silent on an empty weekend, and
         silent the moment the day is published. */
      /* A WEEKEND NO LEAVE WAR PERIOD COVERS (owner's ruling D19, 22 Sep 26 —
         "Perhaps indicate that the leave war period doesn't exist, create it").
         A weekend counts as a day that earns whether or not a war holds it —
         that is the calendar — but the credit can only be written into a war
         that DOES hold the date. Driven on Sat 13 Feb 27: the day offered OIL
         Earn, drew a full green bar, promised a full day, told the scheduler to
         publish it before the day was out, and then reported "No conflicts
         flagged for this day" while the war had no cell for that date and never
         could. The app instructed him to do something that cannot work and
         reported success. So the day NAMES what is missing, and it keeps saying
         so after publication — publishing does not fix it, and a day that reads
         clean is the lie. The way out is offered beside it, on screen. */
      const noPeriod=oilWouldEarn(di)?HOOKS.oilNoPeriod(di):'';
      if(noPeriod){
        add('adv','OIL_NO_PERIOD',[],`There is no leave war period for ${noPeriod}, so no OIL can be earned for this day — create the period on the Leave War`);
      }
      /* silent where the period is missing: telling him to publish would be
         telling him to do the one thing that cannot help */
      if(!noPeriod&&!dayApproved(di)&&oilWouldEarn(di)){
        add('adv','OIL_UNPUBLISHED',[],'This day is not published yet, so nobody earns their OIL for it — publish it before the day is out');
      }
      /* THE DAY STARTED EARNING AFTER IT WENT OUT (owner, 21 Sep 26 — R-1:
         "only the issued schedule pays", both directions). A day published as an
         ordinary working day froze "this day earns nothing"; if the war later
         calls it a public holiday, the frozen answer still governs and nobody is
         paid until the day is published again. That is the right rule — money
         comes from the issued document, not from today's calendar — but it must
         never be SILENT, or a scheduler sees an unexplained "1 change" on a day
         he did not touch and nobody is paid for a real holiday. This is what
         says so. It cannot collide with the reminder above: that one speaks only
         on an UNPUBLISHED day, this one only on a published one. */
      if(dayApproved(di)&&oilWouldEarn(di)){
        const ver=dayCurVer(di), snap:any=ver!=null?daySnapOf(di,ver):null;
        const frozen=snap&&snap.d&&snap.d.oilev;
        if(frozen&&!frozen.earns){
          add('adv','OIL_STALE_DAY',[],'This day started earning OIL after it was published — publish it again so the OIL lands');
        }
        /* AND THE OTHER WAY A PUBLISHED DAY'S MONEY MOVES UNDER IT (owner,
           22 Sep 26 — "ok fix this first"). A day issued before the app counted
           the people behind an ALL / ALL AVAIL puck on a duty desk, a sim seat or
           an extras line reads "1 pending" the moment those seats start paying —
           correctly, because republishing it WOULD credit them — but with no cell
           marked and nothing in History, because the difference is worked out
           rather than recorded. Beside the puck the count chip reads "?", since
           that block never wrote down who was there. Something changed, nothing
           says what, and the one place to look was never written down.
           This says it. It does not change what the comparison decides — that is
           still the owner's question — it stops the day asking for an amendment
           it cannot explain. */
        if(frozen&&oilOldBlockCrowd(frozen,oilEvidenceOf(di))){
          add('adv','OIL_OLD_BLOCK',[],'This day was published before the app counted who is behind an ALL AVAIL puck on a duty desk, a sim or an extras line — publish it again to credit them');
        }
      }
    }
    /* THE MIRROR OF IT (fix 4, hand pass §6 row 4). R-1 runs BOTH directions, and
       only one of them was speaking. A day published as a holiday that the war
       later stops calling one goes on paying off its frozen block — correctly,
       because money comes from the issued document and not from today's calendar
       — while the screen says nothing at all. The scheduler sees a day that is no
       longer a holiday, men still credited on the Leave War, and no way to work
       out which is right or how to change it.
       It sits OUTSIDE the earning-day block above on purpose: the whole point of
       this case is that the day is no longer one that earns, so nothing in there
       would ever run for it. */
    if(!earnsOil&&dayApproved(di)){
      const ver=dayCurVer(di), snap:any=ver!=null?daySnapOf(di,ver):null;
      const frozen=snap&&snap.d&&snap.d.oilev;
      if(frozen&&frozen.earns){
        add('adv','OIL_STALE_HOLIDAY',[],'This day stopped being a holiday after it was published — publish it again to withdraw the OIL');
      }
    }
    const SORD:any={hard:0,adv:1,note:2};
    ws.sort((a:any,b:any)=>(SORD[a.sev]??3)-(SORD[b.sev]??3));
    byDay[di]={di,dow:day.dow,warns:ws};
  });
  /* THE FORWARD TRACE ACROSS THE WEEK EDGE (owner, 23 Aug 26): within a week
     a late day draws its "Breaks <tomorrow>" box on the day that CAUSED
     the breach; the Sunday-to-next-Monday edge was the one gap left. Run the
     same extracted computation once more with next Monday's seed standing in
     as the phantom day — weekctx's bundle-or-stash, the very data the real
     Monday will validate against when its week loads — so only Sunday's own
     trace box is written here; the breach warning itself still lands on
     Monday when next week is viewed. The trace carries di:null (no in-week
     day to jump to): dayTraceHTML renders it as an informational row, and an
     unauthored, unedited next week seeds empty arrays and writes nothing. */
  NEXTMON=restDayAt(7);
  for(let index=7;index<=10;index++)crewRestDay(restDayAt(index-1),restDayAt(index),null,true,null);
  /* the crew-rest body, kept for the pre-drop query below (restIfPlaced) —
     the same closure the day loop ran, one body, now three callers */
  CREWREST_BODY=crewRestDay;
  CREWREST_BODY.dayAt=restDayAt;
  XD_CACHE=new Map();
  WARN={all,byDay,sev,chip,dash,trace,fz,lv,marks,traces};
  return WARN;
}
/* ---- A HIDDEN WARNING FLAGS NOTHING AND IS NOT COUNTED ([WARN-HIDE-KEPT], owner D469 / D472, 1 Oct 26) -------------
   "If it's hidden, the pucks shouldn't have flagging for that specific item … it should just show a strike out and it's
   darker" · "it should just show 2 issues". shownOf() is the bundle AS SHOWN under a set of hides:
   · each hidden warning is replaced, at the same index, by a COPY carrying `off` (the raw warning is never touched — the
     raw bundle is what a published version stores and what the pending comparison reads, and a hide must never read
     there as "warnings on this day changed");
   · the rings, chips, dashes and next-day marks are rebuilt by replaying `marks` / `traces` in the order the rules wrote
     them, WITHOUT the marks of a hidden warning: a mark is dropped when no shown warning of that day and code names
     that man. So a man with two warnings keeps the flag of the one still showing, and two warnings of one code on one
     man must both be hidden before that code's flag goes;
   · a mark that crosses the week's edge (Sunday's "Breaks Monday", the run's forward dotted mark) has no warning in this
     week: it is dropped only when ITS warning is hidden on next week's Monday (`xwk` — engine/weekctx.ts
     nextMondayHides: that Monday's working hides, or its issued version's when it is published, D471), and kept whenever
     that cannot be told.
   NOTHING HIDDEN → THE RAW BUNDLE ITSELF, so every byte of the old behaviour (and the reference parity) is untouched.
   `off(w)` answers for one warning; `xwk(key)` for a next-Monday key; `force` runs the replay with nothing hidden (the
   tests' proof that the replay rebuilds the very maps the day loop wrote). */
export function shownOf(raw:any,off:(w:any)=>boolean,xwk?:(k:string,w?:any)=>boolean,force?:boolean):any{
  if(!raw||!raw.marks)return raw;
  let any=false; const cp=new Map<any,any>();
  const byDay=(raw.byDay||[]).map((g:any)=>{ if(!g||!g.warns)return g; let ch=false;
    const ws=g.warns.map((w:any)=>{ if(!off(w))return w; ch=true; const c={...w,off:true}; cp.set(w,c); return c; });
    if(ch)any=true; return ch?{...g,warns:ws}:g; });
  /* the key a cross-week mark's warning WILL have on next week's Monday (day 0 of that week) */
  const xHid=(t:any)=>!!(xwk&&t.w&&t.w.di==null&&xwk(hideKey({...t.w,di:t.w.targetDi??0}),t.w));
  if(!any&&!force&&!(raw.traces||[]).some(xHid))return raw;
  const named:any={};
  byDay.forEach((g:any)=>{ if(!g||!g.warns)return; g.warns.forEach((w:any)=>{ if(w.off)return;
    const m=named[g.di]=named[g.di]||{}, st=m[w.code]=m[w.code]||new Set(); (w.who||[]).forEach((id:any)=>st.add(id)); }); });
  const has=(di:any,code:any,id:any)=>!code||!!(named[di]&&named[di][code]&&named[di][code].has(id));
  const sev:any={}, chip:any={}, dash:any={}, trace:any={}, fz:any={sev:{},chip:{},dash:{}}, lv:any={sev:{},chip:{},dash:{}};
  (raw.marks||[]).forEach((m:any)=>{ if(!has(m.di,m.code,m.id))return; const c=m.code&&LIVE_ON_FACE.has(m.code)?lv:fz;
    if(m.k==='sev'){markWorse(sev,m.di,m.id,m.v); markWorse(c.sev,m.di,m.id,m.v);}
    else if(m.k==='chip'){markHigher(chip,m.di,m.id,m.v); markHigher(c.chip,m.di,m.id,m.v);}
    else{dash[m.di]=dash[m.di]||{}; dash[m.di][m.id]=true; c.dash[m.di]=c.dash[m.di]||{}; c.dash[m.di][m.id]=true;} });
  (raw.traces||[]).forEach((t:any)=>{ const w=t.w;
    if(w&&(w.di==null?xHid(t):!has(w.di,w.code,t.id)))return;
    trace[t.pdi]=trace[t.pdi]||{}; trace[t.pdi][t.id]=mergeRestTrace(trace[t.pdi][t.id],t.t); });
  return {all:(raw.all||[]).map((w:any)=>cp.get(w)||w),byDay,sev,chip,dash,trace,fz,lv,marks:raw.marks,traces:raw.traces,raw};}
/* the WORKING copy's hides, as the engine reads them (state/view.ts lends its set through HOOKS — the engine cannot import
   state); unset (an engine-only test), nothing is hidden */
const hidden=():Set<string>=>(HOOKS.hiddenKeys?HOOKS.hiddenKeys():NOHIDES)||NOHIDES;
const NOHIDES=new Set<string>();
/* one shown bundle per raw bundle, under the working hides (a toggle always re-validates, so a raw bundle is never asked
   for twice under two sets — the signature is the belt beside those braces) */
const SHOWN=new WeakMap<any,{sig:string,b:any}>();
function externalHides(raw:any){
  const sets=new Map<string,Set<string>>();
  const address=(w:any)=>`${w?.targetWeek||''}|${w?.targetDi??0}`;
  (raw?.traces||[]).forEach((t:any)=>{const w=t.w;if(!w||w.di!=null)return;
    const key=address(w);if(!sets.has(key))sets.set(key,w.targetWeek?dayHidesIn(w.targetWeek,w.targetDi??0):nextMondayHides(CURWEEK));});
  return {any:[...sets.values()].some(s=>s.size),sig:[...sets].map(([k,s])=>k+':'+[...s].sort().join('\u241f')).sort().join('\u241e'),
    off:(k:string,w?:any)=>!!sets.get(address(w))?.has(k)};
}
function shownWorking(raw:any){
  const hs=hidden(), xw=externalHides(raw);
  if(!hs.size&&!xw.any)return raw;
  const sig=[...hs].sort().join('\u241f')+'\u241e'+xw.sig, hit=SHOWN.get(raw);
  if(hit&&hit.sig===sig)return hit.b;
  const b=shownOf(raw,(w:any)=>hs.size>0&&hs.has(hideKey(w)),xw.off);
  SHOWN.set(raw,{sig,b}); return b;}
/* ---- THE TWO DOCUMENTS (published-schedule flagging, spec §5) ---------------
   validate() computes the WORKING bundle exactly as before — validateCore() above
   writes every module global (WARN/REST/EVD/RUNLEN/RUNSEED/NEXTON/EVDAYS/PREVSUN/
   NEXTMON/CREWREST_BODY/XD_CACHE), which every EDIT surface and the crew-picker/
   drop probes read — then computes the OFFICIAL bundle: each APPROVED day judged
   at its ISSUED (signed) version. The OFFICIAL run leaves NO global behind: it is a
   snapshot/restore around a second validateCore() run, exactly as withDaySnap does
   for a single day, widened to the whole week and to the validator's own globals.
   When no approved day carries an unpublished amendment, OFFICIAL is the SAME object
   as WORKING (the alias — drift-proof by construction, zero cost). The DOM counters
   are emitted from WORKING only. [F-1/CRP-002, CRP-004] */
export let OFFICIAL:any = WARN;
/* WHAT THE ISSUED FACES SHOW ([LEAVE-LATE-PUBLISHED], owner D179 — publish.ts, "THE DAY'S WARNINGS AS ISSUED"): the
   official bundle with every published day's slice replaced by the one its current issued version stored when it went
   out. A draft day keeps the official pass's own slice (viewDayHTML: a draft judged against its published neighbours).
   Built once per official bundle and set of current versions; a version issued before the freeze (no `w`) keeps the
   official slice, as before. */
let FACE:any=null, FACE_OF:any=null, FACE_K='';
/* a warning worded with a callsign since renamed reads today's (a rename is a label, 14 Sep 26) */
const rewordSlice=(w:any,g:any)=>{ if(!g||!w.cs)return g; const ren=Object.keys(w.cs).filter((id:any)=>PEOPLE[id]&&PEOPLE[id].cs&&PEOPLE[id].cs!==w.cs[id]);
  if(!ren.length)return g; return {...g,warns:(g.warns||[]).map((x:any)=>{ let m=String(x.msg||''); ren.forEach((id:any)=>{ m=m.split(String(w.cs[id])).join(String(PEOPLE[id].cs)); }); return {...x,msg:m}; })}; };
/* AND THE HIDES EACH FACE WENT OUT WITH ([WARN-HIDE-KEPT], owner D471, 1 Oct 26 — a hide on a day already published
   "waits" for the next amendment, like every other change to it): the face is the official bundle AS SHOWN —
   · a DRAFT day (and every day while nothing is published) under the WORKING copy's hides, so View-only Sched follows a
     hide like Edit Schedule does (Fable's plan read F4: it used to hand back the raw pass here);
   · a PUBLISHED day under the keys its current issued version stored (`w.wo`), never the working set: its frozen
     warnings and its live ones alike carry `off` by those keys, its frozen marks are the ones it went out showing
     (`w.shown`), its live marks are today's replayed under those keys, and a next-day mark follows the hide state of the
     day its breach is on (that day's issued keys when it is published, the working set when it is not).
   The memo holds because every toggle of a hide re-validates (a new OFFICIAL) and a version's own keys never change —
   the key below carries the working set all the same. */
function faceWarn(){
  const raw=OFFICIAL, fz:any[]=[];
  approvedDays().forEach((di:any)=>{ const v=dayCurVer(di), s=v!=null?daySnapOf(di,v):null; if(s&&s.w)fz.push({di,v,w:s.w}); });
  if(!fz.length)return shownWorking(raw);
  const hs=hidden(), xw=externalHides(raw);
  const k=fz.map((x:any)=>`${x.di}=${x.v}`).join(',')+'\u241e'+[...hs].sort().join('\u241f')+'\u241e'+xw.sig;
  if(FACE&&FACE_OF===raw&&FACE_K===k)return FACE;
  const issued:any={}; fz.forEach(({di,w}:any)=>{ issued[di]=new Set<string>((w.wo||[]) as string[]); });
  const offBy=(w:any)=>{ const st:Set<string>=issued[w.di]||hs; return st.size>0&&st.has(hideKey(w)); };
  const off=shownOf(raw,offBy,xw.off);
  const byDay=(off.byDay||[]).slice(), sev={...off.sev}, chip={...off.chip}, dash={...off.dash}, trace={...off.trace};
  const put=(m:any,di:any,v:any)=>{ if(v)m[di]=v; else delete m[di]; };
  const reword=rewordSlice;
  /* two things stay LIVE on a published face, by design:
     · the next-day crew-rest and run marks (`trace`) — owner, D183, 26 Sep 26: "should be live to see the break of crew
       rest" (Fable's plan read F4; Astra's code read #1 set aside). They show the break as it stands today, drawn from the
       official pass; not stored, not compared, so a change to the next day never makes this day pending. A mark whose
       breach is on a published next day may point at that day's frozen list, where it is absent — its row is then drawn
       without a jump (html.ts dayTraceHTML);
     · the warnings LIVE_ON_FACE names (the Leave War's "no period covers this date"; a crew-rest breach and the 7-day run
       on the day; a lapsed qualification — D184, D185): taken from the official pass with the rings and flags they raise
       (`off.lv`), laid over the frozen ones (the stored `w` holds only the marks of warnings that freeze). A ring is the
       worst of a man's warnings, so each is the worse of the two by the day loop's own order (SEVR, RANK); a dash is
       either's. A live code in a frozen list (none is ever stored — warnSliceOf) is dropped, so each has one source. */
  const LV=off.lv||{sev:{},chip:{},dash:{}}, SORD:any={hard:0,adv:1,note:2};
  const merge=(fr:any,lv:any,worse:any)=>{ if(!lv)return fr||null; const o:any={...(fr||{})};
    Object.keys(lv).forEach((id:any)=>{ o[id]=o[id]==null?lv[id]:worse(o[id],lv[id]); }); return o; };
  fz.forEach(({di,w}:any)=>{ const g=reword(w,w.byDay), live=((off.byDay||[])[di]?.warns||[]).filter((x:any)=>LIVE_ON_FACE.has(x.code));
    /* the frozen warnings, each carrying `off` when this version went out with it hidden (the key folds the callsign,
       so a reworded line keys as it did then); the live ones already carry theirs, by the same keys (offBy) */
    const wo:Set<string>=issued[di], frozen=((g&&g.warns)||[]).filter((x:any)=>!LIVE_ON_FACE.has(x.code)).map((x:any)=>wo.size&&wo.has(hideKey(x))?{...x,off:true}:x);
    /* severity order, as the day loop sorts its list (a stable sort: frozen before live within a severity) */
    const ws=[...frozen,...live].sort((a:any,b:any)=>(SORD[a.sev]??3)-(SORD[b.sev]??3));
    byDay[di]=g||live.length?{...(g||{di,dow:(DAYS[di]||{}).dow}),warns:ws}:undefined;
    /* the frozen marks as the version went out SHOWING them (`shown` — stored only when something was hidden) */
    const F=w.shown||w;
    put(sev,di,merge(F.sev,LV.sev[di],(a:any,b:any)=>SEVR[b]>SEVR[a]?b:a));
    put(chip,di,merge(F.chip,LV.chip[di],(a:any,b:any)=>RANK[b]>RANK[a]?b:a));
    put(dash,di,merge(F.dash,LV.dash[di],()=>true)); });
  const all:any[]=[]; byDay.forEach((g:any)=>{ if(g&&g.warns)all.push(...g.warns); });
  FACE={all,byDay,sev,chip,dash,trace}; FACE_OF=raw; FACE_K=k;
  return FACE;
}
export function officialWarn(){ return faceWarn(); }
/* THE WARNINGS ONE PUBLISHED VERSION SHOWS WHEN IT IS LOOKED AT (owner, D187, 26 Sep 26 — "Q5 it should": the board's and
   the edit week's 👁 look at a published version shows its warnings, as View-only Sched does). The day's CURRENT issued
   version is its published face — exactly what View-only Sched draws (faceWarn: the warnings it went out with, the live
   ones on top). An OLDER, superseded version shows the warnings IT went out with (its own `w`) — a record of what was
   issued then; today's live warnings and the next-day mark belong to the current document, so it carries neither. A
   parked plan ('d:'), a version issued before the freeze (no `w`) or one that no longer resolves: null — it is drawn
   with no warnings, as before. One bundle per (official pass, day, version). */
const VFACE=new WeakMap<any,Map<string,any>>();
export function versionFaceWarn(di:any,ver:any):any{di=+di;
  if(ver==null||(typeof ver==='string'&&ver.slice(0,2)==='d:')||!dayApproved(di))return null;
  if(String(dayCurVer(di))===String(ver))return faceWarn();
  const s:any=daySnapOf(di,ver); if(!s||!s.w)return null;
  /* the whole face it went out with, when the version kept it; else the frozen class alone */
  const f:any=s.w.face;
  const off=OFFICIAL, k=`${di}=${ver}`; let m=VFACE.get(off); if(!m){m=new Map(); VFACE.set(off,m);}
  const hit=m.get(k); if(hit)return hit;
  const byDay=(off.byDay||[]).slice(), sev={...off.sev}, chip={...off.chip}, dash={...off.dash}, trace={...off.trace};
  const put=(mm:any,v:any)=>{ if(v)mm[di]=v; else delete mm[di]; };
  if(f){ const g=rewordSlice({cs:f.cs||s.w.cs},{warns:f.warns||[]});
    byDay[di]={di,dow:(DAYS[di]||{}).dow,warns:(g&&g.warns)||[]};
    put(sev,f.sev); put(chip,f.chip); put(dash,f.dash); }
  else { const g=rewordSlice(s.w,s.w.byDay), wo=new Set<string>((s.w.wo||[]) as string[]), F=s.w.shown||s.w;
    /* …with the hides it went out with ([WARN-HIDE-KEPT]): its lines struck by its own keys, its marks as it showed them
       (the whole stored face, above, already carries both) */
    byDay[di]={...(g||{di,dow:(DAYS[di]||{}).dow}),warns:((g&&g.warns)||[]).filter((x:any)=>!LIVE_ON_FACE.has(x.code)).map((x:any)=>wo.size&&wo.has(hideKey(x))?{...x,off:true}:x)};
    put(sev,F.sev); put(chip,F.chip); put(dash,F.dash); }
  delete trace[di];
  const all:any[]=[]; byDay.forEach((gg:any)=>{ if(gg&&gg.warns)all.push(...gg.warns); });
  const b={all,byDay,sev,chip,dash,trace}; m.set(k,b); return b;}
/* draw fn with WARN pointing at that version's warnings (versionFaceWarn); a version with none reads as before */
export function withVersionWarn(di:any,ver:any,fn:any){ const f=versionFaceWarn(di,ver); if(!f)return fn(); const w=WARN; WARN=f; try{ return fn(); } finally{ WARN=w; } }
/* the official pass's own bundle — today's judgement of every published day (the detector), not what their faces show */
export function officialRaw(){ return OFFICIAL; }
/* the day's slice of a warning bundle — what an issued version stores, and what the detector compares: its warning list
   (less LIVE_ON_FACE's), and the rings, flags and dashes raised by those warnings alone (`fz` — a live warning's marks
   are drawn from today, D184/D185). NOT the next-day crew-rest / run mark (`trace`) — it stays live on a published face
   (owner, D183, 26 Sep 26: "should be live to see the break of crew rest"). */
export function warnSliceOf(b:any,di:any){di=+di;
  const g=((b&&b.byDay)||[])[di]||null, m=(b&&b.fz)||b||{};
  return {byDay:g?{...g,warns:(g.warns||[]).filter((x:any)=>!LIVE_ON_FACE.has(x.code))}:null,sev:(m.sev||{})[di]||null,chip:(m.chip||{})[di]||null,
    dash:(m.dash||{})[di]||null,trace:null};}
/* the official pass's own slice for a day (the detector — today's judgement of the issued day), for the pending list's
   words */
export function officialSliceNow(di:any){ return warnSliceOf(OFFICIAL,di); }
/* THE ONE SURFACE-RESOLVED ACCESSOR (spec §5.4, F-3/CRP-007). Every warning
   reader — sevOf/chipOf/dashOf/traceOf/traceLeads/traceIx/tracesOn, dayWarnHTML,
   personWarns — reads the module WARN by name. Rendering a published day's frozen
   face wraps the build in this, which points WARN at the OFFICIAL bundle for the
   duration (the same swap-and-restore trick withDaySnap uses for DAYS), so the
   whole surface resolves to the displayed day's version with no per-reader change.
   Synchronous, restored in finally — never left swapped. REST/EVD are NOT swapped:
   they feed the edit-page crew picker / drop probes only, never the issued face. */
/* ([LEAVE-LATE-PUBLISHED], D179, 25 Sep 26: the swap now points WARN at the FACE — what the issued faces show, each
   published day's warnings as they went out — not at the raw official pass, which is the pending comparison's detector
   (officialRaw). A draft day's slice is the official pass's own, as before.) */
export function withOfficialWarn(fn:any){ const w=WARN; WARN=faceWarn(); try{ return fn(); } finally{ WARN=w; } }
/* registered with publish.ts at load: at issue, judge the week once as it now stands and keep the day's slice (a deep
   copy — the bundle is rebuilt on the next validate); on every read, today's judgement of the day for the comparison */
HOOKS.issuedWarn=(di:number)=>{ validate(); const s=warnSliceOf(OFFICIAL,di), g=(OFFICIAL.byDay||[])[+di];
  /* …and the WHOLE face the version showed the moment it went out — every warning, the live ones included, with every
     ring and flag (Astra's and Fable's reads of D187: an older version's look dropped the crew-rest, 7-day, qualification
     and OIL warnings it went out with, since only the frozen class is kept for the comparison). Never compared
     (warnSliceKey reads byDay / sev / chip / dash only); drawn when an OLDER version is looked at. The next-day mark
     stays out: it is always today's (D183). */
  /* AND THE HIDES IT GOES OUT WITH ([WARN-HIDE-KEPT], owner D469 / D471, 1 Oct 26): the slice above stays RAW — it is the
     pending comparison's basis, and a hide must never read there as "warnings on this day changed" (warnSliceKey reads
     byDay / sev / chip / dash only). Beside it: `wo` — the keys of the day's warnings hidden as it goes out (only those
     that match a warning: a stale key is not issued); `shown` — the frozen-class marks as SHOWN, kept only when
     something is hidden; and the face is the shown OFFICIAL slice — its hidden lines carry `off`, its rings are the
     shown ones (never `WARN`: the working pass judges the day with the working copy's neighbours — Fable F8.1). */
  void g;
  const sh=shownWorking(OFFICIAL), gs=(sh.byDay||[])[+di], warns=(gs&&gs.warns)||[];
  const face={warns,sev:(sh.sev||{})[+di]||null,chip:(sh.chip||{})[+di]||null,dash:(sh.dash||{})[+di]||null};
  const wo=warns.filter((x:any)=>x.off).map((x:any)=>hideKey(x));
  const out:any={...s,face};
  if(wo.length){ out.wo=wo; const f=sh.fz||{}; out.shown={sev:(f.sev||{})[+di]||null,chip:(f.chip||{})[+di]||null,dash:(f.dash||{})[+di]||null}; }
  return JSON.parse(JSON.stringify(out)); };
/* THE HIDE STATE OF A PUBLISHED DAY, FOR ITS PENDING COMPARISON (publish.ts hideDelta — D471): every warning of today's
   judgement of the ISSUED day that the WORKING copy also raises (a warning only the issued day has is the content
   comparison's business; one only the working copy has goes out with the edit that raised it — Fable F3), with whether
   it is hidden on the working copy, its words for the pending list and its slot key for the tap. One list per official
   bundle and day (a toggle re-validates). */
const HIDENOW=new WeakMap<any,Map<number,any[]>>();
HOOKS.hideNow=(di:number)=>{ let m=HIDENOW.get(OFFICIAL); if(!m){m=new Map(); HIDENOW.set(OFFICIAL,m);}
  let v=m.get(+di); if(v)return v;
  const hs=hidden(), work=new Set<string>((((RAW_B.byDay||[])[+di]||{}).warns||[]).map((w:any)=>hideKey(w)));
  v=((((OFFICIAL.byDay||[])[+di]||{}).warns||[]) as any[]).map((w:any)=>({k:hideKey(w),w})).filter((x:any)=>work.has(x.k))
    .map(({k,w}:any)=>({k,on:hs.has(k),code:w.code,who:w.who||[],msg:String(w.msg||''),sev:w.sev,key:w.key}));
  m.set(+di,v!); return v!; };
/* one slice per day per official bundle, so publish.ts can key it once per validate */
const SLICES=new WeakMap<any,Map<number,any>>();
HOOKS.warnNow=(di:number)=>{ let m=SLICES.get(OFFICIAL); if(!m){m=new Map(); SLICES.set(OFFICIAL,m);}
  let v=m.get(+di); if(!v){v=warnSliceOf(OFFICIAL,di); m.set(+di,v);} return v; };
/* the WORKING bundle as the last validate left it — what WARN reads outside a face or a look. A reader that must answer
   for the working copy while a face is being drawn (WARN swapped for the render) asks this, never WARN (the tap a look's
   cross-day row will make — Fable's read of D187 #4). */
let WORKING_B:any=WARN;
export function workingWarn(){ return WORKING_B; }
/* …and the same pass UNHIDDEN — every warning the rules raised, hidden or not. An engine question about whether a breach
   already EXISTS reads this (the pre-drop crew-rest probe: a hidden breach is still there, and placing a man must not
   read as creating it), never the bundle as shown ([WARN-HIDE-KEPT]). */
let RAW_B:any=WARN;
export function rawWarn(){ return RAW_B; }
export function validate(){
  const raw = validateCore();        // WORKING, as the rules raised it — writes the module globals
  RAW_B = raw;
  if(HOOKS.validated)HOOKS.validated(raw);
  /* what every surface reads is the bundle AS SHOWN (D469, D472): a hidden warning carries `off`, flags no puck */
  const w = shownWorking(raw);
  WARN = w; WORKING_B = w;
  OFFICIAL = officialFor(raw);       // aliased, or a snapshot/restore OFFICIAL run — RAW either way: the pending comparison's detector, and what a version stores
  if(HOOKS.validated&&OFFICIAL!==raw)HOOKS.validated(OFFICIAL);
  const sh=shownWarns(w.all);
  const hard=sh.filter((x:any)=>x.sev==='hard').length;
  const note=sh.filter((x:any)=>x.sev==='note').length;
  if($('nHard'))$('nHard').textContent=hard;
  if($('nAdv'))$('nAdv').textContent=sh.length-hard-note;
  if($('nNote'))$('nNote').textContent=note;
  return w;
}
/* SOME approved day carries an unpublished amendment (a non-empty publication
   delta against its issued version). Phase 1: the loaded week only; the cross-week
   dependency window (§14.1) and the stashed-day delta (§14.2) arrive with the
   cross-week phase. dayDelta already gates on dayApproved + a resolvable issued
   snapshot, so an unresolvable snapshot never reads as "no delta". */
function officialDiverges(){
  /* the loaded week's own approved-day amendments, plus the cross-week half of the
     dependency window (§14.1): a published neighbour Sunday/Monday whose stashed
     working copy carries an unpublished amendment. Either forces the second pass;
     otherwise OFFICIAL aliases WORKING (zero cost, cannot drift). */
  /* per loaded approved day, force the official pass when its evidence is UNAVAILABLE
     (no version / snapshot / snapshot.d → protect, Codex CRPF-005/R2-003), when its
     content diverges (dayDelta), or when its FILING diverges membership-aware
     (Codex R2-001 — the coarse dayDelta filingDelta treats absent == present-empty, so
     a fresh unaccepted commitment on an approved day would otherwise alias). */
  if(approvedDays().some((di:any)=>{
    const ver=dayCurVer(di), snap=ver!=null?daySnapOf(di,ver):null;
    if(!snap||!snap.d)return true;
    if(dayDeltaCore(di).length>0)return true;
    return filingDivergesAt(snap.fil,(DAYS[di]||{}).dt);
  }))return true;
  return windowDiverges(CURWEEK,VCONF.maxRun);
}
function officialFor(working:any){
  if(!officialDiverges()){ ISS_DAYS=null; ISS_EVD=null; return working; }   // ALIAS — the exact same object, cannot drift
  /* …and the week this pass judged, kept for the readers that COUNT the issued week (issuedWorld, below): the days as
     installed — every published day its issued snapshot — and the per-person events built from them. Captured inside the
     swap; the finally restores the working globals as before. */
  return withIssuedWeek(()=>{ const b=validateCore(); ISS_DAYS=DAYS.slice(); ISS_EVD=EVD; return b; });
}
/* THE WEEK AS EVERYONE READS IT ([INSIGHTS-WHICH-COPY], owner D477 / D478, 1 Oct 26 — "It should show the latest copy, so
   if working copy is the only copy then it will use that, unless its published then use Original, if theres an AL1 then
   use AL1 etc."): day by day, a published day at its LATEST PUBLISHED version and a day not yet published as the working
   copy — the days, the per-person events worked out from them (work hours), and the warnings as those faces show them
   (faceWarn: each published day under the hides it went out with, a draft day under the working hides — exactly what
   View-only Sched draws). It is the official pass's own world, so a change waiting on a published day is in none of the
   three until it goes out. While nothing waits the official pass IS the working one (the alias), and so is this.
   Answers for the LAST validate(): a reader calls validate() first (computeInsights does). */
let ISS_DAYS:any=null, ISS_EVD:any=null;
/* …and its ROSTER (Astra's final read, 1 Oct 26): the aircrew of those same days — each published day the roster its
   current version went out with (publish.ts `snap.ros`, what the day panel's "free all day" counts; a man since deleted
   outright has nothing to draw and drops, as faceattrs.ts rosterShown), a day not yet published today's — as one list
   for the week. So a man added or archived since does not move "who is not flying" on a week already published. */
function issuedRoster(){ const s=new Set<string>(); let now:any=null;
  DAYS.forEach((_d:any,di:any)=>{ const v=dayApproved(di)?dayCurVer(di):null, sn:any=v!=null?daySnapOf(di,v):null;
    (sn&&Array.isArray(sn.ros)?sn.ros.filter((id:any)=>!!PEOPLE[id]):(now||(now=rosterIds()))).forEach((id:any)=>s.add(id)); });
  return [...s]; }
export function issuedWorld(){ return {days:ISS_DAYS||DAYS, evd:ISS_EVD||EVD, warn:faceWarn(), roster:issuedRoster()}; }
/* Install EVERY approved day's issued snapshot at once (F-4/CRP-006 — a
   Tuesday-issued day must be judged against a Monday-issued day, not Monday-
   working), run fn against it, then restore DAYS, SCHED and every validate()
   global. Mirrors withDaySnap's swap+finally, widened to the whole week and to the
   validator's own globals. Filing overrides (§14.3) and the world-aware cross-week
   seeds (§5.3) are added in later phases. */
function withIssuedWeek(fn:any){
  /* every approved day: its issued snapshot when resolvable, else null → PROTECT it
     (Codex CRPF-005 — an unresolvable approved day must NOT be left as its live draft
     for the official pass to judge neighbours against). */
  const days=approvedDays().map((di:any)=>{
    const ver=dayCurVer(di); const snap=ver!=null?daySnapOf(di,ver):null;
    return {di,snap:(snap&&snap.d)?snap:null};
  });
  const d0:any={}, ch0=SCHED.changes, pd0=SCHED.pending, changes:any={};
  /* install the loaded week's approved days at their issued snapshot (F-4/CRP-006).
     Even with NONE to install, the pass still runs: world='official' makes the
     cross-week seeds resolve neighbour weeks at their signed version (§5.3), which is
     the whole point of the delta-free-loaded-week case (§14.1). */
  /* the signed filing to honour during the official pass (§14.3): neighbour weeks
     first (windowFiling), then the loaded week's own approved days override — a date
     belongs to exactly one week, so there is no real collision, loaded simply wins. */
  const filing:any=windowFiling(CURWEEK,VCONF.maxRun);
  /* …and the INPUTS each signed date was issued with ([LEAVE-LATE-PUBLISHED], owner D177–D179): the official pass
     judges a published day with the leave, the medical, the SANS offer and the request it went out with, so an input
     changed since moves only the working copy (the pending comparison says so), never the issued face's warnings.
     Neighbour weeks first, the loaded week's own days over them, as the filing is. A protected date (no readable
     snapshot) holds none. */
  const frozenInp:any=windowInputs(CURWEEK,VCONF.maxRun);
  /* capture every approved day's ORIGINAL entry (pure reads) BEFORE the try, so the
     finally can always restore what it needs to. The install itself (below) runs
     INSIDE the try (Fable FR-003): if any step there ever threw — today only
     setFiling→dateOrd and Object.assign are in that window, both effectively
     non-throwing — the restore would otherwise be skipped, leaving DAYS pointing at
     frozen snapshots and SCHED.pending emptied. */
  days.forEach(({di}:any)=>{ d0[di]=DAYS[di]; });
  const g=snapGlobals();
  try{
    if(days.length){
      days.forEach(({di,snap}:any)=>{
        if(snap){ DAYS[di]=snap.d; Object.assign(changes,snap.c||{}); if(snap.d.dt!=null){filing[snap.d.dt]=snap.fil||{}; if(snap.inp)frozenInp[snap.d.dt]=snap.inp;} }
        /* PROTECT: content stripped AND an EMPTY filing map installed for the date
           (Codex R2-002) — stripping the programme alone left global INPUTS still
           contributing via buildDay's day.input (fileAcc fell back to live acc). An
           empty frozen filing makes fileAcc return 'r' for every input on the date, so
           no schedule OR commitment-input flag is derived from unavailable evidence.
           (A current medical fact still reads live, but with the seats stripped there is
           nothing for it to clash with.) */
        else { const sdt=(DAYS[di]||{}).dt; DAYS[di]={...DAYS[di],waves:[],dutywaves:[],sims:{amt:[],oft:[]},ground:[],allhands:[]}; if(sdt!=null){filing[sdt]={}; frozenInp[sdt]={};} }
      });
      SCHED.changes=changes; SCHED.pending={};
    }
    setWorld('official'); setFiling(filing);
    return withFrozenInputs(frozenInp,fn);
  }
  finally{
    setWorld('working'); clearFiling();
    days.forEach(({di}:any)=>{ DAYS[di]=d0[di]; });
    SCHED.changes=ch0; SCHED.pending=pd0;
    restoreGlobals(g);
  }
}
/* the complete set of module state validateCore() reassigns — snapshotted before
   the OFFICIAL run and restored after, so WORKING's globals (which every edit
   surface reads) survive the second run untouched. */
function snapGlobals(){ return {WARN,REST,EVD,SIMW,RUNLEN,RUNSEED,NEXTON,EVDAYS,PREVSUN,NEXTMON,CREWREST_BODY,XD_CACHE}; }
function restoreGlobals(g:any){ WARN=g.WARN;REST=g.REST;EVD=g.EVD;SIMW=g.SIMW;RUNLEN=g.RUNLEN;RUNSEED=g.RUNSEED;NEXTON=g.NEXTON;EVDAYS=g.EVDAYS;PREVSUN=g.PREVSUN;NEXTMON=g.NEXTMON;CREWREST_BODY=g.CREWREST_BODY;XD_CACHE=g.XD_CACHE; }
export const sevOf=(di:any,id:any)=>WARN.sev[di]&&WARN.sev[di][id];
export const chipOf=(di:any,id:any)=>WARN.chip&&WARN.chip[di]&&WARN.chip[di][id];
/* the ring STROKE, published per person like the ring colour above it: true
   where a sanctioned late show still makes step, so the puck reads
   as a breach a scheduler meant rather than one nobody noticed. */
export const dashOf=(di:any,id:any)=>!!(WARN.dash&&WARN.dash[di]&&WARN.dash[di][id]);
/* THE PREVIOUS-DAY TRACE, read from the day that caused the breach: what this
   man's day-end does to TOMORROW. Standing model state, not focus state — the
   dotted ring, the CR label and the cross-day row are all painted off this the
   moment the week renders, with nothing clicked (owner, 6 Aug 26). */
export const traceOf=(di:any,id:any)=>(WARN.trace&&WARN.trace[di]&&WARN.trace[di][id])||null;
/* ...and whether the trace OWNS the puck's flag, which it only does when the
   man carries nothing louder of his own that day. One test, so the chip the
   builder prints and the warning a click opens can never disagree. */
/* which chip the trace itself would print: the run trace outranks the
   crew-rest trace exactly as RUN outranks CR on the day of the breach */
export const traceChip=(t:any)=>t&&t.run?'RUN':'CR';
/* …and it leads only over a chip BELOW crew rest, whichever kind the trace is:
   a man's OWN hard breach today (CR, RUN, C, Q) always keeps its label — a
   dotted trace for a later day must never caption over the breach he has
   right now (review finding, 5 Sep 26). traceChip decides the glyph once it
   does lead. */
export const traceLeads=(di:any,id:any)=>{const t=traceOf(di,id); if(!t)return null;
  const c=chipOf(di,id); return (!c||RANK['CR']>RANK[c])?t:null;};
/* Where the traced breach actually LIVES — its index in the NEXT day's own
   warning list. That pair (day, index) is the address every warning surface
   already navigates by, so a cross-day row and a traced puck both hand the
   ordinary jump the ordinary thing and need no navigation path of their own.
   -1 where the warning has moved under an edit: WARN is rebuilt wholesale. */
/* `b`: the bundle the breach's day is resolved in when it is not the one being drawn (a look — the tap reads that day's
   own displayed list, Fable's read of D187 #4) */
export const traceIx=(t:any,id:any,kind?:any,b?:any)=>{if(!t)return -1;
  const run=kind==='RUN'; const tdi=run?(t.run&&t.run.di):t.di, code=run?'DAYS_RUN':'CREW_REST';
  const W=b||WARN; const g=W.byDay&&W.byDay[tdi];
  return (((g&&g.warns)||[]) as any[]).findIndex((w:any)=>w.code===code&&(w.who||[]).indexOf(id)>=0);};
/* every man whose day-end breaks the NEXT day, for the day that caused it */
export const tracesOn=(di:any)=>{const m=(WARN.trace&&WARN.trace[di])||{};
  return Object.keys(m).map((id:any)=>({id,t:m[id]}));};

/* ---- THE PRE-DROP QUESTION (owner, 5 Sep 26 — step 3 of the flagging plan):
   "what would the two HARD cross-day rules say if this man landed on this
   slot?" Read off the tables the last validate() published, never a second
   copy of either rule: the run walks RUNLEN/RUNSEED/NEXTON, crew rest re-runs
   the validator's own crewRestDay in probe mode. slotBar (avail.ts) appends
   the answer as its last reason, so the palette strike, the green rings, the
   drag hover and the fallback drop toast all say it BEFORE the write, and the
   drop delta says it again after — one oracle, no drift. */
let CREWREST_BODY:any=null;
/* memo per validate(): the palette asks slotBar for every name in a column
   several times over (its sort comparator, the free count, the column
   reason, the row), so the two probes below are answered once per
   (id, key, fromKey) until the next validate() reassigns the tables */
let XD_CACHE:Map<string,string>=new Map();
export const ordinal=(n:any)=>n+(n%10===1&&n%100!==11?'st':n%10===2&&n%100!==12?'nd':n%10===3&&n%100!==13?'rd':'th');
/* the run: would a day on the programme at `di` push a run past the limit,
   and on which day does it break? null when he is already on that day (the
   count would not change) or nothing crosses. Walks forward through the days
   he is already on and, past Sunday, into next Monday's seed. */
/* `from` = {di, key, sole}: the seat he is being moved FROM (a seat-to-seat
   drag) — that day reads as OFF when the moved seat was his only event there
   (`sole`), so the answer describes the week after the move. Counted from
   the on/off pattern alone: back through the days he is on (the seed walks in
   when the run reaches Monday), then forward, then into next Monday. */
export function runIfPlaced(id:any,di:any,from?:any){
  if(!id||!PEOPLE[id]||isSpecial(id)||di==null||di<0||di>6||!RUNLEN.length)return null;
  const on=(k:any)=>!!(RUNLEN[k]&&RUNLEN[k][id]!=null)&&!(from&&from.sole&&from.di===k);
  if(on(di))return null;
  let n=1, k=di-1;
  while(k>=0&&on(k)){n++;k--;}
  if(k<0)n+=RUNSEED[id]||0;
  if(n>VCONF.maxRun)return {di,dow:DAYS[di].dow,n};
  for(k=di+1;k<=6;k++){
    if(!on(k))return null;
    n++; if(n>VCONF.maxRun)return {di:k,dow:DAYS[k].dow,n};
  }
  if(NEXTON.has(id)){n++; if(n>VCONF.maxRun)return {di:null,dow:'Monday',n};}
  return null;
}
/* crew rest, both directions: the candidate leg is a clone of a leg already
   flying the same formation (same to/ld/brief/in-time — formation-level
   facts), so no second copy of events.ts's leg arithmetic exists; an empty
   formation has no sibling to clone and answers null — the drop delta still
   catches it after the write. `key` is a flying-seat or standalone-shift key
   (`di.gi.li.ai.seat`); every other kind bears no crew rest of its own. */
export function restIfPlaced(id:any,key:any,from?:any){
  if(!id||!PEOPLE[id]||isSpecial(id)||PEOPLE[id].pers||!CREWREST_BODY)return null;
  const k=String(key); if(k.indexOf(':')>=0)return null;
  const a=k.split('.'); const di=+a[0]; if(!(di>=0&&di<=6)||!EVDAYS[di])return null;
  /* the seat he is leaving (a seat-to-seat drag) comes out of whichever day
     it sits on — a leg being moved cannot break its own crew rest */
  const fk=from&&from.key;
  const strip=(d:any)=>!fk||!d||d.di!==from.di||from.leaves===false?d:{...d,fly:(d.fly||[]).filter((e:any)=>e.id!==id||seatRow(e.key||e.slot)!==seatRow(fk)),events:(d.events||[]).filter((e:any)=>e.id!==id||seatRow(e.key||e.slot)!==seatRow(fk))};   /* his entries only (Fable's read): the day lists hold everyone's */
  /* the day's two lists carry a leg in two shapes: `fly` (the crew-rest
     inputs — brief/intime/to/ld/shift, keyed by `key`) and `events` (every
     kind, keyed by `slot`); the candidate is cloned into each from a sibling
     leg of the same formation in that same list */
  const pre=`${a[0]}.${a[1]}.${a[2]}.`;
  const sibF=(EVDAYS[di].fly||[]).find((e:any)=>String(e.key||e.slot||'').indexOf(pre)===0&&e.id!==id);
  const sibE=(EVDAYS[di].events||[]).find((e:any)=>e.kind==='fly'&&String(e.slot||e.key||'').indexOf(pre)===0&&e.id!==id);
  if(!sibF||!sibE)return null;
  const legF={...sibF,id,seat:a[4]==='w'?'RCP':'FCP',key:k};
  const legE={...sibE,id,slot:k};
  /* the seat he already HOLDS asks nothing — he is there, and the flag on
     the day says whatever there is to say (the same self-exclusion slotBar
     applies everywhere else, audit-c-clash.test.ts) */
  if((EVDAYS[di].fly||[]).some((e:any)=>(e.key||e.slot)===k&&e.id===id))return null;
  const notMine=(e:any)=>(e.key||e.slot)!==k;
  const base=strip(EVDAYS[di]);
  const today={...base,fly:[...base.fly.filter(notMine),legF],events:[...base.events.filter(notMine),legE]};
  let hit:any=null;
  const dayAt=(index:number)=>index===di?today:strip(CREWREST_BODY.dayAt(index));
  const probe={id,dayAt,hit:(h:any)=>{hit=h;}};
  /* ONLY A NEW BREACH IS AN ANSWER — the same delta the drop toast reads. A
     man whose 08:15 leg already breaks today's rest is asked about a 14:00
     seat: the probe still sees the 08:15 leg and says "breach", but landing
     him there changes nothing, so the answer is the existing warning's own
     message; when the two match, nothing is new. Same forward: a breach
     tomorrow that another late leg already causes is not this seat's. */
  /* the RAW pass (rawWarn): a breach the scheduler has hidden is still there — placing him must not read as creating it */
  const already=(d:any,h:any)=>{const g=RAW_B.byDay&&RAW_B.byDay[d]; const w=g&&g.warns&&g.warns.find((x:any)=>x.code==='CREW_REST'&&(x.who||[]).indexOf(id)>=0); return !!w&&w.msg===h.msg;};
  /* backward — his own report today against what ended yesterday */
  const prev=dayAt(di-1);
  if(prev)CREWREST_BODY(prev,today,di,true,null,probe);
  if(hit&&!already(di,hit))return {dir:'back',di,dow:DAYS[di].dow,earliest:hit.earliest,leaveBy:hit.leaveBy,msg:hit.msg};
  hit=null;
  /* forward — this leg's end against his first report tomorrow */
  for(let index=di+1;index<=di+4;index++){
    hit=null;const next=dayAt(index), targetDi=index<7?index:null;
    if(next&&next.fly)CREWREST_BODY(dayAt(index-1),next,targetDi,true,null,probe);
    if(!hit)continue;
    const entries=restTraceEntries(RAW_B.trace?.[di]?.[id]);
    const dup=targetDi!=null?already(targetDi,hit):entries.some((t:any)=>t.targetDi===next.targetDi&&t.targetWeek===next.targetWeek&&t.msg===hit.msg);
    if(!dup)return {dir:'fwd',di:targetDi,dow:next.dow,earliest:hit.earliest,leaveBy:hit.leaveBy,msg:hit.msg};
  }
  return null;
}
/* the one line slotBar prints for either — short, because the palette prints
   it under a crossed-out name at 8.5px */
export function crossDayIfPlaced(id:any,key:any,fromKey?:any){
  const ck=`${id}|${key}|${fromKey||''}`;
  const hit=XD_CACHE.get(ck); if(hit!=null)return hit;
  /* the seat he is leaving: its day, and whether it was his only event there — compared by ROW (keys.ts seatRow): a
     crowd seat or an extra names his place, the event names its row, and the raw compare never matched them */
  let from:any=null;
  if(fromKey){
    const fdi=keyDay(fromKey), evs=(EVD[fdi]&&EVD[fdi][id])||[];
    /* …and he LEAVES that row only when he has no other place on it (a second copy stays — Astra's read, 26 Sep 26) */
    const leaves=!rowPlaces(seatRow(fromKey)).some((x:any)=>x.id===id&&x.key!==String(fromKey));
    from={di:fdi,key:String(fromKey),leaves,sole:leaves&&evs.length===1&&seatRow(evs[0].slot||evs[0].key)===seatRow(fromKey)};
  }
  let out='';
  const r=runIfPlaced(id,keyDay(key),from);
  if(r)out=`${ordinal(r.n)} day in a row — breaks ${r.di==null?'next Monday':r.dow} (${VCONF.maxRun} is the limit)`;
  else{
    const c=restIfPlaced(id,key,from);
    if(c)out=c.dir==='back'?`crew rest — not clear until ${stated(c.earliest)}`:`crew rest — breaks ${c.di==null?'next '+c.dow:c.dow}: he must be gone by ${c.leaveBy}`;
  }
  XD_CACHE.set(ck,out);
  return out;
}
/* how often each code fired across the week now on screen, and on which days */
export function lgFired(){
  const out:any={}; (WARN.all||[]).forEach((w:any)=>{
    const o=out[w.code]=out[w.code]||{n:0,days:new Set(),sev:new Set()};
    o.n++; o.days.add(w.di); o.sev.add(w.sev);});
  return out;}
