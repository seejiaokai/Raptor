import { DAYS } from './data'
import { PEOPLE } from './people'
import { VCONF } from './rules'
import { keyDay, uniqDays } from './keys'
import { isScheduler } from './people'
import { HOOKS } from './hooks'
import { logEdit } from './editlog'
import { ridKey, posKey, ridWriteKey, ensureRowIds, RID_BOOK_VERSION } from './rowids'
import { canonicalDiff, canonicalUnits, digest } from './canonical'
import type { DeltaEntry, PendUnit } from './canonical'
import { INPUTS, inpId, inputCoversDate, inpDetailKey, frozenInputMatch, stableJson } from './inputs'
import { CURWEEK, isStandalone } from './waves'
import { groundOrder } from './order'
import { dayIso, verId, parseVerId, verSeq, verSeqLabel, isValidVerId } from './verid'
import { isPreservedWeek, rowElsewhere } from './weekstash'
import { standsOn } from './overlay'   // functions only both ways
import { inputProtected } from './quarantine'   // functions only both ways, so the import loop is safe
import { rosterIds } from './faceattrs'
import { oilEvidence, oilEvidenceKey, oilSignKey, oilKeyNoMem, oilDecisionsKey, oilKeyBeforeStand, oilUpgradeMovedMoney, oilMovedInputsOnly } from './oilev'

/* the reference calls straight into the UI here; the engine routes those four
   calls through injected hooks (no-ops until the app provides them) so the
   bodies below stay verbatim */
const toast=(...a:any[])=>HOOKS.toast(...a);
const reflow=()=>HOOKS.reflow();
const histPush=()=>HOOKS.histPush();
const renderStatus=()=>HOOKS.renderStatus();
/* =====================================================================
   PUBLISH DAY (approve) + PUBLISH AL (amendment level, whole-schedule tint)
   ===================================================================== */
/* SCHED.pending  — keys edited since the last publish (no seq yet)
   SCHED.changes  — key -> per-day SEQ it was published under (drives the colour)
   SCHED.als      — every published amendment, newest last. Phase 2 shape: each
                    record is SINGLE-DAY and identified by its immutable verId —
                    {id, di, iso, seq, snap:{d,c,fil}, diff, sign}. `seq` is the
                    per-day display number (1 = AL1 …); `id` = verId(iso, seq) is
                    the key; `diff` (the canonical dayDelta at issue) REPLACES the
                    old `keys` list. There is no week-wide `n` any more.
   SCHED.dayOK    — {di:1} the days that have been published (approved) INDIVIDUALLY.
                    Approval is per day, not per week: Monday can be published and
                    flown while Thursday is still being built. The week banner is a
                    summary of this object, never the source of truth. There is no
                    SCHED.approved / SCHED.dirty any more — both are derived.
   SCHED.cur      — {di: verId} which version each day is CURRENTLY showing (the
                    Original is verId(iso,0)). Stamped by alIssue; read through
                    dayCurVer(), which self-heals when the stamped version's
                    snapshot has gone (undo past the issue).                   */
/* `ridV` stamps the addressing-by-rid book format (engine/rowids.ts). A book
   restored from a persisted snapshot WITHOUT it is foundation-era and is migrated
   once at load (migrateLegacyIds); a fresh/modern book carries it, so it is never
   re-migrated. `amV` stamps the Phase-2 amendment-record format (§5, P2-05); a
   book WITHOUT it that still carries publication content is a PRE-Phase-2 book the
   new verId resolvers cannot re-key — see amFormatOf below. */
export const AMBOOK_VERSION=1;
export let SCHED:any={al:0, pending:{}, changes:{}, added:{}, als:[], dayOK:{}, sign:{}, signBind:{}, orig:{}, cur:{}, ridV:RID_BOOK_VERSION, amV:AMBOOK_VERSION, retired:{}, correcting:{}};
/* [GLOBAL-UNDO] §6.1 — `retired` is the APPEND-ONLY issuance log: every issued
   version, once retracted by an unpublish, is kept here as its own immutable
   snapshot, keyed `<verId>~<n>` (n = 1,2… per id, so a same-label reissue never
   collapses the prior one). Read only by the history panel — never by
   daySnapIn/dayVersions/nextSeq/issuedIdSet — so same-label reissue falls out of
   the existing resolvers. `correcting[di]` = a verId flag set by sched.unpublish
   that lets publishALDay/the button reissue the SAME label even on an EMPTY delta
   (a pure round-trip correction), cleared on reissue (§6.1 GU5-001). */
/* Reset ALL of SCHED in place. Every field is keyed by day INDEX (0..6), so
   loading a different week without this would let one week's approvals, pending
   edits, AL colouring and per-day drafts bleed onto the next week's identical
   indices. In-place (not reassign) to match histApply's style and keep any held
   reference valid. The ONE seam a future per-week publish store would hook into
   (state/store.ts:loadWeek calls it). */
export function resetSched(){
  SCHED.al=0; SCHED.pending={}; SCHED.changes={}; SCHED.added={};
  SCHED.als=[]; SCHED.dayOK={}; SCHED.sign={}; SCHED.signBind={}; SCHED.orig={};
  SCHED.cur={}; SCHED.drafts={}; SCHED.curDraft={};
  SCHED.retired={}; SCHED.correcting={};   // [GLOBAL-UNDO] §6.1 — per-week, index-keyed like the rest
  SCHED.ridV=RID_BOOK_VERSION;   // a fresh book is modern — never re-migrated
  SCHED.amV=AMBOOK_VERSION;      // and carries the Phase-2 amendment-record format
}
/* ---- Phase 2: legacy-format isolation — the ONE shared classifier (P2-05) ----
   A book PERSISTED by a PRE-Phase-2 build carries the old shape (cur:'orig'|n,
   als:[{n,keys,…}]) and NO amV stamp. The new verId resolvers already return
   null for it (so publication is naturally suppressed and the OIL wire falls back
   to the raw stashed days — credits stand, never deleted), and it round-trips
   byte-for-byte because SCHED holds it verbatim and persistAll re-serializes it
   as-is. This classifier makes that isolation EXPLICIT so no NEW edit is accepted
   onto data the engine cannot safely re-key: an unsupported week is READ-ONLY.
   Full migration to the new shape is Phase 5. */
/* every published record's identity BELONGS to the outer week key: its verId's
   ISO date must be that day in `weekKey`. A book self-consistent internally but
   filed under the WRONG week (P2-REREVIEW-04) fails this — its resolvers reject
   the foreign dates, so it must be quarantined + byte-preserved, not left
   editable and silently re-saved. Only a DEFINITE mismatch (a valid verId whose
   iso is wrong) fails; a malformed/absent id is left to the resolver. */
function recordsBelongToWeek(sc:any,weekKey:any):boolean{
  const orig=sc.orig||{};
  for(const di of Object.keys(orig)){const o=orig[di];
    if(o&&o.id&&isValidVerId(o.id)&&parseVerId(o.id).iso!==dayIso(weekKey,+di))return false;}
  for(const a of (sc.als||[])){
    if(a&&a.id&&isValidVerId(a.id)&&parseVerId(a.id).iso!==dayIso(weekKey,+a.di))return false;}
  return true;
}
export function amFormatOf(sc:any,weekKey?:any){
  if(!sc)return 'current';
  const has=(o:any)=>!!o&&Object.keys(o).length>0;
  const hasContent=(sc.als&&sc.als.length)||has(sc.orig)||has(sc.cur);
  if(sc.amV===AMBOOK_VERSION){
    /* a STAMPED current-format book is 'current' — UNLESS it carries publication
       content whose identity does not belong to the week it is filed under (a
       wrong-week book, P2-REREVIEW-04). weekKey is optional: an identity-only
       classification (no key threaded) keeps the old "stamped ⇒ current" reading. */
    if(weekKey!=null&&hasContent&&!recordsBelongToWeek(sc,weekKey))return 'unsupported';
    return 'current';
  }
  /* no stamp → unsupported ONLY if it actually carries publication content; an
     empty book has nothing to misread and is a fresh book (treated as current). */
  return hasContent?'unsupported':'current';
}
/* the LIVE loaded week is protected (read-only) when its book is unsupported —
   checked against CURWEEK so a wrong-week book is caught too (P2-REREVIEW-04) —
   OR when the week is byte-PRESERVED (P2-REV2-01): a DAMAGED saved week (a stash
   that would not parse, or parsed without a days array) loads the seed as a
   placeholder VIEW, so amFormatOf(SCHED) reads that seed as 'current' — but its
   original bytes are retained in the preserved registry and must never be
   overwritten or edited. isPreservedWeek is set for BOTH the unsupported and the
   unreadable case (state/store.ts applyWeekModel), so this one term makes the
   loaded damaged week read-only just like an unsupported one. */
export function protectedWeek(){return amFormatOf(SCHED,CURWEEK)==='unsupported'||isPreservedWeek(CURWEEK);}
/* Phase 2 (P2-IMPL-04): a PRE-Phase-2 book saved EMPTY (a parked draft with no
   publication content) classifies as 'current' and stays editable — but it has no
   amV stamp, so the instant it gains content (its first approve/AL) it would
   re-classify as 'unsupported' and go read-only. Stamp the format version at the
   publish path so a validated, currently-supported book stays supported once it
   holds content. A content-bearing legacy/unknown book is already 'unsupported'
   here, so the guard leaves it unstamped — the quarantine holds. */
function stampAmFormat(){if(amFormatOf(SCHED)==='current')SCHED.amV=AMBOOK_VERSION;}
export function dayApproved(di:any){return !!SCHED.dayOK[di];}
export function approvedDays(){return DAYS.map((_:any,i:any)=>i).filter(dayApproved);}
export function dowShort(di:any){return String((DAYS[di]||{}).dow||('day '+di)).slice(0,3);}
export function daysLabel(list:any){return list.length?list.map(dowShort).join(', '):'—';}
/* An AL is a document that went out — now a SINGLE day, so its "days" is just
   [di]. What was ISSUED is frozen on the record (the `diff` and the `snap`) and
   never recalculated; the live keys still drive the marks on screen. */
export function alDays(rec:any){ if(!rec)return []; return rec.di!=null?[+rec.di]:[]; }
/* the item count is frozen on the record at issue (§3 — never from a live key list a later
   delete could shrink). Since D109 (25 Sep 26) it is counted in the same unit "N pending" was
   (`units`, stored by alIssue — a man moved is one item, not two cells); a record issued before
   that falls back to its diff's length. */
export function alCount(rec:any){return !rec?0:rec.units!=null?+rec.units:rec.diff?rec.diff.length:0;}
/* the per-day sequence numbers this day has issued, ascending (1 = AL1 …). */
export function dayALs(di:any){di=+di;return SCHED.als.filter((a:any)=>+a.di===di).map((a:any)=>+a.seq).sort((a:any,b:any)=>a-b);}
/* per-kind counts off a frozen canonical diff — for the AL history and the
   pending summary (kinds: add | delete | change | move | input). */
export function diffCounts(diff:any){const d=diff||[];const by=(k:any)=>d.filter((e:any)=>e.kind===k).length;
  return {total:d.length,add:by('add'),del:by('delete'),chg:by('change')+by('hide'),mov:by('move'),inp:by('input'),oil:by('oil'),warn:by('warn'),hide:by('hide')};}
/* the verId a day is currently showing. The stamped cur[di] counts only while
   its snapshot still resolves; otherwise fall back to the NEWEST surviving issue
   for this day by per-day SEQ, then the Original, then null (never published).
   This derivation IS the orphan guard: a stale SCHED.cur entry after an undo
   past the issue is inert, no cleanup pass exists.
   PARAMETERIZED 29 Aug 26 (one body, two callers — the forward-trace precedent):
   the *In forms take any SCHED-shaped object {cur,als,orig,drafts}, which is how
   the Leave War OIL wire reads publish state out of a STASHED week's snapshot
   (state/store.ts weekStashSnap carries these under schedFields' short keys)
   without loading that week; the bare forms are the live-SCHED wrappers every
   existing caller keeps using. The optional `weekKey` is the trusted week
   identity threaded into the identity/week validation (§1) — CURWEEK on the
   live path, the stash's own key on the OIL stash path. */
export function dayCurVerIn(sc:any,di:any,weekKey?:any){di=+di;
  const v=((sc&&sc.cur)||{})[di];
  if(v!=null&&daySnapIn(sc,di,v,weekKey))return v;
  /* fall back to the NEWEST surviving issue for this day, by per-day SEQ (each
     record is single-day now, so `a.di===di` picks this day's versions). Every
     candidate is re-validated through daySnapIn, so the identity + week-key
     checks (§1, P2-R2-05/P2-R3-03) guard the fallback too. */
  /* iterate this day's issued records by DESCENDING seq and return the HIGHEST
     that VALIDATES through daySnapIn — a higher-seq record filed under the wrong
     week / an inconsistent identity is skipped in favour of a valid lower AL, not
     abandoned to the Original (P2-IMPL-12). */
  const cands=((sc&&sc.als)||[]).filter((a:any)=>a&&+a.di===di&&a.snap&&a.snap.d).sort((a:any,b:any)=>+b.seq-+a.seq);
  for(const a of cands){ if(daySnapIn(sc,di,a.id,weekKey))return a.id; }
  const o=((sc&&sc.orig)||{})[di];
  return (o&&o.id&&daySnapIn(sc,di,o.id,weekKey))?o.id:null;}
export function dayCurVer(di:any){return dayCurVerIn(SCHED,di,CURWEEK);}
export function dayPendCount(di:any){return Object.keys(SCHED.pending).filter((k:any)=>keyDay(k)===di).length;}
/* THE ONE COUNT a person reads as a day's unpublished changes (register AM23, [HUMAN-RETEST]
   the amendment system, 24 Sep 26). On a PUBLISHED day it is the canonical delta against the
   issued version — the same authority as publish eligibility — never the raw pending marks: a
   change with no cell (what the day earns, an input filing) raises no mark, and a filing round
   trip can leave an inert one behind, so a raw count read "nothing unpublished" beside a
   "Publish AL1" button, or an edit that is not there. On a never-published day the draft marks
   ARE the count. The day head, the ⓘ day panel and the plan-switch message all read this. */
export function dayShownPendCount(di:any){di=+di;return dayApproved(di)?dayPendingItems(di).length:dayPendCount(di);}
/* THE ONE COUNTING BODY (owner, D109, 25 Sep 26 — "A move counts as one"). The same comparison
   publication uses (the live day against the CURRENT issued version: the canonical diff, the
   input-filing axis, the OIL axis — dayDeltaIn below), counted in the unit a person counts in:
   a man or a placeholder taken off one place and put on another of the same day is ONE item,
   where the record holds two cells (canonical.ts canonicalUnits). EVERY count reads this — the
   day head's "N pending", the ⓘ panel, the plan-switch message, the sign-off line's "N changes
   to publish", the Amendments panel, the publish message, the stored AL's item count, the load's
   "Discard N edits" (content only) and the pending list itself, whose rows ARE these items — so
   no two of them can disagree. It is empty exactly when dayDelta is (canonicalUnits' invariant),
   so eligibility (dayHasChanges) and the count can never read "0 pending" beside a Publish button.
   What goes out — the stored diff — and the marks on screen are unchanged (D109). */
/* `inp`: a request's filing that belongs to this row's add / delete — the one act of taking a request off (or putting
   it on) the programme (owner, D114, 25 Sep 26: "6 yes"). The record keeps both entries; the person counts one. */
/* `val`: an input's details changed since the day was issued — its own item, or folded into its filing's (D178); `rows`:
   the units of the request row that edit re-landed, folded into it; `was` / `now`: the two records the details entry
   compares — the frozen copy and the live one, which may be ANOTHER record of the same man's (a medical takeover's tail,
   inputs.ts frozenInputMatch step 4, Fable's code read F2), so the words read one edit */
export type PendItem = PendUnit & { axis: 'content'|'filing'|'input'|'oil'|'warn'|'hide', inp?: DeltaEntry, val?: DeltaEntry, rows?: PendUnit[], oilFold?: boolean, was?: any, now?: any };
export function dayPendingItemsIn(sc:any,di:any,weekKey?:any):PendItem[]{di=+di;
  if(!((sc&&sc.dayOK)||{})[di])return [];
  const ver=dayCurVerIn(sc,di,weekKey), snap=ver!=null?daySnapIn(sc,di,ver,weekKey):null;
  if(!snap||!snap.d)return [];
  const items:PendItem[]=canonicalUnits(snap.d,DAYS[di],di).map((u:any)=>({...u,axis:'content'}));
  /* A REQUEST'S ROW AND ITS FILING ARE ONE ACT (owner, D114, 25 Sep 26). ✕ on an accepted request's row removes the
     row AND reads the request "taken off"; accepting one onto the day adds the row AND reads it "on the programme". The
     filing pairs with the ground row whose src is that request — removed from the issued day while the request leaves
     'g', or added to the live day while it arrives at 'g' — so the pair is ONE item. A filing with no such row here (a
     request filed under Unavailable, one whose row stands on another day) stays its own item. */
  /* …AND AN INPUT'S FILING AND ITS DETAILS ARE ONE INPUT ([LEAVE-LATE-PUBLISHED], owner D178, 25 Sep 26 — every member
     input change after publishing is pending). One item per input: a leave filed under Unavailable since (its filing
     and its details both new) reads ONE; so does an accepted request edited after publishing, whose edit re-lands its
     row (the row's times, words or holder move with it — commitInputEdit), and whose window moves the day's OIL block
     when the day earns (folded below). `val` is the details entry; `rows` the re-landed row's own units. */
  const idOf=(e:any)=>String(e.addr||'').split('.').slice(1).join('.');
  const byId=new Map<string,{fil?:DeltaEntry,val?:DeltaEntry}>();
  const slot=(id:string)=>{let g=byId.get(id); if(!g){g={};byId.set(id,g);} return g;};
  const ax=inputAxes(di,snap);
  ax.fil.forEach((e:any)=>{slot(idOf(e)).fil=e;});
  ax.val.forEach((e:any)=>{slot(idOf(e)).val=e;});
  byId.forEach((g,id)=>{
    let item:any=null;
    if(g.fil){const pair=requestRowUnit(items,id,String(g.fil.from||''),String(g.fil.to||''),snap.d,DAYS[di]); if(pair){pair.inp=g.fil; item=pair;}}
    if(!item){item={kind:'input',addr:'',jump:[],keys:[],entry:(g.fil||g.val)!,axis:g.fil?'filing':'input'}; items.push(item);}
    if(g.val){item.val=g.val;
      const ch=ax.changed.find((x:any)=>x.id===id); if(ch){item.was=ch.was; item.now=ch.now;}
      for(let i=items.length-1;i>=0;i--){const u:any=items[i];
        if(u===item||u.axis!=='content'||u.inp||u.val)continue;
        /* its re-landed row's own fields, and the ground programme's order when that row is all that moved in it (a
           request's new times re-sort it — the same edit) */
        if(unitRequestSrc(u,snap.d,DAYS[di])===id||(u.kind==='move'&&/^mov:\d+\.ground$/.test(String((u.entry&&u.entry.addr)||''))&&groundOrderMovedOnlyBy(snap.d,DAYS[di],id))){items.splice(i,1);(item.rows=item.rows||[]).push(u);
          /* …and its place on the schedule: the one line takes the view to the row (Fable's code read F4 — the folded
             line was drawn "still", with the row right there) */
          item.jump=(item.jump||[]).concat(u.jump||[]); item.keys=(item.keys||[]).concat(u.keys||[]);}}}});
  /* the OIL line folds into the inputs that moved it, when they are all that moved it (oilev.ts oilMovedInputsOnly) */
  const oil=oilDelta(di,snap.d);
  if(oil.length){const w=(snap.d||{}).oilev, mem=!!(w&&(w.mem||w.earns));
    const moved=oilMovedInputsOnly(oilEvidence(di),DAYS[di],w,snap.d,mem);
    const who=new Set<string>(); ax.changed.forEach((x:any)=>{if(x.was)who.add(String(x.was.person)); if(x.now)who.add(String(x.now.person));});
    const fold=!!moved&&moved.iids.every((id:string)=>{const g=byId.get(id); return !!(g&&g.val);})&&moved.people.every((p:string)=>who.has(p));
    if(!fold)oil.forEach((e:any)=>items.push({kind:'oil',addr:'',jump:[],keys:[],entry:e,axis:'oil'}));
    /* the record keeps the OIL entry; the line the admin reads says it moves with the input (D45: he SEES it) */
    else{const first:any=items.find((u:any)=>!!u.val); if(first)first.oilFold=true;}}
  /* …and the warnings the issued face froze, when today's judgement of the issued day differs (the live book only —
     a stashed week has no official pass of its own) */
  if(sc===SCHED)warnDelta(di).forEach((e:any)=>items.push({kind:'warn',addr:'',jump:[],keys:[],entry:e,axis:'warn'}));
  /* …and each warning hidden, or flagged again, since the version went out — ONE item each (hideDelta, D471). Wired here
     AND into dayDelta, as the warnings axis is: this list is the day's count, the To go out list and the amendment's
     item count; dayDelta is the publish button and the sign-offs — the two must never disagree (Fable F1, Astra 4). A
     tap goes to the warning's own line (its slot key), where it has one. */
  /* its tap goes to the WARNING'S OWN LINE in the day's list (`warnline:<the hide key>` — ui/interactions.ts jumpToChange
     reads the prefix): the line is the thing that changed, and a warning with no seat of its own (a long work day) has
     one too (the walk, 1 Oct 26 — carrying the warning's seat, such a line could not be tapped, and one with a seat
     lit the seat and left the list shut) */
  if(sc===SCHED)hidePending(di).forEach((x:any)=>items.push({kind:'hide',addr:'',jump:[`warnline:${x.k}`],keys:[],entry:x.entry,axis:'hide'}));
  return items;}
/* the request a content unit belongs to, when the unit is on a field an input's re-landing writes — its ground row's
   words, times, remarks or holder (restore.ts dayKeys: gr:di.ri.{prog,str,end,rmks}, g:di.ri) — '' otherwise. A removal
   reads the issued day's row, anything else the live day's. Extras (g:di.ri.xN) are a scheduler's own and never fold. */
/* is the ground programme's order the same on both sides once the rows landed from request `id` are left out? — then
   its "order changed" is that request's re-landing, not a reorder of anyone else's */
function groundOrderMovedOnlyBy(issuedD:any,liveD:any,id:string):boolean{
  const ids=(d:any)=>(((d&&d.ground)||[]) as any[]).filter((r:any)=>r&&String(r.src||'')!==id).map((r:any)=>r.rid||'');
  const a=ids(issuedD), b=ids(liveD), both=new Set(a.filter((x:any)=>b.includes(x)));
  return a.filter((x:any)=>both.has(x)).join('|')===b.filter((x:any)=>both.has(x)).join('|');}
function unitRequestSrc(u:any,issuedD:any,liveD:any):string{
  const a=String((u&&u.entry&&u.entry.addr)||(u&&u.addr)||'');
  const m=/^gr:\d+\.(\d+)\.(?:prog|str|end|rmks)$/.exec(a)||/^g:\d+\.(\d+)$/.exec(a);
  if(!m)return '';
  const r=(((u.kind==='delete'?issuedD:liveD)||{}).ground||[])[+m[1]];
  return r&&r.src?String(r.src):'';}
/* THE PAIRING, ONE BODY (D114): the content unit — a ground row's add or delete — that belongs to request `id`'s filing
   moving from `was` to `now`. The delete reads the ISSUED day's row at its own index and needs the request to LEAVE
   'g'; the add reads the LIVE day's row and needs it to ARRIVE at 'g'. A unit already paired (`inp` set) is never taken
   twice. Both counts that meet a request's filing read this — the day's items above and the load's "Discard N edits"
   (dayDiscardCount), which counted the row it puts back and the filing it puts back apart, reading 2 beside the day
   head's 1 (the D114 check's roll-call, 25 Sep 26). */
export function requestRow(u:any,d:any):any{const m=/^gr:\d+\.(\d+)\.prog$/.exec(String((u&&u.entry&&u.entry.addr)||''));return m?((d&&d.ground)||[])[+m[1]]||null:null;}
function requestRowUnit(units:any[],id:string,was:string,now:string,issuedD:any,liveD:any):any{
  return units.find((u:any)=>!u.inp&&(
    (u.kind==='delete'&&was==='g'&&now!=='g'&&(requestRow(u,issuedD)||{}).src===id)||
    (u.kind==='add'&&now==='g'&&was!=='g'&&(requestRow(u,liveD)||{}).src===id)))||null;}
export function dayPendingItems(di:any):PendItem[]{di=+di;return passMemo('pi',di,()=>dayPendingItemsIn(SCHED,di,CURWEEK));}
/* the per-kind split of a day's items, the shape diffCounts gives a stored diff — for the
   Amendments panel's "N changes · N removals · N reorders · N input changes" */
export function itemCounts(items:any){const d=items||[];const by=(k:any)=>d.filter((e:any)=>e.kind===k).length;
  /* a hidden warning counts under "changes" (chg takes whatever no other word names) — `hide` says how many of them */
  return {total:d.length,add:by('add'),del:by('delete'),chg:d.length-by('add')-by('delete')-by('move')-by('input')-by('oil')-by('warn'),mov:by('move'),inp:by('input'),oil:by('oil'),warn:by('warn'),hide:by('hide')};}
/* the marks "Discard marks" may clear: those on days never published (F-01 — a published day's
   divergence is published or put back, never silently dropped). The Amendments panel enables
   its button off this, so it is never offered when it could clear nothing (walk S2). */
export function discardableCount(){const orig=SCHED.orig||{};return Object.keys(SCHED.pending).filter((k:any)=>!orig[keyDay(k)]).length;}
export function pendDays(){return uniqDays(Object.keys(SCHED.pending));}
/* pending edits only become publishable amendments once their day is published —
   changes to a day that is still draft are just draft work, not an amendment */
export function publishableKeys(){return Object.keys(SCHED.pending).filter((k:any)=>dayApproved(keyDay(k)));}
export function setDayApproved(di:any,on:any){
  di=+di;
  /* READ-ONLY QUARANTINE (P2-REV2-03): an unsupported / wrong-week book is frozen.
     First-publishing a day stamps SCHED.orig/dayOK and the preserved-blob
     writeback would then discard them on reload — a silent lost publish. Refuse
     at the entry, before the signed/no-op checks below, so the quarantine is the
     first word. Unsupported ≠ unresolvable: this is checked by the WEEK key
     (protectedWeek → amFormatOf(SCHED,CURWEEK)), not by whether verIds resolve. */
  if(on&&protectedWeek())return toast(`${(DAYS[di]||{}).dow||'This day'} is locked — it was published by an older version and can’t be amended here`);
  /* Phase 2 (§9): a published day can NEVER be un-approved — the reopen "beak"
     lost its un-publish job. This path only ever FIRST-approves a draft day;
     changing a published day means editing its working draft and publishing the
     next AL. An `on=false` (or a repeat approve) is a no-op. */
  if(!on||SCHED.dayOK[di])return;
  /* MINT THE ROW IDS BEFORE ANYTHING READS THE DAY (Fable, 21 Sep 26). §9.3
     promises publication freezes exactly the value the signature was validated
     against, and every OIL decision is addressed by a row id — so a row that
     reached here without one would be compared and signed under one address and
     frozen under another. daySnap mints on its way past, which is AFTER
     daySigned and dayDelta have already read the day. Every production add path
     mints before this point, so no reachable case was found; the mint is
     idempotent and costs one walk, which is cheaper than relying on that. */
  ensureRowIds(DAYS);
  if(!daySigned(di))return toast(`${DAYS[di].dow} needs ${signMissing(di).join(', ')} before it can be published`);
  stampAmFormat();   // first publish of a validated empty pre-Phase-2 draft keeps it 'current' (P2-IMPL-04)
  /* the day goes out AS IT STANDS. Everything pending on it up to this moment
     is the draft build, not an amendment to something previously issued —
     leaving those marks meant the day's first AL re-issued the whole day and
     claimed to have "changed" every field the schedulers had ever typed. */
  Object.keys(SCHED.pending).forEach((k:any)=>{if(keyDay(k)===di)delete SCHED.pending[k];});
  Object.keys(SCHED.added||{}).forEach((k:any)=>{if(keyDay(k)===di)delete SCHED.added[k];});
  /* WHO SIGNED THE ORIGINAL IS KEPT, as an amendment's record keeps its four (owner, D95 + D102, 25 Sep 26 — the
     Signed line names who signed each published version, the Original included). It used to be cleared unkept by
     the signClear below, so nothing anywhere could say who approved a day's first issue. Read BEFORE the clear,
     in the same shape alIssue stores (sign:{[di]:{cur,sked,plan,appr}}, callsigns). */
  const origSign=signNames(di);
  SCHED.dayOK[di]=1; signClear(di);          // the signature is spent on the issue
  /* Original = the day as FIRST published, per-day sequence 0. Its immutable
     verId (dayIso#0) is what the resolvers name it by, and cur is stamped to it
     so the day now shows its Original. Frozen forever once issued. */
  SCHED.orig=SCHED.orig||{};
  const iso=dayIso(CURWEEK,di);
  SCHED.orig[di]={id:verId(iso,0),...daySnap(di),sign:{[di]:origSign}};
  SCHED.cur=SCHED.cur||{}; SCHED.cur[di]=verId(iso,0);
  freezeWarn(SCHED.orig[di],di);
  if(SCHED.correcting)delete SCHED.correcting[di];   // [GLOBAL-UNDO] §6.1 — reissuing the Original closes any correction
  reflow(); histPush();
  toast(`${DAYS[di].dow} published — APPROVED`);
}
/* Phase 2 (§9) removed reissueReopened: a published version is FROZEN — it is
   never re-issued in place. A reopen no longer exists; changing a published day
   is always a NEW AL that supersedes the old, which stays immutable in history. */
/* ---- per-day version snapshots -------------------------------------------
   A snapshot is the frozen day plus ITS slice of the changes map, taken at the
   moment of issue — it reproduces the day "as issued, wearing its marks". An AL
   snapshot lives ON the AL record (rec.snap = {d,c,fil}) and the Original in
   SCHED.orig, so both ride the undo stack with the state they belong to.
   CORRECTED 17 Sep 26: the old line here said none of this persists past the
   session. It does. SCHED.orig and SCHED.als ride schedFields(), which
   weekStashSnap() serialises into the week's `weeks/<wk>` record, so on a built
   site the Originals and the whole AL list come back after a reload. Memory-only
   is the dev/test path (MemoryBackend). See CLAUDE.md, WHAT ACTUALLY PERSISTS. */
export function daySnap(di:any){di=+di;
  /* "one walk before every baseline and SNAPSHOT" (engine/rowids.ts) — stated
     as the contract, but only histPush/loadWeek actually ran it, so a row
     created and published inside one turn could be frozen with no identity. It
     matters now because the OIL evidence addresses every item by `rid`
     ([OIL-AUTO-REMOVE] §7.4): an id-less row would freeze a decision-less,
     sentinel-less item and quietly earn nobody anything. Idempotent, never
     printed, so parity is untouched. */
  ensureRowIds(DAYS);
  const c:any={}; Object.keys(SCHED.changes).forEach((k:any)=>{if(keyDay(k)===di)c[k]=SCHED.changes[k];});
  const d=JSON.parse(JSON.stringify(DAYS[di]));
  /* THE OIL EVIDENCE IS FROZEN HERE, and only here ([OIL-AUTO-REMOVE] §7.1/§9.3).
     It rides the day COPY, so the issued document carries its own answer to what
     earns — the credit pass reads snap.d and needs nothing live — while the
     working copy never stores one and cannot go stale. Every clone of a snapshot
     back onto the live day (engine/drafts.ts) strips it for the same reason.
     It is the candidate computed from the day AS IT STANDS AT THIS INSTANT,
     which is the one the signature was validated against: publishALDay checks
     the signatures and takes this snapshot in one synchronous step, and nothing
     between them writes DAYS or INPUTS (alIssue moves SCHED marks only). */
  d.oilev=oilEvidence(di);
  return {d,c,fil:dayFilingFingerprint(di),inp:dayInputsFrozen(di)};}
/* THE DAY'S INPUTS AS ISSUED ([LEAVE-LATE-PUBLISHED], owner D177–D179, 25 Sep 26 — "freeze everything for now"). A copy
   of every input covering this day's date at the moment of issue, keyed by id — every field, its filing state
   included. The issued face reads THESE (engine/inputs.ts inputsOn, installed by ui/html.ts withDaySnap and the
   official pass, validate.ts withIssuedWeek), so a leave filed, edited, deleted or moved after publishing changes the
   working copy only; the comparison below (inputDelta) is what tells the admin, and the next AL (or Unpublish and
   publish again) freezes the new state. `fil` stays beside it: the filing axis, the load's put-back and the signature
   all read it, and it is the same states these copies carry. */
export function dayInputsFrozen(di:any):any{di=+di;
  const dt=(DAYS[di]||{}).dt, out:any={};
  if(dt==null)return out;
  (INPUTS||[]).forEach((inp:any)=>{ if(inputCoversDate(inp,dt))out[inpId(inp)]=JSON.parse(JSON.stringify(inp)); });
  return out;}
/* ---- Phase 2: the FILING FINGERPRINT (P2-R3-01 / P2-R4-01) ------------------
   The publication delta has a fourth axis — input filings — that day content
   does NOT carry: filing an input changes INPUTS.acc, not DAYS. To detect a
   filing change against the issued version WITHOUT trusting the live `inp:`
   pending mark (which survives a file-then-unfile) and WITHOUT depending on live
   INPUTS after navigation (store.ts clears acc), each issued snapshot freezes a
   fingerprint: per input covering this day's date, its acc state. FOUR distinct
   states — 'u' filed-unavailable, 'g' accepted-ground, 'r' removed/dormant, and
   '' fresh/unfiled — because a fresh input still flags conflicts while a 'r' one
   is dormant, so ''→u→r is a real change even though DAYS is unchanged. (absent→u→r
   was one too until D174, 25 Sep 26: the published face reads a request its record
   does not hold as dormant — world.ts fileAcc — so filed since and taken off again
   is no change; filingSame below.) This is NOT AM-04's freezing of full input
   VALUES/identities into content. */
export function dayFilingFingerprint(di:any):any{di=+di;
  const dt=(DAYS[di]||{}).dt, fil:any={};
  if(dt==null)return fil;
  (INPUTS||[]).forEach((inp:any)=>{ if(inputCoversDate(inp,dt))fil[inpId(inp)]=inp.acc||''; });
  return fil;}
/* a STABLE string of the day's filing state, so a signature can bind to the filing
   axis too (owner, 15 Sep 26 — Codex PSF-001). A filing-only change (an Other input
   filed under Unavailable, a leave accepted onto the date) is counted by dayDelta but
   leaves DAYS[di]'s digest untouched, so before this it could publish an AL on stale
   signatures and never cleared the sign-offs. Empty acc == absent, matching
   filingDelta's round-trip rule, so a no-op filing round trip does not invalidate. */
/* …and on a PUBLISHED day a request "taken off" that its current issued version never held (D174) or held "taken off"
   too (D176) is left out of it: neither face shows it, so it is no change (filingSame below) — the four signed before it
   was filed hold again once it is taken off (D103, AM11), and the four signed beside it hold when it is deleted or
   re-dated off the day. Keyed in, the round trip read unsigned beside "0 pending". A change of it that IS one (woken to
   a live request) still moves the binding through `pd`, the whole pending comparison. */
export function filingKey(di:any):string{di=+di;const f=dayFilingFingerprint(di), iss=issuedFilOf(di);
  return Object.keys(f).filter((k:any)=>f[k]&&!(iss&&f[k]==='r'&&filingSame(iss,k,'r'))).sort().map((k:any)=>`${k}=${f[k]}`).join(';');}
/* the current issued version's filing record, on a published day; null on a day not yet published (or one whose
   issued version cannot be read) */
function issuedFilOf(di:any):any{di=+di;if(!dayApproved(di))return null;
  const ver=dayCurVer(di), snap=ver!=null?daySnapOf(di,ver):null;return (snap&&snap.fil)||null;}
/* A FILING THE ISSUED RECORD NEVER HELD, NOW "TAKEN OFF", IS NO DIFFERENCE (owner, D174, 25 Sep 26 — "1. Yes": a request
   filed on a published day and then taken off reads 0). The published face already reads a request its record does not
   hold as dormant (world.ts fileAcc: absent → 'r'), so a request filed since and taken off (✕ on its row, or taken back
   out from under Unavailable) shows exactly what was published: D98, nothing pending. It stays silenced, as ✕ has left
   every request since 26 Aug 26. A request the record DID hold — waiting ('') or on the programme ('g') — and now taken
   off still differs: the issued day showed it. Absent still matches '' as before (a request filed since and not
   actioned, e.g. a leave). AND ITS MIRROR (owner, D176, 25 Sep 26 — "Question 1 make it 0"): a request the record holds
   "taken off", since deleted or re-dated off the day (`present` false — no longer in this day's filing), is no difference
   either: the published face showed it dormant, and nothing shows it now. The same request still on the day and woken
   (retyped, so it flags again) stays a change. ONE rule, read by the comparison (filingDelta), the load's put-back
   (filingRestorePlan) and the signature (filingKey), so none of them can disagree about it. */
function filingSame(was:any,id:any,now:string,present=true):boolean{
  const has=Object.prototype.hasOwnProperty.call(was||{},id), a=has?String(was[id]||''):'';
  return a===now||(!has&&now==='r')||(has&&a==='r'&&!present);}
/* the filing axis: entries for any input whose frozen state differs from now.
   A same-actual-state round trip (r→u→r) is a no-op; absent→u→r is one too since D174, and r→gone since D176
   (filingSame); ''→u→r is a delta. */
function filingDelta(di:any,issuedFil:any):DeltaEntry[]{
  const now=dayFilingFingerprint(di), was=issuedFil||{}, out:DeltaEntry[]=[];
  const ids=new Set([...Object.keys(now),...Object.keys(was)]);
  ids.forEach((id:any)=>{ const a=was[id]||'', b=now[id]||''; if(!filingSame(was,id,b,Object.prototype.hasOwnProperty.call(now,id)))out.push({addr:`inp:${di}.${id}`,kind:'input',from:a,to:b}); });
  return out;}
/* THE OIL EVIDENCE AXIS ([OIL-AUTO-REMOVE] §7.2 / §9.2). A mark on the day
   record is snapshot-able but NOT publishable on its own: canonicalContent is
   built from an EXPLICIT field enumeration (restore.ts dayKeys), and
   canonicalDiff ignores an address that newly appears or disappears unless
   rowKeyOf recognises its owning row — which it cannot, because the OIL block
   owns no row. Without this axis a scheduler could mark an item on a published
   day, get no amendment, and have no way to publish the mark at all, while the
   pass kept reading the older issued snapshot that does not carry it: marked
   forever, never in force.
   So the WHOLE block serialises to ONE always-present value under ONE synthetic
   per-day address. Always present, so it is always compared; deterministic, so
   an unchanged block is byte-identical. No key ever appears or disappears.
   An ABSENT issued block normalises to '' — the same as "nothing decided,
   everything earns" — so the FIRST change against an older snapshot is detected
   rather than read as no change. */
/* BOTH SIDES ARE KEYED WITH THEIR OWN DAY (Codex rank 4, 22 Sep 26). A block
   frozen before `stand` existed carries no standing, and the only honest place
   to recover it is the frozen SCHEDULE beside it — so the issued day goes in,
   not merely its block. Guessing it from `acc` made a cancelled row key
   `active` on the issued side and `cx` live, which offered an amendment on a
   day the money already agreed was unchanged. */
function oilDelta(di:any,issuedDay:any):DeltaEntry[]{
  const w=(issuedDay||{}).oilev;
  /* CAN THE TWO SIDES BE COMPARED ON MEMBERSHIP AT ALL ([OIL-SEATS-CAN-EARN]
     step 9b)? Only where the issued side actually recorded it. A block frozen
     before membership was kept on every day recorded NONE on a day that earns
     nothing — reading that absence as "the crowd changed" would offer an
     amendment nobody made, on every already-published weekday carrying a puck.
     That is the manufactured-amendment shape this branch has now met three
     times, and it is cheaper to refuse the comparison than to explain it.
     An older EARNING block did record membership, so it is still compared on
     it — that signal is real and predates this step. */
  const mem=!!(w&&(w.mem||w.earns));
  const now=oilEvidenceKey(oilEvidence(di),DAYS[+di],mem), was=oilEvidenceKey(w,issuedDay,mem);
  return now===was?[]:[{addr:`oil:${+di}`,kind:'oil',from:was,to:now}];}
/* ---- Phase 2: the ONE normalized publication delta (F-02) ------------------
   Eligibility, the panel counts and the stored diff ALL derive from this — never
   from the accumulated pending marks. Compares the live day against the CURRENT
   issued version (dayCurVerIn/daySnapOf). A never-published day has no issued
   baseline, so its delta is empty (publishing it is the first approve, not an AL).
   Parameterized on a SCHED-shaped object so the same body serves a stashed week
   (the Leave War OIL wire's read) as well as the live book. */
export function dayDeltaIn(sc:any,di:any,weekKey?:any):DeltaEntry[]{di=+di;
  if(!((sc&&sc.dayOK)||{})[di])return [];
  const ver=dayCurVerIn(sc,di,weekKey), snap=ver!=null?daySnapIn(sc,di,ver,weekKey):null;
  if(!snap||!snap.d)return [];
  const ax=inputAxes(di,snap);
  return canonicalDiff(snap.d,DAYS[di],di).concat(ax.fil).concat(ax.val).concat(oilDelta(di,snap.d));}
/* THE TWO INPUT AXES, ONE BODY: the filing (by id — D174, D176) and the details (inputDelta), with the records a move
   or a cascade merely replaced by an identical one taken out of BOTH (inputs.ts frozenInputMatch) — so the count, the
   signature and eligibility read the same answer. A version issued before the freeze has no `inp` and keeps the plain
   filing axis. */
function inputAxes(di:any,snap:any):{fil:DeltaEntry[],val:DeltaEntry[],changed:Array<{id:string,was:any,now:any,nowId?:string}>}{di=+di;
  const fil0=filingDelta(di,snap.fil);
  if(!snap||!snap.inp)return {fil:fil0,val:[],changed:[]};
  const m=frozenInputMatch(snap.inp,(DAYS[di]||{}).dt), gone=new Set<string>();
  m.same.forEach(([a,b])=>{gone.add(a);gone.add(b);});
  const idOf=(e:any)=>String(e.addr||'').split('.').slice(1).join('.');
  return {fil:fil0.filter((e:any)=>!gone.has(idOf(e))),
    val:m.diffs.map((x:any)=>({addr:`inv:${di}.${x.id}`,kind:'input' as const,from:x.was?fp(inpDetailKey(x.was)):'',to:x.now?fp(inpDetailKey(x.now)):''})),
    changed:m.diffs};}
/* THE INPUT DETAILS AXIS — the `val` half of inputAxes above ([LEAVE-LATE-PUBLISHED], owner D177/D178, 25 Sep 26 — "whenever there is a change, in terms of
   input from a member … the admin should see the pending after the schedule is published"). The fifth axis beside the
   content, the filing and the OIL block: one entry per input covering the day whose details differ from the copy the
   current issued version froze (daySnap → snap.inp) — filed since, edited, deleted, re-dated on or off, handed to
   another man. Its filing state is the filing axis's, so a round trip (filed, then deleted) reads nothing, and a
   request taken off on one side and absent on the other reads nothing (D174, D176; inputs.ts frozenInputMatch). The
   entry carries a short fingerprint of each side, so the signature binding (pendingKey, D103) moves with any edit and
   comes back when it is put back (AM11). A version issued before this axis existed froze no inputs and is compared on
   none (demo data, D56). */
/* a short, stable fingerprint of a string (FNV-1a, 32-bit) */
function fp(t:string):string{let h=0x811c9dc5; for(let i=0;i<t.length;i++){h^=t.charCodeAt(i); h=Math.imul(h,0x01000193);} return (h>>>0).toString(36);}
export function dayDelta(di:any):DeltaEntry[]{di=+di;return passMemo('dd',di,()=>dayDeltaCore(di).concat(warnDelta(di)).concat(hideDelta(di)));}
/* the comparison WITHOUT the warnings axis — what the official pass itself must be gated on (validate.ts
   officialDiverges): the warnings axis reads that pass's own output, so gating the pass on it would make the validator
   depend on itself */
export function dayDeltaCore(di:any):DeltaEntry[]{di=+di;return passMemo('dc',di,()=>dayDeltaIn(SCHED,di,CURWEEK));}
/* ---- THE DAY'S WARNINGS AS ISSUED ([LEAVE-LATE-PUBLISHED], owner D179, 25 Sep 26 — "freeze everything for now") ----
   A published day's face used to be re-judged on every change: its issued content and filings, but TODAY's people,
   rules and neighbour days — so a qualification ticked, a rule setting changed or a leave filed on the unpublished day
   beside it moved the issued face's rings and warning list with nothing pending (the sweep B2, B5; D48 for rules). Now
   each issued version keeps the day's slice of the official warnings as they stood the moment it went out (`w`: the
   warning list, and the rings, flags and dashes those warnings raise), the issued face shows THAT (validate.ts
   faceWarn), and the official pass — the same judgement, re-run on today's world — becomes the detector:
   where its slice differs from the stored one, ONE pending change reads "Warnings on this day changed" (warnDelta),
   the four fall (D103, through pendingKey) and the next AL (or Unpublish and publish again) stores the new slice. The
   official pass judges each published day with the inputs it was issued with (layer 1), so this axis never moves on
   the day's own input changes — the input axis counts those — only on what is NOT the day's: people, rules, the days
   around it. EXCEPT what stays live (validate.ts LIVE_ON_FACE — the war's "no period" reminder; a crew-rest breach, the
   7-day run and a lapsed qualification, owner D184/D185, 26 Sep 26; and the next-day crew-rest mark, D183): not stored,
   not compared, drawn on the face from today's judgement — so they alone never make the day pending. The validator
   lends the two bodies through HOOKS at load (publish.ts cannot import it — validate.ts imports
   this file); unset (an engine-only test), nothing is frozen and the face reads the official pass, as before. */
function freezeWarn(snap:any,di:number){ if(!HOOKS.issuedWarn||!snap)return; const w=HOOKS.issuedWarn(di); if(!w)return;
  /* the callsigns its warnings were worded with, by person — so a rename (a label, never a change: 14 Sep 26) reads the
     same warning, and the face can re-word it with today's callsign (validate.ts faceWarn; Astra's plan read #6) */
  w.cs=warnCallsigns(w);
  if(w.face)w.face.cs=warnCallsigns({byDay:{warns:w.face.warns}});
  snap.w=w;
  /* …and what else of the day's face is NOT the day's own data (Astra's plan read #3): the qualifications, seat and
     posting of every man on it (the puck's CAT letter and colour) and the rule value it prints (a blank brief's time).
     The face, the CSV and the print DRAW these as issued (engine/faceattrs.ts — Astra's code read #2; whether to keep
     the brief time with the day, against his 7 Aug 26 "no rule versioning", is his look card's Q1) and they are
     COMPARED, so a change reads pending instead of moving the published face silently.
     And the ROSTER the day went out with (`ros`, Astra's second read #3): the aircrew the day panel's "free all day"
     counts. Drawn as issued, NOT compared — a man joining the squadron would otherwise make every published day pending
     for a count on a panel; nothing on the published face moves either way. */
  snap.pa=dayPeopleAttrs(snap.d,snap.inp); snap.rv=faceRuleVals(snap.d); snap.ros=rosterIds(); }
/* every man an issued face draws, with what his puck draws from the roster: a person id in a PERSON SLOT of its content —
   a flying seat (p, w), a sim seat or passenger (p, w, pax), a desk's holder (id), a ground or Common Programme name
   (who), the extras beside a row (more) — never free text that happens to spell an id (a programme called "bane" is not
   Bane — Astra's second read #4); the men behind every ALL / ALL AVAIL puck, as the day froze them (`oilev.sent` — the
   window lists them as pucks, split by seat: Astra's second read #1); and the man of every input it froze (the Unavailable
   block's pucks, Astra's code read #2) */
const PERSON_SLOTS=new Set(['p','w','pax','id','who','more']);
const attrsOf=(p:any)=>p?{q:p.q??null,seat:p.seat??null,pers:!!p.pers,san:!!p.san,sxo:!!p.sxo,archived:!!p.archived}:null;
export function dayPeopleAttrs(d:any,inp?:any):any{const out:any={};
  const put=(v:any)=>{ if(typeof v!=='string')return; const p=(PEOPLE as any)[v]; if(p&&!out[v])out[v]=attrsOf(p); };
  /* an array keeps the key it sits under (a sim's pax list, a row's extras, a crowd); an object's fields carry their own */
  const walk=(v:any,k:string)=>{ if(k==='oilev')return;
    if(typeof v==='string'){ if(PERSON_SLOTS.has(k))put(v); return; }
    if(Array.isArray(v)){ v.forEach((x:any)=>walk(x,k)); return; }
    if(v&&typeof v==='object')Object.keys(v).forEach((kk:any)=>walk(v[kk],kk)); };
  walk(d,'');
  const sent=(d&&d.oilev&&d.oilev.sent)||{}; Object.keys(sent).forEach((it:any)=>([] as any[]).concat(sent[it]||[]).forEach(put));
  Object.keys(inp||{}).forEach((id:any)=>{ const r=(inp||{})[id]; if(r&&r.person)put(r.person); }); return out;}
/* the men a version recorded, as the roster draws them TODAY — the comparison reads the version's own list of men (its
   content is frozen, so who they are cannot move) and never re-derives it; a man deleted from the roster outright reads
   null, which differs (his puck would vanish from the face) */
/* [POST-OUT-OUTCOMES] (D297, D299 — Fable F8, Astra A7): a DELETED man reads as the version froze him, on every day —
   never compared. Before his cutoff the day is the past, which a delete does not change (D297: "every day he already
   flew keeps his puck"); on or after it he is taken off the working copy, and THAT seat is the one change (D109, D113 —
   one pending change, not a second "posted out" line). The ONE function the pending count (warnDelta) and the pending
   list (ui/pendlist.ts) both read, so the two always agree. */
export function peopleAttrsNow(pa:any):any{const out:any={};
  Object.keys(pa||{}).forEach((id:any)=>{ const p=(PEOPLE as any)[id]; out[id]=(p&&p.deleted)?(pa[id]??null):attrsOf(p); }); return out;}
/* the rule values an issued face PRINTS rather than judges — the blank brief's time (html.ts, board.ts, export.ts) —
   only on a day that prints one (a line with no B) */
const blankB=(w:any)=>((w&&w.formations)||[]).some((f:any)=>f&&!String(f.br||'').trim());
export function faceRuleVals(d:any):any{
  return ((d&&d.waves)||[]).some(blankB)?{briefLead:(VCONF as any).briefLead}:{};}
/* …and whether a change of it is a change the admin must see (Fable's second read #1): only where the SCHEDULE prints
   a suggested brief — a blank B on a flying line. A standby line (SC / AVALON / BB) prints no brief on the face, and a
   blank B there is its normal state (24 Aug 26), so one Logic-page change would otherwise make every published day with a
   standby wave pending for nothing visible. The CSV does print a computed brief on a standby line; `rv` keeps it frozen
   there all the same (it is stored whenever any line is blank), so nothing moves silently. */
export function faceRuleValsCompared(d:any):boolean{
  return ((d&&d.waves)||[]).some((w:any)=>!isStandalone(w)&&blankB(w));}
/* person id → the callsign a slice's warnings name him by */
export function warnCallsigns(w:any):any{const out:any={};
  (((w&&w.byDay&&w.byDay.warns)||[]) as any[]).forEach((x:any)=>{ ([] as any[]).concat(x.who||[]).forEach((id:any)=>{ const p=(PEOPLE as any)[id]; if(p&&p.cs)out[id]=p.cs; }); });
  return out;}
/* a warning's words with each named man's callsign replaced by his id — the same warning under two callsigns keys the
   same (a rename is a label) */
export function warnMsgKey(msg:any,cs:any):string{let m=String(msg||'');
  Object.keys(cs||{}).sort((a,b)=>String(cs[b]).length-String(cs[a]).length).forEach((id:any)=>{ const c=String(cs[id]||''); if(c)m=m.split(c).join('@'+id); });
  return m;}
/* the key a warnings slice is compared on: every warning that freezes (sorted, so the validator's order never reads as
   a change) and the rings, flags and dashes they raise — a live warning's marks are in neither side (warnSliceOf) */
export function warnSliceKey(w:any,cs?:any):string{
  if(!w)return '';
  const names=cs||w.cs||warnCallsigns(w);
  const warns=((w.byDay&&w.byDay.warns)||[]).map((x:any)=>stableJson({...x,msg:warnMsgKey(x.msg,names)})).sort();
  /* the next-day crew-rest / run mark is not compared — it stays live (owner, D183) */
  return stableJson({warns,sev:w.sev||{},chip:w.chip||{},dash:w.dash||{}});}
const WKEY=new WeakMap<any,string>();
/* today's slice — validate.ts hands back the SAME object for a day until the next validate (its memo), so its key is
   worked out once per validate, not on every read of the count */
const LKEY=new WeakMap<any,string>();
function liveWarnKey(w:any):string{if(!w||typeof w!=='object')return warnSliceKey(w);
  let k=LKEY.get(w); if(k===undefined){k=warnSliceKey(w); LKEY.set(w,k);} return k;}
function storedWarnKey(w:any):string{let k=WKEY.get(w); if(k===undefined){k=warnSliceKey(w); WKEY.set(w,k);} return k;}
function warnDelta(di:any):DeltaEntry[]{di=+di;
  if(!HOOKS.warnNow||!dayApproved(di))return [];
  const ver=dayCurVer(di), snap=ver!=null?daySnapOf(di,ver):null;
  if(!snap||!snap.w)return [];
  const now=HOOKS.warnNow(di); if(now==null)return [];
  /* the face beyond the warnings, where the version recorded it: the men on it as the roster draws them, the printed
     rule values */
  const cmpRv=!!snap.rv&&faceRuleValsCompared(snap.d);
  const pa=snap.pa?stableJson(snap.pa):'', rv=cmpRv?stableJson(snap.rv):'';
  const paNow=snap.pa?stableJson(peopleAttrsNow(snap.pa)):'', rvNow=cmpRv?stableJson(faceRuleVals(snap.d)):'';
  const was=storedWarnKey(snap.w)+'\n'+pa+'\n'+rv, k=liveWarnKey(now)+'\n'+paNow+'\n'+rvNow;
  return k===was?[]:[{addr:`warn:${di}`,kind:'warn',from:fp(was),to:fp(k)}];}
/* ---- A WARNING HIDDEN ON A PUBLISHED DAY WAITS FOR THE NEXT AMENDMENT ([WARN-HIDE-KEPT], owner D471, 1 Oct 26 — "2. Waits")
   A hide is the scheduler saying "I have seen this and it is no problem" — on a published day that changes what the
   schedule SHOWS to everyone, so it goes out like every other change to a published day (D45): each issued version
   keeps the keys of the warnings hidden as it went out (`w.wo`, validate.ts HOOKS.issuedWarn), the issued face draws by
   THOSE keys (faceWarn), and this is the comparison — for every warning of today's judgement of the issued day that the
   working copy also raises (HOOKS.hideNow), "hidden on the working copy" against "hidden as issued". EACH ONE THAT
   DIFFERS IS ONE PENDING CHANGE; hide then flag-again is none (D98).
   The entry's address is a FINGERPRINT OF THE WARNING'S KEY — never its place in the list, never its words: the four
   sign-offs are bound to these entries (pendingKey), and a list that re-sorts or a man who is renamed must not drop
   them (Fable F3). The key folds callsigns to ids, so a rename keeps it. `from` / `to` are the plain shown / hidden.
   A version issued before this build has no `wo`: nothing was hidden when it went out. Unset hook (an engine-only test),
   or a day with no stored warnings: nothing is compared. */
export function hidePending(di:any):Array<{entry:DeltaEntry,k:string,hidden:boolean,code:string,who:string[],msg:string,sev:string,key?:string}>{di=+di;
  if(!HOOKS.hideNow||!dayApproved(di))return [];
  const ver=dayCurVer(di), snap:any=ver!=null?daySnapOf(di,ver):null;
  if(!snap||!snap.w)return [];
  const was=new Set<string>(((snap.w.wo||[]) as any[]).map(String));
  return HOOKS.hideNow(di).filter((x:any)=>x.on!==was.has(x.k)).map((x:any)=>({
    entry:{addr:`hide:${di}.${fp(x.k)}`,kind:'hide',from:x.on?'shown':'hidden',to:x.on?'hidden':'shown'} as DeltaEntry,
    k:x.k,hidden:x.on,code:x.code,who:x.who,msg:x.msg,sev:x.sev,key:x.key}));}
function hideDelta(di:any):DeltaEntry[]{ return hidePending(di).map((x:any)=>x.entry); }
/* ONE REPAINT READS EACH DAY'S COMPARISON ONCE (Fable F9, 25 Sep 26 — measured: five published days signed through
   the app's selects cost one edit ~116 ms more at the phone's 4× slowdown, because D103's binding reads the whole
   pending comparison and a day's head, sign-off line and marker each asked for it several times). Inside
   publishReadPass — the day and board string builders, which write nothing — the canonical comparison, the counting
   items and the signature binding are worked out once per day and reused; keyed by the day OBJECT as well, so a
   preview's snapshot swap (withDaySnap replaces DAYS[di]) can never read the live day's answer, or the reverse.
   Outside a pass every call computes afresh, exactly as before. The same shape as oilev.ts oilReadPass. */
let PUB_PASS:Map<string,{d:any,v:any}>|null=null;
export function publishReadPass<T>(fn:()=>T):T{const outer=PUB_PASS; if(!outer)PUB_PASS=new Map();
  try{return fn();}finally{if(!outer)PUB_PASS=null;}}
function passMemo<T>(kind:string,di:number,calc:()=>T):T{
  if(!PUB_PASS)return calc();
  const k=kind+di, hit=PUB_PASS.get(k);
  if(hit&&hit.d===DAYS[di])return hit.v;
  const v=calc(); PUB_PASS.set(k,{d:DAYS[di],v}); return v;}
/* the publish trigger + every publication affordance (P2-02/P2-07): a published
   day has changes iff its normalized delta is non-empty. Derived SOLELY from
   dayDelta — the one authority for eligibility, the panel counts and the stored
   diff (F-02). The old digest fast-path is gone (P2-IMPL-07): the positional
   digest flips on a reorder whose EFFECTIVE display order is unchanged (a ground
   move a gman/time-sort compensates), which enabled a zero-change AL the panel
   then offered no way to publish. dayDelta already gates on dayApproved + a
   resolvable issued snapshot, so this reads straight through it. */
export function dayHasChanges(di:any):boolean{di=+di;return dayDelta(di).length>0;}
/* THE "NOT YET SIGNED" MARKER (published-schedule flagging, §6/§14.5). Shown to
   EVERYONE on a published day whose live working copy diverges from its signed
   version — i.e. an unpublished amendment exists. Derived from the canonical delta
   (dayHasChanges), NEVER from SCHED.pending marks (which survive a file-then-unfile
   round trip), and MUST be read on the LIVE day, before any withDaySnap swap (inside
   the swap the day diffs against itself and reads clean). A never-published day has
   no signed version to diverge from, so the marker is a published-day thing only. */
export function notYetSigned(di:any):boolean{di=+di;return dayApproved(di)&&dayHasChanges(di);}
/* the number of unpublished edits a "Load onto working copy" would DISCARD — the
   count the recovery confirm shows and the recovery handler acts on. ONE authority
   (P2-IMPL-09): the two button renderers (ui/html.ts week, ui/SchedBoard.tsx board)
   and the handler (ui/interactions.ts) all read this, so the confirmed number and
   the discarded number can never drift, and none of them re-derives it from a live
   pending count (which a canonical-only change leaves at 0, and which withDaySnap
   zeroes during a preview render). MUST be read on the LIVE day, before any
   withDaySnap swap. */
/* `toVer` — the version the load will put on the working copy (the one being looked at); unnamed, the current one. It
   decides the HIDES half only: the load sets the day's hides to THAT version's, so of the PENDING hides (hidePending —
   the unpublished ones) it replaces each whose state that version does not share. Loading an older version whose hides
   the working copy already matches replaces none (Astra's scenario design, 1 Oct 26: it said "Discard 1 edit" and
   discarded nothing) — and a hide that is already PUBLISHED is never "your unpublished edit", however it differs from
   the version loaded (the walk, 1 Oct 26: counted as every difference from that version, a look at the Original with
   nothing pending read "1 pending" and "Discard 1 edit & load"). The content half is unchanged. */
export function dayDiscardCount(di:any,toVer?:any):number{di=+di;
  /* CONTENT ONLY — the count of working-draft edits that "Load onto working copy"
     actually DISCARDS. Recovery replaces DAYS (content) but NOT the global input
     filing state, so the filing axis must be EXCLUDED here or the confirm claims
     to discard a filing change it then leaves in place (P2-REREVIEW-08). Publish
     eligibility (dayHasChanges/dayDelta) still counts filing — that IS a real
     divergence — but it is retained across a recovery, not discarded. */
  if(!dayApproved(di))return 0;
  const ver=dayCurVer(di), snap=ver!=null?daySnapOf(di,ver):null;
  if(!snap||!snap.d)return 0;
  /* the DECISIONS half of the OIL block is day content — a recovery replaces it
     with the snapshot's, so it counts here. The DERIVED half (the input
     projection, the frozen sentinel membership) is not: recovery re-derives it
     from the live inputs and roster, exactly as the filing axis is retained. */
  const decDrop=oilDecisionsKey((DAYS[di]||{}).oild)!==oilDecisionsKey((snap.d||{}).oild)?1:0;
  /* counted in the ONE unit (D109): a man moved is one edit here too, as on the day head — and, since the load puts
     back what the version had filed (D98, drafts.ts loadVersionToWorkingCopy), each request filing it will put back
     is an edit it replaces too (the filing axis was excluded while the load left filings alone, P2-REREVIEW-08).
     Only those it CAN put back: one it must leave (it also covers another published day, or its row is landed
     elsewhere) is not replaced, so it is not counted. And a request's row and its filing, both put back, are ONE edit —
     the pairing the day head counts in (D114; the D114 check found this read 2 beside the day head's 1). */
  /* measured against the day as the load will LEAVE it (D175): a row whose request now stands on another day is not
     put back, so the edit that took it off Monday is not replaced — counting it read "Discard 1 edit" for a load that
     discards nothing */
  /* …AND as the working-out after it leaves it ([DB-READINESS] phase 6 (c) — Fable's round-2 F5; drafts.ts dayAsLoadLeaves):
     a deleted man stripped, the rows the holder brings back `kept`, a row re-made for what its request has changed since
     the version (a hand-over), and a request filed since landed again — none of those is discarded by the load */
  const after=HOOKS.dayAsLoadLeaves?HOOKS.dayAsLoadLeaves(di,snap.d):(()=>{const left=rowsLeftOut(di,snap.d);return left.length?leaveRowsOut(JSON.parse(JSON.stringify(snap.d)),left.map((x:any)=>x.id)):snap.d;})();
  const units:any[]=canonicalUnits(after,DAYS[di],di);
  /* the filings are planned against the version's day with its rows as they went out — a row issued `kept` (dead) is not
     "landed" — exactly as the load plans them, before it marks `kept` anew (drafts.ts loadVersionToWorkingCopy; the FULL
     check's walk K2: counted against the worked-out day, the filing it puts back went uncounted and the button said the
     day "is already at" its version) */
  const asIssued=(()=>{const left=rowsLeftOut(di,snap.d);const c=JSON.parse(JSON.stringify(snap.d));return left.length?leaveRowsOut(c,left.map((x:any)=>x.id)):c;})();
  const lone=filingRestorePlan(di,snap.fil,asIssued).put.filter((p:any)=>{
    const u=requestRowUnit(units,inpId(p.inp),String(p.want||''),String(p.inp.acc||''),after,DAYS[di]);
    if(u){u.inp=true;return false;}
    return true;});
  /* …and each PENDING hide the load will undo: it puts the day's hides back to the LOADED version's (drafts.ts
     loadVersionToWorkingCopy, D98), so a hide or a flag-again not yet published is an edit it replaces — unless that
     version already has the warning the way the working copy has it ([WARN-HIDE-KEPT]). A saved plan carries no hides
     and changes none. */
  const tsnap:any=toVer==null||String(toVer)===String(ver)?snap:(String(toVer).slice(0,2)==='d:'?null:daySnapOf(di,toVer));
  const twas=tsnap&&tsnap.w?new Set<string>(((tsnap.w.wo||[]) as any[]).map(String)):null;
  const hides=twas?hidePending(di).filter((x:any)=>twas.has(x.k)!==x.hidden).length:0;
  return units.length+decDrop+lone.length+hides;}
/* WHAT A LOAD CAN PUT BACK OF A VERSION'S FILINGS (owner, D98, 25 Sep 26 — "if the change results in going back to the
   same as the published schedule … it shouldnt show as pending"). For every request covering this day: the state
   the version froze (`fil`, snapshot's filing fingerprint; absent = fresh), set only where it can be true without
   moving anything else — a request's filing is ONE value for every day it covers (INPUTS.acc), and loading one day
   must never change another (AM1; Fable F3, Astra 3):
     · "on the programme" ('g') only where its row is on a loaded day — the load has just put the version's rows back;
     · never away from 'g' while its row stands on a loaded day (a request accepted onto another day stays there);
     · never for a request that covers ANOTHER loaded day at all — its one filing value is that day's too.
   Returns what to set (`put`) and what must be left as filed (`left`, by input id) — the load says so. Pure; the
   load applies it (drafts.ts), and the discard count above counts it, so the confirm and the load agree. `dayAfter`
   is this day as the load will leave it (the version's content) — the discard count asks BEFORE the load, when the
   row it will put back is not on the live day yet; the load itself asks after, with the day already replaced. */
export function filingRestorePlan(di:any,fil:any,dayAfter?:any):{put:Array<{inp:any,want:string}>,left:string[]}{di=+di;
  const dt=(DAYS[di]||{}).dt, put:any[]=[], left:string[]=[];
  if(dt==null)return {put,left};
  (INPUTS||[]).forEach((inp:any)=>{
    if(!inputCoversDate(inp,dt))return;
    const id=inpId(inp), want=String(((fil||{})[id])||''), cur=String(inp.acc||'');
    if(filingSame(fil,id,cur))return;   // D174: a request the version never held, taken off since, stays taken off — never back to a fresh one that flags
    if(inputProtected(inp))return;   // a quarantined week's request is never touched — in the one plan both callers read (Fable's read, #2)
    /* ITS row — on a day it covers. A DEAD kept row (a version's row on a day the request no longer covers, D363) carries
       its id but is not its row, and must not read as "landed" here: the load would leave the issued filing as filed
       (D98). Its current filing is not asked — that is what this plan is about to set ([DB-READINESS] phase 6 (c), the
       FULL check: Astra's scenario design §3 B). */
    /* …and never a row carrying `kept` — on another day a dead one (the view clears the mark from a row that can stand);
       in the incoming version its row as it went out, dead at issue — so a version issued with its row dead and the
       request filed under Unavailable puts both back (the FULL check, Astra's final read #2) */
    const has=(d:any)=>!!d&&inputCoversDate(inp,d.dt)&&((d.ground)||[]).some((g:any)=>g&&g.src===id&&!g.kept);
    const landed=DAYS.some((d0:any,j:number)=>has((j===di&&dayAfter)?dayAfter:d0));
    if(want==='g'?!landed:landed){left.push(id);return;}
    /* the version's OWN row for it stands on this very day: "on the programme" is then the fact, whatever other day the
       request also covers — leaving it "taken off" beside its standing row would be the dangling state P2-REV2-05
       forbids the other way round, and the next AL would freeze it (Fable's code read, #1). The other day reads it too;
       the load names that (LOADMOVED). */
    if(want==='g'&&has((dayAfter||DAYS[di]))){put.push({inp,want});return;}
    /* a request's filing is ONE value for every day it covers, so changing it changes every other loaded day it
       covers too — their pending count, their flags, a waiting change on their working copy (walker B3, 25 Sep 26:
       comparing only with the other day's ISSUED state let a load of Monday silently clear Tuesday's waiting change).
       One day's load never moves another day (AM1): such a request is left as filed, and the load says so. */
    if(DAYS.some((d:any,dj:number)=>dj!==di&&d&&inputCoversDate(inp,d.dt))){left.push(id);return;}
    put.push({inp,want});
  });
  return {put,left};}
/* ONE REQUEST, ONE ROW (owner, D175, 25 Sep 26 — "2. Ok"). A whole-day replacement — loading a version onto the working
   copy, switching to a parked plan — installs a day that may hold the row of a request that has since been put on
   ANOTHER loaded day (✕ on Monday, Accept onto Tuesday, then Monday's older version loaded: Astra's d114 read, Finding
   2). Installed whole, the request stood on two days' programmes, a later ✕ removed only the first, and the orphan left
   behind read two pending. acceptInput has always kept one row per request; this is that rule for the replacements:
   the incoming day leaves such a row OUT, and the door names it — the way the load already leaves a filing it cannot
   set as filed (LOADLEFT), and never by moving the other day (AM1). Returns, per request, the other loaded days its row
   stands on (by index); empty when nothing would stand twice. Pure: the load and the switch apply it (drafts.ts), and
   the load's discard count above counts against it, so the confirm and the load agree. */
/* …AND ON ANOTHER WEEK ([REQ-ORPHAN-ROW], 28 Sep 26 — Fable's G3, F15): a request covering Sun 19 – Mon 20 Jul has one row,
   and it may stand in the OTHER week (weekstash.ts rowElsewhere, read-only). A load or a switch that would bring back a
   copy of it here leaves it out the same way and names that day ("it is on Sun 19 Jul's programme") — `away`.
   A SAVED WEEK THE REQUEST COVERS THAT CANNOT BE READ FAILS CLOSED (Astra's final read #1, 28 Sep 26 — the plan's §9): its
   row may be there, so the incoming copy is left out too and the sentence says the week could not be read (`away`
   'unreadable') — a second row on an unknown is the harm; a row left out is put back by Accept once the week is loaded.
   Narrowed to the weeks the request covers (its request is found by id), so one damaged week blocks only its own. */
export function rowsLeftOut(di:any,dayIn:any):Array<{id:string,days:number[],row:any,away?:string}>{di=+di;const out:any[]=[];
  ((dayIn&&dayIn.ground)||[]).forEach((r:any)=>{const id=r&&r.src; if(!id||out.some((x:any)=>x.id===String(id)))return;
    const days=DAYS.map((d:any,dj:number)=>(dj!==di&&d&&standsOn(d,id))?dj:-1).filter((dj:number)=>dj>=0);   // STANDS there — a dead kept row does not
    if(days.length){out.push({id:String(id),days,row:r});return;}
    const inp=(INPUTS as any[]).find((x:any)=>x&&String(inpId(x))===String(id));
    const w=rowElsewhere(id,inp);
    if(w==='unreadable')out.push({id:String(id),days:[],row:r,away:'unreadable'});
    else if(w)out.push({id:String(id),days:[],row:r,away:w.iso});});
  return out;}
/* take those rows out of a day object (a clone the caller owns — never an issued snapshot or a parked plan's record) */
export function leaveRowsOut(d:any,ids:string[]){
  if(d&&ids.length&&Array.isArray(d.ground))d.ground=d.ground.filter((r:any)=>!(r&&r.src&&ids.includes(String(r.src))));
  return d;}
/* THE ONE PLACE records are found by identity (§1, P2-R2-05/P2-R3-03). `ver` is
   a verId (`iso#seq`) — the Original is `iso#0`, an AL is `iso#seq`. It also
   still resolves a `d:<id>` DRAFT blob (unchanged). It MUST validate that the
   identity belongs to the requested day AND — when a `weekKey` is passed — to
   that week: the flat `als` list no longer implies day-membership, and a
   self-consistent book filed under the WRONG week key would otherwise be
   credited to the wrong dates. A legacy bare number / 'orig' is NOT resolved
   here — an old-format book is quarantined at load (§5), never reaching this
   resolver as authoritative. Returns null for a cross-day / cross-week /
   malformed / foreign id, never a wrong day's snapshot. */
export function daySnapIn(sc:any,di:any,ver:any,weekKey?:any){di=+di;
  /* 'd:<id>' — a pre-publish DRAFT blob (engine/drafts.ts; SCHED.drafts rides
     this object so it undoes with everything else). Resolved here so the whole
     preview machinery — withDaySnap, dayPreviewHTML, DPREV, prunePreviews —
     works on a draft with no second code path; the empty changes slice is the
     truth, a draft has no issued marks by definition. Resolving to null once
     the draft is deleted (or undone away) is what lets prunePreviews drop a
     stale draft preview exactly like a stale AL one. */
  if(typeof ver==='string'&&ver.slice(0,2)==='d:'){
    const t=((((sc&&sc.drafts)||{})[di])||[]).find((x:any)=>'d:'+x.id===ver);
    return t?{d:t.d,c:{}}:null;}
  /* a verId is the ONLY other accepted shape — a bare number/'orig'/foreign
     string resolves to null (quarantined-book back-compat is a load-time
     concern, §5, not this authoritative resolver). Validate the SYNTAX strictly
     (§1, P2-REREVIEW-11): parseVerId coerces, so `iso#` (→ seq 0), `iso#-1`,
     `iso#1.5` and a non-date left part would otherwise resolve — isValidVerId
     rejects them (real ISO date + nonnegative safe-integer sequence). */
  if(typeof ver!=='string'||!isValidVerId(ver))return null;
  const {iso,seq}=parseVerId(ver);
  /* week-key validation: the id's ISO date must BE this day in the passed week
     (live = CURWEEK, stash = the stash's own key). Skipped only when no key is
     threaded (identity-only, e.g. the live delta's internal read). */
  if(weekKey!=null&&iso!==dayIso(weekKey,di))return null;
  if(seq===0){
    const o=((sc&&sc.orig)||{})[di];
    return (o&&o.id===ver)?o:null;   // exact Original-id match — not "any id ending #0"
  }
  const r=((sc&&sc.als)||[]).find((a:any)=>a&&a.id===ver&&+a.di===di&&a.iso===iso&&+a.seq===seq);
  return (r&&r.snap&&r.snap.d)?r.snap:null;}
export function daySnapOf(di:any,ver:any){return daySnapIn(SCHED,di,ver,CURWEEK);}
export function dayVersions(di:any){di=+di;
  const v:any[]=['live'];
  const o=(SCHED.orig||{})[di]; if(o&&o.id)v.push(o.id);
  SCHED.als.filter((a:any)=>+a.di===di&&a.snap&&a.snap.d).slice().sort((a:any,b:any)=>+a.seq-+b.seq).forEach((a:any)=>v.push(a.id));
  return v;}
/* the label a verId reads as: 'Live' for the live working copy, else the
   sequence's per-day label ('Original', 'AL1' …). Draft ('d:<id>') vers are
   relabelled by drafts.ts:draftVerLabel BEFORE they reach here. */
export function verLabel(ver:any){return ver==='live'?'Live':verSeqLabel(verSeq(ver));}
/* AL1 cyan · AL2 amber · AL3 bright green · AL4 white · AL5 purple · AL6 pink ·
   AL7 orange. Every entry has to read as an ALn tag in dark ink (#08131b) on top
   of itself, so the ramp stays light and saturated — the old AL5 magenta (#C21E93)
   was too dark for its own tag. Orange moved 6→7 to make room for the pink; it
   stays off green so it can never be misread as AL3, and it is the last entry,
   which alColor() also hands to any AL past the palette.
   Must stay in step with the [data-alc="n"]{--alc:…} rules in the stylesheet. */
export const AL_COLORS:any[]=['','#3BC6E8','#E5C24A','#3DE86B','#FFFFFF','#B388FF','#FF7FC4','#E5872B'];
export function alColor(n:any){return AL_COLORS[n]||AL_COLORS[AL_COLORS.length-1];}
export function pendCount(){return Object.keys(SCHED.pending).length;}
/* alAttr runs per cell on every repaint — thousands of calls — so its
   "nothing is marked anywhere" short-circuit must not allocate. Object.keys().length
   builds a whole array each call; a for-in with an early return does not. The
   hasOwnProperty guard keeps it EXACTLY equivalent to the old Object.keys check —
   own keys only, ignoring any inherited enumerable property — so a polluted
   Object.prototype can never leak a phantom mark into the byte-compared HTML
   (Astra RID-REV2-02). */
function bookEmpty(){const H=Object.prototype.hasOwnProperty;for(const k in SCHED.changes)if(H.call(SCHED.changes,k))return false;for(const k in SCHED.pending)if(H.call(SCHED.pending,k))return false;return true;}
/* A deletion has no live cell left to carry its amendment mark. Reusing the
   deleted address would tint whatever row shifted into it, so removals use an
   inert synthetic key instead: del:DAY.SEQ.KIND. The day stays first after
   the prefix, which lets every existing day filter, snapshot and AL path
   treat it like an ordinary key; SEQ is derived from live/history keys, so it
   survives publish, unpublish, rollback and undo without extra counter state.
   KIND is controlled vocabulary for the AL panel, never user-entered text. */
export const DELETE_LABELS:any={line:'line',wave:'wave',note:'note',programme:'programme item',dutyblock:'duty block',duty:'duty row',sim:'sim row',ground:'ground item'};
export function isDeleteKey(key:any){return /^del:\d+\.\d+\.[a-z]+$/.test(String(key));}
export function deleteLabel(key:any){const k=String(key).split('.').pop()||'';return DELETE_LABELS[k]||'item';}
export function deleteCount(keys:any){return (keys||[]).filter(isDeleteKey).length;}
export function inputActionCount(keys:any){return (keys||[]).filter((k:any)=>/^inp:\d+\./.test(String(k))).length;}
function syntheticKey(prefix:any,di:any,kind:any){di=+di;
  const p=`${prefix}:${di}.`,keys=Object.keys(SCHED.pending||{}).concat(Object.keys(SCHED.changes||{}));
  (SCHED.als||[]).forEach((a:any)=>keys.push(...(a.keys||[])));
  let n=0;keys.forEach((k:any)=>{if(String(k).indexOf(p)!==0)return;const x=+String(k).slice(p.length).split('.')[0];if(isFinite(x)&&x>n)n=x;});
  return `${p}${n+1}.${kind}`;}
export function deletionKey(di:any,kind:any){kind=DELETE_LABELS[kind]?String(kind):'programme';return syntheticKey('del',di,kind);}
/* REORDERS ON A PUBLISHED DAY use an inert synthetic key too — mov:DAY.SEQ.KIND
   — for the same reason deletions do, plus one specific to reordering (owner,
   31 Aug 26 — a reported bug). Every mover in engine/reorder.ts used to record a
   move by marking the moved row's own head FIELD key (wl:di.to, dr:di.wi.to.role
   …) pending. That works while the swapped rows carry DIFFERENT values there, but
   reconcileIssuedMarks (engine/drafts.ts) then drops any pending field key whose
   live value equals the issued value — so reordering two rows that happen to read
   the SAME at that head (two unnamed waves, two same-role duty rows) had its only
   mark reconciled away: the day read "no changes" and the move reached no AL, even
   though the printed order really had changed. A structural mov: key sidesteps the
   value comparison entirely (reconcile skips it by name, like del:/inp:), so a move
   of an ISSUED row always counts. It is minted ONLY on a published day and ONLY for
   a row that was actually issued — a still-draft added row reordered then deleted
   before its AL is the same net no-op it always was (reorder.ts's `done` gates on
   SCHED.added, so no mov: is minted there). Rides every day filter, snapshot, AL
   and undo path as an ordinary key, exactly as del: does. */
export const MOVE_LABELS:any={wave:'wave',formation:'formation',aircraft:'aircraft',duty:'duty row',dutyblock:'duty block',sim:'sim row',ground:'ground item',programme:'programme item',note:'note'};
export function isMoveKey(key:any){return /^mov:\d+\.\d+\.[a-z]+$/.test(String(key));}
export function moveLabel(key:any){const k=String(key).split('.').pop()||'';return MOVE_LABELS[k]||'item';}
export function moveCount(keys:any){return (keys||[]).filter(isMoveKey).length;}
export function moveKey(di:any,kind:any){kind=MOVE_LABELS[kind]?String(kind):'item';return syntheticKey('mov',di,kind);}
export function markMove(di:any,kind:any){const key=moveKey(di,kind);markEdit(key);return key;}
/* the added-marker is stored rid-anchored (ridWriteKey self-heals a just-added
   row's missing id). Returns the STORED (rid) key, so a caller that indexes
   SCHED.added by the return value stays correct across any later splice. */
export function trackStructuralAdd(key:any){if(!key)return '';SCHED.added=SCHED.added||{};const rk=ridWriteKey(String(key),DAYS);SCHED.added[rk]=1;return rk;}
/* flashAdded gets the POSITIONAL key untranslated — paintFreshAdds matches it
   against the row's data-bfld DOM attribute, which the renderer builds from the
   loop index, never from a rid. */
export function markStructuralAdd(key:any){const rk=trackStructuralAdd(key);markEdit(key);HOOKS.flashAdded(key);return rk;}
export function structuralAddExists(key:any){
  /* the stored key is rid-anchored; resolve it to the CURRENT positional
     address first (null → the row is gone → it no longer exists). A NONROW
     note key and a legacy positional key pass through posKey unchanged. */
  const pk=posKey(key,DAYS); if(pk===null)return false;
  const s=String(pk),c=s.indexOf(':'),p=c<0?'':s.slice(0,c),a=(c<0?s:s.slice(c+1)).split('.'),di=+a[0],d=DAYS[di];
  if(!d)return false;
  if(p==='wl')return !!(d.waves||[])[+a[1]];
  if(p==='ff'){const w=(d.waves||[])[+a[1]];return !!(w&&(w.formations||[])[+a[2]]);}
  if(p==='fr'){const w=(d.waves||[])[+a[1]],f=w&&(w.formations||[])[+a[2]];return !!(f&&(f.aircraft||[])[+a[3]]);}
  if(p==='dn')return +a[1]<(d.notes||[]).length;
  if(p==='ap')return !!(d.allhands||[])[+a[1]];
  if(p==='dl')return !!(d.dutywaves||[])[+a[1]];
  if(p==='dr'){const b=(d.dutywaves||[])[+a[1]];return !!(b&&(b.rows||[])[+a[2]]);}
  if(p==='sr')return !!(((d.sims||{})[String(a[1])]||[])[+a[2]]);
  if(p==='g'||p==='gr')return !!(d.ground||[])[+a[1]];
  return false;
}
/* Whether the structure being removed was present in the day that is
   currently issued. Add -> delete before the next AL is a net no-op, not a
   removal. SCHED.added carries each draft addition's structural key through
   every reorder; issue clears it and unpublish restores it. The frozen issued
   snapshot remains the fallback for legacy/session data without that marker.
   Accepted Ground inputs also pass their stable source token. */
export function deletionWasIssued(di:any,kind:any,...at:any[]){di=+di;
  const added=SCHED.added||{};
  /* the identity keys below are BUILT positional from live indices; SCHED.added
     is now rid-anchored, so translate each built key before the lookup. `issued`
     is computed before the delete splice (board.ts / slots.ts), so the live rows
     still resolve. A note key (dn:) passes through ridKey unchanged. */
  const has=(...keys:any[])=>keys.some((k:any)=>!!added[ridKey(k,DAYS)]);
  if(kind==='line'&&has(`wl:${di}.${+at[0]}`,`ff:${di}.${+at[0]}.${+at[1]}.cs`,`fr:${di}.${+at[0]}.${+at[1]}.${+at[2]}`))return false;
  if(kind==='wave'&&has(`wl:${di}.${+at[0]}`))return false;
  if(kind==='note'&&has(`dn:${di}.${+at[0]}`))return false;
  if(kind==='programme'&&has(`ap:${di}.${+at[0]}.prog`))return false;
  if(kind==='dutyblock'&&has(`dl:${di}.${+at[0]}`))return false;
  if(kind==='duty'&&has(`dl:${di}.${+at[0]}`,`dr:${di}.${+at[0]}.${+at[1]}.role`))return false;
  if(kind==='sim'&&has(`sr:${di}.${String(at[0])}.${+at[1]}.label`))return false;
  if(kind==='ground'&&has(`gr:${di}.${+at[0]}.prog`,`g:${di}.${+at[0]}`))return false;
  if(!dayApproved(di))return true;
  const ver=dayCurVer(di),snap=ver!=null?daySnapOf(di,ver):null,d=snap&&snap.d;
  if(!d)return true;
  if(kind==='ground'&&at[1]!=null)return (d.ground||[]).some((r:any)=>r&&r.src===at[1]);
  /* The snapshot is indexed by the LIVE index, and a reorder makes the two
     diverge: add a draft row, Sort all, and the issued rows can sit at
     indices the shorter issued snapshot never had — so the lookup answered
     "never issued" about a row the squadron holds a printed copy of, and
     its removal reached no AL (audit, 12 Aug 26). The identity checks above
     have already said this row is NOT one of the outstanding draft adds, so
     when its index runs past the snapshot's tail while the live section is
     longer than the issued one, the surplus is exactly those draft adds and
     THIS row must be issued: say so. An in-range hit keeps the plain
     positional answer, which is also the whole story for legacy/session
     data that predates the identity markers. */
  const sectOf=(day:any):any[]=>{
    if(!day)return [];
    if(kind==='wave')return day.waves||[];
    if(kind==='line'){const w=(day.waves||[])[+at[0]],f=w&&(w.formations||[])[+at[1]];return (f&&f.aircraft)||[];}
    if(kind==='note')return day.notes||[];
    if(kind==='programme')return day.allhands||[];
    if(kind==='dutyblock')return day.dutywaves||[];
    if(kind==='duty'){const b=(day.dutywaves||[])[+at[0]];return (b&&b.rows)||[];}
    if(kind==='sim')return ((day.sims||{})[String(at[0])])||[];
    if(kind==='ground')return day.ground||[];
    return [];
  };
  const ix=kind==='line'?+at[2]:(kind==='duty'||kind==='sim')?+at[1]:+at[0];
  if(!isFinite(ix))return true;
  const was=sectOf(d);
  if(ix<was.length&&(kind==='note'||!!was[ix]))return true;
  return sectOf(DAYS[di]).length>was.length;
}
/* DELETE CLEANUP (addressing-by-rid finding 2). A deleted row's stored marks
   have no live cell left to carry them, and — because keys are rid-anchored and
   keys.ts's renumber is now inert on them — nothing renumbers them away either.
   So the real delete sites (board.ts, slots.ts:unacceptInput) capture the
   removed ROOT rid(s) BEFORE the splice and call this after: it drops every
   stored key whose ancestry PATH contains one of those rids. Ancestor-retaining
   keys mean a deleted PARENT rid alone sweeps its children (their keys carry the
   parent rid), so only the root rid(s) need capturing.
   Scoped to the LIVE book (pending/changes/added) ONLY — NEVER an issued AL's
   diff or snap.c (Astra RID-R5-03 ≡ Fable #1): a deleted row is routinely
   RESURRECTED by switching to a parked draft that still holds it, after which
   rebaseDayPending re-tints it from snap.c. Emptying the frozen AL record would
   strand a tint that outlives its issue. Left intact, a stale AL entry on a day
   whose row is gone is inert (structuralAddExists is posKey→null→false). */
export function dropRowMarks(rids:any){
  const set=new Set((rids||[]).filter(Boolean));
  if(!set.size)return;
  const hit=(k:any)=>String(k).split(/[.:]/).some((seg:any)=>set.has(seg));
  [SCHED.pending,SCHED.changes,SCHED.added].forEach((book:any)=>{
    if(!book)return; Object.keys(book).forEach((k:any)=>{if(hit(k))delete book[k];});
  });
}
export function markDeletion(di:any,kind:any,wasIssued:any=true){if(!wasIssued)return '';const key=deletionKey(di,kind);markEdit(key);return key;}
/* THE FILING MARK IS GONE ([DB-READINESS] group A, phase 6 (b)): a filing under Unavailable is counted from the filing
   itself (filingDelta, above) and never written into a day's book — see engine/slots.ts, where it was written. An `inp:`
   key already in a stored book is inert: no cell carries it, and no count reads it. */
/* record an edit.  `key` is the slot/field address that changed — that single
   item is what gets coloured when the amendment is published.
   `was`/`now` are the edit log's (editlog.ts), and optional for the same
   reason noteChange's are: this function is called three different ways and
   only one of them knows both values. A funnel write passes them; a
   structural mark after an add passes a key alone (there is no "before"); the
   bare epilogue in afterSchedMutate() passes nothing at all. Only the first
   reaches the log, which is what keeps a phantom row off every mutation. */
export function markEdit(key?:any,was?:any,now?:any){
  /* store the mark rid-anchored (self-healing translate); logEdit translates
     independently on the read side, so it takes the original key. A synthetic
     del:/mov:/inp: key is NONROW and passes through untranslated. */
  if(key){ const rk=ridWriteKey(key,DAYS); SCHED.pending[rk]=1; delete SCHED.changes[rk]; logEdit(key,was,now); }
  renderStatus();
  histPush();
}
/* the per-item amendment mark, emitted straight into the renderer's HTML.
   A pending edit on a PUBLISHED day is different from draft work: publishing a
   day clears its pending marks (the day goes out as it stands), so anything
   pending on it afterwards is exactly what the next AL will carry. Those keys
   also get data-aln — the per-day sequence they will go out as (nextSeq(di)) —
   so the edit surfaces can paint them in that AL's colour before it exists
   (owner request, Aug 26; the view page ignores the attribute). */
export function alAttr(key:any){
  if(!key)return '';
  /* THE OG TAG ([DRAFT-PENDING] — D172): a change new to the viewer, on a day not yet published (the hook answers
     false for a published day, whose ALn tags below say it) */
  if(HOOKS.newToMe(key))return ` data-og="1" title="A change new to you — see the changes"`;
  /* HOT PAINT PATH. The stored book is rid-anchored, so the positional DOM key
     is translated (ridKey, O(depth)) before the lookup. Skip that walk entirely
     when nothing is marked anywhere — a GLOBAL empty check, not a per-day scan
     (Fable #9). On a pristine model (the parity/html gates) this returns '' with
     no walk, so the emitted HTML stays byte-identical. */
  if(bookEmpty())return '';
  key=ridKey(key,DAYS);
  const n=SCHED.changes[key];
  if(n)return ` data-alc="${n}" title="Changed at AL${n}"`;
  if(SCHED.pending[key]){
    /* an amendment mark only means something once the day is PUBLISHED — it says
       "this differs from the issued document". On a still-draft day nothing has
       been issued, so a pending edit is ordinary draft work, and an amendment-style
       mark on every edit reads as a change to a live schedule and misleads (owner,
       25 Aug 26). Published day → the edit previews the AL it will go out as
       (data-aln, painted in that AL's colour on the edit surfaces); draft day →
       NO mark. History still finds the cell by its own key + the edit log, not by
       this attribute, so the changes list and hover are unaffected. */
    if(dayApproved(keyDay(key))){const x=nextSeq(keyDay(key));return ` data-alp="1" data-aln="${x}" title="Edited — goes out as AL${x}"`;}
    return '';
  }
  return '';
}
/* which published days have changes to go out, and which of those are not
   signed right now — the ALPanel's per-day publish affordance reads these. */
export function pendingPublishDays(){return approvedDays().filter((di:any)=>dayHasChanges(di));}
export function alUnsignedDays(){return pendingPublishDays().filter((di:any)=>!daySigned(di));}
export function canPublishAL(){return pendingPublishDays().length>0&&alUnsignedDays().length===0;}
/* the shared issue step, now SINGLE-DAY (§1/§2/§4): freeze the day as the next
   per-day sequence, storing the immutable verId, the canonical `diff` (from
   dayDelta, the ONE authority) and the day's signatures; stamp cur=id. The old
   structural-add ownership tangle (carried/structAdds/adds) is gone (§2) — an
   issue simply CLEARS the day's SCHED.added entries (they are now frozen in the
   snapshot) and records nothing for a future unpublish (there is none). */
export function alIssue(di:any){di=+di;
  /* READ-ONLY QUARANTINE backstop (P2-REV2-03): the shared final step of every
     publish path — refuse to push a record onto an unsupported/wrong-week book,
     so any caller that reached here (present or future) cannot issue onto frozen
     data. Returns a zero-count result rather than throwing, matching its shape. */
  if(protectedWeek())return {seq:0,id:'',sign:{},count:0};
  stampAmFormat();   // defensive: an AL on a validated (supported) book keeps it 'current' (P2-IMPL-04)
  const seq=nextSeq(di), iso=dayIso(CURWEEK,di), id=verId(iso,seq);
  /* the canonical delta vs the CURRENT issued version, captured BEFORE the marks
     move to changes — this is the frozen record of what this AL changed. */
  const diff=dayDelta(di);
  /* …and its COUNT in the unit "N pending" read a moment ago (D109): the record keeps every
     cell, the person reads "1 item" for a man moved, as the day head said */
  const items=dayPendingItems(di), units=items.length;
  /* …and its per-kind split in the same unit, for the Amendments panel's line (D114: "1 item · 1 removal", never a
     separate "1 input filing" beside it); a record issued before falls back to its diff's split */
  const ukinds=itemCounts(items);
  const keys=Object.keys(SCHED.pending).filter((k:any)=>keyDay(k)===di);
  /* a still-outstanding draft add on this day becomes part of the frozen
     snapshot, so it wears this AL's colour and its live-only marker is cleared. */
  Object.keys(SCHED.added||{}).forEach((k:any)=>{if(keyDay(k)===di&&!keys.includes(k))keys.push(k);});
  /* [GLOBAL-UNDO] §6.5 — remember which of this day's `added` structural marks this
     AL consumed, so an unpublish can restore them: a row added-then-deleted inside
     the retracted AL must not mint a spurious `del:` mark when the AL comes off. */
  const added=Object.keys(SCHED.added||{}).filter((k:any)=>keyDay(k)===di);
  keys.forEach((k:any)=>{SCHED.changes[k]=seq; delete SCHED.pending[k];});
  Object.keys(SCHED.added||{}).forEach((k:any)=>{if(keyDay(k)===di)delete SCHED.added[k];});
  const sign=signNames(di);
  /* freeze the day AFTER its marks are on — this is the document */
  const snap=daySnap(di);
  SCHED.als.push({id,di,iso,seq,snap,diff,units,ukinds,sign:{[di]:sign},added});
  SCHED.cur=SCHED.cur||{}; SCHED.cur[di]=id;   // issuing makes it current
  signClear(di);
  freezeWarn(snap,di);
  reflow(); histPush();   // publishing is its own undo step, not a silent baseline shift
  return {seq,id,sign,count:units};
}
/* publish ONE day's changes as its next per-day AL (P2-08 — never publish-all).
   Gates on dayHasChanges (the canonical delta, F-02), NOT on a live pending
   count: a canonical-only change (order, an input filing, a cancelled-formation
   reason) is publishable even if it left no pending field mark. */
export function publishALDay(di:any){
  di=+di;
  /* READ-ONLY QUARANTINE (P2-REV2-03): refuse a new AL on an unsupported/wrong-week
     book FIRST — before the draft/changes/signature checks — so it cannot slip
     through on a book whose verIds merely happen to resolve. The preserved-blob
     writeback would otherwise discard the issue on reload (a silent lost AL). */
  if(protectedWeek())return toast(`${(DAYS[di]||{}).dow||'This day'} is locked — it was published by an older version and can’t be amended here`);
  if(!dayApproved(di))return toast(`${DAYS[di].dow} is still draft — publish the day before publishing its changes`);
  /* the same mint as the first publish above, for the same reason: every read
     in this turn — the delta, the signature binding, the frozen block — must
     see one set of row ids (Fable, 21 Sep 26). */
  ensureRowIds(DAYS);
  /* [GLOBAL-UNDO] §6.1 GU5-001 — a day being CORRECTED (unpublished, then edited)
     may reissue its SAME label even if the correction nets to no delta; an ordinary
     amendment still needs a real change. */
  const correcting=!!(SCHED.correcting&&SCHED.correcting[di]);
  if(!dayHasChanges(di)&&!correcting)return toast(`No changes to publish on ${DAYS[di].dow}`);
  const seq=nextSeq(di);
  if(!daySigned(di))return toast(`Sign off ${signMissing(di).join(', ')} before publishing AL${seq}`);
  const {sign,count}=alIssue(di);
  if(SCHED.correcting)delete SCHED.correcting[di];   // reissued — the correction is closed
  const who=sign||{};
  const held=pendingPublishDays().length;
  toast(`Published AL${seq} · ${count} item${count===1?'':'s'} on ${dowShort(di)} only`
    +(who.appr?` · approved by ${who.appr}`:'')
    +(held?` · ${held} day${held>1?'s':''} with changes still held`:''));
}
/* Restricted to NEVER-PUBLISHED days (Phase 2 lock, F-01). On a day that has
   an issued Original, discarding its pending marks would silently drop a
   live-vs-issued divergence — the only supported way to change a published day
   is to publish it as the next AL. So keep pending on any day that carries an
   Original, and clear only the draft-build marks on never-published days. */
export function discardPending(){
  const orig=SCHED.orig||{};
  /* say what actually happened (walk S2, 24 Sep 26): it used to toast "Pending marks cleared"
     even when every mark sat on a published day and nothing was touched. */
  let n=0, kept=0;
  Object.keys(SCHED.pending).forEach((k:any)=>{ if(!orig[keyDay(k)]){delete SCHED.pending[k]; n++;} else kept++; });
  if(!n)return toast('Nothing to clear — the changes are on published days: publish them as an amendment, or put them back');
  reflow(); histPush();
  toast(`Cleared ${n} draft mark${n===1?'':'s'}`+(kept?' · published days keep their changes until you publish them or put them back':''));
}
/* ---- [GLOBAL-UNDO] §6.5 — UNPUBLISH: retract a published day to a working copy
   ---------------------------------------------------------------------------
   The engine behind the Unpublish button (§6.4 "correct quietly"). A retracted
   version is kept forever as its own immutable snapshot in the append-only
   `retired` log (retireIssued), and the day drops back to an editable working
   copy so it can be corrected and re-issued under the SAME label. Undo of a
   just-published day runs this same retract (wired at the scheduler cutover). */
function nextRetiredN(id:any):number{let mx=0;const rt=SCHED.retired||{};
  for(const k of Object.keys(rt)){const c=String(k).lastIndexOf('~');
    if(c<0)continue; if(k.slice(0,c)!==String(id))continue;
    const n=+k.slice(c+1); if(Number.isSafeInteger(n)&&n>mx)mx=n;}
  return mx+1;}
/* the id of the version that becomes current once `seq` comes off day `di`: the
   highest remaining AL, else the Original. */
function priorVerId(di:any,seq:any):any{di=+di;
  let top=0; (SCHED.als||[]).forEach((a:any)=>{if(+a.di===di){const s=+a.seq; if(s!==+seq&&Number.isSafeInteger(s)&&s>top)top=s;}});
  if(top>0){const a=(SCHED.als||[]).find((x:any)=>+x.di===di&&+x.seq===top); return a&&a.id;}
  const o=(SCHED.orig||{})[di]; return o&&o.id;}
/* ONE retired entry, built from the issued record `rec` and the retraction's own facts (`at`, `by`, `restoreSeq`,
   `logged`) — shared by retireIssued and by the saved week's reader, which joins an issuance row and its retraction
   row back into this entry (state/weekrows.ts; [DB-READINESS] group A, phase 1 — plan §2.9, R2-04). It keeps the
   issued record WHOLE as `rec`: the database keeps every issuance as one append-only row that an Unpublish never
   touches, so the issuance must be recoverable from its retired entry byte-for-byte — the snapshot below drops the
   Original's roster (`ros`) and an amendment's structural adds (`added`). Everything else is the entry as it always
   read (units: the item count as it went out — D109; Astra 4). */
export function retiredEntry(rec:any,id:any,n:number,di:number,meta:any):any{
  return {id,n,di,iso:parseVerId(id).iso,seq:verSeq(id),
    snap:rec?(rec.snap||{d:rec.d,c:rec.c,fil:rec.fil,inp:rec.inp,w:rec.w,pa:rec.pa,rv:rec.rv}):null,
    diff:(rec&&rec.diff)||[],units:rec&&rec.units!=null?rec.units:undefined,ukinds:rec&&rec.ukinds?rec.ukinds:undefined,sign:(rec&&rec.sign)||{},
    at:meta.at,by:meta.by??null,restoreSeq:meta.restoreSeq,logged:!!meta.logged,rec:rec??null};
}
/* append the issued version `id` to the retired log as its own immutable snapshot
   (keyed `<id>~<n>`) and remove the live issued record. `logged` = whether the
   version was disseminated (the history panel prints only logged entries); at Step
   3 always false (no shared database). Returns the retired key. */
export function retireIssued(di:any,id:any,opts:any={}):string{di=+di;
  const seq=verSeq(id);
  const rec=seq===0?(SCHED.orig||{})[di]:(SCHED.als||[]).find((a:any)=>String(a&&a.id)===String(id));
  SCHED.retired=SCHED.retired||{};
  const key=`${id}~${nextRetiredN(id)}`;
  if(opts.append!==false){
    SCHED.retired[key]=retiredEntry(rec,id,+key.slice(key.lastIndexOf('~')+1),di,{at:new Date().toISOString(),by:opts.by??null,restoreSeq:opts.restoreSeq,logged:!!opts.logged});
  }
  if(seq===0){ if(SCHED.orig)delete SCHED.orig[di]; }
  else { const ix=(SCHED.als||[]).findIndex((a:any)=>String(a&&a.id)===String(id)); if(ix>=0)SCHED.als.splice(ix,1); }
  if(opts.clearSigns)signClear(di);
  return key;}
/* retract the LATEST issued version of a published day. Book-only mutation; the
   command wrapper (state/sched-commit.ts) adds canEditSched + the DPREV gate and
   prunePreviews. Returns the retracted id, or null when the gate refuses. */
export function unpublishDay(di:any,opts:any={}):any{di=+di;
  if(protectedWeek())return null;
  if(!dayApproved(di))return null;
  const id=dayCurVer(di);
  if(id==null)return null;
  const seq=verSeq(id), top=Math.max(0,...dayALs(di));
  if(seq!==top)return null;                 // only the most recent version comes off
  const rec=seq===0?null:(SCHED.als||[]).find((a:any)=>String(a&&a.id)===String(id));
  const added:any[]=(rec&&rec.added)||[];
  retireIssued(di,id,{clearSigns:true,append:opts.append!==false,logged:!!opts.disclosed,by:opts.by});
  /* …and EVERY plan of the day re-signs (AM34, owner 18 Sep 26: unpublish "clears that day's
     sign-offs — re-sign on republish"). Each plan carries its own sign-offs (AM12) and a PARKED
     plan's were never spent, so they revived the moment the day was back at the version they
     were signed against, and could unlock a republish on signatures given before the withdrawn
     version existed ([HUMAN-RETEST] walk W2, Fable 5-11, 24 Sep 26). */
  signClearPlans(di);
  if(seq===0){
    // retract the Original → a plain draft (its build marks were consumed at issue)
    delete SCHED.dayOK[di];
    if(SCHED.cur)delete SCHED.cur[di];
  }else{
    // retract AL n → re-open its marks on the working copy as pending
    Object.keys(SCHED.changes).forEach((k:any)=>{
      if(keyDay(k)!==di||+SCHED.changes[k]!==seq)return;
      delete SCHED.changes[k];
      // a delete/move/input mark, or a field mark whose row still resolves, re-opens
      // as pending; a mark whose row no longer exists is dropped (it can't be edited).
      if(isDeleteKey(k)||isMoveKey(k)||posKey(k,DAYS)!==null)SCHED.pending[k]=1;   // an `inp:` filing mark is never written now (phase 6 (b)) — the filing itself reads pending again
    });
    // restore this AL's structural additions so a row added-then-deleted inside the
    // retracted AL does not mint a spurious del: mark (§6.5).
    SCHED.added=SCHED.added||{}; added.forEach((k:any)=>{SCHED.added[k]=1;});
    SCHED.cur=SCHED.cur||{}; const prior=priorVerId(di,seq);
    if(prior)SCHED.cur[di]=prior; else delete SCHED.cur[di];
  }
  // §6.1 GU5-001 — mark the day as CORRECTING this label, so publishALDay / the
  // button may reissue the SAME label even if the correction nets to no delta.
  SCHED.correcting=SCHED.correcting||{}; SCHED.correcting[di]=id;
  return id;}
/* re-validate + repaint every visible surface */
export const SIGN_ROLES:any[]=[['cur','CUR CK',false],['sked','SKED CK',true],['plan','PLANNED BY',true],['appr','APPROVED BY',true]];
export function signOf(di:any){SCHED.sign=SCHED.sign||{}; return (SCHED.sign[+di]=SCHED.sign[+di]||{cur:'',sked:'',plan:'',appr:''});}
/* [ARCH-STACK] follow-up #1 (R2-01): a NON-MUTATING sign reader. signOf lazily
   INSERTS SCHED.sign[di] on first read, and the sign strip is read on every day
   paint (view week included) — a live write outside any command, so the command
   layer's next diff would emit a spurious sched.book sign record for a day nobody
   signed. The read sites (signRoleOk/signShown/signNames, hence daySigned/
   signMissing) use signAt instead; only the WRITE path (setSign) keeps signOf. A
   frozen shared empty is safe because every reader only READS g[role]. */
const EMPTY_SIGN:any=Object.freeze({cur:'',sked:'',plan:'',appr:''});
export function signAt(di:any){return ((SCHED.sign||{})[+di])||EMPTY_SIGN;}
/* AM-06 — signatures bound to CONTENT (brief §5/§9). Beside the signer name in
   SCHED.sign, each role that is signed through the sanctioned path (setSign)
   records, in SCHED.signBind[di][role], the exact content it signed: the
   canonical digest (§5.0), the schedule date, the current issued base id, and
   the candidate (plan/draft) revision. A signature is content-valid only while
   all four still match the live day. Validity is RECOMPUTED on every read here —
   nothing "clears" a signature on an edit (Rev-4 command-layer §2.1): so an edit
   silently invalidates it and an undo/revert back to the signed content makes it
   valid again (F-09), with no invalidation hook to keep in step with every
   mutation path. */
export function signBindOf(di:any){SCHED.signBind=SCHED.signBind||{}; return (SCHED.signBind[+di]=SCHED.signBind[+di]||{});}
/* the content fingerprint a signature is bound to, as it stands right now. */
export function currentBind(di:any){di=+di;return passMemo('cb',di,()=>currentBindNow(di));}
function currentBindNow(di:any){ const d=DAYS[di];
  /* the OIL evidence is part of what a signature promises ([OIL-AUTO-REMOVE]
     §9.3 point 2): the preview, the amendment comparison, the signature binding
     and publication all call the SAME body, so they cannot disagree about what
     is being signed. Without it an answer-only change would be publishable on a
     signature given before the answer moved. */
  /* THE SIGNATURE'S PROJECTION, NOT THE COMPARISON'S (D45, step 9b) — the OIL key
     below still leaves membership out, and everything else about the block still
     binds through it. BUT D45's signature half was REPLACED on 25 Sep 26 by D103
     ("any change on a published day wipes the sign-offs"): on a published day the
     `pd` axis binds the whole pending comparison, membership included, so a changed
     crowd now DOES take the four down there, and putting it back restores them. */
  /* …and the order the GROUND PROGRAMME is shown in (the amendment re-test's final read, Fable #1,
     24 Sep 26). The digest keys ground rows by their raw place in the array, but the amendment compares the
     order on screen — and a first drag freezes the shown order into the array before it moves, so a drag
     could leave the array exactly as it was: "1 reorder" pending, the four still green, and "Publish AL"
     issuing the reorder on signatures given for the old order (AM10, AM11). */
  /* …NOW BOUND AS SHOWN, NOT AS STORED ([AMEND-SMALL-SEEN] 9, 28 Sep 26 — the amendment re-test's final read, Fable #1's
     mirror). The pair above was (the digest of the rows by their raw array position) + (the shown order of those
     positions), so "Sort" on a ground programme whose rows were STORED out of time order — it is always SHOWN in time
     order — changed both halves and took the four sign-offs down, while the day read "no changes to publish": a false
     re-sign for nothing he could see (D103 — only a change that shows takes them down). So the digest reads a COPY of the
     day whose ground rows stand in their SHOWN order (`groundOrder`, the hand order honoured): position i is the i-th row
     on screen, so the one digest binds content AND shown order together — a row moving on screen moves its content to
     another key and clears the four; a re-order only the array sees changes nothing. `gord` is retired (always ''): it
     only restated the order, and a binding stored while it existed re-signs once (demo data — D56). */
  const shown=d&&Array.isArray(d.ground)&&d.ground.length?{...d,ground:groundOrder(d.ground,d.gman).map((x:any)=>x.row)}:d;
  return {dg:d?digest(shown,di):'', iso:dayIso(CURWEEK,di), base:dayCurVer(di)||'', rev:(SCHED.curDraft||{})[di]||'', fil:filingKey(di), oil:oilSignKey(oilEvidence(di),d), gord:'', pd:pendingKey(di)};}
/* ANY PENDING CHANGE WIPES THE SIGN-OFFS (owner, D103, 25 Sep 26 — his own idea: "why dont we just wipe the
   sign offs for any changes to the schedule?"). ONE rule: something waiting means sign again. So a signature on
   a PUBLISHED day also binds to the whole pending comparison itself — every entry of dayDelta, the same body
   "N pending" and eligibility read — which reaches what the other axes deliberately leave out: a change in who
   is behind ALL / ALL AVAIL (the membership the OIL key above omits — REPLACES D45's signature half), an
   edited request's times, a Quals or posting change. Nothing "clears" it: validity is recomputed on every read,
   so putting the change back restores the four (AM11). On a day not yet published nothing is pending (no issued
   version to differ from) and the key is '' — its content axes above are the whole binding, as before. */
/* …AND A CURRENT GROUND ROW IS NAMED BY ITS ID, NOT ITS PLACE ([AMEND-SMALL-SEEN] 9, 28 Sep 26 — found by the walk,
   sf-d9-sort.mjs, after the digest was made to read the rows as shown). The comparison addresses a ground row by its
   STORED position ("gr:1.3.prog" — the jump needs the real cell), so on a published day with a row added and waiting,
   "Sort" renamed the added rows' addresses and the four fell although nothing on screen moved and the count held. Here —
   and only here, the signature's copy — an address naming a row of the CURRENT day (an add, a change) is rewritten to
   that row's id; one naming the issued day (a delete, a hole — `was`) keeps its issued position, which never moves. A
   real re-order still clears the four (the ORDER entry, and the digest bound as shown); a legacy row with no id keeps
   its position. A binding stored before this re-signs once (demo data — D56). */
function pendingKey(di:any):string{
  const g=(DAYS[di]&&DAYS[di].ground)||[];
  const addr=(e:any)=>{ const a=String(e.addr); if(e.kind==='delete'||e.was)return a;
    const m=/^(gr?):(\d+)\.(\d+)(.*)$/.exec(a); if(!m||+m[2]!==+di)return a;
    const r=g[+m[3]]; return r&&r.rid?`${m[1]}:${di}.@${r.rid}${m[4]}`:a; };
  return dayDelta(di).map((e:any)=>`${addr(e)}${'␟'}${e.kind}${'␟'}${e.from??''}${'␟'}${e.to??''}`).sort().join('\n');}
/* set a role's signer through the ONE sanctioned write path (ui/Shell.tsx). A
   truthy signer binds that role to the current content; clearing a role drops its
   binding. Tests / a legacy demo book that write signOf(di)[role] directly leave
   no binding — see signMissing's back-compat rule. */
export function setSign(di:any,role:any,who:any){di=+di; signOf(di)[role]=who;
  const b=signBindOf(di); if(who)b[role]=currentBind(di); else delete b[role];}
/* a role's binding still matches the live content (or there is no binding — a
   pre-Phase-3 / demo signature, appointment-checked only, as before). */
function signBoundOk(di:any,role:any,cur?:any){const b=(SCHED.signBind||{})[+di]; const x=b&&b[role];
  if(!x)return true; const c=cur||currentBind(di);
  /* a binding written before the filing axis existed (x.fil undefined) must re-sign —
     it cannot prove the filing was approved. CORRECTED 17 Sep 26: the old
     "(dev-phase; sign state is session-scoped)" was wrong — sign and signBind ride
     schedFields into the persisted week record, so a pre-filing binding CAN come
     back from storage. Re-signing is therefore the real guard, not a dev-phase
     convenience. */
  /* the OIL axis normalises absent to '' rather than forcing a re-sign, unlike
     the filing axis above: a binding written before the evidence block existed
     carries no oil field, and on a day that earns nothing there is nothing it
     could have failed to promise. A day that DOES carry evidence still
     invalidates, because '' and a real block differ. */
  /* the ground order axis: RETIRED 28 Sep 26 ([AMEND-SMALL-SEEN] 9) — the digest now binds the rows as SHOWN, so the order
     rides `dg`. Every new binding carries gord ''; one stored while it existed re-signs once (demo data — D56) */
  /* …and the pending comparison (D103): a binding written before it existed reads '' — which is exactly what a
     day with nothing waiting has, so it stands there and falls the moment anything is pending */
  return x.dg===c.dg&&x.iso===c.iso&&x.base===c.base&&x.rev===c.rev&&x.fil===c.fil&&(x.gord||'')===(c.gord||'')&&(x.pd||'')===(c.pd||'')&&oilBoundOk(di,x.oil,c.oil);}
/* A BINDING WRITTEN BEFORE `stand` EXISTED stores the OIL key in the old
   six-part form, which can never equal today's seven-part one — so every
   signature given before this build fell off a day whose content had not moved,
   while the amendment panel (repaired beside it) said that same day was
   unchanged. One day, two contradictory answers (Codex rank 4, 22 Sep 26).
   An old string is tested the only way it can be: today's content is written
   the way HE saw it written, and compared. That alone is NOT enough, and Codex
   is right to say so — job 2 changed what some days pay without changing
   anything the old form could show. So the day must also pay today what it paid
   then. Where it does not, the signature is refused and the day must be signed
   again, which is the honest answer: the money under it moved. */
function oilBoundOk(di:any,was:any,now:any){
  if((was||'')===(now||''))return true;
  if(!was)return false;
  /* A BINDING STORED BEFORE THE TWO PROJECTIONS SPLIT carries the membership
     tail inside it ([OIL-SEATS-CAN-EARN] step 9b). Left alone, every signature
     given before this build would fall off its day the moment anybody filed
     leave — which is precisely what D45 forbids, and the same shape as the
     `stand` break below. The stored string is therefore compared on everything
     EXCEPT that tail. */
  if(oilKeyNoMem(was)===(now||''))return true;
  const ev=oilEvidence(di);
  return oilKeyNoMem(oilKeyBeforeStand(ev))===oilKeyNoMem(was)&&!oilUpgradeMovedMoney(DAYS[+di],ev);}
/* a name only counts while it is still appointed — withdrawing someone's
   Scheduler qual after they signed used to leave the day looking signed — AND
   only while its content binding still holds (AM-06). currentBind is computed at
   most once per call, and only if some role carries a binding. */
/* a role's stored signer, but only while it still COUNTS: signed, still an
   appointed scheduler where the role requires it, and (AM-06) its content binding
   still holding. This is the ONE per-role predicate — signMissing lists the roles
   it rejects, signShown blanks the roles whose BINDING it rejects — so the "N to
   sign" text and the greened sign-off selects can never drift. `cur` is the
   caller's once-per-day currentBind; pass it to avoid recomputing the digest. */
export function signRoleOk(di:any,role:any,cur?:any){
  const g=signAt(di),who=g[role]; if(!who)return false;
  const rr=SIGN_ROLES.find((r:any)=>r[0]===role); if(rr&&rr[2]&&!isScheduler(who))return false;
  const b=(SCHED.signBind||{})[+di];
  if(b&&b[role]){const c=cur||currentBind(di); if(!signBoundOk(di,role,c))return false;}
  return true;}
/* currentBind digest is the only non-trivial cost, so compute it at most once per
   call and only if some role actually carries a binding (the old signMissing rule). */
function signCur(di:any){const b=(SCHED.signBind||{})[+di];
  return b&&SIGN_ROLES.some((r:any)=>b[r[0]])?currentBind(di):undefined;}
export function signMissing(di:any){const cur=signCur(di);
  return SIGN_ROLES.filter((r:any)=>!signRoleOk(di,r[0],cur)).map((r:any)=>r[1]);}
export function daySigned(di:any){return signMissing(di).length===0;}
/* the signer to DISPLAY per role. A signature the day's CONTENT has moved out from
   under (its binding no longer matches the live content) reads EMPTY, so a change
   wipes the green and the day must be re-signed before it can publish (owner, 15
   Sep 26 — "a change needs to be signed off … the sign offs will be removed and
   back to default cleared"). Reverting the content in place restores the binding
   and the name returns (AM-06 F-09). Scoped to BINDING breakage ONLY: an
   unappointed-but-signed name still shows (signPeople keeps it offered) — that
   path is unchanged, so this never silently blanks a name on an appointment change. */
export function signShown(di:any){const b=(SCHED.signBind||{})[+di]; const cur=signCur(di);
  const g=signAt(di),o:any={};
  SIGN_ROLES.forEach((r:any)=>{const k=r[0],who=g[k];
    o[k]=(who&&b&&b[k]&&!signBoundOk(di,k,cur))?'':who;});
  return o;}
export function signClear(di:any){SCHED.sign[+di]={cur:'',sked:'',plan:'',appr:''}; if(SCHED.signBind)SCHED.signBind[+di]={};}
/* the PARKED plans' sign-offs (each plan stows its own, AM12) — a pulled-back day re-signs every plan,
   by the Unpublish button and by Undo alike (AM34, AM32; walk W2 Fable 5-11 and walk W3, 24 Sep 26) */
export function signClearPlans(di:any){((SCHED.drafts||{})[+di]||[]).forEach((t:any)=>{ if(t){ t.sign={cur:'',sked:'',plan:'',appr:''}; t.signBind={}; } });}
/* WHO SIGNED A PUBLISHED VERSION (D95, D102): the four callsigns frozen on its record — an amendment's since Phase 2,
   the Original's since 25 Sep 26 — or null for a version with none recorded (a plan, a draft, a record older than
   the keeping). NEVER the live sign-off boxes: those sign the NEXT issue, and the view page must not show them (AM5). */
export function verSigners(di:any,ver:any):any{di=+di;
  if(typeof ver!=='string'||!isValidVerId(ver))return null;
  const rec=verSeq(ver)===0?((SCHED.orig||{})[di]&&(SCHED.orig||{})[di].id===ver?SCHED.orig[di]:null)
    :(SCHED.als||[]).find((a:any)=>a&&a.id===ver&&+a.di===di);
  const g=rec&&rec.sign&&rec.sign[di];
  return g&&SIGN_ROLES.some((r:any)=>g[r[0]])?g:null;}
export function signNames(di:any){const g=signAt(di),o:any={};SIGN_ROLES.forEach((r:any)=>{const p=PEOPLE[g[r[0]]];o[r[0]]=p?p.cs:'';});return o;}
export function signPeople(schedOnly:any,keep?:any){
  const ids=Object.keys(PEOPLE).filter((id:any)=>!PEOPLE[id].special&&!PEOPLE[id].archived
      &&(!schedOnly||isScheduler(id)));
  /* a name already signed stays offered even if the appointment was since
     withdrawn, so an existing signature never silently blanks itself */
  if(keep&&PEOPLE[keep]&&!ids.includes(keep))ids.push(keep);
  return ids.sort((a:any,b:any)=>PEOPLE[a].cs.localeCompare(PEOPLE[b].cs));
}
/* the next per-day sequence for a day: highest issued seq for THIS day + 1
   (Original is seq 0, so a day's first amendment is AL1). Per-day, so Monday's
   AL1 and Tuesday's AL1 are independent — the old week-wide nextAL is gone. */
export function nextSeq(di:any){di=+di;
  /* number ABOVE every existing sequence for THIS day, counting only a POSITIVE
     safe-integer seq (§1, P2-REREVIEW-11): a fractional / negative / NaN seq no
     longer skews the next number. Any real positive seq still raises the ceiling,
     so a fresh AL can never collide with an existing one. */
  let mx=0; (SCHED.als||[]).forEach((a:any)=>{
    if(!a||+a.di!==di)return;
    const s=+a.seq; if(Number.isSafeInteger(s)&&s>0&&s>mx)mx=s;});
  return mx+1;}
