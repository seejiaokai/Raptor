/* SCHEMA CONFORMANCE — the live seed data against the shapes schema.ts
   declares (Part C of the schema-hardening design). PEOPLE, INPUTS, DAYS,
   SCHED and the two week snapshots are `any` in the engine, so the compiler
   cannot see a field the seed grew that nobody declared. This file can: a
   tiny structural checker (below, no dependency) walks every record and
   fails with the exact path of an UNKNOWN field or a wrong primitive — so
   the types and the data cannot drift apart without a red test.

   New file, ordinary TS style (see the header of schema.ts). */
import { afterAll, describe, expect, it } from 'vitest'
import { PEOPLE, QORDER } from './people'
import { INPUTS, INPUT_META } from './inputs'
import { DAYS } from './data'
import { WEEK2_DAYS } from './week2'
import { SCHED } from './publish'
import { VCONF, SHIFT_HARD } from './rules'
import { SECTIONS } from './order'
import { INPUT_TYPES, QLEVELS, SEATS, SECTION_KEYS, SHIFT_KINDS, VCONF_KEYS } from './schema'
import type { Day, Input, Person } from './schema'
import { makeStandalone } from './waves'
import { WAVETPL_CFG, addWaveTpl, addWaveTplLine, setWaveTplLine, waveFromTpl, waveTplReset } from './wavetpl'
import { DUTYTPL_CFG, addTpl, setTplWave, blockFromTpl, dutyTplReset } from './dutytpl'
import { inpId } from './inputs'
import { alIssue, markEdit } from './publish'


/* ---- the mini-DSL --------------------------------------------------------
   'string' | 'number' | 'boolean'   a primitive; a trailing '?' allows absent
   [spec]                            an array whose every element is spec
   { field: spec, ... }              an exact object: an undeclared key FAILS
   { $or: [spec, ...] }              any one of the specs
   { $lit: [v, ...] }                one of the literal values
   { $map: spec }                    a record with any keys, every value spec
   { $opt: spec }                    absent (undefined) or spec
   The checker collects every failure as `path: message` rather than stopping
   at the first, so one run reports every drift in a seed. */
type Spec = string | Spec[] | { [k: string]: Spec } | { $or: Spec[] } | { $lit: readonly unknown[] } | { $map: Spec } | { $opt: Spec }

const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v)
const show = (v: unknown) => v === null ? 'null' : Array.isArray(v) ? 'array' : typeof v
const describe_ = (s: Spec): string =>
  typeof s === 'string' ? s
  : Array.isArray(s) ? `array of ${describe_(s[0])}`
  : '$or' in s ? (s.$or as Spec[]).map(describe_).join('|')
  : '$lit' in s ? `one of ${(s.$lit as unknown[]).map(x => JSON.stringify(x)).join('|')}`
  : '$map' in s ? `record of ${describe_(s.$map as Spec)}`
  : '$opt' in s ? `optional ${describe_(s.$opt as Spec)}`
  : 'object'

function check(v: unknown, spec: Spec, path: string, errs: string[]) {
  const fail = () => errs.push(`${path}: expected ${describe_(spec)}, got ${show(v)}`)
  if (typeof spec === 'string') {
    const opt = spec.endsWith('?'), t = opt ? spec.slice(0, -1) : spec
    if (v === undefined) { if (!opt) fail(); return }
    if (typeof v !== t) fail()
    return
  }
  if (Array.isArray(spec)) {
    if (!Array.isArray(v)) return fail()
    v.forEach((x, i) => check(x, spec[0], `${path}[${i}]`, errs))
    return
  }
  if ('$opt' in spec) { if (v !== undefined) check(v, spec.$opt as Spec, path, errs); return }
  if ('$lit' in spec) { if (!(spec.$lit as unknown[]).includes(v)) fail(); return }
  if ('$or' in spec) {
    const ok = (spec.$or as Spec[]).some(s => { const e: string[] = []; check(v, s, path, e); return !e.length })
    if (!ok) fail()
    return
  }
  if ('$map' in spec) {
    if (!isObj(v)) return fail()
    Object.keys(v).forEach(k => check(v[k], spec.$map as Spec, `${path}.${k}`, errs))
    return
  }
  if (!isObj(v)) return fail()
  const shape = spec as { [k: string]: Spec }
  Object.keys(v).forEach(k => { if (!(k in shape)) errs.push(`${path}.${k}: unknown field`) })
  Object.keys(shape).forEach(k => check(v[k], shape[k], `${path}.${k}`, errs))
}
/* expect() on the joined list so a failure prints every path at once */
const conform = (v: unknown, spec: Spec, path: string) => { const e: string[] = []; check(v, spec, path, e); expect(e).toEqual([]) }

/* ---- the record specs (mirror schema.ts; a change there changes here) ---- */
const iflag: Spec = { $or: ['boolean', { $lit: ['I'] }] }
const QUALS: Spec = { $map: { $or: ['boolean', { $lit: ['I'] }] } }   // every key optional, admin columns land here too
const PERSON: Spec = {
  cs: 'string', seat: { $lit: SEATS }, q: { $lit: QLEVELS }, sxo: 'boolean?', initials: 'string?', flight: 'string?',
  remarks: 'string?', pers: 'boolean?', special: 'boolean?', archived: 'boolean?', san: 'boolean?',
  sanQ: { $opt: { flown: 'number', carry: 'number', missedQtrs: 'number' } },
  tf: 'boolean?', sched: 'boolean?', scDay: 'boolean?', scNight: 'boolean?', daar: { $opt: iflag }, naar: { $opt: iflag },
  quals: QUALS,
  ord: 'number?',   // the roster's order, on each person ([DB-READINESS] group A, phase 2)
}
const inputSpec = (booted: boolean): Spec => ({
  iid: booted ? 'string' : 'string?', person: 'string', date: 'string', endDate: 'string?', yr: 'number?', allday: 'boolean',
  s: 'number?', e: 'number?', half: { $opt: { $lit: ['am', 'pm'] } }, type: { $lit: INPUT_TYPES }, remarks: 'string?',
  mod: 'string', acc: { $opt: { $lit: ['g', 'u', 'r'] } }, lw: 'string?', docId: 'string?', docIds: { $opt: ['string'] },
  oil: { $opt: { $map: { $lit: [0, 0.5, 1] } } }, sans: { $opt: { f: { $opt: { $lit: [true] } }, o: { $opt: { $lit: [true] } }, a: { $opt: { $lit: [true] } } } },
  ord: 'number?',   // its place in the list ([DB-READINESS] group A, phase 2 — state/ord.ts; every booted row has one — below)
  hand: 'number?',  // how many times it has changed hands ([DB-READINESS] group A, phase 6 (a) — an OIL decision's holding)
  leftAt: { $opt: { $map: 'number' } },   // the holding at which it left each man (phase 6 (a))
})
const FLAGS = { cx: 'boolean?', cxr: 'string?', flag: 'boolean?' }
const ALLHANDS: Spec = { ...FLAGS, prog: 'string', str: 'string', end: 'string', who: { $opt: { $or: ['string', ['string']] } }, more: { $opt: ['string'] }, info: 'boolean?', rid: 'string?' }
const GROUND: Spec = { ...(ALLHANDS as object), rmks: 'string?', src: 'string?', srcType: 'string?', srcv: 'string?', kept: 'boolean?' }
const SAKIND: Spec = { $lit: ['sc', 'avalon', 'bb'] }
const SEAT: Spec = { ...FLAGS, p: 'string', w: 'string', area: 'string', rmks: 'string', opts: { $map: { $or: ['boolean', 'string'] } }, spare: 'boolean?', role: { $opt: { $lit: ['MAIN', 'SPARE'] } }, rid: 'string?' }
const FORMATION: Spec = { cs: 'string', msn: 'string', shift: 'string?', to: 'string', ld: 'string', br: 'string?', area: 'string?', atime: 'string?', aircraft: [SEAT], cx: 'boolean?', cxr: 'string?', rid: 'string?' }
const WAVE: Spec = { label: 'string', night: 'boolean', intimes: ['string'], traffic: ['string'], formations: [FORMATION], standalone: 'boolean?', kind: { $opt: SAKIND }, noconf: 'boolean?', rid: 'string?' }
const SIM: Spec = { ...FLAGS, label: 'string', str: 'string', end: 'string', rmks: 'string?', p: 'string?', w: 'string?', pax: { $opt: ['string'] }, who: 'string?', more: { $opt: ['string'] }, rid: 'string?' }
const DUTYROW: Spec = { ...FLAGS, role: 'string', id: 'string', str: 'string', end: 'string', more: { $opt: ['string'] }, rid: 'string?' }
const DUTYBLOCK: Spec = { label: 'string', rows: [DUTYROW], sa: { $opt: SAKIND }, noconf: 'boolean?', rid: 'string?' }
/* [OIL-AUTO-REMOVE] — the day's OIL decisions (stored day content) and, on an
   ISSUED SNAPSHOT'S day copy only, the frozen evidence block. engine/oilev.ts. */
const OILDEC: Spec = { blanket: { $opt: { $lit: [1] } }, items: { $opt: { $map: 'number' } }, people: { $opt: { $map: 'string' } }, pa: { $opt: { $map: 'number' } } }
const OILINP: Spec = { iid: 'string', person: 'string', type: 'string', asks: 'boolean', acc: 'string', win: { $or: [['number'], 'null'] }, ans: { $or: ['number', 'null'] } }
const OILEV: Spec = { iso: 'string', earns: 'boolean', d: OILDEC, inputs: [OILINP], sent: { $map: ['string'] }, mem: { $opt: { $lit: [1] } } }
const DAY: Spec = {
  dow: 'string', dt: 'string', wc: 'string', today: 'boolean?', notes: [{ rid: 'string?', t: 'string' }], allhands: [ALLHANDS], waves: [WAVE],
  sims: { amt: [SIM], oft: [SIM] }, dutywaves: [DUTYBLOCK], ground: [GROUND],
  simnotes: 'string?', prognotes: 'string?', dutynotes: 'string?', grndnotes: 'string?', secOrder: { $opt: ['string'] }, gman: 'boolean?',
  oild: { $opt: OILDEC }, oilev: { $opt: OILEV },
}
const SIGNSET: Spec = { cur: 'string', sked: 'string', plan: 'string', appr: 'string' }
/* Phase 3 (AM-06): the content a signed role is bound to — canonical digest,
   schedule date, current issued base id, candidate revision. */
const SIGNBIND: Spec = { dg: 'string', iso: 'string', base: 'string', rev: 'string' }
/* Phase 2 DaySnapshot: the frozen day, its issued-marks slice, the filing
   fingerprint, and (on SCHED.orig only) the Original's own verId. */
/* a warning is the validator's own record (engine/validate.ts: sev, code, who, day, di, msg, key and per-rule extras) —
   checked for shape loosely; the rings, flags, dashes and traces are per-person maps, null when empty */
const ANYW: Spec = { $or: ['string', 'number', 'boolean', 'object'] }
const WARNSLICE: Spec = { byDay: { $or: [{ di: 'number', dow: 'string', warns: [{ $map: ANYW }] }, 'object'] }, sev: 'object', chip: 'object', dash: 'object', trace: 'object', cs: { $opt: { $map: 'string' } },
  face: { $opt: { warns: [{ $map: ANYW }], sev: 'object', chip: 'object', dash: 'object', cs: { $opt: { $map: 'string' } } } },   // D187: the whole face at issue
  wo: { $opt: ['string'] }, shown: { $opt: { sev: 'object', chip: 'object', dash: 'object' } } }   // the hides a version went out with, and its marks as shown ([WARN-HIDE-KEPT], D469 / D471)
/* the men on the day as the roster drew them, and the rule values the face prints (drawn as issued and compared — D179,
   Astra's code read #2); the roster at issue (`ros` — drawn by the day panel's "free all day", never compared) */
const PEOPLEATTRS: Spec = { $map: { q: { $or: ['string', 'object'] }, seat: { $or: ['string', 'object'] }, pers: 'boolean', san: 'boolean', sxo: 'boolean', archived: 'boolean' } }
const DAYSNAP: Spec = { d: DAY, c: { $map: 'number' }, fil: { $opt: { $map: 'string' } }, id: 'string?', sign: { $opt: { $map: SIGNSET } },   // sign: the Original's four, kept since 25 Sep 26 (D95, D102)
  /* the day's inputs and warnings as issued ([LEAVE-LATE-PUBLISHED], D177–D179) */
  inp: { $opt: { $map: inputSpec(true) } }, w: { $opt: WARNSLICE }, pa: { $opt: PEOPLEATTRS }, rv: { $opt: { briefLead: 'number' } }, ros: { $opt: ['string'] } }
/* Phase 2 AlRecord: SINGLE-DAY, keyed by its immutable verId; the canonical
   `diff` replaces the old `keys` list, and there is no n/days/n0/adds/structAdds. */
const ANYV: Spec = { $or: ['string', 'number', 'boolean'] }
const ALDIFF: Spec = { addr: 'string', kind: { $lit: ['add', 'delete', 'change', 'move', 'input', 'oil', 'warn', 'hide'] }, from: { $opt: ANYV }, to: { $opt: ANYV } }   // hide: a warning hidden / flagged again (D471)
const UKINDS: Spec = { $opt: { total: 'number', add: 'number', del: 'number', chg: 'number', mov: 'number', inp: 'number', oil: 'number', warn: 'number?', hide: 'number?' } }   // D114; warn: the warnings item (D179)
const AL: Spec = { id: 'string', di: 'number', iso: 'string', seq: 'number', snap: DAYSNAP, diff: [ALDIFF], units: 'number?', ukinds: UKINDS, sign: { $map: SIGNSET }, added: { $opt: ['string'] } }   // units: the item count as a person counts it (D109)
const ONE: Spec = { $lit: [1] }
/* [GLOBAL-UNDO] §6.1 — a retired-issuance snapshot (the append-only log, keyed
   `<verId>~<n>`). snap/by may be null when the retracted record was absent. */
const RETIRED: Spec = { $map: {
  id: 'string', n: 'number', di: 'number', iso: 'string', seq: 'number',
  snap: { $or: [DAYSNAP, { $lit: [null] }] }, diff: [ALDIFF], units: 'number?', ukinds: UKINDS, sign: { $map: SIGNSET },
  at: 'string', by: { $or: ['string', { $lit: [null] }] }, restoreSeq: 'number?', logged: 'boolean',
  rec: { $opt: { $or: [AL, DAYSNAP, { $lit: [null] }] } },   // the issued record kept whole ([DB-READINESS] group A, phase 1)
} }
/* Phase 2: cur is a verId STRING per day (Original = `iso#0`); orig carries an id. */
const SCHED_SPEC: Spec = {
  al: 'number', pending: { $map: ONE }, changes: { $map: 'number' }, added: { $map: ONE }, als: [AL], dayOK: { $map: ONE },
  sign: { $map: SIGNSET }, signBind: { $map: { $map: SIGNBIND } }, orig: { $map: DAYSNAP }, cur: { $map: 'string' },
  drafts: { $opt: { $map: [{ id: 'string', name: 'string', d: DAY }] } }, curDraft: { $opt: { $map: 'string' } },
  ridV: 'number',   // the addressing-by-rid book-format version (engine/rowids.ts)
  amV: { $opt: 'number' },   // the Phase-2 amendment-record format version (§5); absent on a PRE-Phase-2 book
  retired: { $opt: RETIRED }, correcting: { $opt: { $map: 'string' } },   // [GLOBAL-UNDO] §6.1
}
const SCHED_FIELDS = {
  c: { $map: 'number' }, p: { $map: ONE }, ad: { $map: ONE }, a: [AL], al: 'number', ok: { $map: ONE }, sg: { $map: SIGNSET },
  sb: { $map: { $map: SIGNBIND } }, o: { $map: DAYSNAP }, cv: { $map: 'string' },
  dr: { $opt: { $map: [{ id: 'string', name: 'string', d: DAY }] } }, cd: { $opt: { $map: 'string' } },
  v: { $opt: 'number' },   // book-format version; ABSENT on a foundation-era snapshot (triggers migrateLegacyIds)
  am: { $opt: 'number' },  // Phase-2 amendment-record format version; ABSENT on a PRE-Phase-2 snapshot
  rt: { $opt: RETIRED }, cr: { $opt: { $map: 'string' } },   // [GLOBAL-UNDO] §6.1 — the issuance log + correction flags ride the snapshot
}
const PUCK: Spec = { $or: [
  { id: 'string', date: 'string', kind: { $opt: { $lit: ['note'] } }, text: 'string', ord: 'number?' },
  { id: 'string', date: 'string', kind: { $lit: ['pucks'] }, ids: ['string'], ord: 'number?' },
] }
const WEEK_SNAP: Spec = { ...SCHED_FIELDS, d: [DAY], i: [inputSpec(true)], wo: ['string'], pp: [PUCK], dm: { $map: 'string' } }
const STASH_SNAP: Spec = { ...SCHED_FIELDS, d: [DAY], wo: ['string'] }

/* pristine copies, taken at import before any test boots the store: the
   seed literals are what the reference-parity harness reads, and this file
   must judge them as authored, not as initStore leaves them */
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v))
const DAYS0 = clone(DAYS), INPUTS0 = clone(INPUTS), SCHED0 = clone(SCHED), WEEK2 = clone(WEEK2_DAYS)

describe('the structural checker itself', () => {
  it('names the exact path of an unknown field and of a wrong primitive', () => {
    const d = clone(DAYS0[0])
    d.waves[0].formations[0].aircraft[0].bogus = 1          // a field nobody declared
    d.waves[0].formations[0].aircraft[0].opts.tk2 = 7       // a store toggle that is neither boolean nor string
    d.ground.push({ prog: 'X', str: '', end: '' })          // fine — proves the walk goes on past a failure
    const e: string[] = []
    check(d, DAY, 'DAYS[0]', e)
    expect(e).toEqual([
      'DAYS[0].waves[0].formations[0].aircraft[0].bogus: unknown field',
      'DAYS[0].waves[0].formations[0].aircraft[0].opts.tk2: expected boolean|string, got number',
    ])
  })
  it('reports a missing required field, a bad literal and a bad array element', () => {
    const e: string[] = []
    check({ cs: 'X', seat: 'LEFT', q: 'IP', quals: {} }, PERSON, 'P', e)
    check(['a', 2], ['string'], 'L', e)
    expect(e).toEqual([
      'P.seat: expected one of "FCP"|"RCP"|"GND", got string',
      'L[1]: expected string, got number',
    ])
  })
})

describe('the const literal unions match the live catalogues', () => {
  /* the unions in schema.ts are hand-typed copies of keys that live in `any`
     objects; these pins are what stop the two spellings drifting */
  it('INPUT_TYPES = INPUT_META keys', () => expect([...INPUT_TYPES]).toEqual(Object.keys(INPUT_META)))
  it('VCONF_KEYS = VCONF keys', () => expect([...VCONF_KEYS].sort()).toEqual(Object.keys(VCONF).sort()))
  it('SHIFT_KINDS = SHIFT_HARD keys', () => expect([...SHIFT_KINDS]).toEqual(Object.keys(SHIFT_HARD)))
  it('SECTION_KEYS = SECTIONS', () => expect([...SECTION_KEYS]).toEqual(SECTIONS))
  it('QLEVELS = the CAT ladder plus the ground-crew blank', () => expect([...QLEVELS]).toEqual([...Object.keys(QORDER), '']))
})

describe('the seed records conform', () => {
  it('PEOPLE — every person, and every one carries derived quals', () => {
    conform(PEOPLE, { $map: PERSON }, 'PEOPLE')
    Object.keys(PEOPLE).forEach(id => expect(isObj(PEOPLE[id].quals), `PEOPLE.${id}.quals`).toBe(true))
  })
  it('INPUTS (pristine, before iids are minted)', () => conform(INPUTS0, [inputSpec(false)], 'INPUTS'))
  it('DAYS', () => conform(DAYS0, [DAY], 'DAYS'))
  it('WEEK2_DAYS', () => conform(WEEK2, [DAY], 'WEEK2_DAYS'))
  it('the initial SCHED', () => conform(SCHED0, SCHED_SPEC, 'SCHED'))
})

describe('every person reference in the seed resolves', () => {
  /* p / w / id / pax[] / more[] are ids or ''. `who` on a programme, ground
     or sim row may be free text ('EXT SQN'), so it cannot be required to
     resolve — but a value shaped like an id (lowercase word) is one, and a
     typo there would silently schedule nobody. */
  const idish = /^[a-z][a-z0-9]*$/
  const must = (v: unknown, path: string, errs: string[]) => { if (v !== '' && !PEOPLE[v as string]) errs.push(`${path}: '${String(v)}' is not a PEOPLE id`) }
  const who = (v: unknown, path: string, errs: string[]) => {
    const list = Array.isArray(v) ? v : v === undefined ? [] : [v]
    list.forEach((x, i) => { if (typeof x === 'string' && idish.test(x) && !PEOPLE[x]) errs.push(`${path}${Array.isArray(v) ? `[${i}]` : ''}: '${x}' looks like an id but is not a PEOPLE id`) })
  }
  const walk = (days: Day[], name: string) => {
    const errs: string[] = []
    days.forEach((d, di) => {
      const P = `${name}[${di}]`
      d.allhands.forEach((r, i) => { who(r.who, `${P}.allhands[${i}].who`, errs); (r.more || []).forEach((m, j) => must(m, `${P}.allhands[${i}].more[${j}]`, errs)) })
      d.ground.forEach((r, i) => { who(r.who, `${P}.ground[${i}].who`, errs); (r.more || []).forEach((m, j) => must(m, `${P}.ground[${i}].more[${j}]`, errs)) })
      d.waves.forEach((w, wi) => w.formations.forEach((f, fi) => f.aircraft.forEach((a, ai) => {
        must(a.p, `${P}.waves[${wi}].formations[${fi}].aircraft[${ai}].p`, errs)
        must(a.w, `${P}.waves[${wi}].formations[${fi}].aircraft[${ai}].w`, errs)
      })))
      ;(['amt', 'oft'] as const).forEach(k => d.sims[k].forEach((r, i) => {
        const Q = `${P}.sims.${k}[${i}]`
        if (r.p !== undefined) must(r.p, `${Q}.p`, errs)
        if (r.w !== undefined) must(r.w, `${Q}.w`, errs)
        ;(r.pax || []).forEach((x, j) => must(x, `${Q}.pax[${j}]`, errs))
        who(r.who, `${Q}.who`, errs)
      }))
      d.dutywaves.forEach((b, bi) => b.rows.forEach((r, ri) => must(r.id, `${P}.dutywaves[${bi}].rows[${ri}].id`, errs)))
    })
    expect(errs).toEqual([])
  }
  it('DAYS', () => walk(DAYS0, 'DAYS'))
  it('WEEK2_DAYS', () => walk(WEEK2, 'WEEK2_DAYS'))
  it('INPUTS.person', () => {
    const errs: string[] = []
    ;(INPUTS0 as Input[]).forEach((r, i) => must(r.person, `INPUTS[${i}].person`, errs))
    expect(errs).toEqual([])
  })
})

describe('after boot', () => {
  /* initStore merges the other weeks' inputs and the demo seeds, mints every
     iid, lands the activity inputs and takes the first history snapshot —
     the snapshots are only real once it has run. Imported lazily so the
     pristine copies above are taken before the store wires anything. */
  it('histSnap() and weekStashSnap() conform, every input has an iid', async () => {
    const { initStore, weekStashSnap } = await import('../state/store')
    const { histSnap } = await import('../state/history')
    initStore()
    conform(JSON.parse(histSnap()), WEEK_SNAP, 'histSnap')
    conform(JSON.parse(weekStashSnap()), STASH_SNAP, 'weekStashSnap')
    conform(INPUTS, [inputSpec(true)], 'INPUTS')
    /* every booted request and person carries its place in its list ([DB-READINESS] group A, phase 2) */
    expect(INPUTS.filter((r: any) => typeof r.ord !== 'number').map((r: any) => r.iid), 'every request has an ord').toEqual([])
    expect(Object.keys(PEOPLE).filter(id => !PEOPLE[id].special && typeof (PEOPLE as any)[id].ord !== 'number'), 'every person has an ord').toEqual([])
    conform(DAYS, [DAY], 'DAYS')
    conform(SCHED, SCHED_SPEC, 'SCHED')
    Object.keys(PEOPLE).forEach(id => expect(isObj(PEOPLE[id].quals), `PEOPLE.${id}.quals`).toBe(true))
    const { rowsOf } = await import('./rowids')
    DAYS.forEach((d, i) => rowsOf(d).forEach((r: any, j) => expect(typeof r.rid, `DAYS[${i}] row ${j} rid`).toBe('string')))
  })
})

describe('after edits — fields the seeds never carry', () => {
  /* Review, 9 Sep 26: everything above judges data as SHIPPED or as BOOTED.
     Most fields the app writes arrive later — a minted wave or duty block, a
     typed-over area strip, a synced leave, an issued amendment — and the
     checker could not see them (it missed `area`/`atime` and the type of
     `lw` on day one). These cases build those records the way the app does,
     headlessly, and hold them to the same specs. LAST in the file: case (e)
     publishes the live SCHED, and nothing may follow it. */
  afterAll(() => { waveTplReset(); dutyTplReset() })

  it('a minted standalone wave, per kind', () => {
    for (const k of ['sc', 'avalon', 'bb'] as const) conform(makeStandalone(k), WAVE, `makeStandalone(${k})`)
  })
  it('a wave minted from a template, per kind, and a standby template with a spare line', () => {
    for (const k of ['fly', 'sc', 'avalon', 'bb'] as const) {
      const t = addWaveTpl('T ' + k, k)!
      if (k === 'sc') { addWaveTplLine(t.id); setWaveTplLine(t.id, 1, 'spare', true) }
      conform(waveFromTpl(t.id), WAVE, `waveFromTpl(${k})`)
    }
    expect(WAVETPL_CFG.length).toBe(4)
  })
  it('a duty block minted from the standard set and from an AVALON template', () => {
    conform(blockFromTpl(DUTYTPL_CFG[0].id), DUTYBLOCK, 'blockFromTpl(std)')
    const t = addTpl('N')!; setTplWave(t.id, 'avalon')
    const b = blockFromTpl(t.id)
    conform(b, DUTYBLOCK, 'blockFromTpl(avalon)')
    expect(b.sa).toBe('avalon'); expect(b.noconf).toBe(true)
  })
  it('a formation with a typed-over area strip (ui/textedit.ts)', () => {
    const f = clone(DAYS0[0]).waves[0].formations[0]
    f.area = 'NORTH'; f.atime = '0800-0900'
    conform(f, FORMATION, 'formation+area')
  })
  it('a leave synced from the Leave War carries the war id as its lw tag (leavewar/sync.ts)', () => {
    const row: any = { person: 'bane', type: 'LL', date: 'Jul 13', yr: 2026, allday: true, remarks: '', mod: 'now', lw: 'y2026' }
    inpId(row)
    conform(row, inputSpec(true), 'synced leave')
  })
  it('a minted wave, template wave and duty block carry rids once the walk has run', async () => {
    const { ensureRowIds, rowsOf } = await import('./rowids')
    const d: any = { waves: [makeStandalone('sc'), waveFromTpl(WAVETPL_CFG[0].id)], dutywaves: [blockFromTpl(DUTYTPL_CFG[0].id)] }
    ensureRowIds([d])
    expect(rowsOf(d).every((r: any) => typeof r.rid === 'string')).toBe(true)
    conform(d.waves[0], WAVE, 'sc+rid'); conform(d.dutywaves[0], DUTYBLOCK, 'block+rid')
  })
  it('an issued amendment: SCHED, the AL and the day snapshots conform', async () => {
    const { histSnap } = await import('../state/history')
    markEdit('dn:0.0'); alIssue(0)               // Phase 2: single-arg, a day index
    expect(SCHED.als.length).toBe(1)
    expect(SCHED.als[0].seq).toBe(1)             // the day's first amendment
    expect(SCHED.cur[0]).toBe(SCHED.als[0].id)   // cur is the issued verId
    conform(SCHED, SCHED_SPEC, 'SCHED after AL 1')
    conform(JSON.parse(histSnap()), WEEK_SNAP, 'histSnap after AL 1')
  })
  /* [WARN-HIDE-KEPT] — Astra's final read 2, Fable's F5 (1 Oct 26): an amendment can now carry a `hide` entry (a warning
     hidden, or flagged again, on a published day — D471), and the declared shape of the stored record did not list
     it. The table format handed to the IT side is written from this (D473), so it must say what the app saves. */
  it('an amendment that carries a hidden warning: its diff holds a `hide` entry, and the record still conforms', async () => {
    const view = await import('../state/view'), V = await import('./validate'), P = await import('./publish')
    V.validate()
    /* Monday published the way the app publishes it: the four names, then the day */
    P.setSign(0, 'cur', 'ignite'); P.setSign(0, 'sked', 'bane'); P.setSign(0, 'plan', 'stiff'); P.setSign(0, 'appr', 'pump')
    P.setDayApproved(0, true); V.validate()
    expect(P.dayApproved(0), 'Monday is published').toBe(true)
    const w = V.rawWarn().byDay[0].warns[0]
    view.WARNOFF.add(view.warnMuteKey(w)); V.validate()
    expect(P.hidePending(0).length, 'one pending hide').toBe(1)
    alIssue(0)
    const al = SCHED.als[SCHED.als.length - 1]
    expect(al.diff.map((e: any) => e.kind), 'the amendment carries the hide').toContain('hide')
    conform(SCHED, SCHED_SPEC, 'SCHED after an amendment with a hide')
    view.WARNOFF.clear(); V.validate()
  })
})

/* type-level sanity, checked by `tsc -b` (tests are in tsconfig.app.json):
   a literal must satisfy the declared type, so a new required field or a
   narrowed union fails the build. (The live exports are `any`; assigning one
   to a type proves nothing, which is why no such line is here.) */
;({ cs: 'X', seat: 'FCP', q: 'A', quals: {} }) satisfies Person
;({ person: 'x', date: 'Jul 1', allday: true, type: 'LL', mod: 'now' }) satisfies Input
;({ dow: 'Mon', dt: '1 Jul', wc: '', notes: [], allhands: [], waves: [], sims: { amt: [], oft: [] }, dutywaves: [], ground: [] }) satisfies Day
