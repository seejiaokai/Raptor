/* Booting the untouched reference app in jsdom, for the parity tests.
   NOT a test file itself — vitest fails a *.test.ts that declares no tests, so
   this deliberately sits outside that glob. Nothing in the app imports it, so
   it never reaches a bundle.

   The reference is the read-only spec for existing behaviour, and the parity
   tests byte-compare against it. Where the port has deliberately diverged, the
   house idiom is to excise the divergence from BOTH strings and pin it
   positively — never to weaken the comparison.

   This helper removes one whole class of divergence at the source. The seed
   INPUTS no longer match: the port dropped "Office" / "Available fly" /
   "Available duty" and gained "Detachment" (owner decision, Aug 26). Rather
   than excising every row those types touch, push the port's INPUTS into the
   reference so both engines compute from IDENTICAL input data, leaving only the
   structural divergences for the tests themselves to handle.

   The push is filtered through inputFlags (owner, Aug 26): the reference
   has no accept gate of its own, so it must be fed only what the port's
   validator would see or its warnings diverge. filter() preserves order, so
   day.input still compares byte-for-byte. That same filter is what keeps a
   REMOVED input (acc 'r' — dormant since 26 Aug 26, see inputDormant) out of
   the reference entirely: both engines are equally blind to it, so the
   dormancy rule needs no reference-side rewrite at all. */
import { readFileSync } from 'node:fs'
import { JSDOM, VirtualConsole } from 'jsdom'
import { INPUTS, inputFlags } from '../engine/inputs'
import { noteText } from '../engine/note'
import { DAYS } from '../engine/data'
import { PEOPLE } from '../engine/people'

export async function refWindow(): Promise<any> {
  const html = relabel(reshift(reinput(redn(reirest(refirst(reaar(rerest(rering(rebrief(relead(rematrix(resim(rejet(remap(retier(redt(renm(readFileSync('reference/scheduler.html', 'utf8')))))))))))))))))))
  const vc = new VirtualConsole()
  vc.on('jsdomError', () => {})
  const dom = new JSDOM(html, { runScripts: 'dangerously', resources: 'usable', virtualConsole: vc, pretendToBeVisual: true })
  const w: any = dom.window
  w.URL.createObjectURL = () => 'blob:x'
  w.HTMLElement.prototype.scrollIntoView = () => {}
  await new Promise(r => setTimeout(r, 300))
  syncInputs(w)
  reduty(w)
  recs(w)
  reground(w)
  reday(w)
  w.eval('validate()')
  return w
}

/* THE SENSITIVITY SCRUB, mirrored (owner, 21 Aug 26). The port's demo roster
   and its ground/meeting labels were rewritten to fictional handles and generic
   titles so no real callsign or unit name ships in the public demo. The
   reference file is read-only and still carries the originals, so — exactly as
   syncInputs/reduty do for their divergences — the in-memory reference is
   renamed to MATCH THE PORT before either engine runs, keeping every
   byte-comparison (WARN messages, dayHTML markup, seed-DAYS deep-equal) exact.
   The port is the single source of truth: recs copies PEOPLE[*].cs BY ID and
   reground copies the day labels BY POSITION, so no original name is ever
   written into this file. A pure data rename — no rule behaviour moves. */
/* nameToId is id-tolerant in the port (people.ts): a who-string that is already
   a person id resolves to itself. The seed stores lowercase ids in ground and
   programme `who` fields — they used to double as the callsign lowercased, so
   the reference's callsign-only lookup resolved them, until recs (below)
   rewrites the callsigns. Teach the reference's copy the same fallback so both
   engines resolve those who-strings identically, exactly as the ORIGINAL
   callsigns did — a pure resolution parity, no rule moves. */
function renm(html: string): string {
  const from = 'function nameToId(nm){return ID_BY_CS[(nm||\'\').toLowerCase().trim()];}'
  const to = 'function nameToId(nm){const k=(nm||\'\').toLowerCase().trim();return ID_BY_CS[k]||(PEOPLE[nm]?nm:(PEOPLE[k]?k:undefined));}'
  const n = html.split(from).length - 1
  if (n !== 1) throw new Error(`refwin renm: expected exactly 1 match, got ${n}`)
  return html.split(from).join(to)
}

export function recs(w: any) {
  const map: any = {}
  Object.keys(PEOPLE).forEach((id: any) => { map[id] = PEOPLE[id].cs })
  w.eval('(function(m){for(const k in m){if(PEOPLE[k])PEOPLE[k].cs=m[k];}'
    + 'if(typeof ID_BY_CS!=="undefined"&&ID_BY_CS){for(const k in ID_BY_CS)delete ID_BY_CS[k];'
    + 'for(const id in PEOPLE)ID_BY_CS[PEOPLE[id].cs.toLowerCase()]=id;}})('
    + JSON.stringify(map) + ')')
}

/* The ground/all-hands/sim labels the port genericised, pushed onto the
   reference's own DAYS by index (only the first REFN days are compared). Copies
   the exact fields the scrub touched — allhands/ground `prog`, ground/sim `who`,
   sim `label`/`rmks` — leaving times, ids and structure untouched (they were
   already identical, which is why parity passed before). */
export function reground(w: any) {
  const refn = w.eval('DAYS.length')
  DAYS.slice(0, refn).forEach((d: any, i: number) => {
    const p = JSON.stringify({ allhands: d.allhands || [], ground: d.ground || [], sims: d.sims || { amt: [], oft: [] } })
    w.eval(`(function(p){const D=DAYS[${i}];`
      + `if(D.allhands)D.allhands.forEach((r,j)=>{if(p.allhands[j]!=null)r.prog=p.allhands[j].prog;});`
      + `if(D.ground)D.ground.forEach((r,j)=>{if(p.ground[j]!=null){r.prog=p.ground[j].prog;r.who=p.ground[j].who;}});`
      + `['amt','oft'].forEach(k=>{if(D.sims&&D.sims[k])D.sims[k].forEach((r,j)=>{const s=(p.sims[k]||[])[j];if(s!=null){r.label=s.label;if('who' in s)r.who=s.who;if('rmks' in s)r.rmks=s.rmks;}});});`
      + `})(${p})`)
  })
}

/* The second scrub (owner, 9 Sep 26 — "put more made up areas and generic
   wording"): the demo week's AREA codes, day NOTES (the orders line, the EP of
   the day) and the wave TRAFFIC line were rewritten to invented values so no
   real airspace, orders reference or visiting-aircraft detail ships in the
   public demo. Same idiom as reground — the read-only reference still carries
   the originals, so the in-memory copy is overwritten BY POSITION from the
   port's seed before either engine runs, keeping the seed-DAYS deep-equal and
   every rendered byte exact. Pure data; no rule moves. */
export function reday(w: any) {
  const refn = w.eval('DAYS.length')
  DAYS.slice(0, refn).forEach((d: any, i: number) => {
    const p = JSON.stringify({
      /* the reference's notes are bare strings; the port's are { id, t } objects
         since 13 Sep 26 (ARCH-STACK 1A). Project the port note's TEXT so the
         reference stays string-shaped and every rendered byte matches — the id
         is never printed, so it is excluded here (Astra SID-06). */
      notes: (d.notes || []).map((n: any) => noteText(n)),
      waves: (d.waves || []).map((wv: any) => ({
        intimes: wv.intimes || [],
        traffic: wv.traffic || [],
        forms: (wv.formations || []).map((f: any) => (f.aircraft || []).map((a: any) => a.area)),
      })),
    })
    w.eval(`(function(p){const D=DAYS[${i}];`
      + `if(D.notes)D.notes.forEach((_,j)=>{if(p.notes[j]!=null)D.notes[j]=p.notes[j];});`
      + `if(D.waves)D.waves.forEach((wv,g)=>{const q=p.waves[g];if(!q)return;`
      + `wv.intimes=q.intimes.slice();`
      + `if(wv.traffic)wv.traffic.forEach((_,j)=>{if(q.traffic[j]!=null)wv.traffic[j]=q.traffic[j];});`
      + `(wv.formations||[]).forEach((f,k)=>{const fa=q.forms[k];if(!fa)return;`
      + `(f.aircraft||[]).forEach((a,j)=>{if(fa[j]!=null)a.area=fa[j];});});});`
      + `})(${p})`)
  })
}

/* `w.INPUTS = [...]` does NOT work. The reference declares `let INPUTS` at the
   top level of a classic script, which is a global LEXICAL binding, not a
   property of window — assigning to w.INPUTS just creates a shadowing property
   the page never reads. An indirect eval resolves the real binding.

   Mutated in place rather than reassigned, because the reference's own history
   restore does `INPUTS.length=0; …push(…)` and holds references to the array. */
export function syncInputs(w: any) {
  w.eval('INPUTS.length=0;INPUTS.push.apply(INPUTS,JSON.parse('
    + JSON.stringify(JSON.stringify(INPUTS.filter(inputFlags))) + '))')
}

/* Fifth structural divergence, closed the same way as INPUTS. The week's
   duty rows are re-laid into DUTY_ORDER in the port's seed (owner, 8 Aug 26)
   so dropping html.ts's dutySort() prints the board's own order instead of
   silently overriding it. The RENDER side needs no patch for this: the
   reference still sorts, and sorting an already-sorted list is a no-op, so
   both sides paint the same HTML either way. What the re-lay breaks is the
   two STRUCTURAL comparisons in parity.test.ts that read `dutywaves.rows` in
   raw stored order and never went through dutySort in the first place —
   `seed data matches (DAYS)`, a straight deep-equal of the two models, and
   `collectEvents matches the reference exactly`, which walks each day's rows
   in array order to build the timeline. Both sides need the SAME stored
   order for those to hold, and the reference file is read-only, so the fix
   is the model this file already has for INPUTS: push the port's rows into
   the in-memory reference before either engine runs. Same `w.eval` shape and
   the same reason — the reference declares `let DAYS` at the top level of a
   classic script, a lexical binding rather than a window property, so
   `w.DAYS = …` would only shadow it and the page would keep reading its own.
   Mutated wave-by-wave, in place, rather than replacing DAYS wholesale: the
   reference has never had the weekend days the port adds, so only the first
   REFN days are touched, and only their existing dutywaves entries — the
   wave count and labels are unchanged between the two builds, only the row
   order within each wave differs.

   The price: this makes both comparisons TAUTOLOGICAL for duty-row content
   and order. By the time `seed data matches (DAYS)` or `collectEvents
   matches the reference exactly` run, the reference's rows ARE the port's
   rows — a corrupted duty row landing in data.ts (a wrong name, a dropped
   role, a mistyped time) would not be caught here; it would show up
   identically on both sides and compare equal. Nothing outside this
   function narrows that gap. What still has teeth: every OTHER field of
   DAYS and collectEvents — flying waves, sims, ground, notes — is still a
   real comparison against the untouched reference; wave LABELS are never
   touched by this push (only `.rows` is overwritten) so a wrong or renamed
   label still fails for real.
   The wave-count-mismatch guard is ONE-DIRECTIONAL, not the blanket safety
   net an earlier version of this comment claimed (corrected, review 9 Aug
   26): the forEach above walks the PORT's `d.dutywaves`, so it only throws,
   from the out-of-bounds `DAYS[i].dutywaves[j]` write, when the PORT has
   MORE duty blocks for a day than the reference does. The reverse — the
   port having FEWER — writes nothing at all for the missing indices and
   leaves the reference's extra block exactly as it was; that direction is
   caught downstream instead, by `seed data matches (DAYS)`'s ordinary deep
   comparison of the two models (a dutywaves array of the wrong length
   simply fails to deep-equal).
   The guard that actually still holds duty-row ORDER accountable is a
   different one, and it is not this function's own throw: the reference's
   render still calls dutySort(dwv.rows) on whatever this push hands it
   (reference/scheduler.html's dutySort, DUTY_ORDER unchanged), while the
   port renders model order with no sort at all. The two markups agree only
   because the seed's rows are ALREADY laid out in role order — the moment a
   real drag (or a future seed) leaves a duty block out of role order, the
   reference's render re-sorts it back and the port's does not, and
   `html.test.ts`'s byte-exact dayHTML comparison fails on the DIVERGED
   MARKUP, immediately, with no help needed from this function. It's
   accepted because there is nothing left for the old model-level comparison
   to assert honestly: the port and the reference deliberately no longer
   agree on stored duty order (that is the whole point of dropping the
   port's own dutySort), so holding the parity gate to duty-row model
   content would not buy more coverage — the markup comparison above already
   catches a drift, and buys it for free. */
export function reduty(w: any) {
  const refn = w.eval('DAYS.length')
  DAYS.slice(0, refn).forEach((d: any, i: number) => {
    d.dutywaves.forEach((dw: any, j: number) => {
      w.eval(`DAYS[${i}].dutywaves[${j}].rows.length=0;`
        + `DAYS[${i}].dutywaves[${j}].rows.push.apply(DAYS[${i}].dutywaves[${j}].rows,JSON.parse(`
        + JSON.stringify(JSON.stringify(dw.rows)) + `))`)
    })
  })
}

/* Second structural divergence, closed the same way as the INPUTS push — at
   the source, before boot. NO_BRIEF, SIM_BRIEF and DT_SUM are amber in the
   port (owner, 4 Aug 26); the reference bakes 'hard' into those three call
   sites as string literals. Patch the in-memory copy so both engines carry
   the same tiers and every byte-comparison (WARN, dayHTML markup, banner
   counts) stays exact — the file on disk is never touched. Each replacement
   must hit exactly once: if the reference text ever shifts, this throws
   rather than silently comparing the un-patched behaviour. */
function retier(html: string): string {
  const swaps: Array<[string, string]> = [
    ["markChip(di,id,'NB');markRing(di,id,'hard');\n          add('hard','NO_BRIEF'",
     "markChip(di,id,'NB');markRing(di,id,'adv');\n          add('adv','NO_BRIEF'"],
    ["markChip(di,id,'SB');markRing(di,id,'hard');\n          add('hard','SIM_BRIEF'",
     "markChip(di,id,'SB');markRing(di,id,'adv');\n          add('adv','SIM_BRIEF'"],
    ["add('hard','DT_SUM'", "add('adv','DT_SUM'"],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin retier: expected exactly 1 match, got ${n} for: ${from.slice(0, 40)}…`)
    html = html.replace(from, to)
  }
  return html
}

/* A double-booked man is not "double turning" (owner, 21 Aug 26 — the hard
   DOUBLE_BOOK clash already speaks for him, so the DT chip and the DT_SUM
   advisory now need some pair of his legs to be SEQUENTIAL, i.e. airborne
   windows apart). The reference counts any 2+ sorties; patch the same
   dturns predicate into its copy — validate.ts is the master, keep the two
   bodies identical — so both engines carry the same rule. It fires nowhere
   on the seed week (nobody is double-booked there), but "they agree on this
   week" is luck, not parity — the rematrix OCU_NO_IP note's rule. */
function redt(html: string): string {
  const swaps: Array<[string, string]> = [
    ["const byP={}; day.fly.filter(e=>!e.shift).forEach(e=>{(byP[e.id]=byP[e.id]||[]).push(e);});",
     "const byP={}; day.fly.filter(e=>!e.shift).forEach(e=>{(byP[e.id]=byP[e.id]||[]).push(e);});"
     + "const dturns=(ls)=>{for(let i=0;i<ls.length;i++)for(let j=i+1;j<ls.length;j++)if(!(ls[i].to!=null&&ls[j].to!=null&&overlap(ls[i].to,ls[i].ld,ls[j].to,ls[j].ld)))return true;return false;};"],
    ["if(es.length>=2)markChip(di,id,'DT');",
     "if(es.length>=2&&dturns(es))markChip(di,id,'DT');"],
    ["const dts=Object.keys(byP).filter(id=>byP[id].length>=2);",
     "const dts=Object.keys(byP).filter(id=>byP[id].length>=2&&dturns(byP[id]));"],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin redt: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}

/* Third structural divergence, closed the same way. The port's CAT ladder is
   OCU→D→C→B→A→IW→IP→IR→FI (owner, Aug 5 '26): the generic I tier and the
   standalone `ip` flag are gone, instructor-ness lives solely in CAT. The
   reference still carries I/CI + ip:true, so patch the in-memory copy to the
   same world before boot:
     · ladder tables (QCHIP/QCLASS/QCOLOR/LEVELNAME/QORDER) → the port's, byte
       for byte, so migrated CATs resolve to identical chips and tooltips
     · isInstr → the four-CAT body
     · the puck builder loses its p.ip override, the tooltip its ' · IP'
     · PEOPLE literals migrate: FCP I/CI → IP, RCP I → IW, Bane's A+ip → IP.
       ip:true stays on the reference records — harmless, because after the
       migration every read of it (`p.ip||isInstr(p.q)` in hasIP/anyIP and the
       boot seeding) is true exactly when the patched isInstr is true, and
       quals.instr is compared nowhere
     · the jet's QUAL message literal and the legend swatch take the port's
       wording, so IF they render they render identically (the sim back-seat
       literal used to be reworded here too — resim below removes its whole
       check instead, since 14 Aug 26)
   The port-only rules (NO_IR, the IW-in-FCP guard) fire nowhere on the seed,
   so WARN stays byte-equal without patching them in. Multi-hit swaps carry
   their expected count; a drifted count throws, same as retier. */
function remap(html: string): string {
  const swaps: Array<[string, string, number?]> = [
    ["{OCU:'O',D:'D',C:'C',B:'B',A:'A',I:'I',CI:'CI',IR:'IR'}",
     "{OCU:'O',D:'D',C:'C',B:'B',A:'A',IW:'IW',IP:'IP',IR:'IR',FI:'FI'}"],
    ["{OCU:'q-ocu',D:'q-d',C:'q-c',B:'q-b',A:'q-a',I:'q-ins',CI:'q-ins',IR:'q-ins'}",
     "{OCU:'q-ocu',D:'q-d',C:'q-c',B:'q-b',A:'q-a',IW:'q-ins',IP:'q-ins',IR:'q-ins',FI:'q-ins'}"],
    /* the `to` carries the port's DEEPENED white-text CAT fills (owner, 15 Aug
       26 badge-contrast fix) so the reference renders the same qmini colours;
       C and B are unchanged. The `from` stays the reference file's original. */
    ["{OCU:'#8A6ED0',D:'#3B7DF0',C:'#3BC6E8',B:'#E5A83B',A:'#F0555F',I:'#A64DE8',CI:'#A64DE8',IR:'#A64DE8'}",
     "{OCU:'#7F65BF',D:'#3673DD',C:'#3BC6E8',B:'#E5A83B',A:'#CA4750',IW:'#9F4ADF',IP:'#9F4ADF',IR:'#9F4ADF',FI:'#9F4ADF'}"],
    ["{OCU:'OCU (ab-initio)',D:'D · wingman',C:'C · ops wingman',B:'B · 2-ship FL',A:'A · 4-ship FL',I:'I · instructor',CI:'CI · C-cat instr',IR:'IR · instr rating exmr'}",
     "{OCU:'OCU (ab-initio)',D:'D · wingman',C:'C · ops wingman',B:'B · 2-ship FL',A:'A · 4-ship FL',IW:'IW · instructor WSO',IP:'IP · instructor pilot',IR:'IR · instrument rating exmr',FI:'FI · fighter wing instructor'}"],
    ["const isInstr=q=>q==='I'||q==='CI'||q==='IR';",
     "const isInstr=q=>q==='IW'||q==='IP'||q==='IR'||q==='FI';"],
    ["{OCU:0,D:1,C:2,B:3,A:4,I:5,CI:6,IR:7}",
     "{OCU:0,D:1,C:2,B:3,A:4,IW:5,IP:6,IR:7,FI:8}"],
    ["const chipTxt=p.ip?'I':QCHIP[p.q], chipCls=p.ip?'q-ins':QCLASS[p.q];",
     "const chipTxt=QCHIP[p.q], chipCls=QCLASS[p.q];"],
    ["LEVELNAME[p.q]+(p.ip?' · IP':'')+", "LEVELNAME[p.q]+"],
    [`<span><span class="qk" style="background:var(--q-ins)">I</span>IP / instr</span>`,
     `<span><span class="qk" style="background:var(--q-ins)">IW</span>IWSO</span>\n    <span><span class="qk" style="background:var(--q-ins)">IP</span>IP</span>\n    <span><span class="qk" style="background:var(--q-ins)">IR</span>IR exmr</span>\n    <span><span class="qk" style="background:var(--q-ins)">FI</span>FWI</span>`],
    ["seat:'FCP',q:'I',ip:true", "seat:'FCP',q:'IP',ip:true", 8],
    ["seat:'FCP',q:'CI',ip:true", "seat:'FCP',q:'IP',ip:true", 6],
    ["seat:'RCP',q:'I',ip:true", "seat:'RCP',q:'IW',ip:true", 7],
    ["q:'A',ip:true", "q:'IP',ip:true", 1],
  ]
  for (const [from, to, want] of swaps) {
    const n = html.split(from).length - 1
    if (n !== (want ?? 1)) throw new Error(`refwin remap: expected ${want ?? 1} match(es), got ${n} for: ${from.slice(0, 50)}…`)
    html = html.split(from).join(to)
  }
  return html
}

/* The sim's rear seat lost its instructor rule (owner, 14 Aug 26 — "oft
   doesn't need an instructor to be in the RCP, likewise for amt"). The port's
   check is deleted from validate(), so the reference's is excised from the
   in-memory copy too — the parity idiom, both sides — though it fires nowhere
   on the seed anyway (every seeded sim rear seat holds an IP or a WSO), so
   WARN was byte-equal either way. The jet's rear-seat rule went the same way
   on 7 Sep 26 — see rejet() below. */
function resim(html: string): string {
  const from = "if(w&&w.seat==='FCP'&&!(w.ip||isInstr(w.q))){markChip(di,s.w,'Q');markRing(di,s.w,'hard');add('hard','QUAL',[s.w],`${w.cs} is a pilot, not IP — only IP may take the back seat (${s.label})`);}"
  const n = html.split(from).length - 1
  if (n !== 1) throw new Error(`refwin resim: expected 1 match, got ${n}`)
  return html.split(from).join('')
}

/* The JET's rear-seat instructor rule went the way of the sim's (owner, 7 Sep
   26 — "don't flag out that they are in an illegal seat"): any pilot may ride
   any back seat now. The port's check is deleted from validate(), so the
   reference's is excised from the in-memory copy too — the parity idiom, both
   sides. It fires nowhere on the seed either way (no seeded jet rear seat holds
   a non-instructor pilot), so WARN stays byte-equal; the excision keeps a
   later seed fixture from reopening the seam silently. The message remap that
   used to reword this line was dropped from remap() the same day — the whole
   statement goes, so there is nothing left to reword. */
function rejet(html: string): string {
  const from = "if(w&&w.seat==='FCP'&&!(w.ip||isInstr(w.q))){markChip(di,ac.w,'Q');markRing(di,ac.w,'hard');add('hard','QUAL',[ac.w],`${w.cs} is a pilot, not IP — only IP may fly RCP (${f.label})`);}"
  const n = html.split(from).length - 1
  if (n !== 1) throw new Error(`refwin rejet: expected 1 match, got ${n}`)
  return html.split(from).join('')
}

/* Fourth structural divergence, closed the same way. The port grades every
   properly-seated non-instructor crew through the F-15 combination matrix
   (Table 1.5-2, owner Aug 5 '26); the reference only knows the old two-OCU
   hard rule, and the matrix DOES fire on the seed week (Mon bapster+nick is
   now the crew-solo advisory, Wed krait+wrangler and pike+badger want CO
   approval, Thu bapster+badger is an unauthorised combination). So the rule
   itself is patched into the in-memory reference at the exact call site the
   two-OCU line occupied — same insertion order, byte-identical messages —
   and WCODE gains the two new labels so dayHTML renders them identically.
   Runs AFTER remap: the injected code leans on the patched four-CAT isInstr;
   isInstrPilot has no reference equivalent, so it is inlined. */
function rematrix(html: string): string {
  const swaps: Array<[string, string]> = [
    ["TURN:'Tight turn',ILLEGAL_CREW:'Illegal aircrew combination',OCU_NO_IP:",
     "TURN:'Tight turn',ILLEGAL_CREW:'Illegal aircrew combination',CREW_SOLO:'Crew solo — only allowed under syllabus',CO_APPROVAL:'Crew combination — CO approval required',OCU_NO_IP:"],
    /* The crew-pairing chip (renamed from CC, owner ask 5 Aug 26). The
       reference's RANK has no CP/CPH, and markChip compares
       `RANK[c] > RANK[current]` — with an unranked code that is
       `undefined > n`, i.e. false — so the reference would keep whichever
       crew-pairing chip landed FIRST and drop every later one, while the port
       ranks them properly. The whole literal is replaced rather than appended
       to, so the two tables are identical and the comparison cannot drift.
       (The reference has no RUN either; it is carried in for the same reason
       — one table, not two that happen to agree on this week.) */
    ["const RANK={LD:0,DT:1,TT:2,A:3,SD:4,SB:5,DB:6,NB:7,CR:8,C:9,Q:10}",
     "const RANK={LD:0,DT:1,TT:2,A:3,SD:4,SB:5,DB:6,NB:7,CP:8,CR:9,RUN:10,CPH:11,C:12,Q:13}"],
    /* The chip also has to RENDER identically, and the reference's puck builder
       falls back to the raw code for both the glyph and the tooltip
       (`CHIP_TEXT[flag]||flag`, `CHIP_LABEL[flag]||flag`). Left unpatched, CPH
       would print the literal "CPH" against the port's "CP", and every CP puck
       would carry the code as its title instead of the label — so the dayHTML
       byte-comparison in html.test.ts fails on the markup, not on the rule. */
    ["const CHIP_TEXT={DT:'DT',TT:'TT',C:'C',A:'A',Q:'Q',CR:'R',NB:'B',SB:'B',DB:'D',SD:'D',LD:'L'}",
     "const CHIP_TEXT={DT:'DT',TT:'TT',C:'C',A:'A',Q:'Q',CR:'R',NB:'B',SB:'B',DB:'D',SD:'D',LD:'L',CP:'CP',CPH:'CP'}"],
    ["SD:'No time for the sim debrief',LD:'Long work day (>{longDay})'};",
     "SD:'No time for the sim debrief',LD:'Long work day (>{longDay})',"
     + "CP:'Crew pairing — this pairing needs approval',CPH:'Crew pairing — not an authorised pairing'};"],
    /* The A label grew a SANS tail when SANS_AVAIL moved off CP onto A (owner,
       26 Aug 26). The reference has no SANS gate, so its A chip never fires for
       SANS and no compared day renders the label this week — the swap exists so
       the two CHIP_LABEL tables stay byte-identical, per the rule the RANK
       comment above states: one table, not two that happen to agree. */
    ["A:'Advisory — on shift and also down for a ground event or programme item',",
     "A:'Advisory — on shift and also down for a ground event or programme item, or planned outside SANS availability',"],
    ["if(p&&w&&isOcu(p.q)&&isOcu(w.q)){markRing(di,ac.p,'hard');markRing(di,ac.w,'hard');add('hard','ILLEGAL_CREW',[ac.p,ac.w],`Two OCU in one aircraft (${f.label})`);}",
     "if(p&&w&&p.seat==='FCP'&&w.seat==='RCP'&&!(p.q==='IP'||p.q==='IR'||p.q==='FI')&&!isInstr(w.q)){"
     + "if(isOcu(p.q)&&isOcu(w.q)){markRing(di,ac.p,'adv');markRing(di,ac.w,'adv');markChip(di,ac.p,'CP');markChip(di,ac.w,'CP');add('adv','CREW_SOLO',[ac.p,ac.w],`${p.cs} (OCU pilot) with ${w.cs} (OCU WSO) in ${f.label} — a crew solo, only allowed under the Basic Course Syllabus`);}"
     + "else if(isOcu(p.q)||isOcu(w.q)){markRing(di,ac.p,'hard');markRing(di,ac.w,'hard');markChip(di,ac.p,'CPH');markChip(di,ac.w,'CPH');add('hard','ILLEGAL_CREW',[ac.p,ac.w],isOcu(p.q)?`OCU pilot ${p.cs} with CAT ${w.q} WSO ${w.cs} — not an authorised combination (${f.label})`:`OCU WSO ${w.cs} with CAT ${p.q} pilot ${p.cs} — not an authorised combination (${f.label})`);}"
     + "else if((p.q==='D'&&(w.q==='C'||w.q==='D'))||(p.q==='C'&&w.q==='D')){markRing(di,ac.p,'adv');markRing(di,ac.w,'adv');markChip(di,ac.p,'CP');markChip(di,ac.w,'CP');add('adv','CO_APPROVAL',[ac.p,ac.w],`CAT ${p.q} pilot ${p.cs} with CAT ${w.q} WSO ${w.cs} in ${f.label} — CO approval required`);}"
     + "}"],
    /* OCU_NO_IP exists in BOTH engines, so unlike NO_IR it cannot be left to
       diverge on the strength of "it does not fire on this week" — that is luck,
       not parity. Same code, same chip, both sides. */
    ["if(ocuAll.length&&!anyIP){ocuAll.forEach(id=>markRing(di,id,'adv'));",
     "if(ocuAll.length&&!anyIP){ocuAll.forEach(id=>{markRing(di,id,'adv');markChip(di,id,'CP');});"],
    /* The ALL AVAIL sentinel fix (owner scenario run, 5 Aug 26): crewAll used to
       be `.filter(Boolean)`, so the sentinel flowed into ocuAll/anyIP here and
       into NO_IR (port-only, never patched into the reference). OCU_NO_IP DOES
       fire on the seed and IS patched above, so the reference's copy of this
       line needs the identical fix or a sentinel could pick up a ring/chip on
       one side and not the other — the same crewAll line lives at
       reference/scheduler.html:3140, read-only, patched here in memory only. */
    ["const crewAll=[...new Set(f.acs.reduce((a,x)=>a.concat([x.p,x.w]),[]).filter(Boolean))];",
     "const crewAll=[...new Set(f.acs.reduce((a,x)=>a.concat([x.p,x.w]),[]).filter(id=>id&&PEOPLE[id]&&!isSpecial(id)))];"],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin rematrix: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}

/* The remark-driven OFT brief lead (owner, 5 Aug 26): a row whose rmks name a
   brief time ("BRIEF 30 PRIOR", "30 mins prior") briefs THAT long, epBrief
   only when it says nothing. The seed EP-4s carry "BRIEF 30 PRIOR" on both
   builds, so parity needs the identical parse in the reference's simwin push —
   same regexes, same 0–240 bound as the port's briefLeadOf. Note the swap
   strings are TS string literals: the \\b below reaches the page as \b. */
/* The squadron's real absence vocabulary (owner, 10 Aug 26). The port removed
   the plain `Downchit` and `Detachment` types: OML / ATT B / ATT C carry the
   medical meaning now and OD the overseas one, and the seed was retyped to
   match. The reference has never heard those words, so its isDownchit returns
   false for divot and sufa and it grades them INPUT_FLY where the port grades
   them DNIF_FLY — a divergence in the DATA, not in any rule.
   Teaching the reference the four medical codes closes it at the source, the
   same way syncInputs closes the INPUTS divergence. It is a pure RENAME: all
   four behave in the reference exactly as `Downchit` did, because on the
   reference side nothing distinguishes them — the port's own new axis (ATT B
   may still work) lives in code the reference does not have, and the seed
   deliberately puts ATT B on nobody, so it can never be exercised here.
   `OD` needs no patch: the reference graded `Detachment` as an ordinary input
   and grades `OD` identically, both falling through to INPUT_FLY. */
function redn(html: string): string {
  const from = "function isDownchit(t){return /DNIF|Downchit/i.test(String(t==null?'':t));}"
  const to = "function isDownchit(t){return /DNIF|Downchit|^\\s*(HL|OML|ATT\\s*[BC])\\s*$/i.test(String(t==null?'':t));}"
  const n = html.split(from).length - 1
  if (n !== 1) throw new Error(`refwin redn: expected exactly 1 match, got ${n}`)
  return html.replace(from, to)
}

/* THE GATE REVERSAL (owner, 10 Aug 26 — "all will automatically go in").
   Every input now reaches the validator the moment it is typed, where a
   personal one used to be a request that blocked nothing until a scheduler
   actioned it. That change did not create a divergence; it EXPOSED two that
   were already there, and that the old inputFlags filter had been hiding by
   keeping personal inputs out of both engines.

   The note at the foot of this file called the first one and said the parity
   tests would go red here, correctly, the day a personal input reached both
   engines. That day is today, so both are patched rather than excised — the
   comparison stays whole.

     1. THE OFFER EXEMPTION. The reference still treats `Fly` as an OFFER that
        clashes with nothing. The port dropped the offer concept (owner,
        Aug 26): a man flying with another squadron is not available for this
        sortie, so Fly costs exactly what a Meeting costs. The old note said
        this could not be patched because `isOffer` is a const — but the
        FLY loop tests an inline regex, which is an ordinary string swap.
     2. THE WIDENED TASKING LOOP (owner, 4 Aug 26). The reference's non-flying
        loop covers leave and downchits only, so a personal input warned
        against a sortie but let a sim seat, a duty post or a ground row
        through silently. The port widened it to every input, with the SC
        shift carve-out for ordinary personal types.

   The port's ATT B exemption is folded in too, so the reference agrees about
   the one type that may still work. It cannot actually fire — the seed puts
   ATT B on nobody, deliberately — but leaving it out would mean the two
   engines disagreed the moment a test seeded one. */
function reinput(html: string): string {
  const swaps: Array<[string, string]> = [
    /* 1 — Fly is a commitment, not an offer */
    ["if(/^Available|^Fly$/i.test(inp.type))return;",
     "if(/^Available/i.test(inp.type))return;"],
    /* 2 — every input clashes with every kind of tasking, except that ATT B
       may still work — EXCEPT an SC MAIN shift, which may launch him (owner,
       26 Aug 26) — and an ordinary personal type is graded BY TYPE against a
       shift. The amber branch is the port's "known soft type" gate
       (!shiftHardInput && inpMeta), which reduces to exactly MEETING — every
       other known type is unavailable or red-list — so the reference, which
       has no INPUT_META to consult, states that literal directly. Anything
       else, an UNRECOGNISED type included, falls closed to the hard branch in
       both engines (owner, 26 Aug 26 — the old !rh mirror sent unknowns
       amber, the softness this seam close removed). The SHIFT_SOFT wording is
       byte-for-byte the port's; its `${inp.type}` matches the port's
       inpLabel(inp) because they differ only for 'Other', which never reaches
       the amber branch. The reference's `un` still misses SANS, but with the
       Meeting-only amber gate SANS now lands on the hard branch in both
       engines anyway (seedDemoSans is boot-only, so no parity fixture reaches
       it either way). */
    ["const dn=isDownchit(inp.type), lv=isLeave(inp.type);\n        if(!dn&&!lv)return;",
     "if(/^\\s*ATT\\s*B\\s*$/i.test(String(inp.type||''))&&e.kind!=='shift')return;"
     + "const dn=isDownchit(inp.type), lv=isLeave(inp.type);"
     + "const un=dn||lv||/^\\s*OD\\s*$/i.test(String(inp.type||''));"
     + "const soft=/^\\s*MEETING\\s*$/i.test(String(inp.type||''));"
     + "if(!un&&e.kind==='shift'&&soft){"
     + "if(!overlap(e.s,e.e,inp.s,inp.e))return;"
     + "markChip(di,e.id,'A'); markRing(di,e.id,'adv');"
     + "add('adv','SHIFT_SOFT',[e.id],`${PEOPLE[e.id]?PEOPLE[e.id].cs:e.id} is on ${e.label} (${hm24(e.s)}–${hm24(e.e)}) and also down for ${inp.type}`);"
     + "return;}"],
    ["add('hard',dn?'DNIF_FLY':'LEAVE_FLY',[e.id],\n          (dn?'Downchit but tasked':'On leave but tasked')",
     "add('hard',dn?'DNIF_FLY':lv?'LEAVE_FLY':'INPUT_FLY',[e.id],"
     + "(dn?'Downchit but tasked':lv?'On leave but tasked':`${inp.type} but tasked`)"],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin reinput: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}

/* THE GROUND-ROW SEVERITY OVERLAY (owner, 26 Aug 26). The port upgrades a
   ground row that IS a red-list commitment from SHIFT_SOFT to the hard clash
   (validate.ts shiftEvHard), in the clash loop and the crew picker's `live`
   alike. The reference has no row.src to consult, so it gets the KEYWORD half
   only — which is all a parity fixture can exercise anyway, because the src
   path needs an ACCEPTED input and the accept machinery diverged long ago.
   Documented parity boundary: an accepted 'Other' vs SC MAIN would diverge
   (port reads the source type off row.src; the reference reads the remarks
   label) — no parity fixture may build one. */
function reshift(html: string): string {
  const RH = "/\\b(TRAINING|CSE|FLY\\s+WITH|PERSONAL|APPOINTMENT|DUTY|OTHER)\\b/i"
  const swaps: Array<[string, string]> = [
    /* the sortie-clash loop no longer speaks over a shift line — the graded
       events loop is a shift's one voice (see validate.ts, same guard) */
    ["day.fly.forEach(e=>day.input.forEach(inp=>{ if(inp.id!==e.id)return;",
     "day.fly.forEach(e=>day.input.forEach(inp=>{ if(inp.id!==e.id)return;if(e.shift)return;"],
    ["if(SHIFT_HARD[other.kind]){",
     `if(SHIFT_HARD[other.kind]||(other.kind==='ground'&&${RH}.test(String(other.label||'')))){`],
    ["const live=e=>SHIFT_HARD[e.kind]&&e.s!=null&&e.e!=null&&e.slot!==self;",
     `const live=e=>(SHIFT_HARD[e.kind]||(e.kind==='ground'&&${RH}.test(String(e.label||''))))&&e.s!=null&&e.e!=null&&e.slot!==self;`],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin reshift: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}

function relead(html: string): string {
  const from = "simwin.push({ids,label:'OFT '+(s.label||'sim'),bs:st-VCONF.epBrief,be:st,ds:en,de:en+VCONF.simDebrief}); });"
  const to = "const _r=String(s.rmks||''),_m=_r.match(/\\bbrief\\s*[-:]?\\s*(\\d{1,3})\\b/i)||_r.match(/\\b(\\d{1,3})\\s*(?:min(?:ute)?s?\\s*)?prior\\b/i);"
    + "const _bl=_m&&+_m[1]>0&&+_m[1]<=240?+_m[1]:null;"
    + "simwin.push({ids,label:'OFT '+(s.label||'sim'),bs:st-(_bl!=null?_bl:VCONF.epBrief),be:st,ds:en,de:en+VCONF.simDebrief}); });"
  const n = html.split(from).length - 1
  if (n !== 1) throw new Error(`refwin relead: expected exactly 1 match, got ${n}`)
  return html.replace(from, to)
}

/* The INDICATED brief time (owner, 6 Aug 26). The port lets a scheduler type a
   B per formation and every brief-driven rule follows it, falling back to
   VCONF.briefLead when the line has none; the reference only ever computes the
   fallback. The seed week types no B, so both engines agree today — but "they
   agree on this week" is luck, not parity, exactly as the OCU_NO_IP note in
   rematrix says, and the first test to set f.br would silently compare a typed
   port against an untyped reference. Two swaps, mirroring events.ts and
   validate.ts: the brief itself, and the crew-rest anchor (which must read the
   leg's own brief rather than recompute it, plus the late-show exemption off
   the aircraft remarks). */
/* WORDING-ONLY divergences, kept apart from the behavioural patches above
   because they change no rule at all — they exist purely so ui/html.test.ts's
   byte comparison keeps comparing STRUCTURE rather than failing on a word the
   owner renamed. A rename that reaches dayHTML has to land here in the same
   PR, or the parity gate goes red for a reason that has nothing to do with
   behaviour; HANDOFF.md records the same trap for CHIP_LABEL.
   MAIN/SPARE needed no entry, and that is worth writing down so the next
   reader does not go looking: the seed week has no standalone wave, so the
   `sa` branch that carried the .rolet chip never renders on a compared day
   in EITHER build. */
function relabel(html: string): string {
  const swaps: Array<[string, string]> = [
    /* the day's all-hands heading (owner, 10 Aug 26) */
    ['<div class="ah-h">Programme</div>', '<div class="ah-h">Common Programme</div>'],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin relabel: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}
function rebrief(html: string): string {
  const swaps: Array<[string, string]> = [
    /* the dashed-ring store the CREW_REST patch below writes into, and its
       publication on WARN — the reference has neither */
    ["const ev=collectEvents(), all=[], byDay=[], sev={}, chip={};",
     "const ev=collectEvents(), all=[], byDay=[], sev={}, chip={}, dash={};"],
    ["WARN={all,byDay,sev,chip};", "WARN={all,byDay,sev,chip,dash};"],
    ["const briefM=shiftLine?null:toM-VCONF.briefLead;",
     "const _bt=shiftLine?null:parseHM(f.br);const briefM=shiftLine?null:(_bt!=null?_bt:toM-VCONF.briefLead);"],
    ["const insOf=e=>e.shift?e.to:Math.min(e.intime!=null?e.intime:Infinity,e.to-VCONF.briefLead);",
     "const _bo=e=>e.brief!=null?e.brief:e.to-VCONF.briefLead;"
     + "const insOf=e=>e.shift?e.to:Math.min(e.intime!=null?e.intime:Infinity,_bo(e));"],
    /* The crew-rest tail spells out the debrief assumption (owner, 15 Aug 26):
       track the winning rest-end's raw landing (null for a shift) and, when a
       sortie set it, print "landed HH:MM, +Nh debrief assumed → ended HH:MM".
       Parity compares the message, so the reference tracks and prints the same. */
    ["const prevEnd={}, prevFlyEnd={};", "const prevEnd={}, prevFlyEnd={}, prevFlyLd={};"],
    ["if(rests&&(prevFlyEnd[e.id]==null||end>prevFlyEnd[e.id]))prevFlyEnd[e.id]=end;",
     "if(rests&&(prevFlyEnd[e.id]==null||end>prevFlyEnd[e.id])){prevFlyEnd[e.id]=end;prevFlyLd[e.id]=e.kind==='fly'?e.ld:null;}"],
    ["const tail=`${ev[idx-1].dow} ended ${hm24(pe)} → crew rest clear at ${hm24(earliest)}`;",
     "const landed=prevFlyEnd[id]!=null?prevFlyLd[id]:null;"
     + "const tail=landed!=null"
     + "?`${ev[idx-1].dow} landed ${hm24(landed)}, +${lgT(VCONF.debrief)} debrief assumed → ended ${hm24(pe)} → crew rest clear at ${hm24(earliest)}`"
     + ":`${ev[idx-1].dow} ended ${hm24(pe)} → crew rest clear at ${hm24(earliest)}`;"],
    /* The crew-rest breach itself (owner, 6 Aug 26; reworded cause-first
       22 Aug 26 — tail leads, "but <commitment> — only Xh rest.", and the
       leave-by is DATA only now, never message text): the port carries
       prevDi/leaveBy/dashed on the warning, so the previous day can be
       traced from a click. The reference
       says none of that, and parity compares the message text — so mirror the
       whole add, dashed ring included. `add` there takes no extras argument,
       so they are attached to the pushed warning by patching the message
       first and the object after; keep both sides' field ORDER identical or
       the deep-equal compares unequal objects that print the same. */
    ["          markChip(di,id,'CR');markRing(di,id,'hard');\n"
     + "          add('hard','CREW_REST',[id],\n"
     + "            (onShift?`Crew rest breach — ${legs.filter(e=>e.shift).map(e=>e.label)[0]} starts ${hm24(instructed)}, only ${dur(instructed+1440-pe)} rest. `\n"
     + "                   :`Crew rest breach — told to report ${hm24(instructed)}, only ${dur(instructed+1440-pe)} rest. `)+tail);",
     "          const _bl=legs.reduce((m,e)=>insOf(e)<insOf(m)?e:m);"
     + "const _lv=hm24(instructed+1440-VCONF.crewRest);"
     + "const _mk=!_bl.shift&&earliest<=_bl.to-VCONF.step;"
     + "const _da=!!_bl.lateShow&&_mk;"
     + "markChip(di,id,'CR');markRing(di,id,'hard');if(_da){dash[di]=dash[di]||{};dash[di][id]=true;}\n"
     + "          add('hard','CREW_REST',[id],\n"
     + "            `Crew rest breach — ${tail}, but `+(onShift?`${legs.filter(e=>e.shift).map(e=>e.label)[0]} starts ${hm24(instructed)} — only ${dur(instructed+1440-pe)} rest.`\n"
     + "                   :`told to report ${hm24(instructed)} — only ${dur(instructed+1440-pe)} rest.`)"
     + "+(_da?` Late show — he still makes the ${hm24(_bl.to-VCONF.step)} step.`"
     + ":(_bl.lateShow?` Late show cannot save it — the ${hm24(_bl.to-VCONF.step)} step is still before rest clears.`:''))"
     + ");"
     + "{const _w=ws[ws.length-1];_w.prevDi=idx-1>=0?ev[idx-1].di:null;_w.leaveBy=_lv;_w.dashed=_da;}"],
    /* the reference's fly.push has no lateShow, so _bo's exemption could never
       fire there — carry the same remark parse onto its legs */
    ["fly.push({id,seat,brief:briefM,to:toM,ld:ldM,step:stepM,dekit:dekitM,report,intime,",
     "fly.push({id,seat,brief:briefM,to:toM,ld:ldM,step:stepM,dekit:dekitM,report,intime,"
     + "lateShow:!shiftLine&&/\\b(?:late\\s*show|show\\s*(?:at|@)\\s*brief|brief\\s*show)\\b/i.test(String(a.rmks||'')),"],
    /* The long-work-day note names the debrief pad on its end (owner, 15 Aug
       26): a sortie closes the day at land + the assumed 2h debrief. Parity
       compares the message, so the reference tracks the bounding fly event
       (ef) and prints the identical string. */
    ["if(oe!=null&&(e==null||oe>e))e=oe;", "if(oe!=null&&(e==null||oe>e)){e=oe;ef=o.kind==='fly'?o:null;}"],
    ["let s=null,e=null;", "let s=null,e=null,ef=null;"],
    ["add('note','LONGDAY',[id],`${PEOPLE[id]?PEOPLE[id].cs:id} has a long work day: ${dur(span)} (${hm24(s)} → ${hm24(e)})`);}",
     "const back=ef?`${hm24(e)} (last landing ${hm24(ef.ld)} + ${lgT(VCONF.debrief)} debrief assumed)`:`${hm24(e)}`;"
     + "add('note','LONGDAY',[id],`${PEOPLE[id]?PEOPLE[id].cs:id} has a long work day: ${dur(span)}, ${hm24(s)} → ${back}`);}"],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin rebrief: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}

/* EVERYTHING THAT ENDS THE DAY BEARS CREW REST (owner, 21 Aug 26 — first
   duties joined the sortie-or-shift set that morning, then "anything that
   ends the day prior and affects the 12 hour crew rest will be a warning"
   widened it to every event kind: sims, ground events and programme items
   included). The port's validate.ts sets rests=true; the reference computes
   rest from the identical line, so the same substitution moves both engines
   together — REST[] maps, the hard branch and the messages all follow from
   it. Rule: docs/engine-rules.md §Validation, "Crew rest". */
/* THE DAY STARTS AT ITS FIRST COMMITMENT (owner, 21 Aug 26 — "if they have
   anything earlier like a meeting that busts crew rest and they fly later,
   it's also a violation… this person needs 12 hours of rest in order to
   fly"). The port anchors the crew-rest breach on the EARLIEST of the
   instructed flying report and any other scheduled commitment that day
   (sim, duty, ground, programme — not the flying legs' own derived pads;
   duty & commitment INPUTS joined the set later the same day, see
   reirest()). Parity compares the message text and the dashed
   ring, so the reference gets the identical anchor, message branch and
   late-show guard. These swaps target the text rebrief() has already
   emitted, so refirst must sit OUTSIDE rebrief in the chain. */
function refirst(html: string): string {
  const swaps: Array<[string, string]> = [
    ['const instructed=Math.min.apply(null,legs.map(insOf));',
     'const instructed=Math.min.apply(null,legs.map(insOf));'
     + "const fe=day.events.reduce((m,e)=>e.id===id&&e.kind!=='fly'&&e.kind!=='shift'&&e.s!=null&&isFinite(e.s)&&(m==null||e.s<m.s)?e:m,null);"
     + 'const first=Math.min(instructed,fe!=null?fe.s:Infinity);'
     + 'const evBound=first<instructed;'],
    ['if(pfly[id]&&instructed<earliest){', 'if(pfly[id]&&first<earliest){'],
    ['const _lv=hm24(instructed+1440-VCONF.crewRest);', 'const _lv=hm24(first+1440-VCONF.crewRest);'],
    ['const _da=!!_bl.lateShow&&_mk;', 'const _da=!evBound&&!!_bl.lateShow&&_mk;'],
    ["add('hard','CREW_REST',[id],\n            `Crew rest breach — ${tail}, but `+(onShift?",
     "add('hard','CREW_REST',[id],\n            `Crew rest breach — ${tail}, but `+(evBound?`his day starts ${hm24(first)} (${fe.label}) before the ${hm24(instructed)} report — only ${dur(first+1440-pe)} rest.`:onShift?"],
    [':(_bl.lateShow?', ':(!evBound&&_bl.lateShow?'],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin refirst: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}

/* DUTY & COMMITMENT INPUTS BEAR CREW REST (owner, 21 Aug 26 — "everything in
   duty and commitments affects crew rest… do not include personal, sans
   availability"; both sides, typed times only). The port's set is
   inputs.ts:restsInput and its label inputs.ts:inpLabel; the reference has
   neither (its type classes are still regex-era), so the patch injects
   self-contained equivalents: _rt is the type set, _il the Other-reads-by-
   its-remarks label. Change the rule in restsInput and this regex changes
   with it — both carry a pointer to the other. Swap A appends the prior-day
   input loop after the text rebrief() emitted (the braced prevFlyLd line);
   swap B retargets the fe reduce refirst() emitted — so reirest sits
   OUTSIDE refirst in the chain. The reference's day.input has no nx/pv
   midnight tails, but the injected code keeps the port's guards verbatim:
   undefined flags read false and the emitted strings stay identical. */
function reirest(html: string): string {
  const swaps: Array<[string, string]> = [
    ["prevFlyLd[e.id]=e.kind==='fly'?e.ld:null;}\n      });",
     "prevFlyLd[e.id]=e.kind==='fly'?e.ld:null;}\n      });"
     + "const _rt=/^(training|cse|meeting|fly with|appointment|duty|od|other)$/i;"
     + "const _il=i=>(/^other$/i.test(String(i.type||'').trim())&&String(i.remarks||'').trim())?String(i.remarks).trim():String(i.type||'');"
     + "ev[idx-1].input.forEach(i=>{"
     + "if(i.nx||i.pv||!_rt.test(String(i.type||'').trim()))return;"
     + "if(i.s==null||i.e==null||!isFinite(i.e)||i.e-i.s>=1439)return;"
     + "if(prevEnd[i.id]==null||i.e>prevEnd[i.id])prevEnd[i.id]=i.e;"
     + "if(prevFlyEnd[i.id]==null||i.e>prevFlyEnd[i.id]){prevFlyEnd[i.id]=i.e;prevFlyLd[i.id]=null;}"
     + "});"],
    ["const fe=day.events.reduce((m,e)=>e.id===id&&e.kind!=='fly'&&e.kind!=='shift'&&e.s!=null&&isFinite(e.s)&&(m==null||e.s<m.s)?e:m,null);",
     "const fe0=day.events.reduce((m,e)=>e.id===id&&e.kind!=='fly'&&e.kind!=='shift'&&e.s!=null&&isFinite(e.s)&&(m==null||e.s<m.s)?e:m,null);"
     + "const fi=day.input.reduce((m,i)=>i.id===id&&!i.nx&&!i.pv&&_rt.test(String(i.type||'').trim())&&i.s!=null&&isFinite(i.s)&&i.e!=null&&i.e-i.s<1439&&(m==null||i.s<m.s)?i:m,null);"
     + "const fe=fi!=null&&(fe0==null||fi.s<fe0.s)?{s:fi.s,label:_il(fi)}:fe0;"],
  ]
  for (const [from, to] of swaps) {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin reirest: expected exactly 1 match, got ${n} for: ${from.slice(0, 50)}…`)
    html = html.replace(from, to)
  }
  return html
}

/* NIGHT AAR IS THE WAVE'S CALL, NOT THE CLOCK'S (owner, 21 Aug 26 — "make
   the rule for NAAR instead of a time: if the wave is night and AAR is
   mentioned, it's night AAR. Or NAAR is mentioned"). The reference decides
   a bare AAR's day/night with `!!w.night||ldM>19*60` in the validator and
   the same clause again in the crew picker; the port dropped the clock in
   both places, so both reference sites are excised to the wave flag alone.
   aarNeed itself is untouched — an explicit NAAR/DAAR still overrides. */
function reaar(html: string): string {
  const subs: Array<[string, string]> = [
    ['aar:aarNeed(a.rmks,!!w.night||ldM>19*60)', 'aar:aarNeed(a.rmks,!!w.night)'],
    ['out.aar=aarNeed(ac.rmks,!!wv.night||(ld!=null&&ld>19*60));', 'out.aar=aarNeed(ac.rmks,!!wv.night);'],
  ]
  subs.forEach(([from, to]) => {
    const n = html.split(from).length - 1
    if (n !== 1) throw new Error(`refwin reaar: expected exactly 1 match, got ${n} for: ${from.slice(0, 40)}…`)
    html = html.replace(from, to)
  })
  return html
}

function rerest(html: string): string {
  const from = "const rests=(e.kind==='fly'||e.kind==='shift');"
  const to = 'const rests=true;'
  const n = html.split(from).length - 1
  if (n !== 1) throw new Error(`refwin rerest: expected exactly 1 match, got ${n}`)
  return html.replace(from, to)
}

/* The tight-turn chip loses its ring (owner, 7 Aug 26). Both builds chip DT
   and the same-day TT bare, and both ring the crew-rest TT amber — so the same
   glyph meant "ringed problem" in one place and "unringed note" in another.
   The port drops that one ring; the reference has to drop it too or every
   byte-comparison of a seed day's markup fails on the ring class rather than
   on the rule. Chip and warning are untouched on both sides — this removes a
   mark, nothing else. */
function rering(html: string): string {
  const from = "markChip(di,id,'TT');markRing(di,id,'adv');"
  const n = html.split(from).length - 1
  if (n !== 1) throw new Error(`refwin rering: expected exactly 1 match, got ${n}`)
  return html.replace(from, "markChip(di,id,'TT');")
}

/* CLOSED, 10 Aug 26. This used to read "one divergence the sync CANNOT close":
   the reference treats "Fly" as an offer that clashes with nothing, and the
   note reasoned that `isOffer` being a `const` put it out of reach. That was
   half right — the const is out of reach, but the FLY loop tests its own
   inline regex, and swapping that string is enough. The prediction the note
   made came true exactly as written the day every input started reaching the
   validator, and the fix is `reinput` above rather than a re-thought seed. */
